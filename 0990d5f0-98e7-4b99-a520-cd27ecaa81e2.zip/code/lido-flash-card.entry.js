import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { q as executeActions, z as parseProp, A as AudioPlayer, x as setVisibilityWithDelay, y as initEventsForElement } from './utils-Zx3fBgtB.js';

const lidoFlashCardCss = () => `.card{position:relative;width:100%;height:100%;transform-style:preserve-3d;transition:transform 0.6s ease;cursor:pointer}.card.flipped{transform:rotateY(180deg)}.card-face{position:absolute;width:100%;height:100%;backface-visibility:hidden;display:flex;align-items:center;justify-content:center}.card-back{transform:rotateY(180deg)}lido-container[template-id="flashcardtemplate"] #arrow{position:absolute !important;left:auto !important;top:50% !important;right:13.3% !important;transform:translateY(-50%);z-index:4 !important;overflow:visible;box-sizing:border-box;border:10px solid transparent;box-shadow:0px 8px 0px 0px #8b310f !important}lido-container[template-id="flashcardtemplate"] #arrow.flash-card-next-glowing{animation:flash-card-next-attention 1.4s ease-in-out infinite}@keyframes flash-card-next-attention{0%,100%{border-color:#ffc34d;filter:drop-shadow(0 0 0 rgba(255, 195, 77, 0))}50%{border-color:#fff1a8;filter:drop-shadow(0 0 10px rgba(255, 195, 77, 0.95))}}lido-container[template-id="flashcardtemplate"] #arrow:active{transform:translateY(calc(-50% + 8px)) !important;box-shadow:0px 0px 0px 0px !important}@media (orientation: portrait){lido-container[template-id="flashcardtemplate"] #arrow{right:-4.3% !important}}`;

const LidoFlash = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /* ---------- Generic Lido props (mirrors lido‑row) ---------- */
        /**
         * The value associated with the column component. Typically used for internal logic.
         */
        this.value = '';
        /**
         * The height of the column component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the column component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the column within its container (CSS value, e.g., '10px', '5%').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the column within its container (CSS value, e.g., '10px', '5%').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the column relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the column (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * Defines the type of the column, which can be used for styling or specific logic handling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * A boolean that controls whether the column is visible (`true`) or hidden (`false`).
         */
        this.visible = true;
        /**
         * Audio file URL or identifier for sound that will be associated with the column.
         */
        this.audio = '';
        /**
         * Event handler for a touch event, where a custom function can be triggered when the column is touched.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the column is entered, useful for triggering animations or logic.
         */
        this.onEntry = '';
        /**
         * Whether the card is flipped (back side visible).
         * `mutable` lets the component toggle itself on click;
         * `reflect` keeps the `<lido-flash-card flipped>` attribute in sync.
         */
        this.flipped = false;
        this.autoFlipAfter = 4500;
        this.narrationTarget = null;
        this.narrationHandled = false;
        this.instructionDone = false;
        this.instructionStarted = false;
        this.onAudioStarted = (event) => {
            var _a;
            const target = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.target;
            if (target === this.instructionText())
                this.instructionStarted = true;
            if (target && target === this.narrationTarget && !this.narrationHandled) {
                if (this.narrationGraceTimer)
                    window.clearTimeout(this.narrationGraceTimer);
                this.narrationGraceTimer = undefined;
            }
        };
        this.onAudioPlaying = (event) => {
            const detail = event.detail;
            const target = detail === null || detail === void 0 ? void 0 : detail.target;
            if ((target === null || target === void 0 ? void 0 : target.id) !== 'lido-avatar')
                return;
            if (detail.playbackContext !== this.goodJobPlaybackContext)
                return;
            const arrow = this.nextArrow();
            if (!arrow || !this.flipped)
                return;
            this.goodJobPlaybackId = detail.playbackId;
            arrow.classList.add('flash-card-next-glowing');
        };
        this.onAudioEnded = (event) => {
            var _a, _b, _c, _d;
            const target = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.target;
            const instruction = this.instructionText();
            if (!target || (target !== instruction && target.id !== 'lido-avatar' && !this.el.contains(target)))
                return;
            if (target === this.narrationTarget && !this.narrationHandled) {
                this.finishNarration(target);
                return;
            }
            if (this.narrationHandled && target === this.narrationTarget)
                return;
            if (target === this.instructionText()) {
                this.instructionDone = true;
                this.frontStartTimer = window.setTimeout(() => {
                    this.speakFront();
                }, 1200);
            }
            else if (target === this.frontText()) {
                if (this.flipped)
                    return;
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
            else if (target === this.backText()) {
                if (this.flipped)
                    this.showArrow();
            }
            else if (target.id === 'lido-avatar') {
                const playbackId = (_b = event.detail) === null || _b === void 0 ? void 0 : _b.playbackId;
                const playbackContext = (_c = event.detail) === null || _c === void 0 ? void 0 : _c.playbackContext;
                if (playbackContext !== this.goodJobPlaybackContext || playbackId !== this.goodJobPlaybackId)
                    return;
                this.goodJobPlaybackId = undefined;
                (_d = this.nextArrow()) === null || _d === void 0 ? void 0 : _d.classList.remove('flash-card-next-glowing');
                executeActions("this.avatarAnimate='Idle'", target);
            }
        };
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.style = {};
        /**
        * Delay in milliseconds to make the cell visible after mount.
        */
        this.delayVisible = '';
        /* ---------- Internal helpers ---------- */
        /** Compute responsive inline styles. */
        this.updateStyles = () => {
            const o = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
            this.style = {
                height: parseProp(this.height, o) || '200px',
                width: parseProp(this.width, o) || '200px',
                backgroundColor: parseProp(this.bgColor, o),
                top: parseProp(this.y, o),
                left: parseProp(this.x, o),
                zIndex: this.z,
                display: this.visible ? (this.display ? parseProp(this.display, o) : 'inline-block') : 'none',
                flexDirection: this.direction ? parseProp(this.direction, o) : undefined,
                margin: parseProp(this.margin, o),
            };
        };
        /** Toggle the card when it is clicked. */
        this.handleFlip = () => {
            var _a;
            if (this.autoFlipTimer)
                window.clearTimeout(this.autoFlipTimer);
            AudioPlayer.getI().stop();
            this.clearNarrationTimers();
            const goingBack = !this.flipped;
            this.flipped = !this.flipped;
            this.stopGoodJobGlow();
            this.setArrowVisible(false);
            if (goingBack) {
                const text = this.backText();
                if (text && ((_a = text.textContent) === null || _a === void 0 ? void 0 : _a.trim()))
                    this.startNarration(text);
                else
                    this.showArrow();
            }
            else {
                this.speakFront();
            }
        };
        this.instructionText = () => {
            const container = this.el.closest('lido-container');
            const id = container === null || container === void 0 ? void 0 : container.getAttribute('template-id');
            return id ? container === null || container === void 0 ? void 0 : container.querySelector(`[id="${id}"]`) : null;
        };
        this.frontText = () => this.el.querySelector('.card-front lido-text');
        this.backText = () => this.el.querySelector('.card-back lido-text');
        this.nextArrow = () => { var _a; return (_a = this.el.closest('lido-container')) === null || _a === void 0 ? void 0 : _a.querySelector('#arrow'); };
        this.stopGoodJobGlow = () => {
            var _a;
            this.goodJobPlaybackId = undefined;
            this.goodJobPlaybackContext = undefined;
            (_a = this.nextArrow()) === null || _a === void 0 ? void 0 : _a.classList.remove('flash-card-next-glowing');
        };
        this.speakFront = () => {
            var _a, _b;
            const text = this.frontText();
            if (this.instructionDone && !this.flipped && text && ((_a = text.textContent) === null || _a === void 0 ? void 0 : _a.trim())) {
                this.startNarration(text);
            }
            else if (this.instructionDone && !this.flipped && (!text || !((_b = text.textContent) === null || _b === void 0 ? void 0 : _b.trim()))) {
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
        };
        this.clearNarrationTimers = () => {
            if (this.narrationGraceTimer)
                window.clearTimeout(this.narrationGraceTimer);
            this.narrationGraceTimer = undefined;
            this.narrationTarget = null;
            this.narrationHandled = false;
        };
        this.continueAfterNarration = (target) => {
            if (target === this.instructionText()) {
                this.instructionDone = true;
                this.frontStartTimer = window.setTimeout(() => this.speakFront(), 1200);
            }
            else if (target === this.frontText()) {
                if (this.flipped)
                    return;
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
            else if (target === this.backText()) {
                if (this.flipped)
                    this.showArrow();
            }
        };
        this.finishNarration = (target) => {
            if (target !== this.narrationTarget || this.narrationHandled)
                return;
            this.narrationHandled = true;
            if (this.narrationGraceTimer)
                window.clearTimeout(this.narrationGraceTimer);
            this.narrationGraceTimer = undefined;
            this.continueAfterNarration(target);
        };
        this.startNarration = (target) => {
            this.clearNarrationTimers();
            this.narrationTarget = target;
            this.narrationGraceTimer = window.setTimeout(() => {
                if (!this.narrationHandled)
                    this.finishNarration(target);
            }, LidoFlash.narrationStartGrace);
            executeActions("this.speak='true'", target);
        };
        this.showArrow = () => {
            if (!this.flipped)
                return;
            const container = this.el.closest('lido-container');
            if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) !== 'flashcardtemplate')
                return;
            const arrow = this.nextArrow();
            if (!arrow)
                return;
            // Existing ZIPs may not have the newer template onTouch action. Reuse
            // the same direct nextBtn action as the shared home arrow for them.
            if (!arrow.getAttribute('onTouch'))
                arrow.setAttribute('onTouch', "this.nextBtn='true';");
            const mascot = container.querySelector('#lido-avatar');
            const scaffoldAudio = arrow.getAttribute('audio');
            if (mascot && scaffoldAudio) {
                mascot.setAttribute('audio', scaffoldAudio);
            }
            this.setArrowVisible(true);
            if (mascot) {
                this.goodJobPlaybackContext = {};
                this.goodJobPlaybackId = undefined;
                executeActions("this.avatarAnimate='Idle speak'", mascot);
                AudioPlayer.getI().play(mascot, true, this.goodJobPlaybackContext);
            }
        };
        this.setArrowVisible = (visible) => {
            const container = this.el.closest('lido-container');
            if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) !== 'flashcardtemplate')
                return;
            const arrow = container.querySelector('#arrow');
            if (!arrow)
                return;
            arrow.visible = visible;
            arrow.setAttribute('visible', String(visible));
            // lido-cell's visible prop is a non-reflected string prop; keep the
            // rendered host in sync as well so an attribute update cannot leave its
            // previous inline display:none in place.
            arrow.style.display = visible ? 'block' : 'none';
            arrow.style.visibility = visible ? 'visible' : 'hidden';
            arrow.style.opacity = visible ? '1' : '0';
            arrow.style.pointerEvents = visible ? 'auto' : 'none';
            const arrowImage = arrow.querySelector('lido-image');
            if (arrowImage) {
                arrowImage.style.display = visible ? 'flex' : 'none';
                arrowImage.style.visibility = visible ? 'visible' : 'hidden';
                arrowImage.style.opacity = visible ? '1' : '0';
            }
            if (typeof arrow.updateStyles === 'function')
                arrow.updateStyles();
        };
    }
    /* ---------- Watches ---------- */
    /** React to external changes if you need side‑effects. */
    handleFlippedChange() {
        /* No side‑effects for now; re‑render happens automatically. */
    }
    /* ---------- Lifecycle ---------- */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.updateStyles);
        window.addEventListener('load', this.updateStyles);
    }
    componentDidLoad() {
        var _a;
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        window.addEventListener('lidoAudioStarted', this.onAudioStarted);
        window.addEventListener('lidoAudioPlaying', this.onAudioPlaying);
        window.addEventListener('lidoAudioEnded', this.onAudioEnded);
        const container = this.el.closest('lido-container');
        if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) === 'flashcardtemplate') {
            (_a = container.querySelector('#lido-avatar')) === null || _a === void 0 ? void 0 : _a.setAttribute('disable-speak', 'true');
            this.instructionStartTimer = window.setTimeout(() => {
                if (!this.instructionStarted && !this.instructionDone) {
                    const instruction = this.instructionText();
                    if (instruction)
                        this.startNarration(instruction);
                }
            }, 150);
        }
        // handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength, 'inline-block');
    }
    disconnectedCallback() {
        window.removeEventListener('lidoAudioEnded', this.onAudioEnded);
        window.removeEventListener('lidoAudioPlaying', this.onAudioPlaying);
        window.removeEventListener('lidoAudioStarted', this.onAudioStarted);
        if (this.autoFlipTimer)
            window.clearTimeout(this.autoFlipTimer);
        if (this.instructionStartTimer)
            window.clearTimeout(this.instructionStartTimer);
        if (this.frontStartTimer)
            window.clearTimeout(this.frontStartTimer);
        this.clearNarrationTimers();
        window.removeEventListener('resize', this.updateStyles);
        window.removeEventListener('load', this.updateStyles);
    }
    /* ---------- Render ---------- */
    render() {
        return (h(Host, { key: 'c4b0bdbed6a679ce901062490caed55899d307e2', value: this.value, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, type: this.type, onClick: (event) => {
                var _a, _b;
                if ((_b = (_a = event.target) === null || _a === void 0 ? void 0 : _a.closest) === null || _b === void 0 ? void 0 : _b.call(_a, '#lido-avatar'))
                    return;
                this.handleFlip();
            }, "disable-speak": this.disableSpeak }, h("div", { key: 'd0c40360985b6ebfcbd08600eb9bbc695e66e15b', class: `card ${this.flipped ? 'flipped' : ''}` }, h("div", { key: 'c9c26f340703747af5391293aeae3daa1f27c612', class: "card-face card-front" }, this.front != null ? this.front : h("slot", { name: "front" })), h("div", { key: '38fe3aaf13bf96c988412c291879bc72eccebaf4', class: "card-face card-back" }, this.back != null ? this.back : h("slot", { name: "back" })))));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "flipped": [{
                "handleFlippedChange": 0
            }]
    }; }
};
LidoFlash.narrationStartGrace = 800;
LidoFlash.style = lidoFlashCardCss();

export { LidoFlash as lido_flash_card };
