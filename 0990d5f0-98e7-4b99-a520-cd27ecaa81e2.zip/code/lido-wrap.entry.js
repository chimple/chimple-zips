import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { y as initEventsForElement, F as handlingChildElements, H as attachSpeakIcon, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoWrapCss = () => `.lido-wrap{display:grid;grid-gap:10px;grid-template-columns:repeat(auto-fill, minmax(186px, auto))}.lido-wrap>*{padding:10px;background-color:var(--child-bg-color, #f0f0f0);box-sizing:border-box}.lido-flex{display:flex;flex-wrap:wrap;align-content:flex-start;gap:10px}`;

const LidoWrap = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It initializes custom events based on the `type` of the wrap container.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.flex === 'true') {
            this.el.classList.remove('lido-wrap');
            this.el.classList.add('lido-flex');
        }
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: JSON.parse(parseProp(`${this.visible}`, orientation)) ? (this.flex === 'true' ? 'flex' : 'grid') : 'none', // Toggle visibility
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: '8d8ea2a16213d6a54c947d2fa20dd094024d30d1', class: "lido-wrap", value: this.value, type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, minDrops: this.minDrops, maxDrops: this.maxDrops, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, disableSpeak: this.disableSpeak }, h("slot", { key: 'f42ddae95ef36fe6e7a42d2ccfcb58bf09243b08' })));
    }
    get el() { return getElement(this); }
};
LidoWrap.style = lidoWrapCss();

export { LidoWrap as lido_wrap };
