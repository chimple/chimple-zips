import { r as registerInstance, a as getAssetPath, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { Y as TraceMode, k as convertUrlToRelative, x as setVisibilityWithDelay, Z as speakIcon, _ as fingerUrl, C as storingEachActivityScore, q as executeActions, l as LidoContainer, E as calculateScore, u as triggerNextContainer, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoTraceCss = () => `:host{display:block;position:relative}#lido-svgContainer{display:flex;justify-content:center;align-items:center;overflow:hidden}.lido-trace-svg{width:100%;height:100%;touch-action:none}#lido-draggableCircle{cursor:pointer;fill:#CF1565;transition:fill 0.2s, r 0.2s}.lido-blindTracing{stroke:none !important}.lido-blindFreeTrace{stroke:none !important}.lido-hovered{cursor:grab;fill:darkred}#lido-controls{position:fixed;bottom:0;left:0;right:0;display:flex;justify-content:space-between;padding:10px;background-color:#f0f0f0;border-top:1px solid #ccc}button{padding:10px;font-size:16px}@media (max-width: 600px){button{padding:8px;font-size:14px}}.lido-trace-path-green{}.lido-flow-indicator{stroke:blue;stroke-width:2;stroke-dasharray:6, 6;fill:none}.lido-trace{height:700px;width:700px;z-index:1;justify-items:center;align-content:center}.trace-animate{animation:trace-bounce 0.5s}@keyframes trace-bounce{0%{transform:scale(1)}30%{transform:scale(1.05)}60%{transform:scale(0.95)}100%{transform:scale(1)}}`;

const LidoTrace = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * Various configuration properties for `lido-trace`
         */
        /**
         * Unique identifier for this `lido-trace` component instance.
         */
        this.id = '';
        /**
         * Source URL or path for the SVG file used in this component.
         */
        this.svgSource = '';
        /**
         * Array of SVG URLs to be used for tracing, separated by semicolons.
         * This allows multiple SVGs to be loaded and traced in sequence.
         */
        this.svgUrls = [];
        /**
         * Array of audio URLs to be played when tracing is completed, separated by semicolons.
         * This allows multiple audio files to be loaded and played in sequence.
         */
        this.audioUrls = [];
        /**
         * Index of the currently active SVG in the `svgUrls` array.
         * This is used to track which SVG is currently being traced.
         */
        this.currentSvgIndex = 0;
        /**
         * Specifies whether the component is currently in a moving state.
         * This can be used to control animations or transitions.
         * Defaults to `false`.
         */
        this.moving = false;
        /**
         * A custom string value associated with the component for additional data or identification.
         */
        this.value = '';
        /**
         * Specifies the height of the component container, accepts any valid CSS height value (e.g., `"100px"`, `"50%"`).
         */
        this.height = 'auto';
        /**
         * Specifies the width of the component container, accepts any valid CSS width value (e.g., `"100px"`, `"50%"`).
         */
        this.width = 'auto';
        /**
         * URL or identifier for an audio file associated with the text component.
         */
        this.audio = '';
        /**
         * Defines the x-coordinate position (left offset) of the component container, using any valid CSS `left` value (e.g., `"10px"`, `"5%"`).
         */
        this.x = '0px';
        /**
         * Defines the y-coordinate position (top offset) of the component container, using any valid CSS `top` value (e.g., `"10px"`, `"5%"`).
         */
        this.y = '0px';
        /**
         * Sets the z-index of the component, controlling its stacking order on the page.
         */
        this.z = '0';
        /**
         * Accessible label for screen readers, providing a textual description of the component's purpose.
         */
        this.ariaLabel = '';
        /**
         * Controls visibility for assistive technologies. If `"true"`, the component is hidden from screen readers.
         */
        this.ariaHidden = '';
        /**
         * Sets the tab order of the component within the page, enabling keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Mode for the tracing interaction, defining how users interact with the SVG paths.
         * Options may include `"noFlow"`, `"showFlow"`, `"freeTrace"`, `"blindTracing"`, and `"blindFreeTrace"`
         */
        this.mode = TraceMode.ShowFlow;
        /**
         * URL for the finger hint image
         */
        this.fingerHintUrl = getAssetPath('assets/Tracing-hand.svg');
        /**
         * Indicates whether to highlight the text associated with the SVG when the trace is completed.
         */
        this.highlightTextId = '';
        /**
         * Indicates whether to play an animation trace when the SVG is completed.
         */
        this.animationTrace = false;
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        this.fileIndex = -1;
        this.isDragging = false;
        this.activePointerId = null;
        this.activeTraceState = null;
        // Counter for throttling free trace updates
        // This is only an internal counter. Keeping it out of @State prevents a
        // Stencil component re-render while the user is dragging.
        this.freeTraceUpdateCounter = 0;
        /** ───────────────────────────────────────────────────────────
         *  NEW: idle‑timer + finger‑hint state
         *  ─────────────────────────────────────────────────────────── */
        this.idleTimer = null;
        this.fingerImg = null;
    }
    // MODES = ['noFlow', 'showFlow', 'freeTrace', 'blindTracing', 'blindFreeTrace'];
    // Handle the pointermove event with optimizations
    // Update the path trace as the red circle moves
    async initializeSVG() {
        this.cleanupTraceState(this.activeTraceState);
        let state = {
            fileIndex: -1,
            currentPathIndex: 0,
            lastLength: 0,
            totalPathLength: 0,
            isDragging: false,
            circle: null,
            paths: [],
            svg: null,
            proximityThreshold: 60, // Increased general proximity threshold (was 100)
            freeTraceProximityThreshold: 350, // Increased proximity for free trace (was 50)
            rafId: null,
            pointerMoveEvent: null,
            activePointerId: null,
            mode: this.mode,
            flowMarkers: [],
            freeTraceLines: [],
            currentFreePath: [],
            lastPointerPos: null,
            dragOffset: null,
            isCompletingPath: false,
            touchProximityThreshold: null,
            pointerTransform: null,
            pointerRect: null,
        };
        this.activeTraceState = state;
        const url = this.svgUrls[this.currentSvgIndex];
        if (!url || url.trim() === '') {
            console.error('No SVG URL provided or index out of bounds.');
            return;
        }
        const svgText = await this.fetchSVG(convertUrlToRelative(url));
        await this.loadAnotherSVG(state, true); // Load the first SVG
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
    }
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
        this.svgUrls = this.svgSource.split(';').map(s => s.trim());
        this.currentSvgIndex = 0;
        if (this.showSpeakIcon) {
            speakIcon(this.el);
            this.el.append(speakIcon(this.el));
        }
        this.initializeSVG();
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
        this.cleanupTraceState(this.activeTraceState);
        this.activeTraceState = null;
    }
    /** Release listeners, pending frames, timers, and cached SVG geometry. */
    cleanupTraceState(state) {
        var _a;
        if (!state)
            return;
        (_a = state.cleanup) === null || _a === void 0 ? void 0 : _a.call(state);
        if (state.rafId)
            cancelAnimationFrame(state.rafId);
        state.rafId = null;
        state.pointerMoveEvent = null;
        state.pathSamples = [];
        state.paths = [];
        state.svg = null;
        if (this.idleTimer !== null) {
            clearTimeout(this.idleTimer);
            this.idleTimer = null;
        }
        this.hideFingerHint();
    }
    /** ───────────────────────────────────────────────────────────
     *  Idle‑timer helpers
     *  ─────────────────────────────────────────────────────────── */
    resetIdleTimer(state) {
        if (this.idleTimer !== null) {
            clearTimeout(this.idleTimer);
            this.idleTimer = null;
        }
        this.idleTimer = window.setTimeout(() => {
            this.showFingerHint(state);
        }, 3000);
    }
    showFingerHint(state) {
        var _a;
        if (this.fingerImg)
            return; // already showing
        const currentPath = state.paths[state.currentPathIndex];
        if (!currentPath)
            return;
        /**  FIX: centre the image on the path (was offset down‑right)  **/
        const IMG_SIZE = 40; // width & height of finger.png
        const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
        const testImage = new Image();
        testImage.onload = () => {
            img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', convertUrlToRelative(this.fingerHintUrl));
        };
        testImage.onerror = () => {
            img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', convertUrlToRelative(fingerUrl));
        };
        testImage.src = convertUrlToRelative(this.fingerHintUrl || fingerUrl);
        img.setAttribute('width', `${IMG_SIZE}`);
        img.setAttribute('height', `${IMG_SIZE}`);
        img.setAttribute('id', 'lido-finger-hint');
        img.style.pointerEvents = 'none';
        img.style.opacity = '0.8';
        // place the image so its centre aligns with the path’s start point
        // const start = currentPath.getPointAtLength(0);
        img.setAttribute('x', '0');
        img.setAttribute('y', '0');
        // animateMotion
        const motion = document.createElementNS('http://www.w3.org/2000/svg', 'animateMotion');
        motion.setAttribute('dur', '2s');
        motion.setAttribute('repeatCount', 'indefinite');
        const mpath = document.createElementNS('http://www.w3.org/2000/svg', 'mpath');
        mpath.setAttributeNS('http://www.w3.org/1999/xlink', 'href', `#${currentPath.id}`);
        motion.appendChild(mpath);
        img.appendChild(motion);
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(img);
        this.fingerImg = img;
    }
    hideFingerHint() {
        if (this.fingerImg && this.fingerImg.parentNode) {
            this.fingerImg.parentNode.removeChild(this.fingerImg);
        }
        this.fingerImg = null;
    }
    // Fetch the SVG file asynchronously
    async fetchSVG(url) {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch SVG (${url}): ${response.statusText}`);
        }
        return await response.text();
    }
    // to calculate the bounding box of all paths
    calculateBoundingBox(paths, padding = 22) {
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        paths.forEach(path => {
            const length = path.getTotalLength();
            const numPoints = 100; // Number of points to sample along the path
            for (let i = 0; i <= numPoints; i++) {
                const point = path.getPointAtLength((i / numPoints) * length);
                if (point.x < minX)
                    minX = point.x;
                if (point.y < minY)
                    minY = point.y;
                if (point.x > maxX)
                    maxX = point.x;
                if (point.y > maxY)
                    maxY = point.y;
            }
        });
        // Apply padding
        minX -= padding;
        minY -= padding;
        maxX += padding;
        maxY += padding;
        return { minX, minY, maxX, maxY };
    }
    // Insert the fetched SVG into the container and adjust viewBox
    insertSVG(svgText) {
        const svgContainer = document.getElementById('lido-svgContainer');
        if (!svgContainer)
            return;
        svgContainer.innerHTML = svgText;
        // After inserting, get the SVG element
        const svgElement = svgContainer.querySelector('svg');
        svgElement.classList.add('lido-trace-svg');
        // Remove the width and height attributes from the SVG element
        svgElement.removeAttribute('width');
        svgElement.removeAttribute('height');
        // Get all paths
        const paths = svgElement.querySelectorAll('path, line');
        // Calculate bounding box
        const bbox = this.calculateBoundingBox(Array.from(paths));
        // Set the viewBox to the bounding box
        const viewBoxWidth = bbox.maxX - bbox.minX;
        const viewBoxHeight = bbox.maxY - bbox.minY;
        svgElement.setAttribute('viewBox', `${bbox.minX} ${bbox.minY} ${viewBoxWidth} ${viewBoxHeight}`);
    }
    // Retrieve the SVG element from the container
    getSVGElement() {
        const svgContainer = document.getElementById('lido-svgContainer');
        return svgContainer.querySelector('svg');
    }
    // Get all path and line elements from the SVG
    getPaths(svg) {
        return Array.from(svg.querySelectorAll('path, line'));
    }
    // Create a single dotted line with an arrow at the end for the entire path
    createFlowMarkersForPath(path) {
        var _a;
        if (!path)
            return;
        const svg = path.ownerSVGElement;
        if (!svg)
            return;
        // --- 1. Create the dotted line that follows the same path ---
        // Create a new <path> element that will visually represent the flow (dotted line)
        const dottedLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        // Copy the "d" (path drawing instructions) from the original path
        dottedLine.setAttribute('d', path.getAttribute('d') || '');
        dottedLine.setAttribute('stroke', 'blue');
        dottedLine.setAttribute('stroke-width', '2');
        // Define a repeating pattern of dashes: "6 units on, 6 units off"
        dottedLine.setAttribute('stroke-dasharray', '6,6');
        dottedLine.setAttribute('fill', 'none');
        // Add a class name for styling or later querying
        dottedLine.setAttribute('class', 'lido-flow-indicator');
        (_a = path.parentNode) === null || _a === void 0 ? void 0 : _a.appendChild(dottedLine);
        // --- 2. Ensure we only add <defs> + marker once per SVG ---
        // Look for an existing <defs> section with our custom ID inside the SVG
        let defs = svg.querySelector('defs#lido-flow-defs');
        // If it doesn’t exist, create one and insert it at the top of the SVG
        if (!defs) {
            defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
            defs.setAttribute('id', 'lido-flow-defs');
            svg.insertBefore(defs, svg.firstChild); // defs should usually be at the beginning
        }
        // --- 3. Create a unique marker for this path ---
        const uniqueId = `arrow-${Math.random().toString(36)}`;
        // Create the <marker> element that defines the arrowhead
        const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        marker.setAttribute('id', uniqueId);
        // Set the width/height of the marker viewport (10x10 units)
        marker.setAttribute('markerWidth', '10');
        marker.setAttribute('markerHeight', '10');
        // Reference point inside the marker (where the path will attach to arrow)
        marker.setAttribute('refX', '5');
        marker.setAttribute('refY', '5');
        // Automatically rotate arrowhead to match the path direction
        marker.setAttribute('orient', 'auto');
        // Scale the marker relative to the stroke width of the path
        marker.setAttribute('markerUnits', 'strokeWidth');
        // --- Create the arrow shape itself ---
        const arrowPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        // Define the arrowhead shape using SVG path commands
        arrowPath.setAttribute('d', 'M0,0 L10,5 L0,10 L2,5 Z');
        arrowPath.setAttribute('fill', 'blue');
        marker.appendChild(arrowPath);
        defs.appendChild(marker);
        // --- 4. Attach the arrow marker to the end of the dotted line  ---
        dottedLine.setAttribute('marker-end', `url(#${uniqueId})`);
        return dottedLine;
    }
    // Show or hide flow indicators based on mode
    updateFlowIndicators(state) {
        const indicators = state.svg.querySelectorAll('.lido-flow-indicator');
        indicators.forEach(indicator => {
            if (state.mode === TraceMode.NoFlow) {
                indicator.style.display = 'none';
            }
            else if (state.mode === TraceMode.ShowFlow) {
                indicator.style.display = 'block';
            }
        });
    }
    // Create a new path element for the drawing effect
    setupDrawingPath(state) {
        state.paths.forEach((path, index) => {
            const pathLength = path.getTotalLength();
            // Geometry calls are expensive on slower SVG implementations. Cache
            // the length once and reuse it during pointer movement.
            path._lidoTraceLength = pathLength;
            path._lidoTraceStart = path.getPointAtLength(0);
            path._lidoTraceEnd = path.getPointAtLength(pathLength);
            path._lidoTraceIsClosed = this.getDistanceSquared(path._lidoTraceStart, path._lidoTraceEnd) < 200;
            // Index the path once. Repeated getPointAtLength calls are expensive on
            // low-end SVG implementations and used to dominate every pointer frame.
            const sampleCount = 192;
            const sampleStep = pathLength / sampleCount || 1;
            const samples = [];
            for (let sampleIndex = 0; sampleIndex <= sampleCount; sampleIndex++) {
                const length = Math.min(pathLength, sampleIndex * sampleStep);
                const point = path.getPointAtLength(length);
                samples.push({ x: point.x, y: point.y, length });
            }
            path._lidoTraceSamples = samples;
            path._lidoTraceSampleStep = sampleStep;
            // /** give every path an id so <mpath> can follow it */
            path.setAttribute('id', 'lido-path-' + index); //  ← NEW
            // Create green path for tracing effect
            const greenPath = path.cloneNode();
            greenPath.style.opacity = '100';
            greenPath.style['stroke-opacity'] = '100';
            // greenPath.setAttribute('stroke', 'green');
            const strokeWidth = path.style['stroke-width'] || path.getAttribute('stroke-width');
            greenPath.setAttribute('stroke-width', strokeWidth);
            greenPath.setAttribute('stroke-dasharray', pathLength.toString());
            greenPath.setAttribute('stroke-dashoffset', pathLength.toString()); // Hidden initially
            path.parentNode.appendChild(greenPath, path);
            path.setAttribute('class', 'lido-trace-path'); // Add class for easier reference
            greenPath.setAttribute('class', 'lido-trace-path-green'); // Add class for easier reference
            path.greenPath = greenPath;
            path.classList.add(state.mode);
            // Conditionally hide or show the black path based on blind tracing mode
            if (state.mode === TraceMode.BlindTracing || state.mode === TraceMode.BlindFreeTrace) {
                // In blind tracing or blind free trace mode, hide the black path
                path.setAttribute('stroke', 'none');
            }
            else {
                // In other modes, show the black path
                path.setAttribute('stroke', '#000');
                path.setAttribute('stroke-width', strokeWidth);
                path.setAttribute('fill', 'none');
                path.setAttribute('stroke-dasharray', pathLength.toString());
                path.setAttribute('stroke-dashoffset', '0'); // Fully visible initially
            }
            // Only create flow markers for the current path in normal modes
            if (index === state.currentPathIndex && state.mode === TraceMode.ShowFlow) {
                state.flowMarkers = this.createFlowMarkersForPath(path);
            }
        });
        state.totalPathLength = state.paths[state.currentPathIndex]._lidoTraceLength;
    }
    // Set up the draggable circle at the start of the first path
    setupDraggableCircle(state) {
        var _a;
        const firstPathStart = state.paths[0].getPointAtLength(0);
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        const strokeWidth = state.paths[state.currentPathIndex].style['stroke-width'] || state.paths[state.currentPathIndex].getAttribute('stroke-width');
        circle.setAttribute('id', 'lido-draggableCircle');
        circle.setAttribute('cx', firstPathStart.x.toString());
        circle.setAttribute('cy', firstPathStart.y.toString());
        circle.setAttribute('r', `20`); // Radius of the draggable circle
        circle.setAttribute('fill', '#CF1565'); // fill the color for the circle
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(circle);
        state.circle = circle;
        this.resetIdleTimer(state); // ← start idle timer once the SVG is ready
    }
    // Add necessary event listeners using Pointer Events
    addEventListeners(state) {
        var _a, _b, _c, _d;
        // Ensure the circle exists before adding events
        if (!state.circle || !state.paths || state.paths.length === 0)
            return;
        state.svg.style.touchAction = 'none';
        state.circle.style.touchAction = 'none';
        // Keep named handlers so the detached SVG can be fully released when the
        // next trace starts. Anonymous handlers here previously retained every
        // completed trace for the lifetime of the page.
        const onPointerDown = (evt) => {
            evt.preventDefault(); // Prevent default actions like text selection
            state.pointerRect = state.svg.getBoundingClientRect();
            state.pointerTransform = this.getSvgViewBoxTransform(state.svg, state.pointerRect);
            const pointerPos = this.getPointerPosition(evt, state.svg, state.pointerTransform, state.pointerRect);
            const circlePos = {
                x: parseFloat(state.circle.getAttribute('cx')),
                y: parseFloat(state.circle.getAttribute('cy')),
            };
            const distance = this.getDistanceSquared(pointerPos, circlePos);
            const startThreshold = this.getProximityThresholdForEvent(state, evt);
            const isWithinStartThreshold = distance <= startThreshold * startThreshold;
            if (isWithinStartThreshold || evt.pointerType === 'touch') {
                state.isDragging = true;
                state.activePointerId = evt.pointerId;
                state.dragOffset = {
                    x: pointerPos.x - circlePos.x,
                    y: pointerPos.y - circlePos.y,
                };
                try {
                    state.circle.setPointerCapture(evt.pointerId);
                }
                catch (_a) {
                    // iOS/Safari can be fussy with pointer capture on SVG nodes.
                }
                state.lastPointerPos = circlePos;
            }
            this.hideFingerHint(); // ← NEW
            this.resetIdleTimer(state); // ← NEW
        };
        // Handle pointermove on the SVG to update the circle position
        const onPointerMove = (evt) => {
            if (!state.isDragging || evt.pointerId !== state.activePointerId)
                return;
            evt.preventDefault();
            state.pointerMoveEvent = evt;
            if (!state.rafId) {
                state.rafId = requestAnimationFrame(() => {
                    this.handlePointerMove(state);
                    state.rafId = null;
                });
            }
        };
        // Handle pointerup and pointercancel on the SVG to stop dragging
        const endDrag = (evt) => {
            if (evt.pointerId === state.activePointerId) {
                state.isDragging = false;
                state.activePointerId = null;
                state.lastPointerPos = null;
                state.dragOffset = null;
                this.hideFingerHint(); // ← NEW
                this.resetIdleTimer(state); // ← NEW
            }
        };
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.addEventListener('pointerup', endDrag);
        (_b = state.svg) === null || _b === void 0 ? void 0 : _b.addEventListener('pointercancel', endDrag);
        // Optional: Prevent context menu on long press
        const onContextMenu = (evt) => {
            evt.preventDefault();
        };
        state.circle.addEventListener('pointerdown', onPointerDown, { passive: false });
        (_c = state.svg) === null || _c === void 0 ? void 0 : _c.addEventListener('pointermove', onPointerMove);
        (_d = state.svg) === null || _d === void 0 ? void 0 : _d.addEventListener('contextmenu', onContextMenu);
        state.cleanup = () => {
            var _a, _b, _c, _d, _e;
            (_a = state.circle) === null || _a === void 0 ? void 0 : _a.removeEventListener('pointerdown', onPointerDown);
            (_b = state.svg) === null || _b === void 0 ? void 0 : _b.removeEventListener('pointermove', onPointerMove);
            (_c = state.svg) === null || _c === void 0 ? void 0 : _c.removeEventListener('pointerup', endDrag);
            (_d = state.svg) === null || _d === void 0 ? void 0 : _d.removeEventListener('pointercancel', endDrag);
            (_e = state.svg) === null || _e === void 0 ? void 0 : _e.removeEventListener('contextmenu', onContextMenu);
            state.isDragging = false;
            state.activePointerId = null;
        };
    }
    // Modified handlePointerMove function
    async handlePointerMove(state) {
        var _a, _b, _c, _d, _e;
        if (!state.isDragging)
            return;
        if (!state.circle || !state.paths || state.paths.length === 0)
            return;
        if (state.isCompletingPath)
            return;
        this.hideFingerHint(); // user is active, remove hint
        const evt = state.pointerMoveEvent;
        const rawPointerPos = this.getPointerPosition(evt, state.svg, state.pointerTransform, state.pointerRect);
        const pointerPos = state.dragOffset
            ? {
                x: rawPointerPos.x - state.dragOffset.x,
                y: rawPointerPos.y - state.dragOffset.y,
            }
            : rawPointerPos;
        const circlePos = {
            x: parseFloat(state.circle.getAttribute('cx')),
            y: parseFloat(state.circle.getAttribute('cy')),
        };
        // Only update if pointer moved a minimum distance (to reduce unnecessary updates)
        const MOVE_THRESHOLD = 1; // px
        let pointerMoveDistanceSquared = Infinity;
        if (state.lastPointerPos) {
            const dx = pointerPos.x - state.lastPointerPos.x;
            const dy = pointerPos.y - state.lastPointerPos.y;
            pointerMoveDistanceSquared = dx * dx + dy * dy;
            if (pointerMoveDistanceSquared < MOVE_THRESHOLD * MOVE_THRESHOLD) {
                return;
            }
        }
        const currentPath = state.paths[state.currentPathIndex];
        if (!currentPath) {
            console.error('No valid path found at the current index');
            return;
        }
        // Use a reduced proximity threshold for free trace mode
        const proximityThreshold = this.getProximityThresholdForEvent(state, evt);
        const proximitySquared = proximityThreshold * proximityThreshold;
        // Calculate the distance between the pointer and the draggable circle
        const distanceSquared = this.getDistanceSquared(pointerPos, circlePos);
        // If the pointer is outside the proximity threshold, do not proceed with drawing or moving
        if (distanceSquared > proximitySquared) {
            return; // Skip any further actions
        }
        const isFreeTraceMode = state.mode === TraceMode.FreeTrace || state.mode === TraceMode.BlindFreeTrace;
        const closestPoint = this.getClosestPointOnPath(currentPath, pointerPos, isFreeTraceMode ? undefined : state.lastLength);
        // Ensure drawing happens only within proximity threshold
        const distanceToPathSquared = this.getDistanceSquared(pointerPos, closestPoint);
        if (distanceToPathSquared > proximitySquared) {
            return; // Skip drawing if too far from the path
        }
        // For free trace mode and blind free trace mode, allow free drawing only if within the reduced proximity threshold
        if (isFreeTraceMode) {
            // Throttle: Only update every 2nd event (for reducing excessive dom updates)
            this.freeTraceUpdateCounter = (this.freeTraceUpdateCounter || 0) + 1;
            if (this.freeTraceUpdateCounter % 2 !== 0) {
                return;
            }
            // Initialize the currentFreePath array if it's not created
            if (!state.currentFreePath) {
                state.currentFreePath = [];
            }
            // Create a new polyline element if it's the first trace for the current path index
            if (!state.currentFreePath[state.currentPathIndex]) {
                const newPolyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
                const strokeWidth = state.paths[state.currentPathIndex].style['stroke-width'] || state.paths[state.currentPathIndex].getAttribute('stroke-width');
                newPolyline.setAttribute('stroke-width', strokeWidth);
                newPolyline.setAttribute('fill', 'none');
                newPolyline.setAttribute('stroke-linecap', 'round');
                newPolyline.setAttribute('stroke', 'lightgreen');
                newPolyline.setAttribute('points', `${pointerPos.x},${pointerPos.y}`);
                (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(newPolyline);
                state.currentFreePath[state.currentPathIndex] = newPolyline;
                // Store points array for this polyline
                state.currentFreePolylinePoints = state.currentFreePolylinePoints || [];
                state.currentFreePolylinePoints[state.currentPathIndex] = [{ x: pointerPos.x, y: pointerPos.y }];
                // Reset lastPointerPos for the new path
                state.lastPointerPos = pointerPos;
                // Add a points counter to limit path growth
                state.freeTracePointsCount = 1;
            }
            // Limit the number of points in the free trace path for performance
            const MAX_FREE_TRACE_POINTS = 5;
            state.freeTracePointsCount = (state.freeTracePointsCount || 1) + 1;
            if (state.freeTracePointsCount > MAX_FREE_TRACE_POINTS) {
                // If limit reached, skip adding more points
                return;
            }
            // Add the new point to the polyline's points array
            state.currentFreePolylinePoints = state.currentFreePolylinePoints || [];
            let pointsArr = state.currentFreePolylinePoints[state.currentPathIndex] || [];
            pointsArr.push({ x: pointerPos.x, y: pointerPos.y });
            state.currentFreePolylinePoints[state.currentPathIndex] = pointsArr;
            // Update the polyline's points attribute
            const pointsStr = pointsArr.map(pt => `${pt.x},${pt.y}`).join(' ');
            state.currentFreePath[state.currentPathIndex].setAttribute('points', pointsStr);
            // Move the draggable circle with the freehand trace
            state.circle.setAttribute('cx', pointerPos.x.toString());
            state.circle.setAttribute('cy', pointerPos.y.toString());
            // Keep the original safety check without scanning every SVG child.
            if (state.circle.parentNode !== state.svg) {
                (_b = state.svg) === null || _b === void 0 ? void 0 : _b.appendChild(state.circle);
            }
            // Update the last pointer position
            state.lastPointerPos = pointerPos;
            // For polyline, estimate the end by number of points (not path length)
            if (pointsArr.length >= MAX_FREE_TRACE_POINTS) {
                this.moveToNextPath(state);
                state.currentFreePath[state.currentPathIndex] = null; // Reset free path for next path
                state.currentFreePolylinePoints[state.currentPathIndex] = [];
                state.freeTracePointsCount = 0;
            }
            // this.resetIdleTimer(state); // ← keep timer alive
            return; // Exit early since we're in free trace or blind free trace mode
        }
        // In normal modes, allow movement and drawing only within the general proximity threshold
        const BACKWARD_TOLERANCE = 20; // allow slight backward movement
        const MAX_FORWARD_JUMP = 80; // prevent jumping to wrong segment
        const RECOVERY_FORWARD_JUMP = Math.min(320, Math.max(160, state.totalPathLength * 0.45)); // recover on long strokes without skipping short paths
        const RECOVERY_END_BUFFER = Math.min(60, Math.max(24, state.totalPathLength * 0.12)); // don't let recovery auto-finish the last part
        const RECOVERY_POINTER_MOVE_THRESHOLD = 8; // only recover after a meaningful drag, not during slow tracing
        let guidedClosestPoint = closestPoint;
        let isValidProgress = guidedClosestPoint.length >= state.lastLength - BACKWARD_TOLERANCE &&
            guidedClosestPoint.length - state.lastLength <= MAX_FORWARD_JUMP;
        if (!isValidProgress) {
            const recoveryPoint = this.getClosestPointOnPath(currentPath, pointerPos);
            const recoveryDistanceSquared = this.getDistanceSquared(pointerPos, recoveryPoint);
            const canRecover = pointerMoveDistanceSquared >= RECOVERY_POINTER_MOVE_THRESHOLD * RECOVERY_POINTER_MOVE_THRESHOLD &&
                recoveryDistanceSquared <= proximitySquared &&
                recoveryPoint.length >= state.lastLength - BACKWARD_TOLERANCE &&
                recoveryPoint.length - state.lastLength <= RECOVERY_FORWARD_JUMP &&
                recoveryPoint.length < state.totalPathLength - RECOVERY_END_BUFFER;
            if (canRecover) {
                guidedClosestPoint = recoveryPoint;
                isValidProgress = true;
            }
        }
        if (state.isDragging && isValidProgress) {
            state.lastLength = Math.max(state.lastLength, guidedClosestPoint.length);
            state.lastPointerPos = pointerPos;
            // Only update the circle if it moved enough
            if (Math.abs(guidedClosestPoint.x - circlePos.x) > MOVE_THRESHOLD || Math.abs(guidedClosestPoint.y - circlePos.y) > MOVE_THRESHOLD) {
                state.circle.setAttribute('cx', guidedClosestPoint.x.toString());
                state.circle.setAttribute('cy', guidedClosestPoint.y.toString());
            }
            // Keep the original safety check without scanning every SVG child.
            if (state.circle.parentNode !== state.svg) {
                (_c = state.svg) === null || _c === void 0 ? void 0 : _c.appendChild(state.circle);
            }
            (_d = currentPath.greenPath) === null || _d === void 0 ? void 0 : _d.setAttribute('stroke-dashoffset', (state.totalPathLength - state.lastLength).toString());
            // Completion logic for closed paths: only allow completion if almost all points are traced
            const COMPLETION_THRESHOLD = 0.95; // 95% of the path must be traced
            let percentComplete = state.lastLength / state.totalPathLength;
            const pathIsClosed = (_e = currentPath._lidoTraceIsClosed) !== null && _e !== void 0 ? _e : false;
            if (pathIsClosed && state.totalPathLength > 50) {
                if (percentComplete >= COMPLETION_THRESHOLD) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    // Animate the draggable circle & green trace to the very end, then proceed
                    await this.animatePathToEnd(state, currentPath);
                    if (state.currentPathIndex < state.paths.length - 1) {
                        this.moveToNextPath(state);
                    }
                    else if (state.currentPathIndex === state.paths.length - 1) {
                        this.moveToNextContainer();
                    }
                }
            }
            else {
                // For open paths, allow completion if near the end
                if (state.totalPathLength - 1 - state.lastLength < 5 && state.currentPathIndex < state.paths.length - 1) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    this.moveToNextPath(state);
                }
                else if (state.totalPathLength - 1 - state.lastLength < 5 && state.currentPathIndex === state.paths.length - 1) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    this.moveToNextContainer();
                }
            }
        }
        // this.resetIdleTimer(state); // ← keep timer alive
    }
    // Smoothly animate the draggable circle + green stroke from current lastLength to totalPathLength
    animatePathToEnd(state, path, duration = 300) {
        if (!path || !state.svg)
            return Promise.resolve();
        if (state._animatingToEnd)
            return Promise.resolve();
        state._animatingToEnd = true;
        const start = state.lastLength || 0;
        const end = path.getTotalLength();
        const startTime = performance.now();
        // get greenPath safely: prefer the attached property, otherwise query by class near the original path
        const greenPath = path.greenPath ||
            (path.parentNode && path.parentNode.querySelector('.lido-trace-path-green'));
        return new Promise(resolve => {
            const step = (now) => {
                const t = Math.min(1, (now - startTime) / duration);
                const eased = t; // linear easing
                const currentLen = start + (end - start) * eased;
                state.lastLength = currentLen;
                // update circle position and green path dashoffset
                const pt = path.getPointAtLength(currentLen);
                if (state.circle) {
                    state.circle.setAttribute('cx', pt.x.toString());
                    state.circle.setAttribute('cy', pt.y.toString());
                }
                if (greenPath) {
                    greenPath.setAttribute('stroke-dashoffset', (state.totalPathLength - currentLen).toString());
                }
                if (t < 1) {
                    requestAnimationFrame(step);
                }
                else {
                    // ensure fully complete
                    state.lastLength = end;
                    if (state.circle) {
                        const finalPt = path.getPointAtLength(end);
                        state.circle.setAttribute('cx', finalPt.x.toString());
                        state.circle.setAttribute('cy', finalPt.y.toString());
                    }
                    if (greenPath) {
                        greenPath.setAttribute('stroke-dashoffset', '0');
                    }
                    state._animatingToEnd = false;
                    resolve();
                }
            };
            requestAnimationFrame(step);
        });
    }
    // Move to the next container after completing the current SVG
    async moveToNextContainer() {
        this.isDragging = false;
        if (this.moving)
            return; // Prevent multiple calls
        this.moving = true; // Set moving to true to prevent re-entrance
        if (this.highlightTextId) {
            this.highlightLetter(this.currentSvgIndex);
        }
        if (this.animationTrace) {
            await this.playTraceAnimation();
        }
        storingEachActivityScore(true);
        const delay = 1000; // milliseconds
        if (this.currentSvgIndex < this.svgUrls.length - 1) {
            await new Promise(resolve => setTimeout(resolve, delay));
            this.currentSvgIndex++;
            await this.initializeSVG();
            const svgContainer = document.getElementById('lido-svgContainer');
            svgContainer.style.visibility = 'visible';
            this.moving = false;
            if (this.el && this.onCorrect) {
                await executeActions(this.onCorrect, this.el);
            }
            return;
        }
        const container = document.querySelector(LidoContainer);
        const containerOnCorrect = container.getAttribute("onCorrect");
        if (container && containerOnCorrect) {
            await new Promise(resolve => setTimeout(resolve, delay));
            await executeActions(containerOnCorrect, this.el);
        }
        calculateScore();
        triggerNextContainer();
    }
    // Get the pointer position relative to the SVG
    getPointerPosition(evt, svg, cachedTransform, cachedRect) {
        var _a;
        const viewBoxPoint = this.getPointerPositionFromViewBox(evt, svg, cachedTransform, cachedRect);
        if (viewBoxPoint)
            return viewBoxPoint;
        const svgPoint = svg.createSVGPoint();
        svgPoint.x = evt.clientX;
        svgPoint.y = evt.clientY;
        const ctm = (_a = svg.getScreenCTM()) === null || _a === void 0 ? void 0 : _a.inverse();
        return ctm ? svgPoint.matrixTransform(ctm) : { x: evt.clientX, y: evt.clientY };
    }
    getPointerPositionFromViewBox(evt, svg, cachedTransform, cachedRect) {
        const rect = cachedRect || svg.getBoundingClientRect();
        const viewBox = svg.viewBox.baseVal;
        if (!rect.width || !rect.height || !viewBox.width || !viewBox.height) {
            return null;
        }
        const { offsetX, offsetY, scaleX, scaleY } = cachedTransform || this.getSvgViewBoxTransform(svg, rect);
        return {
            x: viewBox.x + (evt.clientX - rect.left - offsetX) / scaleX,
            y: viewBox.y + (evt.clientY - rect.top - offsetY) / scaleY,
        };
    }
    getSvgViewBoxTransform(svg, rect = svg.getBoundingClientRect()) {
        const viewBox = svg.viewBox.baseVal;
        const preserveAspectRatio = svg.preserveAspectRatio.baseVal;
        const scaleX = rect.width / viewBox.width;
        const scaleY = rect.height / viewBox.height;
        const SVG_PRESERVEASPECTRATIO_NONE = 1;
        const SVG_MEETORSLICE_SLICE = 2;
        if (preserveAspectRatio.align === SVG_PRESERVEASPECTRATIO_NONE) {
            return { offsetX: 0, offsetY: 0, scaleX, scaleY };
        }
        const scale = preserveAspectRatio.meetOrSlice === SVG_MEETORSLICE_SLICE ? Math.max(scaleX, scaleY) : Math.min(scaleX, scaleY);
        const renderedWidth = viewBox.width * scale;
        const renderedHeight = viewBox.height * scale;
        let offsetX = 0;
        let offsetY = 0;
        const align = preserveAspectRatio.align;
        if (align === 3 || align === 6 || align === 9) {
            offsetX = (rect.width - renderedWidth) / 2;
        }
        else if (align === 4 || align === 7 || align === 10) {
            offsetX = rect.width - renderedWidth;
        }
        if (align === 5 || align === 6 || align === 7) {
            offsetY = (rect.height - renderedHeight) / 2;
        }
        else if (align === 8 || align === 9 || align === 10) {
            offsetY = rect.height - renderedHeight;
        }
        return { offsetX, offsetY, scaleX: scale, scaleY: scale };
    }
    getProximityThresholdForEvent(state, evt) {
        const baseThreshold = state.mode === TraceMode.FreeTrace || state.mode === TraceMode.BlindFreeTrace ? state.freeTraceProximityThreshold : state.proximityThreshold;
        if ((evt === null || evt === void 0 ? void 0 : evt.pointerType) !== 'touch' || !state.svg) {
            return baseThreshold;
        }
        const rect = state.svg.getBoundingClientRect();
        const viewBox = state.svg.viewBox.baseVal;
        if (!rect.width || !rect.height || !viewBox.width || !viewBox.height) {
            return baseThreshold;
        }
        const { scaleX, scaleY } = this.getSvgViewBoxTransform(state.svg, rect);
        const touchTargetInSvgUnits = 44 * Math.max(1 / scaleX, 1 / scaleY);
        return Math.max(baseThreshold, touchTargetInSvgUnits);
    }
    // Calculate the squared Euclidean distance between two points
    getDistanceSquared(p1, p2) {
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        return dx * dx + dy * dy;
    }
    // Find the closest point on the given path to the specified point using two-pass sampling (optimized)
    getClosestPointOnPath(pathNode, point, lastLength) {
        var _a;
        const pathLength = (_a = pathNode._lidoTraceLength) !== null && _a !== void 0 ? _a : pathNode.getTotalLength();
        const samples = pathNode._lidoTraceSamples;
        const sampleStep = pathNode._lidoTraceSampleStep;
        if ((samples === null || samples === void 0 ? void 0 : samples.length) && sampleStep) {
            const searchWindow = lastLength === undefined ? pathLength : 150;
            const searchStart = lastLength === undefined ? 0 : Math.max(0, lastLength - searchWindow);
            const searchEnd = lastLength === undefined ? pathLength : Math.min(pathLength, lastLength + searchWindow);
            let nearest = samples[Math.max(0, Math.min(samples.length - 1, Math.round((lastLength || 0) / sampleStep)))];
            let nearestDistance = Infinity;
            for (const sample of samples) {
                if (sample.length < searchStart || sample.length > searchEnd)
                    continue;
                const distance = this.getDistanceSquared(point, sample);
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearest = sample;
                }
            }
            // Refine only around the cached winner. This keeps the path accurate
            // while reducing hot-path geometry calls from roughly 50 to a handful.
            const refinementStep = 6;
            const refineStart = Math.max(searchStart, nearest.length - sampleStep);
            const refineEnd = Math.min(searchEnd, nearest.length + sampleStep);
            let closestPoint = Object.assign({}, nearest);
            let minDistanceSquared = nearestDistance;
            for (let length = refineStart; length <= refineEnd; length += refinementStep) {
                const candidate = pathNode.getPointAtLength(length);
                const distance = this.getDistanceSquared(point, candidate);
                if (distance < minDistanceSquared) {
                    minDistanceSquared = distance;
                    closestPoint = { x: candidate.x, y: candidate.y, length };
                }
            }
            return closestPoint;
        }
        let closestPoint = { x: 0, y: 0, length: 0 };
        let minDistanceSquared = Infinity;
        const coarseStep = 40;
        const fineStep = 6;
        //  dynamic search window (prevents jump)
        const SEARCH_WINDOW = 150;
        let searchStart = 0;
        let searchEnd = pathLength;
        // If lastLength exists → restrict search (smooth tracing)
        if (lastLength !== undefined) {
            searchStart = Math.max(0, lastLength - SEARCH_WINDOW);
            searchEnd = Math.min(pathLength, lastLength + SEARCH_WINDOW);
        }
        let coarseClosest = { x: 0, y: 0, length: searchStart };
        for (let i = searchStart; i <= searchEnd; i += coarseStep) {
            const pt = pathNode.getPointAtLength(i);
            const dist = this.getDistanceSquared(point, pt);
            if (dist < minDistanceSquared) {
                minDistanceSquared = dist;
                coarseClosest = { x: pt.x, y: pt.y, length: i };
            }
        }
        const fineStart = Math.max(0, coarseClosest.length - coarseStep);
        const fineEnd = Math.min(pathLength, coarseClosest.length + coarseStep);
        minDistanceSquared = Infinity;
        for (let i = fineStart; i <= fineEnd; i += fineStep) {
            const pt = pathNode.getPointAtLength(i);
            const dist = this.getDistanceSquared(point, pt);
            if (dist < minDistanceSquared) {
                minDistanceSquared = dist;
                closestPoint = { x: pt.x, y: pt.y, length: i };
            }
        }
        return closestPoint;
    }
    // Load the next or previous SVG based on the isNext flag
    async loadAnotherSVG(state, isNext) {
        state.isDragging = false;
        try {
            if (state.svg) {
                this.cleanupPreviousSVG(state);
            }
            const svgText = await this.fetchSVG(convertUrlToRelative(this.svgSource.split(';').map(s => s.trim())[this.currentSvgIndex]));
            this.insertSVG(svgText);
            state.svg = this.getSVGElement();
            if (this.mode === TraceMode.BlindTracing || this.mode === TraceMode.BlindFreeTrace) {
                //make image in the svg style as display none
                state.svg.querySelectorAll('image').forEach(img => {
                    img.style.display = 'none';
                });
            }
            state.paths = this.getPaths(state.svg);
            this.setupDrawingPath(state);
            this.setupDraggableCircle(state);
            this.addEventListeners(state);
        }
        catch (error) {
            console.error(`Error loading SVG (${this.svgSource}):`, error);
        }
    }
    // Cleanup previous SVG's elements and state
    cleanupPreviousSVG(state) {
        var _a, _b;
        if (state.circle) {
            (_a = state.svg) === null || _a === void 0 ? void 0 : _a.removeChild(state.circle);
            state.circle = null;
        }
        const indicators = (_b = state.svg) === null || _b === void 0 ? void 0 : _b.querySelectorAll('.lido-flow-indicator');
        indicators.forEach(indicator => {
            indicator.remove(); // Remove all previous flow indicators
        });
        state.currentPathIndex = 0;
        state.lastLength = 0;
        state.totalPathLength = state.paths[0].getTotalLength();
        this.hideFingerHint();
        this.resetIdleTimer(state);
    }
    // Move to the next path in the SVG
    async moveToNextPath(state) {
        var _a, _b;
        state.isDragging = false;
        state.currentPathIndex++;
        state.lastLength = 0;
        state.isCompletingPath = false;
        this.hideFingerHint(); // remove hint when changing path
        if (state.currentPathIndex >= state.paths.length) {
            this.moveToNextContainer();
            return;
        }
        const nextPath = state.paths[state.currentPathIndex];
        if (!nextPath) {
            console.error('No valid path found at the next index');
            return;
        }
        state.totalPathLength = nextPath.getTotalLength();
        const startPoint = nextPath.getPointAtLength(0);
        (_a = state.circle) === null || _a === void 0 ? void 0 : _a.setAttribute('cx', startPoint.x.toString());
        (_b = state.circle) === null || _b === void 0 ? void 0 : _b.setAttribute('cy', startPoint.y.toString());
        if (state.mode === TraceMode.ShowFlow) {
            state.flowMarkers = this.createFlowMarkersForPath(nextPath);
        }
        this.resetIdleTimer(state);
    }
    async playTraceAnimation() {
        const el = document.getElementById(this.id);
        if (!el)
            return;
        el.classList.add('trace-animate');
        // Wait for the animation to finish (500ms)
        await new Promise(resolve => setTimeout(resolve, 500));
        el.classList.remove('trace-animate');
    }
    async highlightLetter(index) {
        const container = document.getElementById(LidoContainer);
        if (!container)
            return;
        const traceElement = this.el;
        if (!traceElement)
            return;
        // Ensure highlightTextId is set
        const textId = this.highlightTextId;
        if (!textId)
            return;
        // Find the lido-text element by id
        const textElem = document.getElementById(textId);
        if (!textElem)
            return;
        // Extract audio URLs from the trace element's audio attribute
        const audioList = this.audio;
        if (!audioList)
            return;
        this.audioUrls = audioList.split(';').map(s => s.trim());
        // Check if the textElem has a span-type attribute
        const spanType = textElem.getAttribute('span-type');
        if (!spanType)
            return;
        // Find the .lido-text-content container inside lido-text
        const content = textElem.querySelector('.lido-text-content');
        if (!content)
            return;
        if (spanType === 'letters') {
            const letters = content.querySelectorAll('.text-letters');
            if (index < 0 || index >= letters.length)
                return;
            // Highlight the current letter keeping the previous ones highlighted
            const letter = letters[index];
            if (letter) {
                const svgContainer = traceElement.querySelector('#lido-svgContainer');
                await executeActions("this.alignMatch='true';", textElem, svgContainer);
                svgContainer.style.animation = 'trace-animation 0.4s forwards';
                svgContainer.style.setProperty('--trace-width', `${letter.offsetWidth - 5}px`);
                svgContainer.style.setProperty('--trace-height', `${letter.offsetHeight - 5}px`);
                await executeActions("this.alignMatch='true';", letter, svgContainer);
                setTimeout(() => {
                    letter.classList.add('letter-highlight');
                    svgContainer.style.transform = '';
                    svgContainer.style.animation = '';
                    svgContainer.style.visibility = 'hidden';
                }, 500);
                if (this.audioUrls[this.currentSvgIndex]) {
                    const audio = new Audio(convertUrlToRelative(this.audioUrls[this.currentSvgIndex]));
                    await audio.play();
                }
            }
        }
        if (spanType === 'words') {
            const words = content.querySelectorAll('.text-words');
            if (index < 0 || index >= words.length)
                return;
            // Highlight the current word keeping the previous ones highlighted
            const word = words[index];
            if (word) {
                word.classList.add('word-highlight');
                if (this.audioUrls[this.currentSvgIndex]) {
                    const audio = new Audio(convertUrlToRelative(this.audioUrls[this.currentSvgIndex]));
                    await audio.play();
                }
            }
        }
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            // position: 'absolute',
        };
    }
    render() {
        return (h(Host, { key: '07506adee10b4f0348ba7b7c4d0f338d7e61cfd9', class: "lido-trace", id: this.id, audio: this.audio, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, tabindex: this.tabIndex, "disable-speak": this.disableSpeak }, h("div", { key: '9b3c311582a7246cded868234a47293ae78a3932', style: this.style, id: "lido-svgContainer" })));
    }
    static get assetsDirs() { return ["assets"]; }
    get el() { return getElement(this); }
    static get watchers() { return {
        "svgSource": [{
                "initializeSVG": 0
            }],
        "mode": [{
                "initializeSVG": 0
            }]
    }; }
};
LidoTrace.style = lidoTraceCss();

export { LidoTrace as lido_trace };
