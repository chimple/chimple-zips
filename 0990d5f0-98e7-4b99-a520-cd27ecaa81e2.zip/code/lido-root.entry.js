import { r as registerInstance, a as getAssetPath, h } from './index-f3zQbgzu.js';
import { i as instance } from './i18n-CCzaXRoU.js';

const LidoRoot = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Language to apply to all texts */
        this.Lang = '';
        /**
         * Prop to hold the XML file path or URL. This can be a relative path or an external URL.
         */
        this.xmlPath = '';
        /**
         * Initial index of the container being displayed.
         */
        this.initialIndex = 0;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Boolean that controls the playability of the game.
         */
        this.canplay = true;
        /**
         * Base URL for the containers.
         */
        this.baseUrl = '';
        /**
         * ZIP URL pointing to a package containing XML and asset files.
         */
        this.zipUrl = '';
    }
    /**
     * Lifecycle method that runs before the component is loaded.
     * It fetches the XML data from the specified path or URL and sets it to the component's state.
     */
    connectedCallback() {
        this.setLanguage(this.Lang);
    }
    onLangChange(newLang) {
        this.setLanguage(newLang);
    }
    setLanguage(lang) {
        const effectiveLang = lang || instance.language;
        instance.changeLanguage(effectiveLang);
    }
    async componentWillLoad() {
        var _a, _b;
        // If a ZIP URL is provided, we will load XML from the ZIP rather than fetching an external xmlPath.
        if (this.zipUrl) {
            this.xmlData = '';
            return;
        }
        const xmlPath = (_a = this.xmlPath) !== null && _a !== void 0 ? _a : this.baseUrl + (((_b = this.baseUrl) === null || _b === void 0 ? void 0 : _b.endsWith('/')) ? 'index.xml' : '/index.xml');
        // Fetch the XML data
        try {
            const resolvedPath = xmlPath.startsWith('http')
                ? xmlPath // Use the provided URL if it's an HTTP/HTTPS link
                : getAssetPath(xmlPath); // Otherwise, resolve it as an asset path
            const response = await fetch(resolvedPath);
            if (!response.ok) {
                throw new Error(`Failed to fetch XML data: ${response.statusText}`);
            }
            const data = await response.text();
            // Store the XML data in the component's state
            this.xmlData = data;
        }
        catch (error) {
            console.error('Error fetching XML data:', error);
            this.xmlData = null;
        }
    }
    render() {
        // Show a loading message until the XML data is fetched
        if (this.xmlData === undefined) {
            return h("div", null, "Loading...");
        }
        // Show an error message if the XML data could not be fetched
        if (this.xmlData === null) {
            return h("div", null, "Error loading XML data. Please check the path or URL.");
        }
        // Once the XML data is loaded, pass it to the `lido-home` component
        return (h("lido-home", Object.assign({ showNav: true, activeContainerIndexes: [], initialIndex: this.initialIndex, canplay: this.canplay, xmlData: this.xmlData, baseUrl: this.baseUrl }, (this.zipUrl ? { zipUrl: this.zipUrl } : {}), { exitButtonUrl: this.exitButtonUrl, prevButtonUrl: this.prevButtonUrl, nextButtonUrl: this.nextButtonUrl, speakerButtonUrl: this.speakerButtonUrl })));
    }
    static get assetsDirs() { return ["assets"]; }
    static get watchers() { return {
        "Lang": [{
                "onLangChange": 0
            }]
    }; }
};

export { LidoRoot as lido_root };
