import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { y as initEventsForElement, F as handlingChildElements, H as attachSpeakIcon, k as convertUrlToRelative, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoColCss = () => `.lido-col{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);padding:15px;border-radius:10px;display:flex;justify-content:space-around;flex-direction:column;align-items:center}.lido-col>*{}`;

const LidoCol = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * This lifecycle hook is called after the component is rendered in the DOM.
     * It initializes events for the column based on the provided type.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const borderImg = this.borderImage ? convertUrlToRelative(this.borderImage) : '';
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: this.visible ? 'flex' : 'none', // Toggle visibility
            flexDirection: !this.direction ? 'column' : parseProp(this.direction, orientation),
            borderImage: `url(${borderImg})`,
            borderImageSlice: borderImg ? '0 fill' : '',
            boxShadow: this.boxShadow ? this.boxShadow : 'unset',
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: '334206d6054442fec787cfb479a68ae164404730', id: this.id, class: "lido-col", type: this.type, "tab-index": this.tabIndex, value: this.value, style: this.style, minDrops: this.minDrops, maxDrops: this.maxDrops, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: '590cd219bc5a02e6b96eafe108fb8b310daf941d' })));
    }
    get el() { return getElement(this); }
};
LidoCol.style = lidoColCss();

export { LidoCol as lido_col };
