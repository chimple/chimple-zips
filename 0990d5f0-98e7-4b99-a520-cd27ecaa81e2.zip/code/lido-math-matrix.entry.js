import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { y as initEventsForElement, k as convertUrlToRelative, l as LidoContainer, z as parseProp, B as equationCheck, C as storingEachActivityScore, W as validateObjectiveStatus } from './utils-Zx3fBgtB.js';

const lidoMathMatrixCss = () => `.math-matrix{width:100%;height:100%;display:flex;justify-content:center}.slot{width:100%;height:100%;text-align:center;align-content:center;font-size:42px;font-weight:800;font-family:'Baloo Bhai 2';box-sizing:content-box}.slot:hover{opacity:0.7}.slot-parent{width:100%;height:100%;display:flex;justify-content:center;align-items:center;flex-direction:column}.slot-active{background-color:var(--active-bg-color);background-image:var(--bg-image);background-size:contain;background-position:center;background-repeat:no-repeat}.slot-inactive{background-color:var(--deactive-bg-color);background-size:cover;background-position:center;background-repeat:no-repeat}.topIndex,.leftIndex,.bottomIndex{height:100%;width:100%;text-align:center;align-content:center;font-size:30px;font-weight:600;font-family:'Baloo Bhai 2'}`;

const LidoMathMatrix = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Number of rows in the matrix */
        this.rows = "10";
        /** Number of columns in the matrix */
        this.cols = "10";
        /** Number of slots to pre-fill as active by default */
        this.defualtFill = 0;
        /** Show row index numbers on the left side */
        this.leftIndex = false;
        /** Show column index numbers on the top side */
        this.topIndex = false;
        /** Show row index numbers on the bottom side */
        this.bottomIndex = false;
        /** Enable/disable click interactions on the slots */
        this.clickable = true;
        /** If true, only active slots are visible; inactive ones are hidden */
        this.activeOnlyVisible = false;
        /** Background color for active slots */
        this.activeBgColor = 'transparent';
        this.deactiveBgColor = 'transparent';
        /** Border style applied to each slot */
        this.border = '2px solid green';
        /** Height of the slot container */
        this.height = '100%';
        /** Width of the slot container */
        this.width = '100%';
        /** Border radius for each slot */
        this.borderRadius = '5px';
        /** Controls the visibility of the matrix (accepts "true" or "false" as string) */
        this.visible = 'false';
        /** Tracks the previously filled slot index to clear it when a new slot is clicked */
        this.previousFilledSlot = -1;
        /** Reference to the previously filled slot element for clearing its text */
        this.previousFilledSlotElement = null;
        /** Holds dynamically generated inline styles for the container */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    updateValue(index) {
        this.el.setAttribute('value', index);
    }
    componentDidLoad() {
        const slotElements = this.el.querySelectorAll('.slot');
        initEventsForElement(this.el, this.type);
        slotElements.forEach((el, i) => {
            const slot = el;
            slot.style.setProperty('--active-bg-color', this.activeBgColor);
            slot.style.setProperty('--deactive-bg-color', this.deactiveBgColor);
            this.clickable ? (slot.style.pointerEvents = '') : (slot.style.pointerEvents = 'none');
            slot.style.border = this.border;
            slot.style.color = this.fontColor;
            if (slot.className.includes('slot-active')) {
                slot.style.visibility = '';
                if (this.matrixImage) {
                    slot.style.setProperty('--bg-image', `url(${convertUrlToRelative(this.matrixImage)})`);
                }
            }
            else if (this.activeOnlyVisible) {
                slot.style.visibility = 'hidden';
            }
        });
        this.updateSlots();
        this.updateStyles();
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        this.updateSlots();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateSlots() {
        const slotElement = this.el.querySelectorAll('.slot');
        const fristElement = this.el.querySelector('.slot');
        if (!slotElement.length || !fristElement)
            return;
        const container = document.getElementById(LidoContainer);
        let numOfRows = this.rows;
        let numOfCols = this.cols;
        if (container && container.getAttribute("template-id") === "multiplyBeeds") {
            numOfCols = "9";
            numOfRows = "1";
        }
        const elementSize = Number(numOfRows) < Number(numOfCols) ? this.el.offsetHeight : this.el.offsetWidth;
        const numberOfSlots = Number(numOfRows) > Number(numOfCols) ? Number(numOfRows) : Number(numOfCols);
        const slotParent = this.el.querySelectorAll('.slot-parent');
        const slotMaxValues = elementSize / numberOfSlots;
        slotParent.forEach(parent => {
            parent.style.width = `${slotMaxValues}px`;
            Array.from(parent.children).forEach(el => {
                const item = el;
                item.style.width = `${slotMaxValues}px`;
                item.style.height = `${slotMaxValues}px`;
                if (this.type === 'drop' || this.type === 'drag' || this.type === 'checkerBlock') {
                    this.el.style.width = 'auto';
                    this.el.style.height = 'auto';
                }
                if ((!this.topIndex && item.classList.contains('topIndex')) ||
                    (!this.leftIndex && item.classList.contains('leftIndex')) ||
                    (!this.bottomIndex && item.classList.contains('bottomIndex'))) {
                    if (item.classList.contains('leftIndex'))
                        item.parentElement.remove();
                    item.remove();
                }
            });
        });
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'flex' : 'none',
            borderRadius: parseProp(this.borderRadius, orientation),
            left: parseProp(this.x, orientation),
            top: parseProp(this.y, orientation),
            cols: parseProp(`${this.cols}`, orientation),
            rows: parseProp(`${this.rows}`, orientation),
        };
    }
    handleClickSlot(element) {
        const index = parseInt(element.className.split(' ')[1].split('-')[1]);
        const slotElements = this.el.querySelectorAll('.slot');
        slotElements.forEach((el, i) => {
            const slotEl = el;
            if (i < index) {
                slotEl.classList.add('slot-active');
                slotEl.classList.remove('slot-inactive');
                if (this.matrixImage) {
                    slotEl.style.setProperty('--bg-image', `url(${convertUrlToRelative(this.matrixImage)})`);
                }
            }
            else {
                slotEl.classList.remove('slot-active');
                slotEl.classList.add('slot-inactive');
            }
        });
        if (this.previousFilledSlot !== -1) {
            // Clear the text from the previously filled slot
            if (this.previousFilledSlotElement !== null) {
                this.previousFilledSlotElement.textContent = '';
            }
        }
        // Display the slot value/text on the clicked slot itself
        element.textContent = index.toString();
        // Track this slot as the previously filled slot for next click
        this.previousFilledSlot = index;
        this.previousFilledSlotElement = element;
        // If the slot is the bottom-most slot for this matrix, dispatch a generic event
        // so templates or global handlers can handle bottom-slot behaviour (e.g., MultiplyBeadsAnimation).
        if (index === slotElements.length) {
            try {
                const event = new CustomEvent('math-matrix-bottom-click', {
                    detail: {
                        matrix: this.el,
                        cols: this.style.cols,
                        rows: this.style.rows,
                    },
                    bubbles: true,
                    composed: true,
                });
                // dispatch from the host so listeners on container or document receive it
                this.el.dispatchEvent(event);
            }
            catch (err) {
                console.warn('Error dispatching math-matrix-bottom-click from handleClickSlot', err);
            }
        }
        this.updateValue(index.toString());
        const container = document.getElementById(LidoContainer);
        const isWriteSetGrid = this.clickable &&
            this.type === 'checkerBlock' &&
            this.el.id === 'mat1' &&
            !!(container === null || container === void 0 ? void 0 : container.getAttribute('equationCheck'));
        if (isWriteSetGrid && container) {
            const result = !!equationCheck(container.getAttribute('equationCheck'));
            console.log('Write Set checkerBlock click:', { result });
            storingEachActivityScore(result);
        }
        // trigger the next container if right slot was clicked
        validateObjectiveStatus();
    }
    getSlotData() {
        const data = {};
        if (!this.text)
            return data;
        this.text.split(',').forEach((item, index) => {
            const [rawText, rawColor] = item.split('-');
            const num = parseInt(rawText.trim());
            if (!isNaN(num)) {
                data[index] = { text: rawText.trim(), color: rawColor === null || rawColor === void 0 ? void 0 : rawColor.trim() };
            }
        });
        return data;
    }
    render() {
        let slotNumber = 1;
        const slotData = this.getSlotData();
        return (h(Host, { key: '8a17727416da00fda95c401c3a005cdea1e732d0', class: "math-matrix", style: {
                height: this.style.height,
                width: this.style.width,
                z: this.style.z,
                display: this.style.display,
                top: this.style.top,
                left: this.style.left,
            }, type: this.type, value: this.value, "tab-index": this.tabIndex, rows: this.style.rows, cols: this.style.cols, text: this.text, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, Array.from({ length: parseInt(this.style.rows) + 1 }, (_, rowIndex) => (h("div", { class: "slot-parent", key: `row-${rowIndex}` }, h("div", { style: rowIndex === 0 && { visibility: 'hidden' }, class: "topIndex" }, rowIndex), Array.from({ length: parseInt(this.style.cols) }, (_, colIndex) => {
            var _a, _b;
            return rowIndex === 0 ? (h("div", { class: "leftIndex" }, ++colIndex)) : (h("div", { class: `slot slot-${slotNumber} ${this.defualtFill >= slotNumber ? 'slot-active' : 'slot-inactive'}`, onClick: (ev) => this.handleClickSlot(ev.currentTarget), key: `slot-${rowIndex}-${colIndex}`, style: {
                    borderRadius: this.style.borderRadius,
                    backgroundColor: ((_a = slotData[slotNumber - 1]) === null || _a === void 0 ? void 0 : _a.color) || '',
                } }, (_b = slotData[slotNumber - 1]) === null || _b === void 0 ? void 0 :
                _b.text, slotNumber++ && null));
        }), h("div", { style: rowIndex === 0 && { visibility: 'hidden' }, class: "bottomIndex" }, parseInt(this.style.cols) * rowIndex))))));
    }
    get el() { return getElement(this); }
};
LidoMathMatrix.style = lidoMathMatrixCss();

export { LidoMathMatrix as lido_math_matrix };
