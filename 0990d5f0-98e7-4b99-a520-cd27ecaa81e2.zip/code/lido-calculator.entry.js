import { r as registerInstance, f as createEvent, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { B as equationCheck, S as SelectedValuesKey, C as storingEachActivityScore, D as CalculatorOk, A as AudioPlayer, q as executeActions, E as calculateScore, u as triggerNextContainer, k as convertUrlToRelative } from './utils-Zx3fBgtB.js';

const lidoCalculatorCss = () => `#lidoCalculator{border-radius:19px;border:5px solid #029A9A;position:relative;display:flex;flex-direction:column;padding:2%;box-sizing:border-box}.lido-calculator-btn-special{--btn-bg-color:#014D4D !important;background-color:#014D4D !important;--btn-shadow-color:#0a2f2f !important}.lido-calculator-btn-default{--btn-bg-color:#029A9A !important;background-color:#029A9A !important;color:#000;--btn-shadow-color:#0f4242 !important}#lido-calculator-penIcon{--btn-bg-color:#FB7038 !important;--btn-shadow-px:0 8px 0 !important;--btn-shadow-color:#D74B12 !important;border-radius:5px !important}.lido-calculator-displayParent{width:89%;height:107px;background-color:rgb(68, 186, 186);border-radius:5px;margin:14px auto 17px auto;overflow:hidden;display:flex;align-items:end}.lido-calculator-display{width:97%;height:94px;background:#029A9A;color:#fff;text-align:right;display:flex;justify-content:flex-end;align-items:center;font-size:72px;font-weight:700;font-family:'Baloo Bhai 2', serif;border-radius:5px 0px 0px 5px;box-sizing:border-box;margin:0 0px -6px auto}.lido-calculator-buttons{flex:1;display:grid;grid-template-columns:repeat(3, 1fr);grid-auto-rows:1fr;gap:0%;width:100%;justify-items:center;align-items:center;position:relative;top:-1%}.lido-calculator-buttons lido-text{display:flex !important;justify-content:center;align-items:center;width:100px !important;height:88px !important;font-size:80px !important;font-weight:700 !important;color:#fff;border-radius:5px !important;cursor:pointer;text-align:center;line-height:1;box-sizing:border-box;transition:transform 0.1s}.lido-calculator-buttons lido-text:active{transform:scale(0.95)}`;

const LidoCalculator = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        this.onOk = createEvent(this, "onOk", 7);
        /** Width of the calculator component (default: '479px') */
        this.width = '479px';
        /**
          * Controls component visibility.
          * Accepts boolean (`true`/`false`) or string ("true"/"false").
        */
        this.visible = false;
        /** Height of the calculator component (default: '711px') */
        this.height = '711px';
        /** Objective or identifier for activity-based logic or validation */
        this.objective = '';
        /** Code or actions to execute when the component is first rendered */
        this.onEntry = '';
        /** X-position of the calculator (can be px, %, etc.) */
        this.x = '0px';
        /** Y-position of the calculator (can be px, %, etc.) */
        this.y = '0px';
        /** Background color for the calculator container */
        this.bgColor = '#60DADA';
        /** Icon URL for the pen image shown on the calculator UI */
        this.penIcon = '';
        /** Current display value shown in the calculator screen */
        this.displayValue = '';
        /** Inline style object for dynamic positioning and layout control */
        this.style = {};
        this.userAnswers = []; // store all calculator inputs
        this.tempInputs = []; // store inputs before clearing display
    }
    updateValueAttr() {
        this.el.setAttribute('value', this.displayValue);
    }
    componentWillLoad() {
        if (!this.objective) {
            const container = this.el.closest('lido-container');
            if (container) {
                this.objective = (container.getAttribute('objective') || '').replace('=', '').trim();
            }
        }
        this.updateValueAttr();
    }
    handleClick(value) {
        const MAX_LENGTH = 8;
        if (value === 'OK') {
            this.verifyAnswer();
        }
        else if (value === '←') {
            this.displayValue = this.displayValue.slice(0, -1);
        }
        else {
            if (this.displayValue.length < MAX_LENGTH) {
                this.displayValue += value;
            }
        }
        this.updateValueAttr();
    }
    async verifyAnswer() {
        var _a;
        const userInput = this.displayValue.trim();
        if (!userInput)
            return;
        let isCorrect = false;
        const container = this.el.closest('lido-container');
        if (!container)
            return;
        if (this.objective && this.objective != '' && !this.objective.includes(',')) {
            isCorrect = Number(userInput) === Number(this.objective);
        }
        // --- Multiple Objectives ---
        else if (this.objective && this.objective.includes(',')) {
            const isContinueOnCorrect = container.getAttribute('is-continue-on-correct') === 'true';
            const objectives = this.objective.split(',').map(obj => obj.trim());
            const currentIndex = this.userAnswers.length;
            // Compare current input with corresponding objective 
            if (currentIndex < objectives.length && Number(userInput) === Number(objectives[currentIndex])) {
                isCorrect = true;
            }
            else {
                // isCorrect = false; 
            }
            //  Store behavior based on mode
            if (isContinueOnCorrect) {
                // PRACTICE MODE → store only correct answers 
                if (isCorrect) {
                    this.userAnswers.push(Number(userInput));
                }
            }
            else {
                // TEST MODE → store all user inputs 
                this.userAnswers.push(Number(userInput));
            }
        }
        else if (this.objective === '') {
            const equationAttr = container.getAttribute('equationCheck') || '';
            if (!equationAttr)
                return;
            try {
                const calculatedValue = equationCheck(equationAttr);
                isCorrect = Number(calculatedValue) === Number(userInput.trim());
            }
            catch (err) {
                console.error('Error evaluating equation:', err);
                isCorrect = false;
            }
        }
        this.onOk.emit(isCorrect);
        const okbtn = document.getElementById("btn-11");
        if (isCorrect) {
            const isNimbleTable = container.getAttribute('template-id') === 'nimbleTable';
            const isMultiObjective = this.objective.includes(',');
            if (!(isNimbleTable && isMultiObjective)) {
                container.setAttribute("game-completed", "true");
            }
            this.tempInputs.push(userInput);
            const existingSelected = JSON.parse((_a = container.getAttribute(SelectedValuesKey)) !== null && _a !== void 0 ? _a : '[]');
            const cleanedSelected = Array.isArray(existingSelected)
                ? existingSelected.filter(v => String(v).trim() !== '')
                : [];
            const tempValue = this.tempInputs[this.tempInputs.length - 1];
            if (String(tempValue).trim() !== '') {
                cleanedSelected.push(tempValue);
            }
            container.setAttribute(SelectedValuesKey, JSON.stringify(cleanedSelected));
            okbtn.style.pointerEvents = 'none'; // Disable OK button to prevent multiple clicks
            this.displayValue = "";
            storingEachActivityScore(isCorrect, CalculatorOk);
            if (isNimbleTable && isMultiObjective) {
                const activeCell = container.querySelector("[type='calculate']");
                if (activeCell) {
                    const activeCellAudio = activeCell.getAttribute('audio') || '';
                    if (activeCellAudio.trim()) {
                        activeCell.style.boxShadow = 'none !important';
                        activeCell.setAttribute('onCorrect', "this.speak='true'");
                        AudioPlayer.getI().play(activeCell);
                    }
                }
            }
            const onCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onCorrect')) || '';
            await executeActions(onCorrect, container);
            const hasScrollAction = onCorrect.includes('scrollCellAfterEquationSolved');
            if (!hasScrollAction) {
                if (!isMultiObjective) {
                    calculateScore();
                    triggerNextContainer();
                }
                else {
                    const objectives = this.objective.split(',').map(obj => obj.trim());
                    const allSolved = this.userAnswers.length >= objectives.length;
                    if (allSolved) {
                        container.setAttribute("game-completed", "true");
                        calculateScore();
                        triggerNextContainer();
                    }
                }
            }
        }
        else {
            okbtn.style.pointerEvents = 'none'; // Disable OK button to prevent multiple clicks
            this.displayValue = "";
            storingEachActivityScore(isCorrect, CalculatorOk);
            const onInCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onInCorrect')) || '';
            const onCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onCorrect')) || '';
            const isContinueOnCorrect = container.getAttribute('is-continue-on-correct') === 'true';
            if (!isContinueOnCorrect) {
                await executeActions(onCorrect, container);
            }
            else {
                await executeActions(onInCorrect, container);
            }
            if (!isContinueOnCorrect) {
                container.setAttribute("game-completed", "true");
                calculateScore();
                triggerNextContainer();
            }
        }
        okbtn.style.pointerEvents = 'auto'; // Re-enable OK button after processing
    }
    render() {
        const numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '←', '0', 'OK'];
        return (h(Host, { key: 'e8249dda090212d327b68b47d42a123de6a890c9', onEntry: this.onEntry, id: "lidoCalculator", style: { width: this.width, height: this.height, backgroundColor: this.bgColor, left: this.x, top: this.y } }, h("lido-cell", { key: '54d093a3dd6a6e5850c881d224290bd6cf9c3690', visible: "true", height: "94px", width: "60px" }, h("lido-text", { key: '7145c80b2477493a8a87f6d098164293732861bf', visible: "true", id: "lido-calculator-penIcon", type: "click", height: "80px", x: "204%", width: "89px", onEntry: "this.position='relative';", class: "top-icon" }, h("img", { key: '7242feedd5172b555df683c747bbef778a9cdcd7', src: convertUrlToRelative(this.penIcon), alt: "pen", style: { width: '100%', height: '100%' } }))), h("div", { key: '6145a4f89da352c3576e6d51a1e260e335778fbb', class: "lido-calculator-displayParent" }, h("div", { key: '04e07b724d912d43b08c7a1e15c605d0fd30c7be', class: "lido-calculator-display" }, this.displayValue)), h("div", { key: '19839d02863ca1e27fddb4093f191171e237f143', class: "lido-calculator-buttons" }, numbers.map((num, i) => (h("lido-text", { id: `btn-${i}`, string: num, visible: "true", type: "click", class: {
                'lido-calculator-btn-special': num === '←' || num === 'OK',
                'lido-calculator-btn-default': num !== '←' && num !== 'OK'
            }, onClick: () => this.handleClick(num) }))))));
    }
    get el() { return getElement(this); }
};
LidoCalculator.style = lidoCalculatorCss();

export { LidoCalculator as lido_calculator };
