import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { z as parseProp } from './utils-Zx3fBgtB.js';

const lidoCanvasCss = () => `:host{box-sizing:border-box}.lido-canvas{background:transparent;border:none;border-radius:0;overflow:hidden;box-sizing:border-box}#lido-exit-button{padding:6px 14px;border:none;background:transparent;color:#fff;border-radius:6px;cursor:pointer;font-size:14px;position:absolute;top:0;right:0;z-index:15}canvas{touch-action:none;display:block;width:100%;height:100%;z-index:10}`;

const LidoCanvas = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        //  Width of the canvas containe
        this.width = '800px';
        // Height of the canvas container
        this.height = '700px';
        // Controls component visibility
        this.visible = false;
        // Z-index for stacking order
        this.z = '0';
        // X-offset position for the canvas
        this.x = '0px';
        // y-offset position for the canvas
        this.y = '0px';
        // Actions to execute when component loads
        this.onEntry = '';
        // Flag to track drawing state
        this.drawing = false;
        this.style = {};
        this.handleWindowPointerUp = () => this.stop();
        this.handleWindowResize = () => this.updateStyles();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            width: parseProp(this.width, orientation),
            height: parseProp(this.height, orientation),
            left: parseProp(this.x, orientation),
            top: parseProp(this.y, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'block' : 'none',
            position: 'absolute',
        };
        if (this.canvas) {
            this.canvas.width = parseInt(parseProp(this.width, orientation));
            this.canvas.height = parseInt(parseProp(this.height, orientation));
            this.ctx.strokeStyle = '#000';
            this.ctx.lineWidth = 10;
            this.ctx.lineCap = 'round';
            this.ctx.lineJoin = 'round';
            // this.loadBackground();
        }
    }
    componentDidLoad() {
        this.canvas = this.el.shadowRoot.querySelector('#lido-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.ctx.strokeStyle = '#000';
        this.ctx.lineWidth = 10;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.updateStyles();
        // this.loadBackground();
        this.canvas.addEventListener('pointerdown', e => this.start(e));
        this.canvas.addEventListener('pointermove', e => this.move(e));
        window.addEventListener('pointerup', this.handleWindowPointerUp);
        window.addEventListener('resize', this.handleWindowResize);
    }
    disconnectedCallback() {
        window.removeEventListener('pointerup', this.handleWindowPointerUp);
        window.removeEventListener('resize', this.handleWindowResize);
    }
    loadBackground() {
        if (!this.bgImage) {
            this.ctx.fillStyle = '#fff';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            return;
        }
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = this.bgImage;
        img.onload = () => {
            this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
        };
    }
    getPos(e) {
        const r = this.canvas.getBoundingClientRect();
        return {
            x: (e.clientX - r.left) * (this.canvas.width / r.width),
            y: (e.clientY - r.top) * (this.canvas.height / r.height),
        };
    }
    start(e) {
        this.drawing = true;
        const pos = this.getPos(e);
        this.ctx.beginPath();
        this.ctx.moveTo(pos.x, pos.y);
    }
    move(e) {
        if (!this.drawing)
            return;
        const pos = this.getPos(e);
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();
    }
    stop() {
        this.drawing = false;
        this.ctx.closePath();
    }
    clearCanvas() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    render() {
        return (h(Host, { key: '6bb47f06656ce667d23236e9f3c3a8f383885a43', id: "lido-canvas", class: "lido-canvas", style: this.style }, h("button", { key: 'fd0d1217bda63071fbf6496c2538c2a944b14181', id: "lido-exit-button", onClick: () => this.clearCanvas() }), h("canvas", { key: 'ed0333972bb7ce0fc4e14c81bb466ea895ce65e0', id: "lido-canvas" })));
    }
    get el() { return getElement(this); }
};
LidoCanvas.style = lidoCanvasCss();

export { LidoCanvas as lido_canvas };
