import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { x as setVisibilityWithDelay, y as initEventsForElement, F as handlingChildElements, H as attachSpeakIcon, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoCellCss = () => `.lido-col{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);padding:15px;border-radius:10px;display:flex;justify-content:space-around;flex-direction:column;align-items:center}.lido-col>*{}.lido-row{display:flex;justify-content:space-around;align-items:center;}.lido-row>*{}.lido-wrap{display:grid;grid-gap:10px;grid-template-columns:repeat(auto-fill, minmax(186px, auto))}.lido-wrap>*{padding:10px;box-sizing:border-box}.lido-flex{display:flex;flex-wrap:wrap;align-content:flex-start;gap:10px}.lido-pos{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);display:flex;justify-content:space-around;flex-direction:column;position:fixed}.lido-pos>*{position:absolute}.lido-random{position:relative;width:100%;height:100%}.lido-random>*{position:absolute}.lido-col::-webkit-scrollbar,.lido-wrap::-webkit-scrollbar,.lido-flex::-webkit-scrollbar{width:var(--scrollbar-width);height:var(--scrollbar-width)}.lido-col::-webkit-scrollbar-thumb,.lido-wrap::-webkit-scrollbar-thumb,.lido-flex::-webkit-scrollbar-thumb{background-color:#888;border-radius:10px;border:3px solid transparent;background-clip:content-box}.lido-col::-webkit-scrollbar-track,.lido-wrap::-webkit-scrollbar-track,.lido-flex::-webkit-scrollbar-track{background:#f1f1f1}`;

const LidoCell = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Defines the width of the scrollbar within the cell (e.g., '14px').
         * Defaults to '0px' if not specified, effectively hiding the scrollbar.
         */
        this.scrollbarWidth = '';
        /**
         * The unique identifier for the column component.
         */
        this.id = '';
        /**
         * The value associated with the column component. Typically used for internal logic.
         */
        this.value = '';
        /**
         * The height of the column component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the column component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * The x-coordinate (left position) of the column within its container (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * The y-coordinate (top position) of the column within its container (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * The z-index of the column to control stacking order.
         */
        this.z = '0';
        /**
         * The gap between child elements inside the column (CSS value, e.g., '10px', '5px 10px').
         * This is applicable when the layout is set to `wrap` or `flex`.
         */
        this.gap = '0';
        /**
         * The background color of the column (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * Defines the type of the column, which can be used for styling or specific logic handling.
         */
        this.type = '';
        /**
         * The tab index value, used to set the tab order of the column for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * A boolean that controls whether the column is visible (`true`) or hidden (`false`).
         */
        this.visible = 'false';
        /**
         * Audio file URL or identifier for sound that will be associated with the column.
         */
        this.audio = '';
        /**
         * Event handler for a touch event, where a custom function can be triggered when the column is touched.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler for when the column is entered, which can be used to initiate specific behaviors on entry.
         */
        this.onEntry = '';
        /**
         * The number of child elements that should be displayed inside the row.
         * This value is dynamically adjusted based on `minLength` and `maxLength`.
         */
        this.childElementsLength = 9999;
        /**
         * The minimum number of child elements that must be displayed inside the row.
         * If `childElementsLength` is less than this value, additional elements may be shown to meet this minimum.
         */
        this.minLength = 0;
        /**
         * The maximum number of child elements that can be displayed inside the row.
         * If `childElementsLength` exceeds this value, excess elements will be hidden.
         */
        this.maxLength = 9999;
        /**
         * Determines the layout behavior of the component's children.
         *
         * - `wrap`: Applies a grid layout to the children, allowing them to wrap automatically in a grid format.
         * - `flex`: Applies a flex layout with wrapping behavior (`flex-wrap`).
         * - `col`: Arranges children in a single column using a vertical flex direction.
         * - `row`: Arranges children in a single row using a horizontal flex direction.
         * - `pos`: Applies absolute positioning to children, allowing manual placement using `x` and `y` values.
         * - `random`: Positions child elements randomly within the container using absolute positioning.
         *
         * Default: `'wrap'`
         */
        this.layout = 'wrap';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS align-items property to control the alignment of flex items.
         * Example: 'flex-start', 'flex-end', 'center', 'baseline', 'stretch'.
         */
        this.alignItems = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * CSS flex direction for the component, which can be used to control the layout of child elements.
         * Accepts values like 'row', 'column', etc.
         */
        this.flexDirection = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
    }
    /**
     * This lifecycle hook is called after the component is rendered in the DOM.
     * It initializes events for the column based on the provided type.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        // Select all direct child elements of the component
        // const slotElements = this.el.querySelectorAll('.lido-random > *');
        // if (!slotElements) return;
        // // Iterate over each child and apply random positions
        // slotElements.forEach((child: HTMLElement) => {
        //   const randomTop = Math.random() * 100; // Random value between 0 and 100 for vertical position
        //   const randomLeft = Math.random() * 100; // Random value between 0 and 100 for horizontal position
        //   child.style.top = `${randomTop}%`;
        //   child.style.left = `${randomLeft}%`;
        // });
        setTimeout(() => {
            const check_random_attr = this.el.className.includes('lido-random') ? this.el : null;
            if (check_random_attr) {
                const parentcontainer = check_random_attr.parentElement;
                if (!parentcontainer)
                    return;
                // Get parent size
                const parentWidth = parentcontainer.offsetWidth;
                const parentHeight = parentcontainer.offsetHeight;
                // Place child elements randomly inside parent
                const children = Array.from(check_random_attr.children);
                children.forEach(child => {
                    const childWidth = child.offsetWidth;
                    const childHeight = child.offsetHeight;
                    const maxLeft = parentWidth - childWidth;
                    const maxTop = parentHeight - childHeight;
                    const randLeft = Math.random() * maxLeft;
                    const randTop = Math.random() * maxTop;
                    child.style.position = 'absolute';
                    child.style.left = `${randLeft}px`;
                    child.style.top = `${randTop}px`;
                });
            }
        }, 50);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            'height': parseProp(this.height, orientation),
            'width': parseProp(this.width, orientation),
            'backgroundColor': parseProp(this.bgColor, orientation),
            'top': parseProp(this.y, orientation),
            'left': parseProp(this.x, orientation),
            'zIndex': this.z,
            'margin': parseProp(this.margin, orientation),
            'padding': parseProp(this.padding, orientation),
            'borderRadius': parseProp(this.borderRadius, orientation),
            'gap': parseProp(this.gap, orientation),
            '--scrollbar-width': parseProp(this.scrollbarWidth || '0px', orientation),
            'display': JSON.parse(parseProp(`${this.visible}`, orientation))
                ? parseProp(this.layout, orientation) === 'wrap'
                    ? 'grid'
                    : parseProp(this.layout, orientation) === 'pos' || parseProp(this.layout, orientation) === 'random'
                        ? 'block'
                        : 'flex'
                : 'none',
            'flexDirection': this.flexDirection ? parseProp(this.flexDirection, orientation) : '',
            'alignItems': this.alignItems ? parseProp(this.alignItems, orientation) : '',
        };
        this.el.className = `lido-${parseProp(this.layout, orientation)}`;
    }
    render() {
        return (h(Host, { key: '73bdf9dd33fdd8322c35465de011697da112193a', id: this.id, class: "lido-cell", value: this.value, type: this.type, "tab-index": this.tabIndex, style: this.style, minDrops: this.minDrops, maxDrops: this.maxDrops, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "flex-direction": this.flexDirection, "disable-speak": this.disableSpeak }, h("slot", { key: '6e9d4507b36716f04853d39ef66015441782aa88' })));
    }
    get el() { return getElement(this); }
};
LidoCell.style = lidoCellCss();

export { LidoCell as lido_cell };
