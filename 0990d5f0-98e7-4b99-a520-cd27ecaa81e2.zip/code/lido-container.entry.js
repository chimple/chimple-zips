import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { I as LIDO_INTERACTION_CLEANUP_EVENT, o as TemplateID, v as calculateScale, k as convertUrlToRelative, y as initEventsForElement, J as highlightElement, K as resetFloatState, T as Timer } from './utils-Zx3fBgtB.js';
import { i as instance } from './i18n-CCzaXRoU.js';

const lidoContainerCss = () => `.lido-container{position:relative;height:100%;width:100%;background-color:var(--bgColor, transparent);display:flex;flex-direction:column;justify-content:center;align-items:center}`;

const LidoContainer = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Language to apply to all texts */
        this.Lang = '';
        /**
         * Controls whether the drop zone displays a border; true shows the border, false hides it.
         */
        this.showDropBorder = true;
        /**
         * Enables appending the dragged element to the drop target after all correct drops are completed.
         */
        this.appendToDropOnCompletion = false;
        /**
         * Unique identifier for the container.
         */
        this.id = '';
        /**
         * Objective or purpose of the container. Can be used for internal logic or tracking.
         */
        this.objective = '';
        /**
         * Custom CSS styles to be applied to the container.
         * Allows for dynamic styling through inline styles or class names.
         */
        this.customStyle = '';
        /**
         * Value assigned to the container. This can be used for logic related to this component.
         */
        this.value = '';
        /**
         * The height of the container (CSS value).
         */
        this.height = 'auto';
        /**
         * The width of the container (CSS value).
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = 'auto';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the container.
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the container.
         */
        this.y = '0px';
        /**
         * Z-index to control the stacking order of the container.
         */
        this.z = '0';
        /**
         * Background color of the container (CSS color value).
         */
        this.bgColor = '';
        /**
         * The background image URL to be applied to the entire body.
         */
        this.bgImage = '';
        /**
         * Type of the container, which can be used for conditional logic or styling purposes.
         */
        this.type = '';
        /**
         * TabIndex for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Visibility flag for the container. If `true`, the container is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier of an audio file associated with the container.
         */
        this.audio = '';
        /**
         * Event handler triggered when the container is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the container is entered, useful for triggering animations or logic.
         */
        this.onEntry = '';
        /**
         * Boolean that controls the playability of the game.
         */
        this.canplay = true;
        /**
         * Indicates whether the "Check" button should be visible or not. Expected values: "true" or "false".
         */
        this.showCheck = false;
        /**
         * Specifies whether the activity should continue automatically upon a correct response. Expected values: "true" or "false".
         */
        this.isContinueOnCorrect = false;
        /**
         * Determines if the activity should proceed automatically only after a correct response.
         * Acceptable values: "true" or "false". Defaults to "false".
         */
        this.isAllowOnlyCorrect = false;
        /**
         * Base URL for the container.
         */
        this.baseUrl = '';
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Indicates whether the previous button should be displayed. Expected values: "true" or "false".
         */
        this.showPrevButton = 'false';
        /**
         * Indicates whether the next button should be displayed. Expected values: "true" or "false".
         */
        this.showNextButton = 'false';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and all its child components.
         */
        this.disableSpeak = false;
        /**
         * Identifies the template type used by this component (e.g., mcq, flashcard, tracing, dragAndDrop).
         */
        this.templateId = '';
        /**
         * When set to true, highlights each word individually during speech playback.
         */
        this.highlightWordByWord = false;
        /**
         * Stores the instruction audio/text key based on the current template.
         */
        this.instructName = '';
        /**
         * Indicates whether the speak action is currently active or in progress.
         */
        this.speakFlag = false;
        this.handleWindowResize = () => this.scaleContainer(this.el);
        this.handleWindowLoad = () => this.scaleContainer(this.el);
    }
    cleanupInteractionHandlers() {
        this.el.querySelectorAll('[type="drag"], [type="slide"], [move="true"]').forEach(element => {
            element.dispatchEvent(new Event(LIDO_INTERACTION_CLEANUP_EVENT));
        });
    }
    languageChanged(newLang) {
        const langToApply = newLang || this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
    }
    componentWillLoad() {
        const langToApply = this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
        this.resolveInstructionAudio();
    }
    resolveInstructionAudio() {
        var _a;
        this.instructName =
            (_a = {
                flashcard: "instruction.flashcards" /* templateAudio.flashcards */,
                mcq: "instruction.mcq" /* templateAudio.mcq */,
                tracing: "instruction.tracing" /* templateAudio.tracing */,
                dragAndDrop: "instruction.dragAndDrop" /* templateAudio.dragAndDrop */,
                "arrangeLetters": "arrangeLetters" /* templateAudio.arrangeLetters */,
                "balancing": "balancing" /* templateAudio.balancing */,
                "balloonPop": "balloonPop" /* templateAudio.balloonPop */,
                "blender": "blender" /* templateAudio.blender */,
                "bubbleType": "bubbleType" /* templateAudio.bubbleType */,
                "calculator": "calculator" /* templateAudio.calculator */,
                "categorize": "categorize" /* templateAudio.categorize */,
                "checkerBlocks": "checkerBlocks" /* templateAudio.checkerBlocks */,
                "createSentence": "createSentence" /* templateAudio.createSentence */,
                "fillAnswer": "fillAnswer" /* templateAudio.fillAnswer */,
                "fillBlank": "fillBlank" /* templateAudio.fillBlank */,
                "fillUp": "fillUp" /* templateAudio.fillUp */,
                "flashcardtemplate": "flashcard" /* templateAudio.flashcardtemplate */,
                "foodJar": "foodJar" /* templateAudio.foodJar */,
                "grid": "grid" /* templateAudio.grid */,
                "imageMatchWithQuestionImageAndMultiOption": "imageMatchWithQuestionImageAndMultiOption" /* templateAudio.imageMatchWithQuestionImageAndMultiOption */,
                "inventedSpelling": "inventedSpelling" /* templateAudio.inventedSpelling */,
                "jumpSentence": "jumpSentence" /* templateAudio.jumpSentence */,
                "letterBoard": "letterBoard" /* templateAudio.letterBoard */,
                "letterIdentification": "letterIdentification" /* templateAudio.letterIdentification */,
                "letterPairing": "letterPairing" /* templateAudio.letterPairing */,
                "makeSentence": "makeSentence" /* templateAudio.makeSentence */,
                "matchingCard": "matchingCard" /* templateAudio.matchingCard */,
                "multiplyBeeds": "multiplyBeeds" /* templateAudio.multiplyBeeds */,
                "nimbleTable": "nimbleTable" /* templateAudio.nimbleTable */,
                "numberBoardOneTwo": "numberBoardOneTwo" /* templateAudio.numberBoardOneTwo */,
                "numberPair": "numberPair" /* templateAudio.numberPair */,
                "openWindow": "openWindow" /* templateAudio.openWindow */,
                "orderTractor": "orderTractor" /* templateAudio.orderTractor */,
                "phonicTractor": "phonicTractor" /* templateAudio.phonicTractor */,
                "pictureMeaningCocos": "pictureMeaningCocos" /* templateAudio.pictureMeaningCocos */,
                "pictureWordMatch1": "pictureWordMatch1" /* templateAudio.pictureWordMatch1 */,
                "pictureWordMatch2": "pictureWordMatch2" /* templateAudio.pictureWordMatch2 */,
                "puzzleGame": "puzzleGame" /* templateAudio.puzzleGame */,
                "questionBoard": "questionBoard" /* templateAudio.questionBoard */,
                "quizLiteracySentenceSentence": "quizLiteracySentenceSentence" /* templateAudio.quizLiteracySentenceSentence */,
                "quizLiteracySoundOnlyImage": "quizLiteracySoundOnlyImage" /* templateAudio.quizLiteracySoundOnlyImage */,
                "quizLiteracySoundOnlySentence": "quizLiteracySoundOnlySentence" /* templateAudio.quizLiteracySoundOnlySentence */,
                "quizLiteracySoundOnlyWord": "quizLiteracySoundonlyWord" /* templateAudio.quizLiteracySoundOnlyWord */,
                "quizLiteracyAndShapes1": "quizLiteracyAndShapes1" /* templateAudio.quizLiteracyAndShapes1 */,
                "quizLiteracyImageWithText": "quizLiteracyImageWithText" /* templateAudio.quizLiteracyImageWithText */,
                "quizliteracyImageWord": "quizliteracyImageWord" /* templateAudio.quizliteracyImageWord */,
                "quizMathBiggerAndSmaller": "quizMathBiggerAndSmaller" /* templateAudio.quizMathBiggerAndSmaller */,
                "quizMathBiggestAndSmallest": "quizMathBiggestAndSmallest" /* templateAudio.quizMathBiggestAndSmallest */,
                "quizmathCustomNumberMagnitude": "quizmathCustomNumberMagnitude" /* templateAudio.quizmathCustomNumberMagnitude */,
                "quizMathHowMany": "quizMathHowMany" /* templateAudio.quizMathHowMany */,
                "quizmathMissingnumberDrag": "quizmathMissingnumberDrag" /* templateAudio.quizmathMissingnumberDrag */,
                "quizMathNumberIdentification": "quizMathNumberIdentification" /* templateAudio.quizMathNumberIdentification */,
                "quizMathOperationWithobjects": "quizMathOperationWithobjects" /* templateAudio.quizMathOperationWithobjects */,
                "quizMathoperationWithoutObjects": "quizMathoperationWithoutObjects" /* templateAudio.quizMathoperationWithoutObjects */,
                "quizMathRecognizeNumber": "quizMathRecognizeNumber" /* templateAudio.quizMathRecognizeNumber */,
                "quizMathShapes": "quizMathShapes" /* templateAudio.quizMathShapes */,
                "reorder": "reorder" /* templateAudio.reorder */,
                "rocketGame": "rocketGame" /* templateAudio.rocketGame */,
                "rowBlock": "rowBlock" /* templateAudio.rowBlock */,
                "sequenceBox1": "sequenceBox1" /* templateAudio.sequenceBox1 */,
                "shapeTractor": "shapeTractor" /* templateAudio.shapeTractor */,
                "spellDoor": "spellDoor" /* templateAudio.spellDoor */,
                "storyMaking": "storyMaking" /* templateAudio.storyMaking */,
                "storyTale": "storyTale" /* templateAudio.storyTale */,
                "sumTogether": "sumTogether" /* templateAudio.sumTogether */,
                "tag": "tag" /* templateAudio.tag */,
                "total": "total" /* templateAudio.total */,
                "writeCard": "writeCard" /* templateAudio.writeCard */,
                "writeLetter": "writeLetter" /* templateAudio.writeLetter */,
                "writeNumber": "writeNumber" /* templateAudio.writeNumber */,
                "writeSet": "writeSet" /* templateAudio.writeSet */,
                "writeWord": "writeWord" /* templateAudio.writeWord */,
                "numberIdentification": "numberIdentification" /* templateAudio.numberIdentification */,
                "wordBuildingWithAndWithoutImage": "wordBuildingWithAndWithoutImage" /* templateAudio.wordBuildingWithAndWithoutImage */,
                "subsWithAndWithoutImage": "subsWithAndWithoutImage" /* templateAudio.subsWithAndWithoutImage */,
                "sentenceMatchTemplate": "sentenceMatch" /* templateAudio.sentenceMatchTemplate */,
                "pictureClues": "pictureClues" /* templateAudio.pictureClues */,
                "palEgmaCalculateSumAndSumTogether": "palEgmaCalculateSumAndSumTogether" /* templateAudio.palEgmaCalculateSumAndSumTogether */,
                "palEgmaPatternMatching": "palEgmaPatternMatchingAudio" /* templateAudio.palEgmaPatternMatching */,
                "palEgmaWordProblem": "palEgmaWordProblem" /* templateAudio.palEgmaWordProblem */,
                "palEgraArrangePictures": "palEgraArrangePicturesAudio" /* templateAudio.palEgraArrangePictures */,
                "palEgraBuildWord": "palEgraBuildWordAudio" /* templateAudio.palEgraBuildWord */,
                "palEgraMCQWithImage": "palEgraMCQWithImage" /* templateAudio.palEgraMCQWithImage */,
                "palEgraOddOneOut": "palEgraOddOneOutAudio" /* templateAudio.palEgraOddOneOut */,
                "palEgraOptionWithAudio": "palEgraOptionWithAudio" /* templateAudio.palEgraOptionWithAudio */,
                "palEgraWordFormation": "palEgraWordFormationAudio" /* templateAudio.palEgraWordFormation */,
                "palEgraWordMatch": "palEgraWordMatch" /* templateAudio.palEgraWordMatch */,
                "substractionWithImage": "substractionWithImageAudio" /* templateAudio.substractionWithImage */,
                "substractionWithoutImage": "substractionWithoutImageAudio" /* templateAudio.substractionWithoutImage */,
                "numberIdentificationWithImage": "numberIdentificationWithImageAudio" /* templateAudio.numberIdentificationWithImage */,
                "numberIdentificationWithoutImage": "numberIdentificationWithoutImageAudio" /* templateAudio.numberIdentificationWithoutImage */,
                "wordBuildingWithImage": "wordBuildingWithImageAudio" /* templateAudio.wordBuildingWithImage */,
                "wordBuildingWithoutImage": "wordBuildingWithoutImageAudio" /* templateAudio.wordBuildingWithoutImage */,
                "pictureWordMatchMultipleImages": "pictureWordMatchMultipleImagesAudio" /* templateAudio.pictureWordMatchMultipleImages */,
                "pictureWordMatchSingleImage": "pictureWordMatchSingleImageAudio" /* templateAudio.pictureWordMatchSingleImage */,
                "sentenceMatch": "sentenceMatchAudio" /* templateAudio.sentenceMatch */,
                "imageMatch": "imageMatchAudio" /* templateAudio.imageMatch */,
                "palStoryTale": "palStoryTaleAudio" /* templateAudio.palStoryTale */,
                "palEgmaWordProblemDragnDrop": "palEgmaWordProblemDragnDropAudio" /* templateAudio.palEgmaWordProblemDragnDrop */,
                "palEgmaWordProblemClick": "palEgmaWordProblemClickAudio" /* templateAudio.palEgmaWordProblemClick */,
                "palInventedSpelling": "palInventedSpellingAudio" /* templateAudio.palInventedSpelling */,
                "palLetterIdentification": "palLetterIdentificationAudio" /* templateAudio.palLetterIdentification */,
                "palStoryMaking": "palStoryMakingAudio" /* templateAudio.palStoryMaking */,
                "palegmasumtogether": "palegmasumtogetherAudio" /* templateAudio.palegmasumtogether */,
                "palegmamultioption": "palegmamultioptionAudio" /* templateAudio.palegmamultioption */,
                "palegraoptionaudio": "palegraoptionAudio" /* templateAudio.palegraoptionaudio */,
                "palegrawordmatch": "palegrawordmatchAudio" /* templateAudio.palegrawordmatch */,
                "palegramcqimages": "palegramcqimagesAudio" /* templateAudio.palegramcqimages */,
                "drawShape": "drawshape" /* templateAudio.drawShape */,
                "drawshape": "drawshape" /* templateAudio.drawshape */,
            }[this.templateId]) !== null && _a !== void 0 ? _a : '';
        const home = document.querySelector('lido-home');
        if (!home)
            return;
        const existing = home.getAttribute(TemplateID) || '';
        this.speakFlag = existing.includes(this.templateId);
        if (!this.speakFlag) {
            home.setAttribute(TemplateID, [existing, this.templateId].filter(Boolean).join(','));
        }
    }
    resolveLanguage() {
        var _a, _b;
        const rootEl = this.el.closest('lido-root');
        const rootLang = (rootEl === null || rootEl === void 0 ? void 0 : rootEl.Lang) || '';
        if (rootLang === null || rootLang === void 0 ? void 0 : rootLang.trim())
            return rootLang;
        if ((_a = this.Lang) === null || _a === void 0 ? void 0 : _a.trim())
            return this.Lang;
        const xmlLang = this.el.getAttribute('Lang');
        if (xmlLang === null || xmlLang === void 0 ? void 0 : xmlLang.trim())
            return xmlLang;
        return (_b = this.el.textContent) === null || _b === void 0 ? void 0 : _b.trim();
    }
    convertToPixels(height, parentElement = document.body) {
        if (!height)
            return 0; // Handle empty or invalid input
        // Directly return numbers if already in pixels
        if (height.endsWith('px')) {
            return parseFloat(height);
        }
        // Convert relative units
        const tempElement = document.createElement('div');
        tempElement.style.position = 'absolute';
        tempElement.style.visibility = 'hidden';
        tempElement.style.height = height;
        parentElement.appendChild(tempElement);
        const computedHeight = tempElement.offsetHeight;
        parentElement.removeChild(tempElement);
        return computedHeight;
    }
    /**
     * Scales the container based on the window or screen size, maintaining the aspect ratio.
     * The container scales according to the minimum dimension of the screen.
     *
     * @param container The container element to be scaled.
     */
    scaleContainer(container) {
        // Calculate the scale factor based on the closest parent element's width and height (1600x900 reference)
        const parentElement = this.getClosestParentWithWidth();
        let scaleFactor = 0;
        if (parentElement) {
            const parentWidth = parentElement.clientWidth;
            const parentHeight = parentElement.clientHeight;
            const scaleX = parentWidth / 1600;
            const scaleY = parentHeight / 900;
            scaleFactor = Math.min(scaleX, scaleY);
        }
        // Center the container and apply scaling
        container.style.transform = `translate(-50%, -50%) scale(${scaleFactor != 0 ? scaleFactor : calculateScale()})`;
        container.style.left = '50%';
        container.style.top = '50%';
        container.style.position = 'absolute'; // Ensure proper positioning
        this.screenOrientation();
    }
    // Find and return the nearest parent element that has a measurable (non-zero) width
    getClosestParentWithWidth() {
        let parent = this.el.parentElement;
        while (parent) {
            if (parent.offsetWidth > 0) {
                return parent;
            }
            parent = parent.parentElement;
        }
        return null;
    }
    screenOrientation() {
        if (window.innerHeight > window.innerWidth) {
            this.el.style.height = '1600px';
            this.el.style.width = '900px';
        }
        else {
            this.el.style.height = '900px';
            this.el.style.width = '1600px';
        }
    }
    updateChildTextLanguage(lang) {
        const appliedLang = lang || instance.language || 'en';
        instance.changeLanguage(appliedLang);
        const texts = this.el.querySelectorAll('lido-text');
        texts.forEach((textEl) => {
            textEl.Lang = appliedLang;
            textEl.dispatchEvent(new CustomEvent('languageChanged', { bubbles: true }));
        });
    }
    /**
     * Lifecycle hook that runs after the component is loaded.
     * - It scales the container.
     * - It sets the background color of the body.
     * - Adds event listeners for `resize` and `load` to rescale the container on window size changes.
     */
    componentDidLoad() {
        this.scaleContainer(this.el);
        const backGroundImage = this.bgImage ? convertUrlToRelative(this.bgImage) : '';
        const standalone = this.el.closest('lido-standalone');
        const backgroundTarget = (standalone === null || standalone === void 0 ? void 0 : standalone.getAttribute('bg-image')) === 'true' ? standalone : document.body;
        backgroundTarget.style.backgroundColor = this.bgColor;
        backgroundTarget.style.backgroundImage = backGroundImage ? `url(${backGroundImage})` : 'none';
        backgroundTarget.style.backgroundPosition = backGroundImage ? 'bottom' : 'none';
        document.body.style.pointerEvents = 'auto';
        // Re-scale the container on window resize or load events
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
        if (this.templateId) {
            setTimeout(() => {
                this.el.setAttribute("onEntry", `${this.templateId}.speak='${!this.speakFlag}'; ` + this.el.getAttribute("onEntry"));
                initEventsForElement(this.el, this.type);
            }, 100);
        }
        else {
            initEventsForElement(this.el, this.type);
        }
        if (this.customStyle) {
            const styleElement = document.createElement('style');
            styleElement.innerHTML = this.customStyle;
            document.head.appendChild(styleElement);
        }
        const langToApply = this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
        setTimeout(() => {
            highlightElement();
        }, 100);
        resetFloatState();
        Timer.getI().start();
    }
    disconnectedCallback() {
        this.cleanupInteractionHandlers();
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
        document.body.style.backgroundColor = '';
        document.body.style.backgroundImage = '';
        resetFloatState();
        Timer.getI().stop();
    }
    render() {
        // Define the styles for the container element
        const style = {
            backgroundColor: this.bgColor,
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)', // Centering the container
            margin: this.margin,
            userSelect: 'none', // Prevent any field selection
        };
        return (h(Host, { key: '1862e30fedda58726edc107f81fae1f63e96d009', id: "lido-container", Lang: this.Lang, "tab-index": 0, class: "lido-container", objective: this.objective, baseUrl: this.baseUrl, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, onTouch: this.onTouch, onInCorrect: this.onInCorrect, onCorrect: this.onCorrect, onEntry: this.onEntry, "show-check": `${this.showCheck}`, "is-continue-on-correct": `${this.isContinueOnCorrect}`, "is-allow-only-correct": `${this.isAllowOnlyCorrect}`, canplay: `${this.canplay}`, appendToDropOnCompletion: `${this.appendToDropOnCompletion}`, "show-prev-button": `${this.showPrevButton}`, "show-next-button": `${this.showNextButton}`, "show-drop-border": `${this.showDropBorder}`, "bg-image": this.bgImage, "exit-button-url": this.exitButtonUrl, "prev-button-url": this.prevButtonUrl, "next-button-url": this.nextButtonUrl, "speaker-button-url": this.speakerButtonUrl, "disable-speak": `${this.disableSpeak}`, "template-id": this.templateId, audio: this.audio, "highlight-word-by-word": `${this.highlightWordByWord}` }, h("lido-text", { key: '86fd014a61ba9cba6d67e2d921b2d8a8a289dbc7', visible: "false", id: this.templateId, audio: "", string: this.instructName }), h("slot", { key: 'c3128ea2164892757b32cb076d717436947f9a4c' })));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "Lang": [{
                "languageChanged": 0
            }]
    }; }
};
LidoContainer.style = lidoContainerCss();

export { LidoContainer as lido_container };
