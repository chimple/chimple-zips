import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { H as attachSpeakIcon } from './utils-Zx3fBgtB.js';

const lidoRandomCss = () => `.lido-random{position:relative;width:100%;height:100%}.lido-random>*{position:absolute}`;

const LidoRandom = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Unique identifier for the random container.
         */
        this.id = '';
        /**
         * Value associated with the component, often used for internal logic.
         */
        this.value = '';
        /**
         * The height of the container (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the container (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the container (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the container (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the container relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the container (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The type of the component, used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the container. If `true`, the container is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It randomly positions all child elements within the container using CSS `top` and `left` percentages.
     */
    componentDidLoad() {
        setTimeout(() => {
            // Select all direct child elements of the component
            const parentcontainer = this.el.parentElement;
            if (!parentcontainer)
                return;
            // Get parent size
            const parentWidth = parentcontainer.offsetWidth;
            const parentHeight = parentcontainer.offsetHeight;
            // Place child elements randomly inside parent
            const children = Array.from(this.el.children);
            children.forEach(child => {
                const childWidth = child.offsetWidth;
                const childHeight = child.offsetHeight;
                const maxLeft = parentWidth - childWidth;
                const maxTop = parentHeight - childHeight;
                const randLeft = Math.random() * maxLeft;
                const randTop = Math.random() * maxTop;
                child.style.position = 'absolute';
                child.style.left = `${randLeft}px`;
                child.style.top = `${randTop}px`;
            });
        }, 50);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    render() {
        // Inline styles for the container, including dimensions, positioning, and visibility
        const style = {
            height: this.height,
            width: this.width,
            top: this.y,
            left: this.x,
            display: this.visible ? 'block' : 'none', // Toggle visibility
            zIndex: this.z,
            backgroundColor: this.bgColor,
            margin: this.margin,
        };
        return (h(Host, { key: 'a4cec45d407b57833a4296a20230717534adf39b', class: "lido-random", type: this.type, "tab-index": this.tabIndex, value: this.value, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, minDrops: this.minDrops, maxDrops: this.maxDrops, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: 'b80726b68b7f1c009f35352b9d05cd573159f87b' })));
    }
    get el() { return getElement(this); }
};
LidoRandom.style = lidoRandomCss();

export { LidoRandom as lido_random };
