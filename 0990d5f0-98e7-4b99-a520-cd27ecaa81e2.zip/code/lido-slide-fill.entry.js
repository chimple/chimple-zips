import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { k as convertUrlToRelative, x as setVisibilityWithDelay, y as initEventsForElement, z as parseProp, X as fraction } from './utils-Zx3fBgtB.js';

const lidoSlideFillCss = () => `.lido-svg-element,.lido-slide-svg{width:100%;height:100%}`;

const LidoSlideFill = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the component instance
         */
        this.id = 'lido-slide-fill';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * Type of number to be displayed on the ruler.
         * Can be 'integer', 'decimal', or 'fraction'.
         */
        this.numberType = 'integer';
        /**
         * Minimum value shown on the ruler (used for number generation)
         */
        this.min = 0;
        /**
         * Number of divisions or segments to split the ruler path into
         */
        this.division = 5;
        /**
         * Maximum value shown on the ruler (used for number generation)
         */
        this.max = 10;
        /**
         * Defines the type of the component, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * Internal state to hold the SVG content after fetching and processing
         */
        this.svgContent = '';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.originalHeight = null;
        this.originalY = null;
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    async componentWillLoad() {
        await this.renderSVG();
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    async onSrcChange() {
        await this.renderSVG();
        this.onPropChange();
    }
    async renderSVG() {
        const response = await fetch(convertUrlToRelative(this.src));
        if (response.ok) {
            let svgText = await response.text();
            let pathIndex = 0;
            svgText = svgText.replace(/<path([^>]*)>/g, (match, attrs) => {
                pathIndex++;
                const id = pathIndex === 1 ? 'glassPath' : pathIndex === 2 ? 'rulerPath' : `path${pathIndex}`;
                return `<path id="${id}"${attrs}>`;
            });
            const clipPathDef = `
        <clipPath id="clipGlass">
          <use xlink:href="#glassPath" />
        </clipPath>
      `;
            svgText = svgText.replace(/<svg([^>]*)>/, `<svg class="lido-slide-svg"$1>
          ${clipPathDef}
        `);
            svgText = svgText.replace(/<rect([^>]*)\/?>/, `<rect id="fillArea" $1 clip-path="url(#clipGlass)" />`);
            this.svgContent = svgText;
        }
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.updateFill();
        this.addRulerNumbers();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) ? 'flex' : 'none',
            alignItems: 'center',
            justifyContent: 'center',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: this.borderRadius,
        };
    }
    onPropChange() {
        this.updateFill();
        this.addRulerNumbers();
    }
    updateFill() {
        var _a;
        const svgEl = (_a = this.el.querySelector('.lido-svg-element')) === null || _a === void 0 ? void 0 : _a.querySelector('svg');
        if (!svgEl)
            return;
        const rect = svgEl.querySelector('#fillArea');
        if (!rect)
            return;
        const fillDirection = this.fillDirection;
        let originalSize;
        let originalOffset;
        if (this.fillDirection === 'vertical') {
            if (this.originalHeight === null || this.originalY === null) {
                this.originalHeight = +rect.getAttribute('height') || 100;
                this.originalY = +rect.getAttribute('y') || 0;
            }
            originalSize = this.originalHeight;
            originalOffset = this.originalY;
        }
        else {
            if (this.originalHeight === null || this.originalY === null) {
                this.originalHeight = +rect.getAttribute('width') || 100;
                this.originalY = +rect.getAttribute('x') || 0;
            }
            originalSize = this.originalHeight;
            originalOffset = this.originalY;
        }
        const fullSize = originalSize;
        const start = originalOffset;
        // Parse fill ("30%" or "30")
        let fillPercent = 0;
        if (typeof this.fill === 'string') {
            const percentMatch = this.fill.match(/^(\d+(?:\.\d+)?)%$/);
            if (percentMatch) {
                fillPercent = Math.min(Math.max(parseFloat(percentMatch[1]) / 100, 0), 1);
            }
            else {
                const numericMatch = this.fill.match(/^(\d+(?:\.\d+)?)$/);
                if (numericMatch) {
                    fillPercent = Math.min(Math.max(parseFloat(numericMatch[1]) / 100, 0), 1);
                }
            }
        }
        const newSize = fullSize * fillPercent;
        const newOffset = fillDirection === 'vertical' ? start + (fullSize - newSize) : start;
        if (fillDirection === 'vertical') {
            rect.setAttribute('height', newSize.toString());
            rect.setAttribute('y', newOffset.toString());
        }
        else {
            rect.setAttribute('width', newSize.toString());
            rect.setAttribute('x', '0');
        }
    }
    addRulerNumbers() {
        var _a;
        const svgEl = (_a = this.el.querySelector('.lido-svg-element')) === null || _a === void 0 ? void 0 : _a.querySelector('svg');
        if (!svgEl)
            return;
        const rulerPath = svgEl.querySelector('#rulerPath');
        if (!rulerPath)
            return;
        // Clear old numbers
        const oldNumbers = svgEl.querySelectorAll('.ruler-number');
        oldNumbers.forEach(node => node.remove());
        const divisions = this.division;
        const pointsCount = divisions + 1;
        const pathLength = rulerPath.getTotalLength();
        const stepValue = (this.max - this.min) / divisions;
        for (let i = 0; i < pointsCount; i++) {
            let value = 0;
            if (this.fillDirection === 'vertical') {
                value = this.max - i * stepValue;
            }
            else if (this.fillDirection === 'horizontal') {
                value = this.min + i * stepValue;
            }
            const pointAtLength = rulerPath.getPointAtLength((pathLength / divisions) * i);
            const textElem = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            const fraction$1 = fraction(value / this.max);
            value = this.numberType === 'integer' ? Math.round(value) : this.numberType === 'decimal' ? parseFloat(value.toFixed(1)) : fraction$1.toFraction(true);
            textElem.classList.add('ruler-number');
            textElem.setAttribute('x', pointAtLength.x.toString());
            textElem.setAttribute('y', (pointAtLength.y + 15).toString());
            textElem.setAttribute('text-anchor', 'end');
            textElem.setAttribute('font-size', '40');
            textElem.setAttribute('fill', '#333');
            textElem.textContent = value.toString();
            svgEl.appendChild(textElem);
        }
    }
    render() {
        return (h(Host, { key: 'df8a5474f641fec4d842013a04ef9e3d422a8ab2', id: this.id, class: "lido-slide-fill", src: this.src, fill: this.fill, fillDirection: this.fillDirection, slider: this.slider, style: this.style, min: this.min, max: this.max, division: this.division, numberType: this.numberType, onEntry: this.onEntry, type: this.type, "disable-speak": this.disableSpeak }, h("div", { key: 'e7b6bcc17f8caea30b074f24596b6b044833d170', innerHTML: this.svgContent, class: "lido-svg-element" })));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "src": [{
                "onSrcChange": 0
            }],
        "fill": [{
                "onPropChange": 0
            }],
        "division": [{
                "onPropChange": 0
            }],
        "fillDirection": [{
                "onPropChange": 0
            }],
        "numberType": [{
                "onPropChange": 0
            }],
        "min": [{
                "onPropChange": 0
            }],
        "max": [{
                "onPropChange": 0
            }]
    }; }
};
LidoSlideFill.style = lidoSlideFillCss();

export { LidoSlideFill as lido_slide_fill };
