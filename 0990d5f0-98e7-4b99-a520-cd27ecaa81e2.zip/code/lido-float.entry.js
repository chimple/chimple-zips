import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { x as setVisibilityWithDelay, y as initEventsForElement, M as handleFloatElementPosition, O as handleElementClick, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoFloatCss = () => `.lido-float{position:relative}.lido-float>*{position:absolute;cursor:pointer}@keyframes float-up{from{top:var(--el-top)}to{top:-500px}}#removeShadow{box-shadow:unset !important}@keyframes float-lr{from{right:var(--el-left)}to{right:-500px}}`;

const LidoFloat = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the text element.
         */
        this.id = '';
        /**
         * Value associated with the text element, typically used for internal logic or tracking.
         */
        this.value = '';
        /**
         * Z-index for stacking order of the text component relative to other elements.
         */
        this.z = '0';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the text component. If `true`, the text is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * Direction of the float element's movement (e.g., 'leftToRight', 'bottomToTop').
         * This can be used to control the animation or positioning of the float elements.
         */
        this.floatDirection = 'bottomToTop';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.initializeFloatElement();
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    initializeFloatElement() {
        const floatElements = this.el.children;
        let delay = 0;
        Array.from(floatElements).forEach((el) => {
            const element = el;
            element.style.visibility = 'hidden';
            setTimeout(() => {
                element.style.visibility = 'visible';
                handleFloatElementPosition(element);
            }, delay);
            delay += 1000; // Stagger the visibility of each element by 1 second
            el.addEventListener('click', () => {
                handleElementClick(element);
            });
        });
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: this.floatDirection !== 'leftToRight' ? "100%" : parseProp(this.height, orientation),
            width: this.floatDirection === 'leftToRight' ? "100%" : parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            zIndex: this.z,
            display: this.visible ? 'flex' : 'none',
        };
    }
    render() {
        return (h(Host, { key: 'c461f1142dd6addd9ceb41ade183b044b875681f', class: "lido-float", "float-direction": this.floatDirection, id: this.id, "tab-index": this.tabIndex, style: this.style, onEntry: this.onEntry }, h("slot", { key: '240439bfda6a9e4e2d67e6ae2b5c878d99e632b3' })));
    }
    get el() { return getElement(this); }
};
LidoFloat.style = lidoFloatCss();

export { LidoFloat as lido_float };
