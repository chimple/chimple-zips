import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { x as setVisibilityWithDelay, y as initEventsForElement, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoShapeCss = () => `.lido-shape{position:absolute;top:var(--y);left:var(--x);display:var(--display);z-index:var(--z);justify-content:center;align-items:center}.lido-rectangle{border-radius:0}.lido-circle{width:var(--width);height:var(--width);border-radius:50%;background-color:var(--bgColor)}.lido-ellipse{width:var(--width);height:var(--height);border-radius:50%;background-color:var(--bgColor)}.lido-triangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--bgColor);clip-path:polygon(50% 0%, 100% 100%, 0% 100%)}.lido-rightTriangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--bgColor);clip-path:polygon(100% 0%, 100% 100%, 0% 100%)}.lido-leftTriangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--triangleBgColor);clip-path:polygon(0% 0%, 100% 100%, 0% 100%)}.lido-parallelogram{width:var(--paralleWidth);height:var(--paralleHeight);transform:skew(20deg)}.lido-trapezium{width:var(--trapeziumWidth);height:var(--trapeziumHeight);background-color:var(--bgColor);clip-path:polygon(      20% 0%,         80% 0%,         100% 100%,      0% 100%      )}.lido-hexagon{width:var(--hexagonWidth);height:var(--hexagonHeight);background-color:var(--bgColor);clip-path:polygon(      25% 0%,         75% 0%,         100% 50%,       75% 100%,       25% 100%,       0% 50%       )}.lido-cone{width:var(--coneWidth);height:var(--coneHeight);background-color:var(--bgColor);clip-path:polygon(            15% 10%,      25% 4%,      35% 1%,      50% 0%,      65% 1%,      75% 4%,      85% 10%,              50% 100%    )}.lido-star{width:var(--starWidth);height:var(--starHeight);background-color:var(--starBgColor);clip-path:polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)}.lido-pentagon{width:var(--pentagonWidth);height:var(--pentagonHeight);background-color:var(--pentagonBgColor);clip-path:polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)}.lido-heptagon{width:var(--heptagonWidth);height:var(--heptagonHeight);background-color:var(--heptagonBgColor);clip-path:polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)}.lido-octagon{width:var(--octagonWidth);height:var(--octagonHeight);background-color:var(--octagonBgColor);clip-path:polygon(25% 0%, 75% 0%, 100% 25%, 100% 75%, 75% 100%, 25% 100%, 0% 75%, 0% 25%)}.lido-rhombus{width:var(--rhombusWidth);height:var(--rhombusHeight);background-color:var(--rhombusBgColor);clip-path:polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)}.lido-heart{height:var(--heartHeight);width:var(--heartWidth);border-image:radial-gradient(var(--heartBgColor) 69%, #0000 70%) 84.5%/50%;clip-path:polygon(-41% 0, 50% 91%, 141% 0)}.cube{width:100%;height:100%;position:relative;transform-style:preserve-3d;transform:rotateX(-20deg) rotateY(45deg)}.face{position:absolute;width:var(--face-width,150px);height:var(--face-width,150px);background:var(--face-bg-color,150px);box-shadow:inset -20px -20px 40px rgba(0,0,0,0.3)}.front{transform:rotateY(  0deg) translateZ(var(--face-translate, 75px))}.back{transform:rotateY(180deg) translateZ(var(--face-translate, 75px))}.right{transform:rotateY( 90deg) translateZ(var(--face-translate, 75px))}.left{transform:rotateY(-90deg) translateZ(var(--face-translate, 75px))}.top{transform:rotateX( 90deg) translateZ(var(--face-translate, 75px))}.bottom{transform:rotateX(-90deg) translateZ(var(--face-translate, 75px))}.lido-cylinder{width:var(--width);height:var(--height);border-radius:100% / 80px;background:radial-gradient(50% 40px at 50% 40px, #0003 99.99%, #0000 0),      radial-gradient(50% 40px at 50% calc(100% - 40px), #fff3 99.99%, #0000 0),      red}.lido-sphere{position:relative;width:var(--width);height:var(--width);border-radius:50%;background:radial-gradient(circle at 30% 18%, #22d4ff 0%, #18c2f4 9%, rgba(24, 194, 244, 0.2) 18%, transparent 30%),      radial-gradient(circle at 36% 26%, #0f8fff 0%, #0b67e6 30%, #083fbe 62%, #120084 100%);box-shadow:inset -22px -26px 40px rgba(5, 0, 70, 0.38),      inset 14px 14px 24px rgba(255, 255, 255, 0.05),      0 4px 2px rgba(0, 0, 0, 0.78);overflow:visible}.lido-sphere::after{content:'';position:absolute;top:50%;left:50%;width:100%;height:16%;border-radius:50%;border-top:2px dashed rgba(0, 0, 0, 0.65);border-bottom:3px solid rgba(0, 0, 0, 0.85);box-sizing:border-box;transform:translate(-50%, -50%);pointer-events:none}`;

const LidoShape = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the shape element.
         */
        this.id = '';
        /**
         * Value associated with the shape, typically used for internal logic or tracking.
         */
        this.value = '';
        /**
         * The height of the shape (CSS value, e.g., '100px', '50%').
         * This is ignored for polygons.
         */
        this.height = 'auto';
        /**
         * The width of the shape (CSS value, e.g., '100px', '50%').
         * This is ignored for polygons.
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the shape (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the shape (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the shape relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the shape (CSS color value, e.g., '#FFFFFF', 'blue').
         * This is ignored for polygons.
         */
        this.bgColor = '';
        /**
         * Defines the type of the shape, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Type of shape to render (e.g., 'circle', 'rectangle', 'polygon').
         */
        this.shapeType = 'circle';
        /**
         * Controls the visibility of the shape. If `true`, the shape is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the shape.
         */
        this.audio = '';
        /**
         * Event handler triggered when the shape is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the shape is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        /** Holds dynamically generated inline styles for the container */
        this.style = {};
    }
    /**
     * Lifecycle hook that runs after the component is loaded into the DOM.
     * It initializes custom events based on the `type` of the shape component.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.updateStyles();
        this.lido3DShapes();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            x: parseProp(`${this.x}`, orientation),
            y: parseProp(`${this.y}`, orientation),
            height: parseProp(`${this.height}`, orientation),
            width: parseProp(`${this.width}`, orientation),
        };
    }
    lido3DShapes() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        if (this.shapeType === "lido-cube") {
            const faces = this.el.querySelectorAll(".face");
            faces.forEach(item => {
                const face = item;
                face.style.setProperty("--face-width", parseProp(`${this.width}`, orientation));
                const translateValue = parseInt(parseProp(`${this.width}`, orientation)) / 2;
                face.style.setProperty("--face-translate", `${translateValue}px`);
                face.style.setProperty("--face-bg-color", this.bgColor);
            });
        }
        if (this.shapeType === "lido-cylinder") {
            const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        }
    }
    render() {
        // Inline styles to position and size the shape component
        const style = {
            height: this.shapeType !== 'polygon' ? this.style.height : undefined, // Set height unless it's a polygon
            width: this.shapeType !== 'polygon' ? this.style.width : undefined, // Set width unless it's a polygon
            top: this.style.y,
            left: this.style.x,
            display: this.visible ? 'block' : 'none', // Toggle visibility
            zIndex: this.z,
            backgroundColor: this.shapeType !== 'polygon' ? this.bgColor : 'transparent', // Apply background only if not a polygon
            margin: this.margin,
        };
        return (h(Host, { key: '90b323eacac8b702168f612f79000da757109ec1', class: `lido-shape ${this.shapeType}`, value: this.value, type: this.type, "tab-index": this.tabIndex, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, minDrops: this.minDrops, maxDrops: this.maxDrops, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "disable-speak": this.disableSpeak }, this.shapeType === "lido-cube" &&
            h("div", { key: '16b4a96f302cd6b1c80023a29253e85fe0937622', class: "cube" }, h("div", { key: '9ce4dfa0021b463aa5dba4c0651d144f844c2db0', class: "face top" }), h("div", { key: 'f10410ef05cbde0a024ccbdbfb4fb7099c1bd9d3', class: "face bottom" }), h("div", { key: '2a08b1857613efd1db596d72a9324ac5b3379628', class: "face left" }), h("div", { key: '4922b4b63dc9538e68d143109bfa12782382ee48', class: "face right" }), h("div", { key: '983bc6815a3b5e6023d76394e0bdeb12c493b771', class: "face front" }), h("div", { key: 'eab0224f427b8a345d3c3285d8d2828b39871eaa', class: "face back" }))));
    }
    get el() { return getElement(this); }
};
LidoShape.style = lidoShapeCss();

export { LidoShape as lido_shape };
