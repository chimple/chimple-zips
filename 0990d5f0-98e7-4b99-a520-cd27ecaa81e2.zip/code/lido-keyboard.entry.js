import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { l as LidoContainer, S as SelectedValuesKey, C as storingEachActivityScore, A as AudioPlayer, U as stopHighlightForSpeakingElement, q as executeActions, E as calculateScore, u as triggerNextContainer, M as handleFloatElementPosition, V as DropAction, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoKeyboardCss = () => `.lido-keyboard{display:flex;flex-direction:column;align-items:center;gap:30px}.input-area{display:flex;gap:15px}input[type="text"]{font-size:30px;font-weight:600;padding-left:20px;width:300px;height:70px;border:2px solid;background:whitesmoke;border-radius:20px;text-align:center}.keyboard-wrapper{justify-content:center;width:700px}.disabled{opacity:0.5;pointer-events:none}.key-button{background:aquamarine;font-weight:600}`;

const LidoKeyboard = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Comma-separated list of keys, optionally with status (e.g., "A,B-disable,C") */
        this.keys = '';
        /** Gap between key buttons (default: "10px") */
        this.gap = '10px';
        /** Background color for each key button */
        this.bgColor = '';
        /** Border radius for key buttons (e.g., "8px") */
        this.borderRadius = '';
        /**
         * Indicates whether the keyboard input is enabled.
         * When set to `true`, the component will respond to keyboard events.
         */
        this.keyboardInput = false;
        /** Number of columns in the keyboard layout (default: "10") */
        this.columns = '10';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        /** Tracks the number of keys clicked by the user */
        this.numberOfClick = 0;
        /** Current input string entered via the keyboard */
        this.inputString = '';
        /** Dynamic style object that stores resolved styles based on props */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    async inputValidation(e) {
        if (this.type !== 'click')
            return;
        const container = document.getElementById(LidoContainer);
        const clickedValue = e.target.getAttribute('value');
        if (!clickedValue)
            return;
        let selectedValue = JSON.parse(localStorage.getItem(SelectedValuesKey)) || '';
        localStorage.setItem(SelectedValuesKey, JSON.stringify(selectedValue));
        const bodyRect = document.body.getBoundingClientRect();
        // Get all word bubbles (make sure bubbles have class "bubble-element")
        const bubbles = Array.from(container.querySelectorAll('.bubble-element'));
        const overlapingBubbles = bubbles.filter(bubble => {
            const elemRect = bubble.getBoundingClientRect();
            return elemRect.left < bodyRect.right && elemRect.right > bodyRect.left && elemRect.top < bodyRect.bottom && elemRect.bottom > bodyRect.top;
        });
        // Find a bubble whose word starts with current progress + clicked letter
        const matchedBubble = overlapingBubbles.find(bubble => {
            const word = bubble.getAttribute('value'); // full word like "one"
            const hasElement = word === null || word === void 0 ? void 0 : word.startsWith(this.inputString.toLowerCase());
            return hasElement ? bubble : null;
        });
        if (matchedBubble) {
            // If full word completed
            if (this.inputString.toLowerCase() === matchedBubble.getAttribute('value').toLowerCase()) {
                storingEachActivityScore(true);
                AudioPlayer.getI().play(matchedBubble);
                stopHighlightForSpeakingElement(matchedBubble);
                setTimeout(() => { this.inputString = ''; }, 1000);
                const elementOnCorrect = matchedBubble.getAttribute('onCorrect');
                await executeActions(elementOnCorrect, matchedBubble);
                matchedBubble.style.animation = 'none';
                matchedBubble.style.pointerEvents = 'none';
                this.numberOfClick++;
                localStorage.removeItem(SelectedValuesKey);
                if (this.numberOfClick === this.letterLength) {
                    const onCorrrect = container.getAttribute('onCorrect');
                    container.style.pointerEvents = 'none';
                    await executeActions(onCorrrect, this.el);
                    calculateScore();
                    triggerNextContainer();
                }
                else {
                    handleFloatElementPosition(matchedBubble);
                }
            }
        }
        else {
            // ❌ Incorrect click
            storingEachActivityScore(false);
            setTimeout(() => { this.inputString = ''; }, 1000);
            localStorage.removeItem(SelectedValuesKey);
            const onInCorrrect = container.getAttribute('onInCorrect');
            await executeActions(onInCorrrect, this.el);
        }
    }
    componentDidLoad() {
        const container = document.getElementById(LidoContainer);
        if (container.getAttribute('drop-action') === DropAction.InfiniteDrop) {
            const buttons = this.el.querySelectorAll('.key-button');
            const firstButton = buttons[0];
            buttons.forEach((button) => {
                button.style.width = firstButton.offsetWidth + 'px';
                button.style.height = firstButton.offsetHeight + 'px';
            });
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            fontSize: parseProp(this.fontSize, orientation),
            fontFamily: this.fontFamily,
            color: parseProp(this.fontColor, orientation),
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'flex' : 'none',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: parseProp(this.borderRadius, orientation),
            columns: parseProp(`${this.columns}`, orientation),
            gap: parseProp(this.gap, orientation),
        };
    }
    render() {
        const keysArray = this.keys.split(',').map(k => k.trim());
        const container = document.getElementById(LidoContainer);
        const showCheck = container.getAttribute('show-check') === 'true';
        return (h(Host, { key: '4de3b75fa2905744ad610d147d9b4fe9912dd732', class: "lido-keyboard", style: { width: this.style.width, height: this.style.height, position: 'relative', margin: this.style.margin, zIndex: this.z } }, this.keyboardInput && (h("div", { key: '7b5d293c52747700cde9c1069cfbbdae065e64f9', class: "input-area" }, h("input", { key: '03a91cd87e6bb4f09bf698087258426dd9232f67', type: "text", value: this.inputString, class: "input-area", readonly: true }), h("lido-text", { key: 'd30e033a055df52b30b2f2775c2b3410ee37df63', visible: showCheck ? 'true' : 'false', string: "<<", "bg-color": "black", "font-color": "white", "border-radius": "20px", "font-size": "30px", width: "100px", height: "70px", type: "click", onClick: () => {
                this.inputString = this.inputString.slice(0, -1);
                this.inputValidation(event);
            } }), h("lido-text", { key: '70d78aed7dedbe7d03a05c13c4c320029280bb03', visible: showCheck ? 'true' : 'false', id: "lido-checkButton", string: "Enter", "bg-color": "green", "font-color": "white", "border-radius": "20px", "font-size": "30px", width: "150px", height: "70px", type: "click" }))), this.letterLength && (h("lido-text", { key: '19306cd12bd98dc8dc7b54b20bad3f2f0318116f', visible: "true", string: `${this.numberOfClick}/${this.letterLength}`, "font-size": "60px", "font-color": "white", onEntry: "this.position='absolute'; this.right='0'; this.fontWeight='800';", x: "unset" })), h("div", { key: '826900d6ba26175eb45d2e7e4c02fccce2004db3', class: "keyboard-wrapper", style: {
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignContent: 'stretch',
                gap: this.gap,
                width: '100%',
                height: '100%',
            } }, keysArray.map((key, index) => {
            const [label, status] = key.split('-');
            const isDisabled = status === 'disable';
            let string = label === 'Space' ? ' ' : label;
            return (h("lido-text", { id: 'key-button-' + index, style: {
                    flex: `0 0 calc(${100 / parseInt(this.style.columns)}% - ${this.style.gap})`,
                }, visible: "true", "font-size": this.style.fontSize, "font-color": this.fontColor, "font-family": this.fontFamily, "bg-color": this.bgColor, string: label, onEntry: this.onEntry, "border-radius": this.style.borderRadius, value: label.toLowerCase(), type: this.type, class: `key-button${isDisabled ? ' disabled' : ''}`, onClick: () => {
                    this.inputString += string;
                    this.inputValidation(event);
                }, "disable-speak": this.disableSpeak }));
        }))));
    }
    get el() { return getElement(this); }
};
LidoKeyboard.style = lidoKeyboardCss();

export { LidoKeyboard as lido_keyboard };
