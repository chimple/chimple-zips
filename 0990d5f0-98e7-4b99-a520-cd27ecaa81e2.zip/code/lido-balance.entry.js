import { r as registerInstance, a as getAssetPath, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { k as convertUrlToRelative, y as initEventsForElement, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoBalanceCss = () => `#lido-balance{position:relative;height:500px;width:1205px;top:20%;left:-91px;z-index:0}.lido-balance-symbol{position:absolute;top:64%;left:50%;transform:translate(-50%, -50%);font-size:5vw;font-weight:bold;color:black;pointer-events:none;z-index:999}@media (orientation: portrait){.lido-balance-shadow{height:100px;position:absolute;top:80%;left:28%}}.balance-plate-feedback{position:absolute;top:52%;width:34%;height:12px;border-radius:0 0 8px 8px;opacity:0.95;box-shadow:0 9px 10px -2px rgba(70, 0, 0, 0.6);pointer-events:none;z-index:95}.balance-plate-feedback[aria-hidden='true']{display:none}.balance-plate-feedback.left{left:2.5%}.balance-plate-feedback.right{right:2.5%}.balance-plate-feedback::after{content:'';position:absolute;top:100%;left:4%;width:92%;height:11px;border-radius:0 0 8px 8px;background:inherit;opacity:0.75;filter:blur(5px);pointer-events:none}@media (orientation: landscape){.lido-balance-shadow{height:100px;position:absolute;top:90%;left:33%}}@media (orientation: portrait){#pivotimg{position:absolute;height:auto;width:23%;bottom:18%;left:38%;z-index:100}}#pivotimg::after{content:"";position:absolute;bottom:-30px;left:50%;transform:translateX(-50%);width:120%;height:60px;background-image:var(--lido-balance-shadow-url);background-size:contain;background-repeat:no-repeat;background-position:center;pointer-events:none;z-index:10}@media (orientation: landscape){#pivotimg{position:absolute;height:auto;width:23%;bottom:8%;left:38%;z-index:100}}.lido-balance .pivot svg{width:100%;height:auto}#scaleimg{position:absolute;width:73%;height:auto;top:61%;left:14%;z-index:90}.lido-balance .scale svg{width:100%;height:auto}@media (orientation: landscape){#handlerimg{position:absolute;width:35%;height:auto;top:49%;left:2%}}@media (orientation:portrait ){#handlerimg{position:absolute;width:35%;height:auto;top:53%;left:2%}}.lido-balance .handler svg{width:100%;height:auto;fill:brown}@media (orientation: landscape){#handimg{position:absolute;width:35%;height:auto;top:49%;right:2%}}@media (orientation:portrait){#handimg{position:absolute;width:35%;height:auto;top:53%;right:2%}}.lido-balance .hand svg{width:100%;height:auto;fill:brown}.pivot svg path:nth-of-type(1){fill:brown}.pivot svg path[d^="M78.9414"]{fill:white}`;

const LidoBalance = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * URL of the pivot (base stand) image used in the balance visualization.
         */
        this.pivotimage = '';
        /**
         * URL of the scale (bar) image that tilts based on the weight difference.
         */
        this.scaleimage = '';
        /**
         * URL of the handler (side stands / hooks) image for the balance.
         */
        this.handlerimage = '';
        /**
         * Fill color applied to all loaded SVGs (pivot, scale, handler).
         * Defaults to "brown".
         */
        this.fill = 'brown';
        /**
         * Initial tilt value of the balance.
         * Negative = tilts left, Positive = tilts right.
         */
        this.tilt = 0;
        /**
         * Maximum allowed tilt angle (in degrees) for the balance bar.
         */
        this.maxTilt = 9.5;
        /**
         * Action(s) to execute when the component enters the DOM.
         * Example: trigger animations or audio cues.
         */
        this.onEntry = '';
        /**
         * CSS height of the component (responsive values allowed).
         * Default: "auto".
         */
        this.height = 'auto';
        /**
         * CSS width of the component (responsive values allowed).
         * Default: "auto".
         */
        this.width = 'auto';
        /**
         * Horizontal (X-axis) offset for positioning the component.
         * Default: "0px".
         */
        this.x = '0px';
        /**
         * Vertical (Y-axis) offset for positioning the component.
         * Default: "0px".
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the component.
         * Default: "0".
         */
        this.z = '0';
        /**
         * Controls component visibility.
         * Accepts boolean (`true`/`false`) or string ("true"/"false").
         */
        this.visible = false;
        /**
         * CSS margin applied to the outer container.
         */
        this.margin = '';
        /**
         * CSS padding applied to the outer container.
         */
        this.padding = '';
        /**
         * Balance symbol shown when `showSymbol` is true.
         * Default: "=".
         */
        this.balanceSymbol = '=';
        /**
         * Whether the balance symbol is currently displayed.
         * Can be toggled with `revealSymbol()` and `hideSymbol()`.
         */
        this.showSymbol = false;
        /**
         * Operation type used to calculate balance values.
         * Supported: "count", "add", "subtract", etc.
         */
        this.operation = 'count';
        /**
         * SVG markup of the pivot element after applying fill/stroke modifications.
         */
        this.pivotSvg = '';
        /**
         * SVG markup of the scale element after applying fill/stroke modifications.
         */
        this.scaleSvg = '';
        /**
         * SVG markup of the handler element after applying fill/stroke modifications.
         */
        this.handlerSvg = '';
        /**
         * Computed inline styles applied to the component host.
         * Updates dynamically based on orientation and props.
         */
        this.style = {};
        /**
         * Final effective tilt value (after clamping/updates).
         */
        this.tiltf = 0;
        /**
         * Current computed value of the left side of the balance.
         */
        this.leftVal = 0;
        /**
         * Current computed value of the right side of the balance.
         */
        this.rightVal = 0;
        this.feedbackColor = '';
        this.currentAngle = 0;
    }
    async revealSymbol() {
        this.showSymbol = true;
    }
    async hideSymbol() {
        this.showSymbol = false;
    }
    async setFeedbackColor(color = '') {
        this.feedbackColor = color;
    }
    async componentWillLoad() {
        this.initializeInitialSymbol();
        this.updateStyles();
        this.pivotSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.pivotimage));
        this.scaleSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.scaleimage));
        this.handlerSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.handlerimage));
    }
    initializeInitialSymbol() {
        var _a, _b;
        const container = (_a = this.el) === null || _a === void 0 ? void 0 : _a.closest('lido-container');
        const objective = (_b = container === null || container === void 0 ? void 0 : container.getAttribute('objective')) === null || _b === void 0 ? void 0 : _b.trim();
        if (objective === '>' || objective === '<' || objective === '=')
            this.balanceSymbol = objective;
        this.showSymbol = true;
    }
    componentDidLoad() {
        this.animateBalance();
        this.leftParentEl = document.getElementById("leftparent");
        this.rightParentEl = document.getElementById("rightparent");
        initEventsForElement(this.el);
    }
    disconnectedCallback() {
        if (this.animationFrameId != null)
            cancelAnimationFrame(this.animationFrameId);
    }
    async fetchAndApplyFill(url) {
        try {
            const res = await fetch(url);
            if (!res.ok)
                return '';
            let svg = await res.text();
            svg = svg.replace(/fill="[^"]*"/g, '');
            svg = svg.replace(/stroke="[^"]*"/g, '');
            svg = svg.replace(/<svg([^>]*)>/, `<svg$1 fill="${this.fill}" stroke="${this.fill}">`);
            return svg;
        }
        catch (e) {
            console.error('SVG fetch failed:', e);
            return '';
        }
    }
    tiltChanged(newValue) {
        this.tiltf = newValue;
    }
    async updateTilt(leftVal, rightVal) {
        const diff = rightVal - leftVal;
        const newTilt = Math.max(-5, Math.min(5, diff));
        await new Promise(res => setTimeout(res, 700));
        this.tiltf = newTilt;
    }
    animateBalance() {
        const rotate = () => {
            let targetAngle = (this.tiltf / 5) * this.maxTilt;
            if (targetAngle > this.maxTilt)
                targetAngle = this.maxTilt;
            if (targetAngle < -this.maxTilt)
                targetAngle = -this.maxTilt;
            this.currentAngle += (targetAngle - this.currentAngle) * 0.1;
            if (this.currentAngle > this.maxTilt)
                this.currentAngle = this.maxTilt;
            if (this.currentAngle < -this.maxTilt)
                this.currentAngle = -this.maxTilt;
            if (this.scaleEl) {
                this.scaleEl.style.transform = `rotate(${this.currentAngle}deg)`;
                this.scaleEl.style.transformOrigin = '50% 80%';
            }
            if (this.leftParentEl && this.rightParentEl) {
                const isPortrait = window.innerHeight > window.innerWidth;
                const maxOffset = isPortrait ? 40 : 60;
                const offset = (this.currentAngle / this.maxTilt) * maxOffset;
                this.leftParentEl.style.transform = `translateY(${-offset}px)`;
                this.rightParentEl.style.transform = `translateY(${offset}px)`;
            }
            if (this.leftHandleEl && this.rightHandleEl) {
                const isPortrait = window.innerHeight > window.innerWidth;
                const maxOffset = isPortrait ? 40 : 60;
                const offset = (this.currentAngle / this.maxTilt) * maxOffset;
                this.leftHandleEl.style.transform = `translateY(${-offset}px)`;
                this.rightHandleEl.style.transform = `translateY(${offset}px)`;
                const feedbackOffset = (this.currentAngle / this.maxTilt) * maxOffset;
                if (this.leftFeedbackEl)
                    this.leftFeedbackEl.style.transform = `translateY(${-feedbackOffset}px)`;
                if (this.rightFeedbackEl)
                    this.rightFeedbackEl.style.transform = `translateY(${feedbackOffset}px)`;
            }
            this.animationFrameId = requestAnimationFrame(rotate);
        };
        rotate();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === "true" ? 'flex' : 'none',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            '--lido-balance-shadow-url': `url(${getAssetPath('assets/Shadow.svg')})`,
        };
    }
    render() {
        return (h(Host, { key: 'b455b2b5d330a2125f7fb8b4e2165d2e6e6bc1a0', id: "lido-balance", "bg-color": "red", onEntry: this.onEntry, class: "lido-balance", tilt: this.tilt.toString(), style: this.style, operation: this.operation.toString(), "pivot-image": this.pivotSvg, "scale-image": this.scaleSvg, "handler-image": this.handlerSvg }, h("div", { key: '657f471d397dd7e3476d5b6e35ee4495c8f2db4c', innerHTML: this.pivotSvg, id: "pivotimg", class: "pivot" }), h("div", { key: '7b91e1919db1fdbcddf79f43a9ad51695b7c806f', innerHTML: this.scaleSvg, id: "scaleimg", class: "scale", ref: (el) => (this.scaleEl = el) }), h("div", { key: '137a1440d55776d0771d8cd71741202c224896db', innerHTML: this.handlerSvg, id: "handlerimg", class: "handler", ref: (el) => (this.leftHandleEl = el) }), h("div", { key: 'd6e0deae63a4e219757240e585d582fb5a72a071', innerHTML: this.handlerSvg, id: "handimg", class: "hand", ref: (el) => (this.rightHandleEl = el) }), h("div", { key: 'ef51f98937cf10c017c8289359c92c24e7316a16', class: "balance-plate-feedback left", ref: (el) => (this.leftFeedbackEl = el), style: { backgroundColor: this.feedbackColor }, "aria-hidden": !this.feedbackColor }), h("div", { key: 'f21aade8543977b657a4d2fbcd623cf8769459a0', class: "balance-plate-feedback right", ref: (el) => (this.rightFeedbackEl = el), style: { backgroundColor: this.feedbackColor }, "aria-hidden": !this.feedbackColor }), h("div", { key: '0470afcef443dbeb69a7d651220d5ff50be3836e', id: "balanceSymbol", class: "lido-balance-symbol", "aria-hidden": !this.showSymbol }, this.showSymbol ? this.balanceSymbol : '')));
    }
    static get assetsDirs() { return ["assets"]; }
    get el() { return getElement(this); }
    static get watchers() { return {
        "tilt": [{
                "tiltChanged": 0
            }]
    }; }
};
LidoBalance.style = lidoBalanceCss();

export { LidoBalance as lido_balance };
