import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { y as initEventsForElement, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoPosCss = () => `.lido-pos{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);display:flex;justify-content:space-around;flex-direction:column;position:fixed}.lido-pos>*{position:absolute}`;

const LidoPos = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the positional element.
         */
        this.id = '';
        /**
         * Value assigned to the component, often used for internal logic or data tracking.
         */
        this.value = '';
        /**
         * The height of the component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the component (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the component (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the element relative to others.
         */
        this.z = '0';
        /**
         * Background color of the component (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The type of the component, used for conditional logic or specific styles.
         */
        this.type = '';
        /**
         * Tab index to support keyboard navigation within the component.
         */
        this.tabIndex = 0;
        /**
         * Visibility flag to control whether the element is displayed (`true`) or hidden (`false`).
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the component is entered, often used to trigger animations or custom logic.
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * Lifecycle hook that is called after the component has been rendered in the DOM.
     * It initializes custom events based on the `type` of the component.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: JSON.parse(parseProp(`${this.visible}`, orientation)) ? 'block' : 'none', // Toggle visibility
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: 'cfd38900b31991e89c21a099fc4f91f77663ae94', id: this.id, class: "lido-pos", type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, minDrops: this.minDrops, maxDrops: this.maxDrops, value: this.value, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: '73f7bfe2d8214693d6f40a4dab6d735906ad4eaa' })));
    }
    get el() { return getElement(this); }
};
LidoPos.style = lidoPosCss();

export { LidoPos as lido_pos };
