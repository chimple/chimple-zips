import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { x as setVisibilityWithDelay, y as initEventsForElement, H as attachSpeakIcon, $ as LIDO_COMMON_AUDIO_READY_EVENT, L as LIDO_COMMON_AUDIO_PATH, k as convertUrlToRelative, z as parseProp } from './utils-Zx3fBgtB.js';
import { i as instance } from './i18n-CCzaXRoU.js';

const lidoTextCss = () => `.lido-text{transition:background-color 0.3s ease;user-select:none;align-items:center;justify-content:center;text-align:center;border-radius:24px;color:#333;cursor:pointer;font-family:'Baloo Bhai 2', serif}.text-letters{transition:color 0.3s, text-shadow 0.3s;display:inline-block;padding:0 2px}.text-letters.letter-highlight{color:#8e24aa;background:none;border-radius:0;text-shadow:0 2px 8px #8e24aa88;animation:text-letter-bounce 0.4s}.text-words{transition:color 0.3s, text-shadow 0.3s;display:inline-block;padding:0 2px}.text-words.word-highlight{color:#8e24aa;background:none;border-radius:0;text-shadow:0 2px 8px #8e24aa88;animation:text-word-bounce 0.4s}@keyframes text-letter-bounce{0%{transform:scale(1)}60%{transform:scale(1.4)}100%{transform:scale(1)}}@keyframes text-word-bounce{0%{transform:scale(1)}60%{transform:scale(1.3)}100%{transform:scale(1)}}`;

const LidoText = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Unique identifier for the text element.
         */
        this.id = '';
        /**
         * Value associated with the text element, typically used for internal logic or tracking.
        */
        this.value = '';
        /**
         * Number of drag elements required for count-based drop interactions.
         * Used by the Blender template to determine the correct and incorrect border state.
         */
        this.requiredDrops = '';
        /**
         * The string of text to be displayed in the component.
         */
        this.string = '';
        /**
         * Font family for the text (CSS value, e.g., 'Arial', 'Times New Roman').
         */
        this.fontFamily = '';
        /**
         * Font size for the text (CSS value, e.g., '16px', '1.5em').
         */
        this.fontSize = '20px';
        /**
         * Font color for the text (CSS color value, e.g., '#000000', 'red').
         */
        this.fontColor = '';
        /**
         * When set to `true`, the text will highlight while being spoken, typically used for accessibility.
         */
        this.highlightWhileSpeaking = false;
        /**
         * Height of the text component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * Width of the text component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * Allows the text element to be freely moved by pointer/touch and persists the final x/y attributes.
         */
        this.move = 'false';
        /**
         * X-axis (horizontal) position of the text component (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the text component (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the text component relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the text component (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The border image of the column (CSS border-image value, e.g., 'url(border.png)', 'linear-gradient(red, blue)').
         */
        this.borderImage = '';
        /**
         * Defines the type of the component, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the text component. If `true`, the text is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the text component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the text component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * Indicates whether to wrap each letter or each word of the text in a span element.
         * This can be useful for animations or styling individual letters.
         */
        this.spanType = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It initializes custom events based on the `type` of the text component.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        // only create span element if requested
        if (this.spanType === 'words' || this.spanType === 'letters') {
            this.addSpanToText();
        }
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
        if (!this.audio || this.audio.trim() === "") {
            const applyAutoAudio = () => {
                const autoAudio = this.resolveAutoAudio();
                if (autoAudio) {
                    this.audio = autoAudio;
                }
            };
            // If path is already available, apply immediately
            if (window.__LIDO_COMMON_AUDIO_PATH__) {
                applyAutoAudio();
            }
            else {
                // Otherwise, wait for it
                window.addEventListener(LIDO_COMMON_AUDIO_READY_EVENT, applyAutoAudio, { once: true });
            }
        }
    }
    resolveAutoAudio() {
        const base = window[LIDO_COMMON_AUDIO_PATH];
        if (!base || !this.string)
            return null;
        const fileName = this.string;
        return `${base}/${fileName}.mp3`;
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const borderImg = this.borderImage ? convertUrlToRelative(this.borderImage) : '';
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            fontSize: parseProp(this.fontSize, orientation),
            fontFamily: this.fontFamily,
            color: parseProp(this.fontColor, orientation),
            display: parseProp(`${this.visible}`, orientation) === "true" ? 'flex' : 'none', // Toggle visibility
            borderImage: `url(${borderImg})`,
            borderImageSlice: borderImg ? '0 fill' : '',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: parseProp(this.borderRadius, orientation),
        };
    }
    async addSpanToText() {
        const content = this.el.querySelector('.lido-text-content');
        if (!content)
            return;
        const text = content.textContent || '';
        content.innerHTML = '';
        // Wrap each letters in a span inside .lido-text-content
        if (this.spanType === 'letters') {
            text.split('').forEach((letter, idx) => {
                // Skip spaces
                if (letter.trim() === '')
                    return;
                // Create a span for each letter
                const letterSpan = document.createElement('span');
                letterSpan.textContent = letter;
                letterSpan.className = 'text-letters';
                content.appendChild(letterSpan);
            });
        }
        // Wrap each words in a span inside .lido-text-content
        if (this.spanType === 'words') {
            text.split(' ').forEach((word, idx) => {
                const wordSpan = document.createElement('span');
                wordSpan.textContent = word;
                wordSpan.className = 'text-words';
                content.appendChild(wordSpan);
            });
        }
    }
    render() {
        const displayText = instance.t(this.string).replace(/_phonics?/gi, '');
        return (h(Host, { key: 'e26a94ac52d05601588db0f756ba17b95848777a', class: "lido-text", value: this.value, "required-drops": this.requiredDrops, type: this.type, "tab-index": this.tabIndex, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, minDrops: this.minDrops, maxDrops: this.maxDrops, id: this.id, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, move: this.move, "span-type": this.spanType, "disable-speak": `${this.disableSpeak}` }, this.spanType !== '' ? h("div", { class: "lido-text-content" }, " ", displayText) : displayText));
    }
    get el() { return getElement(this); }
};
LidoText.style = lidoTextCss();

export { LidoText as lido_text };
