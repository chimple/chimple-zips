import { r as registerInstance, h, d as Host, e as getElement } from './index-f3zQbgzu.js';
import { y as initEventsForElement, F as handlingChildElements, H as attachSpeakIcon, z as parseProp } from './utils-Zx3fBgtB.js';

const lidoRowCss = () => `.lido-row{display:flex;justify-content:space-around;align-items:center;}.lido-row>*{}`;

const LidoRow = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
    }
    /**
     * Lifecycle hook that runs after the component is loaded into the DOM.
     * It initializes custom events based on the `type` of the row component.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: this.visible ? (this.display ? parseProp(this.display, orientation) : 'flex') : 'none', // Toggle visibility
            flexDirection: !this.direction ? 'row' : parseProp(this.direction, orientation),
            gridTemplateColumns: this.display && parseProp(this.display, orientation) === 'grid' ? 'repeat(auto-fill, minmax(186px, auto))' : undefined,
            gap: this.display && parseProp(this.display, orientation) === 'grid' ? '20px' : undefined,
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: 'c69aea0b1b11d9aec167d1a4376f68073f91ca81', class: "lido-row", type: this.type, "tab-index": this.tabIndex, value: this.value, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, minDrops: this.minDrops, maxDrops: this.maxDrops, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "disable-speak": this.disableSpeak }, h("slot", { key: '8756ee0447057cddb949e23decbde5fe4d1d25c8' })));
    }
    get el() { return getElement(this); }
};
LidoRow.style = lidoRowCss();

export { LidoRow as lido_row };
