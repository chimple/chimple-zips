import { r as registerInstance, h, H as Host, a as getElement, c as getAssetPath, d as createEvent } from './index-Dvjbti-h.js';
import { R as RiveService, s as setVisibilityWithDelay, i as initEventsForElement, c as convertUrlToRelative, p as parseProp, e as equationCheck, S as SelectedValuesKey, a as storingEachActivityScore, A as AudioPlayer, b as executeActions, d as calculateScore, t as triggerNextContainer, C as CalculatorOk, h as handlingChildElements, f as attachSpeakIcon, L as LIDO_INTERACTION_CLEANUP_EVENT, T as TemplateID, j as calculateScale, k as highlightElement, l as Timer, r as resetFloatState, m as handleFloatElementPosition, n as handleElementClick, o as commonjsGlobal, g as getDefaultExportFromCjs, q as generateUUIDFallback, u as ActivityScoreKey, v as dispatchActivityChangeEvent, G as GameScore, w as dispatchGameExitEvent, x as speakUrl, y as nextUrl, z as prevUrl, B as exitUrl, N as NextContainerKey, P as PrevContainerKey, D as LIDO_COMMON_AUDIO_PATH, E as LidoContainer$1, F as getCancelBtnPopup, H as matchStringPattern, I as triggerPrevcontainer, J as setActiveZipAssets, K as clearActiveZipAssets, M as setCancelBtnPopup, O as tinycolor, Q as stopHighlightForSpeakingElement, U as DropAction, V as validateObjectiveStatus, W as fraction, X as LIDO_COMMON_AUDIO_READY_EVENT, Y as TraceMode, Z as speakIcon, _ as fingerUrl } from './index-CKf0fZkD.js';

var rive$1 = {exports: {}};

var rive = rive$1.exports;

var hasRequiredRive;

function requireRive () {
	if (hasRequiredRive) return rive$1.exports;
	hasRequiredRive = 1;
	(function (module, exports) {
		(function webpackUniversalModuleDefinition(root, factory) {
			module.exports = factory();
		})(rive, () => {
		return /******/ (() => { // webpackBootstrap
		/******/ 	var __webpack_modules__ = ([
		/* 0 */,
		/* 1 */
		/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
		/* harmony export */ });

		var Rive = (() => {
		  var _scriptName = typeof document != 'undefined' ? document.currentScript?.src : undefined;
		  
		  return (
		function(moduleArg = {}) {
		  var moduleRtn;

		var m = moduleArg, ba, ca, da = new Promise((a, b) => {
		  ba = a;
		  ca = b;
		}), ea = "object" == typeof window, fa = "function" == typeof importScripts;
		function ha() {
		  function a(g) {
		    const k = d;
		    c = b = 0;
		    d = new Map();
		    k.forEach(p => {
		      try {
		        p(g);
		      } catch (n) {
		        console.error(n);
		      }
		    });
		    this.nb();
		    e && e.Pb();
		  }
		  let b = 0, c = 0, d = new Map(), e = null, f = null;
		  this.requestAnimationFrame = function(g) {
		    b ||= requestAnimationFrame(a.bind(this));
		    const k = ++c;
		    d.set(k, g);
		    return k;
		  };
		  this.cancelAnimationFrame = function(g) {
		    d.delete(g);
		    b && 0 == d.size && (cancelAnimationFrame(b), b = 0);
		  };
		  this.Nb = function(g) {
		    f && (document.body.remove(f), f = null);
		    g || (f = document.createElement("div"), f.style.backgroundColor = "black", f.style.position = "fixed", f.style.right = 0, f.style.top = 0, f.style.color = "white", f.style.padding = "4px", f.innerHTML = "RIVE FPS", g = function(k) {
		      f.innerHTML = "RIVE FPS " + k.toFixed(1);
		    }, document.body.appendChild(f));
		    e = new function() {
		      let k = 0, p = 0;
		      this.Pb = function() {
		        var n = performance.now();
		        p ? (++k, n -= p, 1000 < n && (g(1000 * k / n), k = p = 0)) : (p = n, k = 0);
		      };
		    }();
		  };
		  this.Kb = function() {
		    f && (document.body.remove(f), f = null);
		    e = null;
		  };
		  this.nb = function() {
		  };
		}
		function ia(a) {
		  console.assert(true);
		  const b = new Map();
		  let c = -Infinity;
		  this.push = function(d) {
		    d = d + ((1 << a) - 1) >> a;
		    b.has(d) && clearTimeout(b.get(d));
		    b.set(d, setTimeout(function() {
		      b.delete(d);
		      0 == b.length ? c = -Infinity : d == c && (c = Math.max(...b.keys()), console.assert(c < d));
		    }, 1000));
		    c = Math.max(d, c);
		    return c << a;
		  };
		}
		const ja = m.onRuntimeInitialized;
		m.onRuntimeInitialized = function() {
		  ja && ja();
		  let a = m.decodeAudio;
		  m.decodeAudio = function(e, f) {
		    e = a(e);
		    f(e);
		  };
		  let b = m.decodeFont;
		  m.decodeFont = function(e, f) {
		    e = b(e);
		    f(e);
		  };
		  const c = m.FileAssetLoader;
		  m.ptrToAsset = e => {
		    let f = m.ptrToFileAsset(e);
		    return f.isImage ? m.ptrToImageAsset(e) : f.isFont ? m.ptrToFontAsset(e) : f.isAudio ? m.ptrToAudioAsset(e) : f;
		  };
		  m.CustomFileAssetLoader = c.extend("CustomFileAssetLoader", {__construct:function({loadContents:e}) {
		    this.__parent.__construct.call(this);
		    this.Db = e;
		  }, loadContents:function(e, f) {
		    e = m.ptrToAsset(e);
		    return this.Db(e, f);
		  },});
		  m.CDNFileAssetLoader = c.extend("CDNFileAssetLoader", {__construct:function() {
		    this.__parent.__construct.call(this);
		  }, loadContents:function(e) {
		    let f = m.ptrToAsset(e);
		    e = f.cdnUuid;
		    if ("" === e) {
		      return false;
		    }
		    (function(g, k) {
		      var p = new XMLHttpRequest();
		      p.responseType = "arraybuffer";
		      p.onreadystatechange = function() {
		        4 == p.readyState && 200 == p.status && k(p);
		      };
		      p.open("GET", g, true);
		      p.send(null);
		    })(f.cdnBaseUrl + "/" + e, g => {
		      f.decode(new Uint8Array(g.response));
		    });
		    return true;
		  },});
		  m.FallbackFileAssetLoader = c.extend("FallbackFileAssetLoader", {__construct:function() {
		    this.__parent.__construct.call(this);
		    this.jb = [];
		  }, addLoader:function(e) {
		    this.jb.push(e);
		  }, loadContents:function(e, f) {
		    for (let g of this.jb) {
		      if (g.loadContents(e, f)) {
		        return true;
		      }
		    }
		    return false;
		  },});
		  let d = m.computeAlignment;
		  m.computeAlignment = function(e, f, g, k, p = 1.0) {
		    return d.call(this, e, f, g, k, p);
		  };
		};
		const ka = "createConicGradient createImageData createLinearGradient createPattern createRadialGradient getContextAttributes getImageData getLineDash getTransform isContextLost isPointInPath isPointInStroke measureText".split(" "), la = new function() {
		  function a() {
		    if (!b) {
		      var l = document.createElement("canvas"), u = {alpha:1, depth:0, stencil:0, antialias:0, premultipliedAlpha:1, preserveDrawingBuffer:0, powerPreference:"high-performance", failIfMajorPerformanceCaveat:0, enableExtensionsByDefault:1, explicitSwapControl:1, renderViaOffscreenBackBuffer:1,};
		      let q;
		      if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
		        if (q = l.getContext("webgl", u), c = 1, !q) {
		          return console.log("No WebGL support. Image mesh will not be drawn."), false;
		        }
		      } else {
		        if (q = l.getContext("webgl2", u)) {
		          c = 2;
		        } else {
		          if (q = l.getContext("webgl", u)) {
		            c = 1;
		          } else {
		            return console.log("No WebGL support. Image mesh will not be drawn."), false;
		          }
		        }
		      }
		      q = new Proxy(q, {get(E, w) {
		        if (E.isContextLost()) {
		          if (p || (console.error("Cannot render the mesh because the GL Context was lost. Tried to invoke ", w), p = true), "function" === typeof E[w]) {
		            return function() {
		            };
		          }
		        } else {
		          return "function" === typeof E[w] ? function(...L) {
		            return E[w].apply(E, L);
		          } : E[w];
		        }
		      }, set(E, w, L) {
		        if (E.isContextLost()) {
		          p || (console.error("Cannot render the mesh because the GL Context was lost. Tried to set property " + w), p = true);
		        } else {
		          return E[w] = L, true;
		        }
		      },});
		      d = Math.min(q.getParameter(q.MAX_RENDERBUFFER_SIZE), q.getParameter(q.MAX_TEXTURE_SIZE));
		      function C(E, w, L) {
		        w = q.createShader(w);
		        q.shaderSource(w, L);
		        q.compileShader(w);
		        L = q.getShaderInfoLog(w);
		        if (0 < (L || "").length) {
		          throw L;
		        }
		        q.attachShader(E, w);
		      }
		      l = q.createProgram();
		      C(l, q.VERTEX_SHADER, "attribute vec2 vertex;\n                attribute vec2 uv;\n                uniform vec4 mat;\n                uniform vec2 translate;\n                varying vec2 st;\n                void main() {\n                    st = uv;\n                    gl_Position = vec4(mat2(mat) * vertex + translate, 0, 1);\n                }");
		      C(l, q.FRAGMENT_SHADER, "precision highp float;\n                uniform sampler2D image;\n                varying vec2 st;\n                void main() {\n                    gl_FragColor = texture2D(image, st);\n                }");
		      q.bindAttribLocation(l, 0, "vertex");
		      q.bindAttribLocation(l, 1, "uv");
		      q.linkProgram(l);
		      u = q.getProgramInfoLog(l);
		      if (0 < (u || "").trim().length) {
		        throw u;
		      }
		      e = q.getUniformLocation(l, "mat");
		      f = q.getUniformLocation(l, "translate");
		      q.useProgram(l);
		      q.bindBuffer(q.ARRAY_BUFFER, q.createBuffer());
		      q.enableVertexAttribArray(0);
		      q.enableVertexAttribArray(1);
		      q.bindBuffer(q.ELEMENT_ARRAY_BUFFER, q.createBuffer());
		      q.uniform1i(q.getUniformLocation(l, "image"), 0);
		      q.pixelStorei(q.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
		      b = q;
		    }
		    return true;
		  }
		  let b = null, c = 0, d = 0, e = null, f = null, g = 0, k = 0, p = false;
		  a();
		  this.ac = function() {
		    a();
		    return d;
		  };
		  this.Jb = function(l) {
		    b.deleteTexture && b.deleteTexture(l);
		  };
		  this.Ib = function(l) {
		    if (!a()) {
		      return null;
		    }
		    const u = b.createTexture();
		    if (!u) {
		      return null;
		    }
		    b.bindTexture(b.TEXTURE_2D, u);
		    b.texImage2D(b.TEXTURE_2D, 0, b.RGBA, b.RGBA, b.UNSIGNED_BYTE, l);
		    b.texParameteri(b.TEXTURE_2D, b.TEXTURE_WRAP_S, b.CLAMP_TO_EDGE);
		    b.texParameteri(b.TEXTURE_2D, b.TEXTURE_WRAP_T, b.CLAMP_TO_EDGE);
		    b.texParameteri(b.TEXTURE_2D, b.TEXTURE_MAG_FILTER, b.LINEAR);
		    2 == c ? (b.texParameteri(b.TEXTURE_2D, b.TEXTURE_MIN_FILTER, b.LINEAR_MIPMAP_LINEAR), b.generateMipmap(b.TEXTURE_2D)) : b.texParameteri(b.TEXTURE_2D, b.TEXTURE_MIN_FILTER, b.LINEAR);
		    return u;
		  };
		  const n = new ia(8), t = new ia(8), x = new ia(10), y = new ia(10);
		  this.Mb = function(l, u, q, C, E) {
		    if (a()) {
		      var w = n.push(l), L = t.push(u);
		      if (b.canvas) {
		        if (b.canvas.width != w || b.canvas.height != L) {
		          b.canvas.width = w, b.canvas.height = L;
		        }
		        b.viewport(0, L - u, l, u);
		        b.disable(b.SCISSOR_TEST);
		        b.clearColor(0, 0, 0, 0);
		        b.clear(b.COLOR_BUFFER_BIT);
		        b.enable(b.SCISSOR_TEST);
		        q.sort((H, aa) => aa.ub - H.ub);
		        w = x.push(C);
		        g != w && (b.bufferData(b.ARRAY_BUFFER, 8 * w, b.DYNAMIC_DRAW), g = w);
		        w = 0;
		        for (var R of q) {
		          b.bufferSubData(b.ARRAY_BUFFER, w, R.Sa), w += 4 * R.Sa.length;
		        }
		        console.assert(w == 4 * C);
		        for (var W of q) {
		          b.bufferSubData(b.ARRAY_BUFFER, w, W.Ab), w += 4 * W.Ab.length;
		        }
		        console.assert(w == 8 * C);
		        w = y.push(E);
		        k != w && (b.bufferData(b.ELEMENT_ARRAY_BUFFER, 2 * w, b.DYNAMIC_DRAW), k = w);
		        R = 0;
		        for (var pa of q) {
		          b.bufferSubData(b.ELEMENT_ARRAY_BUFFER, R, pa.indices), R += 2 * pa.indices.length;
		        }
		        console.assert(R == 2 * E);
		        pa = 0;
		        W = true;
		        w = R = 0;
		        for (const H of q) {
		          H.image.Ia != pa && (b.bindTexture(b.TEXTURE_2D, H.image.Ha || null), pa = H.image.Ia);
		          H.fc ? (b.scissor(H.Ya, L - H.Za - H.ib, H.tc, H.ib), W = true) : W && (b.scissor(0, L - u, l, u), W = false);
		          q = 2 / l;
		          const aa = -2 / u;
		          b.uniform4f(e, H.ga[0] * q * H.za, H.ga[1] * aa * H.Aa, H.ga[2] * q * H.za, H.ga[3] * aa * H.Aa);
		          b.uniform2f(f, H.ga[4] * q * H.za + q * (H.Ya - H.bc * H.za) - 1, H.ga[5] * aa * H.Aa + aa * (H.Za - H.cc * H.Aa) + 1);
		          b.vertexAttribPointer(0, 2, b.FLOAT, false, 0, w);
		          b.vertexAttribPointer(1, 2, b.FLOAT, false, 0, w + 4 * C);
		          b.drawElements(b.TRIANGLES, H.indices.length, b.UNSIGNED_SHORT, R);
		          w += 4 * H.Sa.length;
		          R += 2 * H.indices.length;
		        }
		        console.assert(w == 4 * C);
		        console.assert(R == 2 * E);
		      }
		    }
		  };
		  this.canvas = function() {
		    return a() && b.canvas;
		  };
		}(), ma = m.onRuntimeInitialized;
		m.onRuntimeInitialized = function() {
		  function a(r) {
		    switch(r) {
		      case n.srcOver:
		        return "source-over";
		      case n.screen:
		        return "screen";
		      case n.overlay:
		        return "overlay";
		      case n.darken:
		        return "darken";
		      case n.lighten:
		        return "lighten";
		      case n.colorDodge:
		        return "color-dodge";
		      case n.colorBurn:
		        return "color-burn";
		      case n.hardLight:
		        return "hard-light";
		      case n.softLight:
		        return "soft-light";
		      case n.difference:
		        return "difference";
		      case n.exclusion:
		        return "exclusion";
		      case n.multiply:
		        return "multiply";
		      case n.hue:
		        return "hue";
		      case n.saturation:
		        return "saturation";
		      case n.color:
		        return "color";
		      case n.luminosity:
		        return "luminosity";
		    }
		  }
		  function b(r) {
		    return "rgba(" + ((16711680 & r) >>> 16) + "," + ((65280 & r) >>> 8) + "," + ((255 & r) >>> 0) + "," + ((4278190080 & r) >>> 24) / 255 + ")";
		  }
		  function c() {
		    0 < L.length && (la.Mb(w.drawWidth(), w.drawHeight(), L, R, W), L = [], W = R = 0, w.reset(512, 512));
		    for (const r of E) {
		      for (const v of r.H) {
		        v();
		      }
		      r.H = [];
		    }
		    E.clear();
		  }
		  ma && ma();
		  var d = m.RenderPaintStyle;
		  const e = m.RenderPath, f = m.RenderPaint, g = m.Renderer, k = m.StrokeCap, p = m.StrokeJoin, n = m.BlendMode, t = d.fill, x = d.stroke, y = m.FillRule.evenOdd;
		  let l = 1;
		  var u = m.RenderImage.extend("CanvasRenderImage", {__construct:function({ka:r, va:v} = {}) {
		    this.__parent.__construct.call(this);
		    this.Ia = l;
		    l = l + 1 & 2147483647 || 1;
		    this.ka = r;
		    this.va = v;
		  }, __destruct:function() {
		    this.Ha && (la.Jb(this.Ha), URL.revokeObjectURL(this.Va));
		    this.__parent.__destruct.call(this);
		  }, decode:function(r) {
		    var v = this;
		    v.va && v.va(v);
		    var F = new Image();
		    v.Va = URL.createObjectURL(new Blob([r], {type:"image/png",}));
		    F.onload = function() {
		      v.Cb = F;
		      v.Ha = la.Ib(F);
		      v.size(F.width, F.height);
		      v.ka && v.ka(v);
		    };
		    F.src = v.Va;
		  },}), q = e.extend("CanvasRenderPath", {__construct:function() {
		    this.__parent.__construct.call(this);
		    this.T = new Path2D();
		  }, rewind:function() {
		    this.T = new Path2D();
		  }, addPath:function(r, v, F, I, B, G, J) {
		    var K = this.T, Z = K.addPath;
		    r = r.T;
		    const S = new DOMMatrix();
		    S.a = v;
		    S.b = F;
		    S.c = I;
		    S.d = B;
		    S.e = G;
		    S.f = J;
		    Z.call(K, r, S);
		  }, fillRule:function(r) {
		    this.Ua = r;
		  }, moveTo:function(r, v) {
		    this.T.moveTo(r, v);
		  }, lineTo:function(r, v) {
		    this.T.lineTo(r, v);
		  }, cubicTo:function(r, v, F, I, B, G) {
		    this.T.bezierCurveTo(r, v, F, I, B, G);
		  }, close:function() {
		    this.T.closePath();
		  },}), C = f.extend("CanvasRenderPaint", {color:function(r) {
		    this.Wa = b(r);
		  }, thickness:function(r) {
		    this.Fb = r;
		  }, join:function(r) {
		    switch(r) {
		      case p.miter:
		        this.Ga = "miter";
		        break;
		      case p.round:
		        this.Ga = "round";
		        break;
		      case p.bevel:
		        this.Ga = "bevel";
		    }
		  }, cap:function(r) {
		    switch(r) {
		      case k.butt:
		        this.Fa = "butt";
		        break;
		      case k.round:
		        this.Fa = "round";
		        break;
		      case k.square:
		        this.Fa = "square";
		    }
		  }, style:function(r) {
		    this.Eb = r;
		  }, blendMode:function(r) {
		    this.Bb = a(r);
		  }, clearGradient:function() {
		    this.ia = null;
		  }, linearGradient:function(r, v, F, I) {
		    this.ia = {wb:r, xb:v, bb:F, cb:I, Pa:[],};
		  }, radialGradient:function(r, v, F, I) {
		    this.ia = {wb:r, xb:v, bb:F, cb:I, Pa:[], $b:true,};
		  }, addStop:function(r, v) {
		    this.ia.Pa.push({color:r, stop:v,});
		  }, completeGradient:function() {
		  }, draw:function(r, v, F) {
		    let I = this.Eb;
		    var B = this.Wa, G = this.ia;
		    r.globalCompositeOperation = this.Bb;
		    if (null != G) {
		      B = G.wb;
		      var J = G.xb;
		      const Z = G.bb;
		      var K = G.cb;
		      const S = G.Pa;
		      G.$b ? (G = Z - B, K -= J, B = r.createRadialGradient(B, J, 0, B, J, Math.sqrt(G * G + K * K))) : B = r.createLinearGradient(B, J, Z, K);
		      for (let Y = 0, T = S.length; Y < T; Y++) {
		        J = S[Y], B.addColorStop(J.stop, b(J.color));
		      }
		      this.Wa = B;
		      this.ia = null;
		    }
		    switch(I) {
		      case x:
		        r.strokeStyle = B;
		        r.lineWidth = this.Fb;
		        r.lineCap = this.Fa;
		        r.lineJoin = this.Ga;
		        r.stroke(v);
		        break;
		      case t:
		        r.fillStyle = B, r.fill(v, F);
		    }
		  },});
		  const E = new Set();
		  let w = null, L = [], R = 0, W = 0;
		  var pa = m.CanvasRenderer = g.extend("Renderer", {__construct:function(r) {
		    this.__parent.__construct.call(this);
		    this.S = [1, 0, 0, 1, 0, 0];
		    this.B = r.getContext("2d");
		    this.Ta = r;
		    this.H = [];
		  }, save:function() {
		    this.S.push(...this.S.slice(this.S.length - 6));
		    this.H.push(this.B.save.bind(this.B));
		  }, restore:function() {
		    const r = this.S.length - 6;
		    if (6 > r) {
		      throw "restore() called without matching save().";
		    }
		    this.S.splice(r);
		    this.H.push(this.B.restore.bind(this.B));
		  }, transform:function(r, v, F, I, B, G) {
		    const J = this.S, K = J.length - 6;
		    J.splice(K, 6, J[K] * r + J[K + 2] * v, J[K + 1] * r + J[K + 3] * v, J[K] * F + J[K + 2] * I, J[K + 1] * F + J[K + 3] * I, J[K] * B + J[K + 2] * G + J[K + 4], J[K + 1] * B + J[K + 3] * G + J[K + 5]);
		    this.H.push(this.B.transform.bind(this.B, r, v, F, I, B, G));
		  }, rotate:function(r) {
		    const v = Math.sin(r);
		    r = Math.cos(r);
		    this.transform(r, v, -v, r, 0, 0);
		  }, _drawPath:function(r, v) {
		    this.H.push(v.draw.bind(v, this.B, r.T, r.Ua === y ? "evenodd" : "nonzero"));
		  }, _drawRiveImage:function(r, v, F, I) {
		    var B = r.Cb;
		    if (B) {
		      var G = this.B, J = a(F);
		      this.H.push(function() {
		        G.globalCompositeOperation = J;
		        G.globalAlpha = I;
		        G.drawImage(B, 0, 0);
		        G.globalAlpha = 1;
		      });
		    }
		  }, _getMatrix:function(r) {
		    const v = this.S, F = v.length - 6;
		    for (let I = 0; 6 > I; ++I) {
		      r[I] = v[F + I];
		    }
		  }, _drawImageMesh:function(r, v, F, I, B, G, J, K, Z, S, Y) {
		    v = this.B.canvas.width;
		    var T = this.B.canvas.height;
		    const Wb = S - K, Xb = Y - Z;
		    K = Math.max(K, 0);
		    Z = Math.max(Z, 0);
		    S = Math.min(S, v);
		    Y = Math.min(Y, T);
		    const Da = S - K, Ea = Y - Z;
		    console.assert(Da <= Math.min(Wb, v));
		    console.assert(Ea <= Math.min(Xb, T));
		    if (!(0 >= Da || 0 >= Ea)) {
		      S = Da < Wb || Ea < Xb;
		      v = Y = 1;
		      var qa = Math.ceil(Da * Y), ra = Math.ceil(Ea * v);
		      T = la.ac();
		      qa > T && (Y *= T / qa, qa = T);
		      ra > T && (v *= T / ra, ra = T);
		      w || (w = new m.DynamicRectanizer(T), w.reset(512, 512));
		      T = w.addRect(qa, ra);
		      0 > T && (c(), E.add(this), T = w.addRect(qa, ra), console.assert(0 <= T));
		      var Yb = T & 65535, Zb = T >> 16;
		      L.push({ga:this.S.slice(this.S.length - 6), image:r, Ya:Yb, Za:Zb, bc:K, cc:Z, tc:qa, ib:ra, za:Y, Aa:v, Sa:new Float32Array(B), Ab:new Float32Array(G), indices:new Uint16Array(J), fc:S, ub:r.Ia << 1 | (S ? 1 : 0),});
		      R += B.length;
		      W += J.length;
		      var xa = this.B, kd = a(F);
		      this.H.push(function() {
		        xa.save();
		        xa.resetTransform();
		        xa.globalCompositeOperation = kd;
		        xa.globalAlpha = I;
		        const $b = la.canvas();
		        $b && xa.drawImage($b, Yb, Zb, qa, ra, K, Z, Da, Ea);
		        xa.restore();
		      });
		    }
		  }, _clipPath:function(r) {
		    this.H.push(this.B.clip.bind(this.B, r.T, r.Ua === y ? "evenodd" : "nonzero"));
		  }, clear:function() {
		    E.add(this);
		    this.H.push(this.B.clearRect.bind(this.B, 0, 0, this.Ta.width, this.Ta.height));
		  }, flush:function() {
		  }, translate:function(r, v) {
		    this.transform(1, 0, 0, 1, r, v);
		  },});
		  m.makeRenderer = function(r) {
		    const v = new pa(r), F = v.B;
		    return new Proxy(v, {get(I, B) {
		      if ("function" === typeof I[B]) {
		        return function(...G) {
		          return I[B].apply(I, G);
		        };
		      }
		      if ("function" === typeof F[B]) {
		        if (-1 < ka.indexOf(B)) {
		          throw Error("RiveException: Method call to '" + B + "()' is not allowed, as the renderer cannot immediately pass through the return                 values of any canvas 2d context methods.");
		        }
		        return function(...G) {
		          v.H.push(F[B].bind(F, ...G));
		        };
		      }
		      return I[B];
		    }, set(I, B, G) {
		      if (B in F) {
		        return v.H.push(() => {
		          F[B] = G;
		        }), true;
		      }
		    },});
		  };
		  m.decodeImage = function(r, v) {
		    (new u({ka:v})).decode(r);
		  };
		  m.renderFactory = {makeRenderPaint:function() {
		    return new C();
		  }, makeRenderPath:function() {
		    return new q();
		  }, makeRenderImage:function() {
		    let r = aa;
		    return new u({va:() => {
		      r.total++;
		    }, ka:() => {
		      r.loaded++;
		      if (r.loaded === r.total) {
		        const v = r.ready;
		        v && (v(), r.ready = null);
		      }
		    },});
		  },};
		  let H = m.load, aa = null;
		  m.load = function(r, v, F = true) {
		    const I = new m.FallbackFileAssetLoader();
		    void 0 !== v && I.addLoader(v);
		    F && (v = new m.CDNFileAssetLoader(), I.addLoader(v));
		    return new Promise(function(B) {
		      let G = null;
		      aa = {total:0, loaded:0, ready:function() {
		        B(G);
		      },};
		      G = H(r, I);
		      0 == aa.total && B(G);
		    });
		  };
		  let ld = m.RendererWrapper.prototype.align;
		  m.RendererWrapper.prototype.align = function(r, v, F, I, B = 1.0) {
		    ld.call(this, r, v, F, I, B);
		  };
		  d = new ha();
		  m.requestAnimationFrame = d.requestAnimationFrame.bind(d);
		  m.cancelAnimationFrame = d.cancelAnimationFrame.bind(d);
		  m.enableFPSCounter = d.Nb.bind(d);
		  m.disableFPSCounter = d.Kb;
		  d.nb = c;
		  m.resolveAnimationFrame = c;
		  m.cleanup = function() {
		    w && w.delete();
		  };
		};
		var na = Object.assign({}, m), oa = "./this.program", sa = "", ta, ua;
		if (ea || fa) {
		  fa ? sa = self.location.href : "undefined" != typeof document && document.currentScript && (sa = document.currentScript.src), _scriptName && (sa = _scriptName), sa.startsWith("blob:") ? sa = "" : sa = sa.substr(0, sa.replace(/[?#].*/, "").lastIndexOf("/") + 1), fa && (ua = a => {
		    var b = new XMLHttpRequest();
		    b.open("GET", a, false);
		    b.responseType = "arraybuffer";
		    b.send(null);
		    return new Uint8Array(b.response);
		  }), ta = (a, b, c) => {
		    if (va(a)) {
		      var d = new XMLHttpRequest();
		      d.open("GET", a, true);
		      d.responseType = "arraybuffer";
		      d.onload = () => {
		        200 == d.status || 0 == d.status && d.response ? b(d.response) : c();
		      };
		      d.onerror = c;
		      d.send(null);
		    } else {
		      fetch(a, {credentials:"same-origin"}).then(e => e.ok ? e.arrayBuffer() : Promise.reject(Error(e.status + " : " + e.url))).then(b, c);
		    }
		  };
		}
		var wa = m.print || console.log.bind(console), ya = m.printErr || console.error.bind(console);
		Object.assign(m, na);
		na = null;
		m.thisProgram && (oa = m.thisProgram);
		var za;
		m.wasmBinary && (za = m.wasmBinary);
		var Aa, Ba = false, z, A, Ca, Fa, D, M, Ga, Ha;
		function Ia() {
		  var a = Aa.buffer;
		  m.HEAP8 = z = new Int8Array(a);
		  m.HEAP16 = Ca = new Int16Array(a);
		  m.HEAPU8 = A = new Uint8Array(a);
		  m.HEAPU16 = Fa = new Uint16Array(a);
		  m.HEAP32 = D = new Int32Array(a);
		  m.HEAPU32 = M = new Uint32Array(a);
		  m.HEAPF32 = Ga = new Float32Array(a);
		  m.HEAPF64 = Ha = new Float64Array(a);
		}
		var Ja = [], Ka = [], La = [];
		function Ma() {
		  var a = m.preRun.shift();
		  Ja.unshift(a);
		}
		var Na = 0, Pa = null;
		function Qa(a) {
		  m.onAbort?.(a);
		  a = "Aborted(" + a + ")";
		  ya(a);
		  Ba = true;
		  a = new WebAssembly.RuntimeError(a + ". Build with -sASSERTIONS for more info.");
		  ca(a);
		  throw a;
		}
		var Ra = a => a.startsWith("data:application/octet-stream;base64,"), va = a => a.startsWith("file://"), Sa;
		function Ta(a) {
		  if (a == Sa && za) {
		    return new Uint8Array(za);
		  }
		  if (ua) {
		    return ua(a);
		  }
		  throw "both async and sync fetching of the wasm failed";
		}
		function Ua(a) {
		  return za ? Promise.resolve().then(() => Ta(a)) : new Promise((b, c) => {
		    ta(a, d => b(new Uint8Array(d)), () => {
		      try {
		        b(Ta(a));
		      } catch (d) {
		        c(d);
		      }
		    });
		  });
		}
		function Va(a, b, c) {
		  return Ua(a).then(d => WebAssembly.instantiate(d, b)).then(c, d => {
		    ya(`failed to asynchronously prepare wasm: ${d}`);
		    Qa(d);
		  });
		}
		function Wa(a, b) {
		  var c = Sa;
		  return za || "function" != typeof WebAssembly.instantiateStreaming || Ra(c) || va(c) || "function" != typeof fetch ? Va(c, a, b) : fetch(c, {credentials:"same-origin"}).then(d => WebAssembly.instantiateStreaming(d, a).then(b, function(e) {
		    ya(`wasm streaming compile failed: ${e}`);
		    ya("falling back to ArrayBuffer instantiation");
		    return Va(c, a, b);
		  }));
		}
		var Xa, Ya, bb = {464256:(a, b, c, d, e) => {
		  if ("undefined" === typeof window || void 0 === (window.AudioContext || window.webkitAudioContext)) {
		    return 0;
		  }
		  if ("undefined" === typeof window.h) {
		    window.h = {ya:0};
		    window.h.I = {};
		    window.h.I.wa = a;
		    window.h.I.capture = b;
		    window.h.I.Ja = c;
		    window.h.fa = {};
		    window.h.fa.stopped = d;
		    window.h.fa.vb = e;
		    let f = window.h;
		    f.D = [];
		    f.rc = function(g) {
		      for (var k = 0; k < f.D.length; ++k) {
		        if (null == f.D[k]) {
		          return f.D[k] = g, k;
		        }
		      }
		      f.D.push(g);
		      return f.D.length - 1;
		    };
		    f.zb = function(g) {
		      for (f.D[g] = null; 0 < f.D.length;) {
		        if (null == f.D[f.D.length - 1]) {
		          f.D.pop();
		        } else {
		          break;
		        }
		      }
		    };
		    f.Oc = function(g) {
		      for (var k = 0; k < f.D.length; ++k) {
		        if (f.D[k] == g) {
		          return f.zb(k);
		        }
		      }
		    };
		    f.pa = function(g) {
		      return f.D[g];
		    };
		    f.Ra = ["touchend", "click"];
		    f.unlock = function() {
		      for (var g = 0; g < f.D.length; ++g) {
		        var k = f.D[g];
		        null != k && null != k.K && k.state === f.fa.vb && k.K.resume().then(() => {
		          Za(k.ob);
		        }, p => {
		          console.error("Failed to resume audiocontext", p);
		        });
		      }
		      f.Ra.map(function(p) {
		        document.removeEventListener(p, f.unlock, true);
		      });
		    };
		    f.Ra.map(function(g) {
		      document.addEventListener(g, f.unlock, true);
		    });
		  }
		  window.h.ya += 1;
		  return 1;
		}, 466434:() => {
		  "undefined" !== typeof window.h && (window.h.Ra.map(function(a) {
		    document.removeEventListener(a, window.h.unlock, true);
		  }), --window.h.ya, 0 === window.h.ya && delete window.h);
		}, 466738:() => void 0 !== navigator.mediaDevices && void 0 !== navigator.mediaDevices.getUserMedia, 466842:() => {
		  try {
		    var a = new (window.AudioContext || window.webkitAudioContext)(), b = a.sampleRate;
		    a.close();
		    return b;
		  } catch (c) {
		    return 0;
		  }
		}, 467013:(a, b, c, d, e, f) => {
		  if ("undefined" === typeof window.h) {
		    return -1;
		  }
		  var g = {}, k = {};
		  a == window.h.I.wa && 0 != c && (k.sampleRate = c);
		  g.K = new (window.AudioContext || window.webkitAudioContext)(k);
		  g.K.suspend();
		  g.state = window.h.fa.stopped;
		  c = 0;
		  a != window.h.I.wa && (c = b);
		  g.Y = g.K.createScriptProcessor(d, c, b);
		  g.Y.onaudioprocess = function(p) {
		    if (null == g.qa || 0 == g.qa.length) {
		      g.qa = new Float32Array(Ga.buffer, e, d * b);
		    }
		    if (a == window.h.I.capture || a == window.h.I.Ja) {
		      for (var n = 0; n < b; n += 1) {
		        for (var t = p.inputBuffer.getChannelData(n), x = g.qa, y = 0; y < d; y += 1) {
		          x[y * b + n] = t[y];
		        }
		      }
		      $a(f, d, e);
		    }
		    if (a == window.h.I.wa || a == window.h.I.Ja) {
		      for (ab(f, d, e), n = 0; n < p.outputBuffer.numberOfChannels; ++n) {
		        for (t = p.outputBuffer.getChannelData(n), x = g.qa, y = 0; y < d; y += 1) {
		          t[y] = x[y * b + n];
		        }
		      }
		    } else {
		      for (n = 0; n < p.outputBuffer.numberOfChannels; ++n) {
		        p.outputBuffer.getChannelData(n).fill(0.0);
		      }
		    }
		  };
		  a != window.h.I.capture && a != window.h.I.Ja || navigator.mediaDevices.getUserMedia({audio:true, video:false}).then(function(p) {
		    g.Ba = g.K.createMediaStreamSource(p);
		    g.Ba.connect(g.Y);
		    g.Y.connect(g.K.destination);
		  }).catch(function(p) {
		    console.log("Failed to get user media: " + p);
		  });
		  a == window.h.I.wa && g.Y.connect(g.K.destination);
		  g.ob = f;
		  return window.h.rc(g);
		}, 469890:a => window.h.pa(a).K.sampleRate, 469963:a => {
		  a = window.h.pa(a);
		  void 0 !== a.Y && (a.Y.onaudioprocess = function() {
		  }, a.Y.disconnect(), a.Y = void 0);
		  void 0 !== a.Ba && (a.Ba.disconnect(), a.Ba = void 0);
		  a.K.close();
		  a.K = void 0;
		  a.ob = void 0;
		}, 470363:a => {
		  window.h.zb(a);
		}, 470413:a => {
		  a = window.h.pa(a);
		  a.K.resume();
		  a.state = window.h.fa.vb;
		}, 470552:a => {
		  a = window.h.pa(a);
		  a.K.suspend();
		  a.state = window.h.fa.stopped;
		}}, cb = a => {
		  for (; 0 < a.length;) {
		    a.shift()(m);
		  }
		};
		function db() {
		  var a = D[+eb >> 2];
		  eb += 4;
		  return a;
		}
		var fb = (a, b) => {
		  for (var c = 0, d = a.length - 1; 0 <= d; d--) {
		    var e = a[d];
		    "." === e ? a.splice(d, 1) : ".." === e ? (a.splice(d, 1), c++) : c && (a.splice(d, 1), c--);
		  }
		  if (b) {
		    for (; c; c--) {
		      a.unshift("..");
		    }
		  }
		  return a;
		}, gb = a => {
		  var b = "/" === a.charAt(0), c = "/" === a.substr(-1);
		  (a = fb(a.split("/").filter(d => !!d), !b).join("/")) || b || (a = ".");
		  a && c && (a += "/");
		  return (b ? "/" : "") + a;
		}, hb = a => {
		  var b = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/.exec(a).slice(1);
		  a = b[0];
		  b = b[1];
		  if (!a && !b) {
		    return ".";
		  }
		  b &&= b.substr(0, b.length - 1);
		  return a + b;
		}, ib = a => {
		  if ("/" === a) {
		    return "/";
		  }
		  a = gb(a);
		  a = a.replace(/\/$/, "");
		  var b = a.lastIndexOf("/");
		  return -1 === b ? a : a.substr(b + 1);
		}, jb = () => {
		  if ("object" == typeof crypto && "function" == typeof crypto.getRandomValues) {
		    return a => crypto.getRandomValues(a);
		  }
		  Qa("initRandomDevice");
		}, kb = a => (kb = jb())(a), lb = (...a) => {
		  for (var b = "", c = false, d = a.length - 1; -1 <= d && !c; d--) {
		    c = 0 <= d ? a[d] : "/";
		    if ("string" != typeof c) {
		      throw new TypeError("Arguments to path.resolve must be strings");
		    }
		    if (!c) {
		      return "";
		    }
		    b = c + "/" + b;
		    c = "/" === c.charAt(0);
		  }
		  b = fb(b.split("/").filter(e => !!e), !c).join("/");
		  return (c ? "/" : "") + b || ".";
		}, mb = "undefined" != typeof TextDecoder ? new TextDecoder("utf8") : void 0, nb = (a, b, c) => {
		  var d = b + c;
		  for (c = b; a[c] && !(c >= d);) {
		    ++c;
		  }
		  if (16 < c - b && a.buffer && mb) {
		    return mb.decode(a.subarray(b, c));
		  }
		  for (d = ""; b < c;) {
		    var e = a[b++];
		    if (e & 128) {
		      var f = a[b++] & 63;
		      if (192 == (e & 224)) {
		        d += String.fromCharCode((e & 31) << 6 | f);
		      } else {
		        var g = a[b++] & 63;
		        e = 224 == (e & 240) ? (e & 15) << 12 | f << 6 | g : (e & 7) << 18 | f << 12 | g << 6 | a[b++] & 63;
		        65536 > e ? d += String.fromCharCode(e) : (e -= 65536, d += String.fromCharCode(55296 | e >> 10, 56320 | e & 1023));
		      }
		    } else {
		      d += String.fromCharCode(e);
		    }
		  }
		  return d;
		}, ob = [], pb = a => {
		  for (var b = 0, c = 0; c < a.length; ++c) {
		    var d = a.charCodeAt(c);
		    127 >= d ? b++ : 2047 >= d ? b += 2 : 55296 <= d && 57343 >= d ? (b += 4, ++c) : b += 3;
		  }
		  return b;
		}, qb = (a, b, c, d) => {
		  if (!(0 < d)) {
		    return 0;
		  }
		  var e = c;
		  d = c + d - 1;
		  for (var f = 0; f < a.length; ++f) {
		    var g = a.charCodeAt(f);
		    if (55296 <= g && 57343 >= g) {
		      var k = a.charCodeAt(++f);
		      g = 65536 + ((g & 1023) << 10) | k & 1023;
		    }
		    if (127 >= g) {
		      if (c >= d) {
		        break;
		      }
		      b[c++] = g;
		    } else {
		      if (2047 >= g) {
		        if (c + 1 >= d) {
		          break;
		        }
		        b[c++] = 192 | g >> 6;
		      } else {
		        if (65535 >= g) {
		          if (c + 2 >= d) {
		            break;
		          }
		          b[c++] = 224 | g >> 12;
		        } else {
		          if (c + 3 >= d) {
		            break;
		          }
		          b[c++] = 240 | g >> 18;
		          b[c++] = 128 | g >> 12 & 63;
		        }
		        b[c++] = 128 | g >> 6 & 63;
		      }
		      b[c++] = 128 | g & 63;
		    }
		  }
		  b[c] = 0;
		  return c - e;
		};
		function rb(a, b) {
		  var c = Array(pb(a) + 1);
		  a = qb(a, c, 0, c.length);
		  b && (c.length = a);
		  return c;
		}
		var sb = [];
		function tb(a, b) {
		  sb[a] = {input:[], G:[], V:b};
		  ub(a, vb);
		}
		var vb = {open(a) {
		  var b = sb[a.node.xa];
		  if (!b) {
		    throw new N(43);
		  }
		  a.s = b;
		  a.seekable = false;
		}, close(a) {
		  a.s.V.oa(a.s);
		}, oa(a) {
		  a.s.V.oa(a.s);
		}, read(a, b, c, d) {
		  if (!a.s || !a.s.V.hb) {
		    throw new N(60);
		  }
		  for (var e = 0, f = 0; f < d; f++) {
		    try {
		      var g = a.s.V.hb(a.s);
		    } catch (k) {
		      throw new N(29);
		    }
		    if (void 0 === g && 0 === e) {
		      throw new N(6);
		    }
		    if (null === g || void 0 === g) {
		      break;
		    }
		    e++;
		    b[c + f] = g;
		  }
		  e && (a.node.timestamp = Date.now());
		  return e;
		}, write(a, b, c, d) {
		  if (!a.s || !a.s.V.Ma) {
		    throw new N(60);
		  }
		  try {
		    for (var e = 0; e < d; e++) {
		      a.s.V.Ma(a.s, b[c + e]);
		    }
		  } catch (f) {
		    throw new N(29);
		  }
		  d && (a.node.timestamp = Date.now());
		  return e;
		},}, wb = {hb() {
		  a: {
		    if (!ob.length) {
		      var a = null;
		      "undefined" != typeof window && "function" == typeof window.prompt && (a = window.prompt("Input: "), null !== a && (a += "\n"));
		      if (!a) {
		        a = null;
		        break a;
		      }
		      ob = rb(a, true);
		    }
		    a = ob.shift();
		  }
		  return a;
		}, Ma(a, b) {
		  null === b || 10 === b ? (wa(nb(a.G, 0)), a.G = []) : 0 != b && a.G.push(b);
		}, oa(a) {
		  a.G && 0 < a.G.length && (wa(nb(a.G, 0)), a.G = []);
		}, Xb() {
		  return {zc:25856, Bc:5, yc:191, Ac:35387, xc:[3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,]};
		}, Yb() {
		  return 0;
		}, Zb() {
		  return [24, 80];
		},}, xb = {Ma(a, b) {
		  null === b || 10 === b ? (ya(nb(a.G, 0)), a.G = []) : 0 != b && a.G.push(b);
		}, oa(a) {
		  a.G && 0 < a.G.length && (ya(nb(a.G, 0)), a.G = []);
		},};
		function yb(a, b) {
		  var c = a.l ? a.l.length : 0;
		  c >= b || (b = Math.max(b, c * (1048576 > c ? 2.0 : 1.125) >>> 0), 0 != c && (b = Math.max(b, 256)), c = a.l, a.l = new Uint8Array(b), 0 < a.v && a.l.set(c.subarray(0, a.v), 0));
		}
		var O = {N:null, U() {
		  return O.createNode(null, "/", 16895, 0);
		}, createNode(a, b, c, d) {
		  if (24576 === (c & 61440) || 4096 === (c & 61440)) {
		    throw new N(63);
		  }
		  O.N || (O.N = {dir:{node:{X:O.j.X, P:O.j.P, ja:O.j.ja, ta:O.j.ta, sb:O.j.sb, yb:O.j.yb, tb:O.j.tb, rb:O.j.rb, Ca:O.j.Ca}, stream:{aa:O.m.aa}}, file:{node:{X:O.j.X, P:O.j.P}, stream:{aa:O.m.aa, read:O.m.read, write:O.m.write, Xa:O.m.Xa, kb:O.m.kb, mb:O.m.mb}}, link:{node:{X:O.j.X, P:O.j.P, la:O.j.la}, stream:{}}, $a:{node:{X:O.j.X, P:O.j.P}, stream:zb}});
		  c = Ab(a, b, c, d);
		  16384 === (c.mode & 61440) ? (c.j = O.N.dir.node, c.m = O.N.dir.stream, c.l = {}) : 32768 === (c.mode & 61440) ? (c.j = O.N.file.node, c.m = O.N.file.stream, c.v = 0, c.l = null) : 40960 === (c.mode & 61440) ? (c.j = O.N.link.node, c.m = O.N.link.stream) : 8192 === (c.mode & 61440) && (c.j = O.N.$a.node, c.m = O.N.$a.stream);
		  c.timestamp = Date.now();
		  a && (a.l[b] = c, a.timestamp = c.timestamp);
		  return c;
		}, Fc(a) {
		  return a.l ? a.l.subarray ? a.l.subarray(0, a.v) : new Uint8Array(a.l) : new Uint8Array(0);
		}, j:{X(a) {
		  var b = {};
		  b.Dc = 8192 === (a.mode & 61440) ? a.id : 1;
		  b.Hc = a.id;
		  b.mode = a.mode;
		  b.Kc = 1;
		  b.uid = 0;
		  b.Gc = 0;
		  b.xa = a.xa;
		  16384 === (a.mode & 61440) ? b.size = 4096 : 32768 === (a.mode & 61440) ? b.size = a.v : 40960 === (a.mode & 61440) ? b.size = a.link.length : b.size = 0;
		  b.vc = new Date(a.timestamp);
		  b.Jc = new Date(a.timestamp);
		  b.Cc = new Date(a.timestamp);
		  b.Gb = 4096;
		  b.wc = Math.ceil(b.size / b.Gb);
		  return b;
		}, P(a, b) {
		  void 0 !== b.mode && (a.mode = b.mode);
		  void 0 !== b.timestamp && (a.timestamp = b.timestamp);
		  if (void 0 !== b.size && (b = b.size, a.v != b)) {
		    if (0 == b) {
		      a.l = null, a.v = 0;
		    } else {
		      var c = a.l;
		      a.l = new Uint8Array(b);
		      c && a.l.set(c.subarray(0, Math.min(b, a.v)));
		      a.v = b;
		    }
		  }
		}, ja() {
		  throw Bb[44];
		}, ta(a, b, c, d) {
		  return O.createNode(a, b, c, d);
		}, sb(a, b, c) {
		  if (16384 === (a.mode & 61440)) {
		    try {
		      var d = Cb(b, c);
		    } catch (f) {
		    }
		    if (d) {
		      for (var e in d.l) {
		        throw new N(55);
		      }
		    }
		  }
		  delete a.parent.l[a.name];
		  a.parent.timestamp = Date.now();
		  a.name = c;
		  b.l[c] = a;
		  b.timestamp = a.parent.timestamp;
		}, yb(a, b) {
		  delete a.l[b];
		  a.timestamp = Date.now();
		}, tb(a, b) {
		  var c = Cb(a, b), d;
		  for (d in c.l) {
		    throw new N(55);
		  }
		  delete a.l[b];
		  a.timestamp = Date.now();
		}, rb(a) {
		  var b = [".", ".."], c;
		  for (c of Object.keys(a.l)) {
		    b.push(c);
		  }
		  return b;
		}, Ca(a, b, c) {
		  a = O.createNode(a, b, 41471, 0);
		  a.link = c;
		  return a;
		}, la(a) {
		  if (40960 !== (a.mode & 61440)) {
		    throw new N(28);
		  }
		  return a.link;
		},}, m:{read(a, b, c, d, e) {
		  var f = a.node.l;
		  if (e >= a.node.v) {
		    return 0;
		  }
		  a = Math.min(a.node.v - e, d);
		  if (8 < a && f.subarray) {
		    b.set(f.subarray(e, e + a), c);
		  } else {
		    for (d = 0; d < a; d++) {
		      b[c + d] = f[e + d];
		    }
		  }
		  return a;
		}, write(a, b, c, d, e, f) {
		  b.buffer === z.buffer && (f = false);
		  if (!d) {
		    return 0;
		  }
		  a = a.node;
		  a.timestamp = Date.now();
		  if (b.subarray && (!a.l || a.l.subarray)) {
		    if (f) {
		      return a.l = b.subarray(c, c + d), a.v = d;
		    }
		    if (0 === a.v && 0 === e) {
		      return a.l = b.slice(c, c + d), a.v = d;
		    }
		    if (e + d <= a.v) {
		      return a.l.set(b.subarray(c, c + d), e), d;
		    }
		  }
		  yb(a, e + d);
		  if (a.l.subarray && b.subarray) {
		    a.l.set(b.subarray(c, c + d), e);
		  } else {
		    for (f = 0; f < d; f++) {
		      a.l[e + f] = b[c + f];
		    }
		  }
		  a.v = Math.max(a.v, e + d);
		  return d;
		}, aa(a, b, c) {
		  1 === c ? b += a.position : 2 === c && 32768 === (a.node.mode & 61440) && (b += a.node.v);
		  if (0 > b) {
		    throw new N(28);
		  }
		  return b;
		}, Xa(a, b, c) {
		  yb(a.node, b + c);
		  a.node.v = Math.max(a.node.v, b + c);
		}, kb(a, b, c, d, e) {
		  if (32768 !== (a.node.mode & 61440)) {
		    throw new N(43);
		  }
		  a = a.node.l;
		  if (e & 2 || a.buffer !== z.buffer) {
		    if (0 < c || c + b < a.length) {
		      a.subarray ? a = a.subarray(c, c + b) : a = Array.prototype.slice.call(a, c, c + b);
		    }
		    c = true;
		    Qa();
		    b = void 0;
		    if (!b) {
		      throw new N(48);
		    }
		    z.set(a, b);
		  } else {
		    c = false, b = a.byteOffset;
		  }
		  return {o:b, uc:c};
		}, mb(a, b, c, d) {
		  O.m.write(a, b, 0, d, c, false);
		  return 0;
		},},}, Db = (a, b) => {
		  var c = 0;
		  a && (c |= 365);
		  b && (c |= 146);
		  return c;
		}, Eb = null, Fb = {}, Gb = [], Hb = 1, Ib = null, Jb = true, N = class {
		  constructor(a) {
		    this.name = "ErrnoError";
		    this.$ = a;
		  }
		}, Bb = {}, Kb = class {
		  constructor() {
		    this.h = {};
		    this.node = null;
		  }
		  get flags() {
		    return this.h.flags;
		  }
		  set flags(a) {
		    this.h.flags = a;
		  }
		  get position() {
		    return this.h.position;
		  }
		  set position(a) {
		    this.h.position = a;
		  }
		}, Lb = class {
		  constructor(a, b, c, d) {
		    a ||= this;
		    this.parent = a;
		    this.U = a.U;
		    this.ua = null;
		    this.id = Hb++;
		    this.name = b;
		    this.mode = c;
		    this.j = {};
		    this.m = {};
		    this.xa = d;
		  }
		  get read() {
		    return 365 === (this.mode & 365);
		  }
		  set read(a) {
		    a ? this.mode |= 365 : this.mode &= -366;
		  }
		  get write() {
		    return 146 === (this.mode & 146);
		  }
		  set write(a) {
		    a ? this.mode |= 146 : this.mode &= -147;
		  }
		};
		function Mb(a, b = {}) {
		  a = lb(a);
		  if (!a) {
		    return {path:"", node:null};
		  }
		  b = Object.assign({gb:true, Oa:0}, b);
		  if (8 < b.Oa) {
		    throw new N(32);
		  }
		  a = a.split("/").filter(g => !!g);
		  for (var c = Eb, d = "/", e = 0; e < a.length; e++) {
		    var f = e === a.length - 1;
		    if (f && b.parent) {
		      break;
		    }
		    c = Cb(c, a[e]);
		    d = gb(d + "/" + a[e]);
		    c.ua && (!f || f && b.gb) && (c = c.ua.root);
		    if (!f || b.fb) {
		      for (f = 0; 40960 === (c.mode & 61440);) {
		        if (c = Nb(d), d = lb(hb(d), c), c = Mb(d, {Oa:b.Oa + 1}).node, 40 < f++) {
		          throw new N(32);
		        }
		      }
		    }
		  }
		  return {path:d, node:c};
		}
		function Ob(a) {
		  for (var b;;) {
		    if (a === a.parent) {
		      return a = a.U.lb, b ? "/" !== a[a.length - 1] ? `${a}/${b}` : a + b : a;
		    }
		    b = b ? `${a.name}/${b}` : a.name;
		    a = a.parent;
		  }
		}
		function Pb(a, b) {
		  for (var c = 0, d = 0; d < b.length; d++) {
		    c = (c << 5) - c + b.charCodeAt(d) | 0;
		  }
		  return (a + c >>> 0) % Ib.length;
		}
		function Cb(a, b) {
		  var c = 16384 === (a.mode & 61440) ? (c = Qb(a, "x")) ? c : a.j.ja ? 0 : 2 : 54;
		  if (c) {
		    throw new N(c);
		  }
		  for (c = Ib[Pb(a.id, b)]; c; c = c.ec) {
		    var d = c.name;
		    if (c.parent.id === a.id && d === b) {
		      return c;
		    }
		  }
		  return a.j.ja(a, b);
		}
		function Ab(a, b, c, d) {
		  a = new Lb(a, b, c, d);
		  b = Pb(a.parent.id, a.name);
		  a.ec = Ib[b];
		  return Ib[b] = a;
		}
		function Rb(a) {
		  var b = ["r", "w", "rw"][a & 3];
		  a & 512 && (b += "w");
		  return b;
		}
		function Qb(a, b) {
		  if (Jb) {
		    return 0;
		  }
		  if (!b.includes("r") || a.mode & 292) {
		    if (b.includes("w") && !(a.mode & 146) || b.includes("x") && !(a.mode & 73)) {
		      return 2;
		    }
		  } else {
		    return 2;
		  }
		  return 0;
		}
		function Sb(a, b) {
		  try {
		    return Cb(a, b), 20;
		  } catch (c) {
		  }
		  return Qb(a, "wx");
		}
		function Tb(a) {
		  a = Gb[a];
		  if (!a) {
		    throw new N(8);
		  }
		  return a;
		}
		function Ub(a, b = -1) {
		  a = Object.assign(new Kb(), a);
		  if (-1 == b) {
		    a: {
		      for (b = 0; 4096 >= b; b++) {
		        if (!Gb[b]) {
		          break a;
		        }
		      }
		      throw new N(33);
		    }
		  }
		  a.W = b;
		  return Gb[b] = a;
		}
		function Vb(a, b = -1) {
		  a = Ub(a, b);
		  a.m?.Ec?.(a);
		  return a;
		}
		var zb = {open(a) {
		  a.m = Fb[a.node.xa].m;
		  a.m.open?.(a);
		}, aa() {
		  throw new N(70);
		},};
		function ub(a, b) {
		  Fb[a] = {m:b};
		}
		function ac(a, b) {
		  var c = "/" === b;
		  if (c && Eb) {
		    throw new N(10);
		  }
		  if (!c && b) {
		    var d = Mb(b, {gb:false});
		    b = d.path;
		    d = d.node;
		    if (d.ua) {
		      throw new N(10);
		    }
		    if (16384 !== (d.mode & 61440)) {
		      throw new N(54);
		    }
		  }
		  b = {type:a, Mc:{}, lb:b, dc:[]};
		  a = a.U(b);
		  a.U = b;
		  b.root = a;
		  c ? Eb = a : d && (d.ua = b, d.U && d.U.dc.push(b));
		}
		function bc(a, b, c) {
		  var d = Mb(a, {parent:true}).node;
		  a = ib(a);
		  if (!a || "." === a || ".." === a) {
		    throw new N(28);
		  }
		  var e = Sb(d, a);
		  if (e) {
		    throw new N(e);
		  }
		  if (!d.j.ta) {
		    throw new N(63);
		  }
		  return d.j.ta(d, a, b, c);
		}
		function cc(a) {
		  return bc(a, 16895, 0);
		}
		function dc(a, b, c) {
		  "undefined" == typeof c && (c = b, b = 438);
		  bc(a, b | 8192, c);
		}
		function ec(a, b) {
		  if (!lb(a)) {
		    throw new N(44);
		  }
		  var c = Mb(b, {parent:true}).node;
		  if (!c) {
		    throw new N(44);
		  }
		  b = ib(b);
		  var d = Sb(c, b);
		  if (d) {
		    throw new N(d);
		  }
		  if (!c.j.Ca) {
		    throw new N(63);
		  }
		  c.j.Ca(c, b, a);
		}
		function Nb(a) {
		  a = Mb(a).node;
		  if (!a) {
		    throw new N(44);
		  }
		  if (!a.j.la) {
		    throw new N(28);
		  }
		  return lb(Ob(a.parent), a.j.la(a));
		}
		function fc(a, b, c) {
		  if ("" === a) {
		    throw new N(44);
		  }
		  if ("string" == typeof b) {
		    var d = {r:0, "r+":2, w:577, "w+":578, a:1089, "a+":1090,}[b];
		    if ("undefined" == typeof d) {
		      throw Error(`Unknown file open mode: ${b}`);
		    }
		    b = d;
		  }
		  c = b & 64 ? ("undefined" == typeof c ? 438 : c) & 4095 | 32768 : 0;
		  if ("object" == typeof a) {
		    var e = a;
		  } else {
		    a = gb(a);
		    try {
		      e = Mb(a, {fb:!(b & 131072)}).node;
		    } catch (f) {
		    }
		  }
		  d = false;
		  if (b & 64) {
		    if (e) {
		      if (b & 128) {
		        throw new N(20);
		      }
		    } else {
		      e = bc(a, c, 0), d = true;
		    }
		  }
		  if (!e) {
		    throw new N(44);
		  }
		  8192 === (e.mode & 61440) && (b &= -513);
		  if (b & 65536 && 16384 !== (e.mode & 61440)) {
		    throw new N(54);
		  }
		  if (!d && (c = e ? 40960 === (e.mode & 61440) ? 32 : 16384 === (e.mode & 61440) && ("r" !== Rb(b) || b & 512) ? 31 : Qb(e, Rb(b)) : 44)) {
		    throw new N(c);
		  }
		  if (b & 512 && !d) {
		    c = e;
		    c = "string" == typeof c ? Mb(c, {fb:true}).node : c;
		    if (!c.j.P) {
		      throw new N(63);
		    }
		    if (16384 === (c.mode & 61440)) {
		      throw new N(31);
		    }
		    if (32768 !== (c.mode & 61440)) {
		      throw new N(28);
		    }
		    if (d = Qb(c, "w")) {
		      throw new N(d);
		    }
		    c.j.P(c, {size:0, timestamp:Date.now()});
		  }
		  b &= -131713;
		  e = Ub({node:e, path:Ob(e), flags:b, seekable:true, position:0, m:e.m, sc:[], error:false});
		  e.m.open && e.m.open(e);
		  !m.logReadFiles || b & 1 || (gc ||= {}, a in gc || (gc[a] = 1));
		  return e;
		}
		function hc(a, b, c) {
		  if (null === a.W) {
		    throw new N(8);
		  }
		  if (!a.seekable || !a.m.aa) {
		    throw new N(70);
		  }
		  if (0 != c && 1 != c && 2 != c) {
		    throw new N(28);
		  }
		  a.position = a.m.aa(a, b, c);
		  a.sc = [];
		}
		var ic;
		function jc(a, b, c) {
		  a = gb("/dev/" + a);
		  var d = Db(!!b, !!c);
		  kc ||= 64;
		  var e = kc++ << 8 | 0;
		  ub(e, {open(f) {
		    f.seekable = false;
		  }, close() {
		    c?.buffer?.length && c(10);
		  }, read(f, g, k, p) {
		    for (var n = 0, t = 0; t < p; t++) {
		      try {
		        var x = b();
		      } catch (y) {
		        throw new N(29);
		      }
		      if (void 0 === x && 0 === n) {
		        throw new N(6);
		      }
		      if (null === x || void 0 === x) {
		        break;
		      }
		      n++;
		      g[k + t] = x;
		    }
		    n && (f.node.timestamp = Date.now());
		    return n;
		  }, write(f, g, k, p) {
		    for (var n = 0; n < p; n++) {
		      try {
		        c(g[k + n]);
		      } catch (t) {
		        throw new N(29);
		      }
		    }
		    p && (f.node.timestamp = Date.now());
		    return n;
		  }});
		  dc(a, d, e);
		}
		var kc, lc = {}, gc, eb = void 0, mc = (a, b) => Object.defineProperty(b, "name", {value:a}), nc = [], oc = [], P, pc = a => {
		  if (!a) {
		    throw new P("Cannot use deleted val. handle = " + a);
		  }
		  return oc[a];
		}, qc = a => {
		  switch(a) {
		    case void 0:
		      return 2;
		    case null:
		      return 4;
		    case true:
		      return 6;
		    case false:
		      return 8;
		    default:
		      const b = nc.pop() || oc.length;
		      oc[b] = a;
		      oc[b + 1] = 1;
		      return b;
		  }
		}, rc = a => {
		  var b = Error, c = mc(a, function(d) {
		    this.name = a;
		    this.message = d;
		    d = Error(d).stack;
		    void 0 !== d && (this.stack = this.toString() + "\n" + d.replace(/^Error(:[^\n]*)?\n/, ""));
		  });
		  c.prototype = Object.create(b.prototype);
		  c.prototype.constructor = c;
		  c.prototype.toString = function() {
		    return void 0 === this.message ? this.name : `${this.name}: ${this.message}`;
		  };
		  return c;
		}, sc, tc, Q = a => {
		  for (var b = ""; A[a];) {
		    b += tc[A[a++]];
		  }
		  return b;
		}, uc = [], vc = () => {
		  for (; uc.length;) {
		    var a = uc.pop();
		    a.g.ea = false;
		    a["delete"]();
		  }
		}, wc, xc = {}, yc = (a, b) => {
		  if (void 0 === b) {
		    throw new P("ptr should not be undefined");
		  }
		  for (; a.C;) {
		    b = a.ma(b), a = a.C;
		  }
		  return b;
		}, zc = {}, Cc = a => {
		  a = Ac(a);
		  var b = Q(a);
		  Bc(a);
		  return b;
		}, Dc = (a, b) => {
		  var c = zc[a];
		  if (void 0 === c) {
		    throw a = `${b} has unknown type ${Cc(a)}`, new P(a);
		  }
		  return c;
		}, Ec = () => {
		}, Fc = false, Gc = (a, b, c) => {
		  if (b === c) {
		    return a;
		  }
		  if (void 0 === c.C) {
		    return null;
		  }
		  a = Gc(a, b, c.C);
		  return null === a ? null : c.Lb(a);
		}, Hc = {}, Ic = (a, b) => {
		  b = yc(a, b);
		  return xc[b];
		}, Jc, Lc = (a, b) => {
		  if (!b.u || !b.o) {
		    throw new Jc("makeClassHandle requires ptr and ptrType");
		  }
		  if (!!b.J !== !!b.F) {
		    throw new Jc("Both smartPtrType and smartPtr must be specified");
		  }
		  b.count = {value:1};
		  return Kc(Object.create(a, {g:{value:b, writable:true,},}));
		}, Kc = a => {
		  if ("undefined" === typeof FinalizationRegistry) {
		    return Kc = b => b, a;
		  }
		  Fc = new FinalizationRegistry(b => {
		    b = b.g;
		    --b.count.value;
		    0 === b.count.value && (b.F ? b.J.O(b.F) : b.u.i.O(b.o));
		  });
		  Kc = b => {
		    var c = b.g;
		    c.F && Fc.register(b, {g:c}, b);
		    return b;
		  };
		  Ec = b => {
		    Fc.unregister(b);
		  };
		  return Kc(a);
		}, Mc = {}, Nc = a => {
		  for (; a.length;) {
		    var b = a.pop();
		    a.pop()(b);
		  }
		};
		function Oc(a) {
		  return this.fromWireType(M[a >> 2]);
		}
		var Pc = {}, Qc = {}, U = (a, b, c) => {
		  function d(k) {
		    k = c(k);
		    if (k.length !== a.length) {
		      throw new Jc("Mismatched type converter count");
		    }
		    for (var p = 0; p < a.length; ++p) {
		      Rc(a[p], k[p]);
		    }
		  }
		  a.forEach(function(k) {
		    Qc[k] = b;
		  });
		  var e = Array(b.length), f = [], g = 0;
		  b.forEach((k, p) => {
		    zc.hasOwnProperty(k) ? e[p] = zc[k] : (f.push(k), Pc.hasOwnProperty(k) || (Pc[k] = []), Pc[k].push(() => {
		      e[p] = zc[k];
		      ++g;
		      g === f.length && d(e);
		    }));
		  });
		  0 === f.length && d(e);
		};
		function Sc(a, b, c = {}) {
		  var d = b.name;
		  if (!a) {
		    throw new P(`type "${d}" must have a positive integer typeid pointer`);
		  }
		  if (zc.hasOwnProperty(a)) {
		    if (c.Vb) {
		      return;
		    }
		    throw new P(`Cannot register type '${d}' twice`);
		  }
		  zc[a] = b;
		  delete Qc[a];
		  Pc.hasOwnProperty(a) && (b = Pc[a], delete Pc[a], b.forEach(e => e()));
		}
		function Rc(a, b, c = {}) {
		  if (!("argPackAdvance" in b)) {
		    throw new TypeError("registerType registeredInstance requires argPackAdvance");
		  }
		  return Sc(a, b, c);
		}
		var Tc = a => {
		  throw new P(a.g.u.i.name + " instance already deleted");
		};
		function Uc() {
		}
		var Vc = (a, b, c) => {
		  if (void 0 === a[b].A) {
		    var d = a[b];
		    a[b] = function(...e) {
		      if (!a[b].A.hasOwnProperty(e.length)) {
		        throw new P(`Function '${c}' called with an invalid number of arguments (${e.length}) - expects one of (${a[b].A})!`);
		      }
		      return a[b].A[e.length].apply(this, e);
		    };
		    a[b].A = [];
		    a[b].A[d.da] = d;
		  }
		}, Wc = (a, b, c) => {
		  if (m.hasOwnProperty(a)) {
		    if (void 0 === c || void 0 !== m[a].A && void 0 !== m[a].A[c]) {
		      throw new P(`Cannot register public name '${a}' twice`);
		    }
		    Vc(m, a, a);
		    if (m.hasOwnProperty(c)) {
		      throw new P(`Cannot register multiple overloads of a function with the same number of arguments (${c})!`);
		    }
		    m[a].A[c] = b;
		  } else {
		    m[a] = b, void 0 !== c && (m[a].Lc = c);
		  }
		}, Xc = a => {
		  if (void 0 === a) {
		    return "_unknown";
		  }
		  a = a.replace(/[^a-zA-Z0-9_]/g, "$");
		  var b = a.charCodeAt(0);
		  return 48 <= b && 57 >= b ? `_${a}` : a;
		};
		function Yc(a, b, c, d, e, f, g, k) {
		  this.name = a;
		  this.constructor = b;
		  this.M = c;
		  this.O = d;
		  this.C = e;
		  this.Qb = f;
		  this.ma = g;
		  this.Lb = k;
		  this.pb = [];
		}
		var Zc = (a, b, c) => {
		  for (; b !== c;) {
		    if (!b.ma) {
		      throw new P(`Expected null or instance of ${c.name}, got an instance of ${b.name}`);
		    }
		    a = b.ma(a);
		    b = b.C;
		  }
		  return a;
		};
		function $c(a, b) {
		  if (null === b) {
		    if (this.La) {
		      throw new P(`null is not a valid ${this.name}`);
		    }
		    return 0;
		  }
		  if (!b.g) {
		    throw new P(`Cannot pass "${ad(b)}" as a ${this.name}`);
		  }
		  if (!b.g.o) {
		    throw new P(`Cannot pass deleted object as a pointer of type ${this.name}`);
		  }
		  return Zc(b.g.o, b.g.u.i, this.i);
		}
		function bd(a, b) {
		  if (null === b) {
		    if (this.La) {
		      throw new P(`null is not a valid ${this.name}`);
		    }
		    if (this.sa) {
		      var c = this.Na();
		      null !== a && a.push(this.O, c);
		      return c;
		    }
		    return 0;
		  }
		  if (!b || !b.g) {
		    throw new P(`Cannot pass "${ad(b)}" as a ${this.name}`);
		  }
		  if (!b.g.o) {
		    throw new P(`Cannot pass deleted object as a pointer of type ${this.name}`);
		  }
		  if (!this.ra && b.g.u.ra) {
		    throw new P(`Cannot convert argument of type ${b.g.J ? b.g.J.name : b.g.u.name} to parameter type ${this.name}`);
		  }
		  c = Zc(b.g.o, b.g.u.i, this.i);
		  if (this.sa) {
		    if (void 0 === b.g.F) {
		      throw new P("Passing raw pointer to smart pointer is illegal");
		    }
		    switch(this.mc) {
		      case 0:
		        if (b.g.J === this) {
		          c = b.g.F;
		        } else {
		          throw new P(`Cannot convert argument of type ${b.g.J ? b.g.J.name : b.g.u.name} to parameter type ${this.name}`);
		        }
		        break;
		      case 1:
		        c = b.g.F;
		        break;
		      case 2:
		        if (b.g.J === this) {
		          c = b.g.F;
		        } else {
		          var d = b.clone();
		          c = this.ic(c, qc(() => d["delete"]()));
		          null !== a && a.push(this.O, c);
		        }
		        break;
		      default:
		        throw new P("Unsupporting sharing policy");
		    }
		  }
		  return c;
		}
		function cd(a, b) {
		  if (null === b) {
		    if (this.La) {
		      throw new P(`null is not a valid ${this.name}`);
		    }
		    return 0;
		  }
		  if (!b.g) {
		    throw new P(`Cannot pass "${ad(b)}" as a ${this.name}`);
		  }
		  if (!b.g.o) {
		    throw new P(`Cannot pass deleted object as a pointer of type ${this.name}`);
		  }
		  if (b.g.u.ra) {
		    throw new P(`Cannot convert argument of type ${b.g.u.name} to parameter type ${this.name}`);
		  }
		  return Zc(b.g.o, b.g.u.i, this.i);
		}
		function dd(a, b, c, d, e, f, g, k, p, n, t) {
		  this.name = a;
		  this.i = b;
		  this.La = c;
		  this.ra = d;
		  this.sa = e;
		  this.hc = f;
		  this.mc = g;
		  this.qb = k;
		  this.Na = p;
		  this.ic = n;
		  this.O = t;
		  e || void 0 !== b.C ? this.toWireType = bd : (this.toWireType = d ? $c : cd, this.L = null);
		}
		var ed = (a, b, c) => {
		  if (!m.hasOwnProperty(a)) {
		    throw new Jc("Replacing nonexistent public symbol");
		  }
		  void 0 !== m[a].A && void 0 !== c ? m[a].A[c] = b : (m[a] = b, m[a].da = c);
		}, fd = [], gd, hd = a => {
		  var b = fd[a];
		  b || (a >= fd.length && (fd.length = a + 1), fd[a] = b = gd.get(a));
		  return b;
		}, jd = (a, b, c = []) => {
		  a.includes("j") ? (a = a.replace(/p/g, "i"), b = (0, m["dynCall_" + a])(b, ...c)) : b = hd(b)(...c);
		  return b;
		}, md = (a, b) => (...c) => jd(a, b, c), V = (a, b) => {
		  a = Q(a);
		  var c = a.includes("j") ? md(a, b) : hd(b);
		  if ("function" != typeof c) {
		    throw new P(`unknown function pointer with signature ${a}: ${b}`);
		  }
		  return c;
		}, nd, od = (a, b) => {
		  function c(f) {
		    e[f] || zc[f] || (Qc[f] ? Qc[f].forEach(c) : (d.push(f), e[f] = true));
		  }
		  var d = [], e = {};
		  b.forEach(c);
		  throw new nd(`${a}: ` + d.map(Cc).join([", "]));
		};
		function pd(a) {
		  for (var b = 1; b < a.length; ++b) {
		    if (null !== a[b] && void 0 === a[b].L) {
		      return true;
		    }
		  }
		  return false;
		}
		function qd(a, b, c, d, e) {
		  var f = b.length;
		  if (2 > f) {
		    throw new P("argTypes array size mismatch! Must at least get return value and 'this' types!");
		  }
		  var g = null !== b[1] && null !== c, k = pd(b), p = "void" !== b[0].name, n = f - 2, t = Array(n), x = [], y = [];
		  return mc(a, function(...l) {
		    if (l.length !== n) {
		      throw new P(`function ${a} called with ${l.length} arguments, expected ${n}`);
		    }
		    y.length = 0;
		    x.length = g ? 2 : 1;
		    x[0] = e;
		    if (g) {
		      var u = b[1].toWireType(y, this);
		      x[1] = u;
		    }
		    for (var q = 0; q < n; ++q) {
		      t[q] = b[q + 2].toWireType(y, l[q]), x.push(t[q]);
		    }
		    l = d(...x);
		    if (k) {
		      Nc(y);
		    } else {
		      for (q = g ? 1 : 2; q < b.length; q++) {
		        var C = 1 === q ? u : t[q - 2];
		        null !== b[q].L && b[q].L(C);
		      }
		    }
		    u = p ? b[0].fromWireType(l) : void 0;
		    return u;
		  });
		}
		var rd = (a, b) => {
		  for (var c = [], d = 0; d < a; d++) {
		    c.push(M[b + 4 * d >> 2]);
		  }
		  return c;
		}, sd = a => {
		  a = a.trim();
		  const b = a.indexOf("(");
		  return -1 !== b ? a.substr(0, b) : a;
		}, td = (a, b, c) => {
		  if (!(a instanceof Object)) {
		    throw new P(`${c} with invalid "this": ${a}`);
		  }
		  if (!(a instanceof b.i.constructor)) {
		    throw new P(`${c} incompatible with "this" of type ${a.constructor.name}`);
		  }
		  if (!a.g.o) {
		    throw new P(`cannot call emscripten binding method ${c} on deleted object`);
		  }
		  return Zc(a.g.o, a.g.u.i, b.i);
		}, ud = a => {
		  9 < a && 0 === --oc[a + 1] && (oc[a] = void 0, nc.push(a));
		}, vd = {name:"emscripten::val", fromWireType:a => {
		  var b = pc(a);
		  ud(a);
		  return b;
		}, toWireType:(a, b) => qc(b), argPackAdvance:8, readValueFromPointer:Oc, L:null,}, wd = (a, b, c) => {
		  switch(b) {
		    case 1:
		      return c ? function(d) {
		        return this.fromWireType(z[d]);
		      } : function(d) {
		        return this.fromWireType(A[d]);
		      };
		    case 2:
		      return c ? function(d) {
		        return this.fromWireType(Ca[d >> 1]);
		      } : function(d) {
		        return this.fromWireType(Fa[d >> 1]);
		      };
		    case 4:
		      return c ? function(d) {
		        return this.fromWireType(D[d >> 2]);
		      } : function(d) {
		        return this.fromWireType(M[d >> 2]);
		      };
		    default:
		      throw new TypeError(`invalid integer width (${b}): ${a}`);
		  }
		}, ad = a => {
		  if (null === a) {
		    return "null";
		  }
		  var b = typeof a;
		  return "object" === b || "array" === b || "function" === b ? a.toString() : "" + a;
		}, xd = (a, b) => {
		  switch(b) {
		    case 4:
		      return function(c) {
		        return this.fromWireType(Ga[c >> 2]);
		      };
		    case 8:
		      return function(c) {
		        return this.fromWireType(Ha[c >> 3]);
		      };
		    default:
		      throw new TypeError(`invalid float width (${b}): ${a}`);
		  }
		}, yd = (a, b, c) => {
		  switch(b) {
		    case 1:
		      return c ? d => z[d] : d => A[d];
		    case 2:
		      return c ? d => Ca[d >> 1] : d => Fa[d >> 1];
		    case 4:
		      return c ? d => D[d >> 2] : d => M[d >> 2];
		    default:
		      throw new TypeError(`invalid integer width (${b}): ${a}`);
		  }
		}, zd = "undefined" != typeof TextDecoder ? new TextDecoder("utf-16le") : void 0, Ad = (a, b) => {
		  var c = a >> 1;
		  for (var d = c + b / 2; !(c >= d) && Fa[c];) {
		    ++c;
		  }
		  c <<= 1;
		  if (32 < c - a && zd) {
		    return zd.decode(A.subarray(a, c));
		  }
		  c = "";
		  for (d = 0; !(d >= b / 2); ++d) {
		    var e = Ca[a + 2 * d >> 1];
		    if (0 == e) {
		      break;
		    }
		    c += String.fromCharCode(e);
		  }
		  return c;
		}, Bd = (a, b, c) => {
		  c ??= 2147483647;
		  if (2 > c) {
		    return 0;
		  }
		  c -= 2;
		  var d = b;
		  c = c < 2 * a.length ? c / 2 : a.length;
		  for (var e = 0; e < c; ++e) {
		    Ca[b >> 1] = a.charCodeAt(e), b += 2;
		  }
		  Ca[b >> 1] = 0;
		  return b - d;
		}, Cd = a => 2 * a.length, Dd = (a, b) => {
		  for (var c = 0, d = ""; !(c >= b / 4);) {
		    var e = D[a + 4 * c >> 2];
		    if (0 == e) {
		      break;
		    }
		    ++c;
		    65536 <= e ? (e -= 65536, d += String.fromCharCode(55296 | e >> 10, 56320 | e & 1023)) : d += String.fromCharCode(e);
		  }
		  return d;
		}, Ed = (a, b, c) => {
		  c ??= 2147483647;
		  if (4 > c) {
		    return 0;
		  }
		  var d = b;
		  c = d + c - 4;
		  for (var e = 0; e < a.length; ++e) {
		    var f = a.charCodeAt(e);
		    if (55296 <= f && 57343 >= f) {
		      var g = a.charCodeAt(++e);
		      f = 65536 + ((f & 1023) << 10) | g & 1023;
		    }
		    D[b >> 2] = f;
		    b += 4;
		    if (b + 4 > c) {
		      break;
		    }
		  }
		  D[b >> 2] = 0;
		  return b - d;
		}, Fd = a => {
		  for (var b = 0, c = 0; c < a.length; ++c) {
		    var d = a.charCodeAt(c);
		    55296 <= d && 57343 >= d && ++c;
		    b += 4;
		  }
		  return b;
		}, Gd = (a, b, c) => {
		  var d = [];
		  a = a.toWireType(d, c);
		  d.length && (M[b >> 2] = qc(d));
		  return a;
		}, Hd = {}, Id = a => {
		  var b = Hd[a];
		  return void 0 === b ? Q(a) : b;
		}, Jd = [], Kd = a => {
		  var b = Jd.length;
		  Jd.push(a);
		  return b;
		}, Ld = (a, b) => {
		  for (var c = Array(a), d = 0; d < a; ++d) {
		    c[d] = Dc(M[b + 4 * d >> 2], "parameter " + d);
		  }
		  return c;
		}, Md = Reflect.construct, Nd = [], Od = {}, Qd = () => {
		  if (!Pd) {
		    var a = {USER:"web_user", LOGNAME:"web_user", PATH:"/", PWD:"/", HOME:"/home/web_user", LANG:("object" == typeof navigator && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8", _:oa || "./this.program"}, b;
		    for (b in Od) {
		      void 0 === Od[b] ? delete a[b] : a[b] = Od[b];
		    }
		    var c = [];
		    for (b in a) {
		      c.push(`${b}=${a[b]}`);
		    }
		    Pd = c;
		  }
		  return Pd;
		}, Pd, Rd = a => 0 === a % 4 && (0 !== a % 100 || 0 === a % 400), Sd = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], Td = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], Ud = (a, b, c, d) => {
		  function e(l, u, q) {
		    for (l = "number" == typeof l ? l.toString() : l || ""; l.length < u;) {
		      l = q[0] + l;
		    }
		    return l;
		  }
		  function f(l, u) {
		    return e(l, u, "0");
		  }
		  function g(l, u) {
		    function q(E) {
		      return 0 > E ? -1 : 0 < E ? 1 : 0;
		    }
		    var C;
		    0 === (C = q(l.getFullYear() - u.getFullYear())) && 0 === (C = q(l.getMonth() - u.getMonth())) && (C = q(l.getDate() - u.getDate()));
		    return C;
		  }
		  function k(l) {
		    switch(l.getDay()) {
		      case 0:
		        return new Date(l.getFullYear() - 1, 11, 29);
		      case 1:
		        return l;
		      case 2:
		        return new Date(l.getFullYear(), 0, 3);
		      case 3:
		        return new Date(l.getFullYear(), 0, 2);
		      case 4:
		        return new Date(l.getFullYear(), 0, 1);
		      case 5:
		        return new Date(l.getFullYear() - 1, 11, 31);
		      case 6:
		        return new Date(l.getFullYear() - 1, 11, 30);
		    }
		  }
		  function p(l) {
		    var u = l.ba;
		    for (l = new Date((new Date(l.ca + 1900, 0, 1)).getTime()); 0 < u;) {
		      var q = l.getMonth(), C = (Rd(l.getFullYear()) ? Sd : Td)[q];
		      if (u > C - l.getDate()) {
		        u -= C - l.getDate() + 1, l.setDate(1), 11 > q ? l.setMonth(q + 1) : (l.setMonth(0), l.setFullYear(l.getFullYear() + 1));
		      } else {
		        l.setDate(l.getDate() + u);
		        break;
		      }
		    }
		    q = new Date(l.getFullYear() + 1, 0, 4);
		    u = k(new Date(l.getFullYear(), 0, 4));
		    q = k(q);
		    return 0 >= g(u, l) ? 0 >= g(q, l) ? l.getFullYear() + 1 : l.getFullYear() : l.getFullYear() - 1;
		  }
		  var n = M[d + 40 >> 2];
		  d = {pc:D[d >> 2], oc:D[d + 4 >> 2], Da:D[d + 8 >> 2], Qa:D[d + 12 >> 2], Ea:D[d + 16 >> 2], ca:D[d + 20 >> 2], R:D[d + 24 >> 2], ba:D[d + 28 >> 2], Nc:D[d + 32 >> 2], nc:D[d + 36 >> 2], qc:n ? n ? nb(A, n) : "" : ""};
		  c = c ? nb(A, c) : "";
		  n = {"%c":"%a %b %d %H:%M:%S %Y", "%D":"%m/%d/%y", "%F":"%Y-%m-%d", "%h":"%b", "%r":"%I:%M:%S %p", "%R":"%H:%M", "%T":"%H:%M:%S", "%x":"%m/%d/%y", "%X":"%H:%M:%S", "%Ec":"%c", "%EC":"%C", "%Ex":"%m/%d/%y", "%EX":"%H:%M:%S", "%Ey":"%y", "%EY":"%Y", "%Od":"%d", "%Oe":"%e", "%OH":"%H", "%OI":"%I", "%Om":"%m", "%OM":"%M", "%OS":"%S", "%Ou":"%u", "%OU":"%U", "%OV":"%V", "%Ow":"%w", "%OW":"%W", "%Oy":"%y",};
		  for (var t in n) {
		    c = c.replace(new RegExp(t, "g"), n[t]);
		  }
		  var x = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "), y = "January February March April May June July August September October November December".split(" ");
		  n = {"%a":l => x[l.R].substring(0, 3), "%A":l => x[l.R], "%b":l => y[l.Ea].substring(0, 3), "%B":l => y[l.Ea], "%C":l => f((l.ca + 1900) / 100 | 0, 2), "%d":l => f(l.Qa, 2), "%e":l => e(l.Qa, 2, " "), "%g":l => p(l).toString().substring(2), "%G":p, "%H":l => f(l.Da, 2), "%I":l => {
		    l = l.Da;
		    0 == l ? l = 12 : 12 < l && (l -= 12);
		    return f(l, 2);
		  }, "%j":l => {
		    for (var u = 0, q = 0; q <= l.Ea - 1; u += (Rd(l.ca + 1900) ? Sd : Td)[q++]) {
		    }
		    return f(l.Qa + u, 3);
		  }, "%m":l => f(l.Ea + 1, 2), "%M":l => f(l.oc, 2), "%n":() => "\n", "%p":l => 0 <= l.Da && 12 > l.Da ? "AM" : "PM", "%S":l => f(l.pc, 2), "%t":() => "\t", "%u":l => l.R || 7, "%U":l => f(Math.floor((l.ba + 7 - l.R) / 7), 2), "%V":l => {
		    var u = Math.floor((l.ba + 7 - (l.R + 6) % 7) / 7);
		    2 >= (l.R + 371 - l.ba - 2) % 7 && u++;
		    if (u) {
		      53 == u && (q = (l.R + 371 - l.ba) % 7, 4 == q || 3 == q && Rd(l.ca) || (u = 1));
		    } else {
		      u = 52;
		      var q = (l.R + 7 - l.ba - 1) % 7;
		      (4 == q || 5 == q && Rd(l.ca % 400 - 1)) && u++;
		    }
		    return f(u, 2);
		  }, "%w":l => l.R, "%W":l => f(Math.floor((l.ba + 7 - (l.R + 6) % 7) / 7), 2), "%y":l => (l.ca + 1900).toString().substring(2), "%Y":l => l.ca + 1900, "%z":l => {
		    l = l.nc;
		    var u = 0 <= l;
		    l = Math.abs(l) / 60;
		    return (u ? "+" : "-") + String("0000" + (l / 60 * 100 + l % 60)).slice(-4);
		  }, "%Z":l => l.qc, "%%":() => "%"};
		  c = c.replace(/%%/g, "\x00\x00");
		  for (t in n) {
		    c.includes(t) && (c = c.replace(new RegExp(t, "g"), n[t](d)));
		  }
		  c = c.replace(/\0\0/g, "%");
		  t = rb(c, false);
		  if (t.length > b) {
		    return 0;
		  }
		  z.set(t, a);
		  return t.length - 1;
		};
		[44].forEach(a => {
		  Bb[a] = new N(a);
		  Bb[a].stack = "<generic error, no stack>";
		});
		Ib = Array(4096);
		ac(O, "/");
		cc("/tmp");
		cc("/home");
		cc("/home/web_user");
		(function() {
		  cc("/dev");
		  ub(259, {read:() => 0, write:(d, e, f, g) => g,});
		  dc("/dev/null", 259);
		  tb(1280, wb);
		  tb(1536, xb);
		  dc("/dev/tty", 1280);
		  dc("/dev/tty1", 1536);
		  var a = new Uint8Array(1024), b = 0, c = () => {
		    0 === b && (b = kb(a).byteLength);
		    return a[--b];
		  };
		  jc("random", c);
		  jc("urandom", c);
		  cc("/dev/shm");
		  cc("/dev/shm/tmp");
		})();
		(function() {
		  cc("/proc");
		  var a = cc("/proc/self");
		  cc("/proc/self/fd");
		  ac({U() {
		    var b = Ab(a, "fd", 16895, 73);
		    b.j = {ja(c, d) {
		      var e = Tb(+d);
		      c = {parent:null, U:{lb:"fake"}, j:{la:() => e.path},};
		      return c.parent = c;
		    }};
		    return b;
		  }}, "/proc/self/fd");
		})();
		P = m.BindingError = class extends Error {
		  constructor(a) {
		    super(a);
		    this.name = "BindingError";
		  }
		};
		oc.push(0, 1, void 0, 1, null, 1, true, 1, false, 1,);
		m.count_emval_handles = () => oc.length / 2 - 5 - nc.length;
		sc = m.PureVirtualError = rc("PureVirtualError");
		for (var Vd = Array(256), Wd = 0; 256 > Wd; ++Wd) {
		  Vd[Wd] = String.fromCharCode(Wd);
		}
		tc = Vd;
		m.getInheritedInstanceCount = () => Object.keys(xc).length;
		m.getLiveInheritedInstances = () => {
		  var a = [], b;
		  for (b in xc) {
		    xc.hasOwnProperty(b) && a.push(xc[b]);
		  }
		  return a;
		};
		m.flushPendingDeletes = vc;
		m.setDelayFunction = a => {
		  wc = a;
		  uc.length && wc && wc(vc);
		};
		Jc = m.InternalError = class extends Error {
		  constructor(a) {
		    super(a);
		    this.name = "InternalError";
		  }
		};
		Object.assign(Uc.prototype, {isAliasOf:function(a) {
		  if (!(this instanceof Uc && a instanceof Uc)) {
		    return false;
		  }
		  var b = this.g.u.i, c = this.g.o;
		  a.g = a.g;
		  var d = a.g.u.i;
		  for (a = a.g.o; b.C;) {
		    c = b.ma(c), b = b.C;
		  }
		  for (; d.C;) {
		    a = d.ma(a), d = d.C;
		  }
		  return b === d && c === a;
		}, clone:function() {
		  this.g.o || Tc(this);
		  if (this.g.ha) {
		    return this.g.count.value += 1, this;
		  }
		  var a = Kc, b = Object, c = b.create, d = Object.getPrototypeOf(this), e = this.g;
		  a = a(c.call(b, d, {g:{value:{count:e.count, ea:e.ea, ha:e.ha, o:e.o, u:e.u, F:e.F, J:e.J,},}}));
		  a.g.count.value += 1;
		  a.g.ea = false;
		  return a;
		}, ["delete"]() {
		  this.g.o || Tc(this);
		  if (this.g.ea && !this.g.ha) {
		    throw new P("Object already scheduled for deletion");
		  }
		  Ec(this);
		  var a = this.g;
		  --a.count.value;
		  0 === a.count.value && (a.F ? a.J.O(a.F) : a.u.i.O(a.o));
		  this.g.ha || (this.g.F = void 0, this.g.o = void 0);
		}, isDeleted:function() {
		  return !this.g.o;
		}, deleteLater:function() {
		  this.g.o || Tc(this);
		  if (this.g.ea && !this.g.ha) {
		    throw new P("Object already scheduled for deletion");
		  }
		  uc.push(this);
		  1 === uc.length && wc && wc(vc);
		  this.g.ea = true;
		  return this;
		},});
		Object.assign(dd.prototype, {Rb(a) {
		  this.qb && (a = this.qb(a));
		  return a;
		}, ab(a) {
		  this.O?.(a);
		}, argPackAdvance:8, readValueFromPointer:Oc, fromWireType:function(a) {
		  function b() {
		    return this.sa ? Lc(this.i.M, {u:this.hc, o:c, J:this, F:a,}) : Lc(this.i.M, {u:this, o:a,});
		  }
		  var c = this.Rb(a);
		  if (!c) {
		    return this.ab(a), null;
		  }
		  var d = Ic(this.i, c);
		  if (void 0 !== d) {
		    if (0 === d.g.count.value) {
		      return d.g.o = c, d.g.F = a, d.clone();
		    }
		    d = d.clone();
		    this.ab(a);
		    return d;
		  }
		  d = this.i.Qb(c);
		  d = Hc[d];
		  if (!d) {
		    return b.call(this);
		  }
		  d = this.ra ? d.Hb : d.pointerType;
		  var e = Gc(c, this.i, d.i);
		  return null === e ? b.call(this) : this.sa ? Lc(d.i.M, {u:d, o:e, J:this, F:a,}) : Lc(d.i.M, {u:d, o:e,});
		},});
		nd = m.UnboundTypeError = rc("UnboundTypeError");
		var Yd = {__syscall_fcntl64:function(a, b, c) {
		  eb = c;
		  try {
		    var d = Tb(a);
		    switch(b) {
		      case 0:
		        var e = db();
		        if (0 > e) {
		          break;
		        }
		        for (; Gb[e];) {
		          e++;
		        }
		        return Vb(d, e).W;
		      case 1:
		      case 2:
		        return 0;
		      case 3:
		        return d.flags;
		      case 4:
		        return e = db(), d.flags |= e, 0;
		      case 12:
		        return e = db(), Ca[e + 0 >> 1] = 2, 0;
		      case 13:
		      case 14:
		        return 0;
		    }
		    return -28;
		  } catch (f) {
		    if ("undefined" == typeof lc || "ErrnoError" !== f.name) {
		      throw f;
		    }
		    return -f.$;
		  }
		}, __syscall_ioctl:function(a, b, c) {
		  eb = c;
		  try {
		    var d = Tb(a);
		    switch(b) {
		      case 21509:
		        return d.s ? 0 : -59;
		      case 21505:
		        if (!d.s) {
		          return -59;
		        }
		        if (d.s.V.Xb) {
		          a = [3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,];
		          var e = db();
		          D[e >> 2] = 25856;
		          D[e + 4 >> 2] = 5;
		          D[e + 8 >> 2] = 191;
		          D[e + 12 >> 2] = 35387;
		          for (var f = 0; 32 > f; f++) {
		            z[e + f + 17] = a[f] || 0;
		          }
		        }
		        return 0;
		      case 21510:
		      case 21511:
		      case 21512:
		        return d.s ? 0 : -59;
		      case 21506:
		      case 21507:
		      case 21508:
		        if (!d.s) {
		          return -59;
		        }
		        if (d.s.V.Yb) {
		          for (e = db(), a = [], f = 0; 32 > f; f++) {
		            a.push(z[e + f + 17]);
		          }
		        }
		        return 0;
		      case 21519:
		        if (!d.s) {
		          return -59;
		        }
		        e = db();
		        return D[e >> 2] = 0;
		      case 21520:
		        return d.s ? -28 : -59;
		      case 21531:
		        e = db();
		        if (!d.m.Wb) {
		          throw new N(59);
		        }
		        return d.m.Wb(d, b, e);
		      case 21523:
		        if (!d.s) {
		          return -59;
		        }
		        d.s.V.Zb && (f = [24, 80], e = db(), Ca[e >> 1] = f[0], Ca[e + 2 >> 1] = f[1]);
		        return 0;
		      case 21524:
		        return d.s ? 0 : -59;
		      case 21515:
		        return d.s ? 0 : -59;
		      default:
		        return -28;
		    }
		  } catch (g) {
		    if ("undefined" == typeof lc || "ErrnoError" !== g.name) {
		      throw g;
		    }
		    return -g.$;
		  }
		}, __syscall_openat:function(a, b, c, d) {
		  eb = d;
		  try {
		    b = b ? nb(A, b) : "";
		    var e = b;
		    if ("/" === e.charAt(0)) {
		      b = e;
		    } else {
		      var f = -100 === a ? "/" : Tb(a).path;
		      if (0 == e.length) {
		        throw new N(44);
		      }
		      b = gb(f + "/" + e);
		    }
		    var g = d ? db() : 0;
		    return fc(b, c, g).W;
		  } catch (k) {
		    if ("undefined" == typeof lc || "ErrnoError" !== k.name) {
		      throw k;
		    }
		    return -k.$;
		  }
		}, _abort_js:() => {
		  Qa("");
		}, _embind_create_inheriting_constructor:(a, b, c) => {
		  a = Q(a);
		  b = Dc(b, "wrapper");
		  c = pc(c);
		  var d = b.i, e = d.M, f = d.C.M, g = d.C.constructor;
		  a = mc(a, function(...k) {
		    d.C.pb.forEach(function(p) {
		      if (this[p] === f[p]) {
		        throw new sc(`Pure virtual function ${p} must be implemented in JavaScript`);
		      }
		    }.bind(this));
		    Object.defineProperty(this, "__parent", {value:e});
		    this.__construct(...k);
		  });
		  e.__construct = function(...k) {
		    if (this === e) {
		      throw new P("Pass correct 'this' to __construct");
		    }
		    k = g.implement(this, ...k);
		    Ec(k);
		    var p = k.g;
		    k.notifyOnDestruction();
		    p.ha = true;
		    Object.defineProperties(this, {g:{value:p}});
		    Kc(this);
		    k = p.o;
		    k = yc(d, k);
		    if (xc.hasOwnProperty(k)) {
		      throw new P(`Tried to register registered instance: ${k}`);
		    }
		    xc[k] = this;
		  };
		  e.__destruct = function() {
		    if (this === e) {
		      throw new P("Pass correct 'this' to __destruct");
		    }
		    Ec(this);
		    var k = this.g.o;
		    k = yc(d, k);
		    if (xc.hasOwnProperty(k)) {
		      delete xc[k];
		    } else {
		      throw new P(`Tried to unregister unregistered instance: ${k}`);
		    }
		  };
		  a.prototype = Object.create(e);
		  Object.assign(a.prototype, c);
		  return qc(a);
		}, _embind_finalize_value_object:a => {
		  var b = Mc[a];
		  delete Mc[a];
		  var c = b.Na, d = b.O, e = b.eb, f = e.map(g => g.Ub).concat(e.map(g => g.kc));
		  U([a], f, g => {
		    var k = {};
		    e.forEach((p, n) => {
		      var t = g[n], x = p.Sb, y = p.Tb, l = g[n + e.length], u = p.jc, q = p.lc;
		      k[p.Ob] = {read:C => t.fromWireType(x(y, C)), write:(C, E) => {
		        var w = [];
		        u(q, C, l.toWireType(w, E));
		        Nc(w);
		      }};
		    });
		    return [{name:b.name, fromWireType:p => {
		      var n = {}, t;
		      for (t in k) {
		        n[t] = k[t].read(p);
		      }
		      d(p);
		      return n;
		    }, toWireType:(p, n) => {
		      for (var t in k) {
		        if (!(t in n)) {
		          throw new TypeError(`Missing field: "${t}"`);
		        }
		      }
		      var x = c();
		      for (t in k) {
		        k[t].write(x, n[t]);
		      }
		      null !== p && p.push(d, x);
		      return x;
		    }, argPackAdvance:8, readValueFromPointer:Oc, L:d,}];
		  });
		}, _embind_register_bigint:() => {
		}, _embind_register_bool:(a, b, c, d) => {
		  b = Q(b);
		  Rc(a, {name:b, fromWireType:function(e) {
		    return !!e;
		  }, toWireType:function(e, f) {
		    return f ? c : d;
		  }, argPackAdvance:8, readValueFromPointer:function(e) {
		    return this.fromWireType(A[e]);
		  }, L:null,});
		}, _embind_register_class:(a, b, c, d, e, f, g, k, p, n, t, x, y) => {
		  t = Q(t);
		  f = V(e, f);
		  k &&= V(g, k);
		  n &&= V(p, n);
		  y = V(x, y);
		  var l = Xc(t);
		  Wc(l, function() {
		    od(`Cannot construct ${t} due to unbound types`, [d]);
		  });
		  U([a, b, c], d ? [d] : [], u => {
		    u = u[0];
		    if (d) {
		      var q = u.i;
		      var C = q.M;
		    } else {
		      C = Uc.prototype;
		    }
		    u = mc(t, function(...R) {
		      if (Object.getPrototypeOf(this) !== E) {
		        throw new P("Use 'new' to construct " + t);
		      }
		      if (void 0 === w.Z) {
		        throw new P(t + " has no accessible constructor");
		      }
		      var W = w.Z[R.length];
		      if (void 0 === W) {
		        throw new P(`Tried to invoke ctor of ${t} with invalid number of parameters (${R.length}) - expected (${Object.keys(w.Z).toString()}) parameters instead!`);
		      }
		      return W.apply(this, R);
		    });
		    var E = Object.create(C, {constructor:{value:u},});
		    u.prototype = E;
		    var w = new Yc(t, u, E, y, q, f, k, n);
		    if (w.C) {
		      var L;
		      (L = w.C).na ?? (L.na = []);
		      w.C.na.push(w);
		    }
		    q = new dd(t, w, true, false, false);
		    L = new dd(t + "*", w, false, false, false);
		    C = new dd(t + " const*", w, false, true, false);
		    Hc[a] = {pointerType:L, Hb:C};
		    ed(l, u);
		    return [q, L, C];
		  });
		}, _embind_register_class_class_function:(a, b, c, d, e, f, g) => {
		  var k = rd(c, d);
		  b = Q(b);
		  b = sd(b);
		  f = V(e, f);
		  U([], [a], p => {
		    function n() {
		      od(`Cannot call ${t} due to unbound types`, k);
		    }
		    p = p[0];
		    var t = `${p.name}.${b}`;
		    b.startsWith("@@") && (b = Symbol[b.substring(2)]);
		    var x = p.i.constructor;
		    void 0 === x[b] ? (n.da = c - 1, x[b] = n) : (Vc(x, b, t), x[b].A[c - 1] = n);
		    U([], k, y => {
		      y = qd(t, [y[0], null].concat(y.slice(1)), null, f, g);
		      void 0 === x[b].A ? (y.da = c - 1, x[b] = y) : x[b].A[c - 1] = y;
		      if (p.i.na) {
		        for (const l of p.i.na) {
		          l.constructor.hasOwnProperty(b) || (l.constructor[b] = y);
		        }
		      }
		      return [];
		    });
		    return [];
		  });
		}, _embind_register_class_class_property:(a, b, c, d, e, f, g, k) => {
		  b = Q(b);
		  f = V(e, f);
		  U([], [a], p => {
		    p = p[0];
		    var n = `${p.name}.${b}`, t = {get() {
		      od(`Cannot access ${n} due to unbound types`, [c]);
		    }, enumerable:true, configurable:true};
		    t.set = k ? () => {
		      od(`Cannot access ${n} due to unbound types`, [c]);
		    } : () => {
		      throw new P(`${n} is a read-only property`);
		    };
		    Object.defineProperty(p.i.constructor, b, t);
		    U([], [c], x => {
		      x = x[0];
		      var y = {get() {
		        return x.fromWireType(f(d));
		      }, enumerable:true};
		      k && (k = V(g, k), y.set = l => {
		        var u = [];
		        k(d, x.toWireType(u, l));
		        Nc(u);
		      });
		      Object.defineProperty(p.i.constructor, b, y);
		      return [];
		    });
		    return [];
		  });
		}, _embind_register_class_constructor:(a, b, c, d, e, f) => {
		  var g = rd(b, c);
		  e = V(d, e);
		  U([], [a], k => {
		    k = k[0];
		    var p = `constructor ${k.name}`;
		    void 0 === k.i.Z && (k.i.Z = []);
		    if (void 0 !== k.i.Z[b - 1]) {
		      throw new P(`Cannot register multiple constructors with identical number of parameters (${b - 1}) for class '${k.name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`);
		    }
		    k.i.Z[b - 1] = () => {
		      od(`Cannot construct ${k.name} due to unbound types`, g);
		    };
		    U([], g, n => {
		      n.splice(1, 0, null);
		      k.i.Z[b - 1] = qd(p, n, null, e, f);
		      return [];
		    });
		    return [];
		  });
		}, _embind_register_class_function:(a, b, c, d, e, f, g, k) => {
		  var p = rd(c, d);
		  b = Q(b);
		  b = sd(b);
		  f = V(e, f);
		  U([], [a], n => {
		    function t() {
		      od(`Cannot call ${x} due to unbound types`, p);
		    }
		    n = n[0];
		    var x = `${n.name}.${b}`;
		    b.startsWith("@@") && (b = Symbol[b.substring(2)]);
		    k && n.i.pb.push(b);
		    var y = n.i.M, l = y[b];
		    void 0 === l || void 0 === l.A && l.className !== n.name && l.da === c - 2 ? (t.da = c - 2, t.className = n.name, y[b] = t) : (Vc(y, b, x), y[b].A[c - 2] = t);
		    U([], p, u => {
		      u = qd(x, u, n, f, g);
		      void 0 === y[b].A ? (u.da = c - 2, y[b] = u) : y[b].A[c - 2] = u;
		      return [];
		    });
		    return [];
		  });
		}, _embind_register_class_property:(a, b, c, d, e, f, g, k, p, n) => {
		  b = Q(b);
		  e = V(d, e);
		  U([], [a], t => {
		    t = t[0];
		    var x = `${t.name}.${b}`, y = {get() {
		      od(`Cannot access ${x} due to unbound types`, [c, g]);
		    }, enumerable:true, configurable:true};
		    y.set = p ? () => od(`Cannot access ${x} due to unbound types`, [c, g]) : () => {
		      throw new P(x + " is a read-only property");
		    };
		    Object.defineProperty(t.i.M, b, y);
		    U([], p ? [c, g] : [c], l => {
		      var u = l[0], q = {get() {
		        var E = td(this, t, x + " getter");
		        return u.fromWireType(e(f, E));
		      }, enumerable:true};
		      if (p) {
		        p = V(k, p);
		        var C = l[1];
		        q.set = function(E) {
		          var w = td(this, t, x + " setter"), L = [];
		          p(n, w, C.toWireType(L, E));
		          Nc(L);
		        };
		      }
		      Object.defineProperty(t.i.M, b, q);
		      return [];
		    });
		    return [];
		  });
		}, _embind_register_emval:a => Rc(a, vd), _embind_register_enum:(a, b, c, d) => {
		  function e() {
		  }
		  b = Q(b);
		  e.values = {};
		  Rc(a, {name:b, constructor:e, fromWireType:function(f) {
		    return this.constructor.values[f];
		  }, toWireType:(f, g) => g.value, argPackAdvance:8, readValueFromPointer:wd(b, c, d), L:null,});
		  Wc(b, e);
		}, _embind_register_enum_value:(a, b, c) => {
		  var d = Dc(a, "enum");
		  b = Q(b);
		  a = d.constructor;
		  d = Object.create(d.constructor.prototype, {value:{value:c}, constructor:{value:mc(`${d.name}_${b}`, function() {
		  })},});
		  a.values[c] = d;
		  a[b] = d;
		}, _embind_register_float:(a, b, c) => {
		  b = Q(b);
		  Rc(a, {name:b, fromWireType:d => d, toWireType:(d, e) => e, argPackAdvance:8, readValueFromPointer:xd(b, c), L:null,});
		}, _embind_register_function:(a, b, c, d, e, f) => {
		  var g = rd(b, c);
		  a = Q(a);
		  a = sd(a);
		  e = V(d, e);
		  Wc(a, function() {
		    od(`Cannot call ${a} due to unbound types`, g);
		  }, b - 1);
		  U([], g, k => {
		    ed(a, qd(a, [k[0], null].concat(k.slice(1)), null, e, f), b - 1);
		    return [];
		  });
		}, _embind_register_integer:(a, b, c, d, e) => {
		  b = Q(b);
		  -1 === e && (e = 4294967295);
		  e = k => k;
		  if (0 === d) {
		    var f = 32 - 8 * c;
		    e = k => k << f >>> f;
		  }
		  var g = b.includes("unsigned") ? function(k, p) {
		    return p >>> 0;
		  } : function(k, p) {
		    return p;
		  };
		  Rc(a, {name:b, fromWireType:e, toWireType:g, argPackAdvance:8, readValueFromPointer:yd(b, c, 0 !== d), L:null,});
		}, _embind_register_memory_view:(a, b, c) => {
		  function d(f) {
		    return new e(z.buffer, M[f + 4 >> 2], M[f >> 2]);
		  }
		  var e = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array,][b];
		  c = Q(c);
		  Rc(a, {name:c, fromWireType:d, argPackAdvance:8, readValueFromPointer:d,}, {Vb:true,});
		}, _embind_register_std_string:(a, b) => {
		  b = Q(b);
		  var c = "std::string" === b;
		  Rc(a, {name:b, fromWireType:function(d) {
		    var e = M[d >> 2], f = d + 4;
		    if (c) {
		      for (var g = f, k = 0; k <= e; ++k) {
		        var p = f + k;
		        if (k == e || 0 == A[p]) {
		          g = g ? nb(A, g, p - g) : "";
		          if (void 0 === n) {
		            var n = g;
		          } else {
		            n += String.fromCharCode(0), n += g;
		          }
		          g = p + 1;
		        }
		      }
		    } else {
		      n = Array(e);
		      for (k = 0; k < e; ++k) {
		        n[k] = String.fromCharCode(A[f + k]);
		      }
		      n = n.join("");
		    }
		    Bc(d);
		    return n;
		  }, toWireType:function(d, e) {
		    e instanceof ArrayBuffer && (e = new Uint8Array(e));
		    var f = "string" == typeof e;
		    if (!(f || e instanceof Uint8Array || e instanceof Uint8ClampedArray || e instanceof Int8Array)) {
		      throw new P("Cannot pass non-string to std::string");
		    }
		    var g = c && f ? pb(e) : e.length;
		    var k = Xd(4 + g + 1), p = k + 4;
		    M[k >> 2] = g;
		    if (c && f) {
		      qb(e, A, p, g + 1);
		    } else {
		      if (f) {
		        for (f = 0; f < g; ++f) {
		          var n = e.charCodeAt(f);
		          if (255 < n) {
		            throw Bc(p), new P("String has UTF-16 code units that do not fit in 8 bits");
		          }
		          A[p + f] = n;
		        }
		      } else {
		        for (f = 0; f < g; ++f) {
		          A[p + f] = e[f];
		        }
		      }
		    }
		    null !== d && d.push(Bc, k);
		    return k;
		  }, argPackAdvance:8, readValueFromPointer:Oc, L(d) {
		    Bc(d);
		  },});
		}, _embind_register_std_wstring:(a, b, c) => {
		  c = Q(c);
		  if (2 === b) {
		    var d = Ad;
		    var e = Bd;
		    var f = Cd;
		    var g = k => Fa[k >> 1];
		  } else {
		    4 === b && (d = Dd, e = Ed, f = Fd, g = k => M[k >> 2]);
		  }
		  Rc(a, {name:c, fromWireType:k => {
		    for (var p = M[k >> 2], n, t = k + 4, x = 0; x <= p; ++x) {
		      var y = k + 4 + x * b;
		      if (x == p || 0 == g(y)) {
		        t = d(t, y - t), void 0 === n ? n = t : (n += String.fromCharCode(0), n += t), t = y + b;
		      }
		    }
		    Bc(k);
		    return n;
		  }, toWireType:(k, p) => {
		    if ("string" != typeof p) {
		      throw new P(`Cannot pass non-string to C++ string type ${c}`);
		    }
		    var n = f(p), t = Xd(4 + n + b);
		    M[t >> 2] = n / b;
		    e(p, t + 4, n + b);
		    null !== k && k.push(Bc, t);
		    return t;
		  }, argPackAdvance:8, readValueFromPointer:Oc, L(k) {
		    Bc(k);
		  }});
		}, _embind_register_value_object:(a, b, c, d, e, f) => {
		  Mc[a] = {name:Q(b), Na:V(c, d), O:V(e, f), eb:[],};
		}, _embind_register_value_object_field:(a, b, c, d, e, f, g, k, p, n) => {
		  Mc[a].eb.push({Ob:Q(b), Ub:c, Sb:V(d, e), Tb:f, kc:g, jc:V(k, p), lc:n,});
		}, _embind_register_void:(a, b) => {
		  b = Q(b);
		  Rc(a, {Ic:true, name:b, argPackAdvance:0, fromWireType:() => {
		  }, toWireType:() => {
		  },});
		}, _emscripten_get_now_is_monotonic:() => 1, _emscripten_memcpy_js:(a, b, c) => A.copyWithin(a, b, b + c), _emval_as:(a, b, c) => {
		  a = pc(a);
		  b = Dc(b, "emval::as");
		  return Gd(b, c, a);
		}, _emval_call_method:(a, b, c, d, e) => {
		  a = Jd[a];
		  b = pc(b);
		  c = Id(c);
		  return a(b, b[c], d, e);
		}, _emval_decref:ud, _emval_get_method_caller:(a, b, c) => {
		  var d = Ld(a, b), e = d.shift();
		  a--;
		  var f = Array(a);
		  b = `methodCaller<(${d.map(g => g.name).join(", ")}) => ${e.name}>`;
		  return Kd(mc(b, (g, k, p, n) => {
		    for (var t = 0, x = 0; x < a; ++x) {
		      f[x] = d[x].readValueFromPointer(n + t), t += d[x].argPackAdvance;
		    }
		    g = 1 === c ? Md(k, f) : k.apply(g, f);
		    return Gd(e, p, g);
		  }));
		}, _emval_get_module_property:a => {
		  a = Id(a);
		  return qc(m[a]);
		}, _emval_get_property:(a, b) => {
		  a = pc(a);
		  b = pc(b);
		  return qc(a[b]);
		}, _emval_incref:a => {
		  9 < a && (oc[a + 1] += 1);
		}, _emval_new_array:() => qc([]), _emval_new_cstring:a => qc(Id(a)), _emval_new_object:() => qc({}), _emval_run_destructors:a => {
		  var b = pc(a);
		  Nc(b);
		  ud(a);
		}, _emval_set_property:(a, b, c) => {
		  a = pc(a);
		  b = pc(b);
		  c = pc(c);
		  a[b] = c;
		}, _emval_take_value:(a, b) => {
		  a = Dc(a, "_emval_take_value");
		  a = a.readValueFromPointer(b);
		  return qc(a);
		}, emscripten_asm_const_int:(a, b, c) => {
		  Nd.length = 0;
		  for (var d; d = A[b++];) {
		    var e = 105 != d;
		    e &= 112 != d;
		    c += e && c % 8 ? 4 : 0;
		    Nd.push(112 == d ? M[c >> 2] : 105 == d ? D[c >> 2] : Ha[c >> 3]);
		    c += e ? 8 : 4;
		  }
		  return bb[a](...Nd);
		}, emscripten_date_now:() => Date.now(), emscripten_get_now:() => performance.now(), emscripten_resize_heap:a => {
		  var b = A.length;
		  a >>>= 0;
		  if (2147483648 < a) {
		    return false;
		  }
		  for (var c = 1; 4 >= c; c *= 2) {
		    var d = b * (1 + 0.2 / c);
		    d = Math.min(d, a + 100663296);
		    var e = Math;
		    d = Math.max(a, d);
		    a: {
		      e = (e.min.call(e, 2147483648, d + (65536 - d % 65536) % 65536) - Aa.buffer.byteLength + 65535) / 65536;
		      try {
		        Aa.grow(e);
		        Ia();
		        var f = 1;
		        break a;
		      } catch (g) {
		      }
		      f = void 0;
		    }
		    if (f) {
		      return true;
		    }
		  }
		  return false;
		}, environ_get:(a, b) => {
		  var c = 0;
		  Qd().forEach((d, e) => {
		    var f = b + c;
		    e = M[a + 4 * e >> 2] = f;
		    for (f = 0; f < d.length; ++f) {
		      z[e++] = d.charCodeAt(f);
		    }
		    z[e] = 0;
		    c += d.length + 1;
		  });
		  return 0;
		}, environ_sizes_get:(a, b) => {
		  var c = Qd();
		  M[a >> 2] = c.length;
		  var d = 0;
		  c.forEach(e => d += e.length + 1);
		  M[b >> 2] = d;
		  return 0;
		}, fd_close:function(a) {
		  try {
		    var b = Tb(a);
		    if (null === b.W) {
		      throw new N(8);
		    }
		    b.Ka && (b.Ka = null);
		    try {
		      b.m.close && b.m.close(b);
		    } catch (c) {
		      throw c;
		    } finally {
		      Gb[b.W] = null;
		    }
		    b.W = null;
		    return 0;
		  } catch (c) {
		    if ("undefined" == typeof lc || "ErrnoError" !== c.name) {
		      throw c;
		    }
		    return c.$;
		  }
		}, fd_read:function(a, b, c, d) {
		  try {
		    a: {
		      var e = Tb(a);
		      a = b;
		      for (var f, g = b = 0; g < c; g++) {
		        var k = M[a >> 2], p = M[a + 4 >> 2];
		        a += 8;
		        var n = e, t = f, x = z;
		        if (0 > p || 0 > t) {
		          throw new N(28);
		        }
		        if (null === n.W) {
		          throw new N(8);
		        }
		        if (1 === (n.flags & 2097155)) {
		          throw new N(8);
		        }
		        if (16384 === (n.node.mode & 61440)) {
		          throw new N(31);
		        }
		        if (!n.m.read) {
		          throw new N(28);
		        }
		        var y = "undefined" != typeof t;
		        if (!y) {
		          t = n.position;
		        } else if (!n.seekable) {
		          throw new N(70);
		        }
		        var l = n.m.read(n, x, k, p, t);
		        y || (n.position += l);
		        var u = l;
		        if (0 > u) {
		          var q = -1;
		          break a;
		        }
		        b += u;
		        if (u < p) {
		          break;
		        }
		        "undefined" != typeof f && (f += u);
		      }
		      q = b;
		    }
		    M[d >> 2] = q;
		    return 0;
		  } catch (C) {
		    if ("undefined" == typeof lc || "ErrnoError" !== C.name) {
		      throw C;
		    }
		    return C.$;
		  }
		}, fd_seek:function(a, b, c, d, e) {
		  b = c + 2097152 >>> 0 < 4194305 - !!b ? (b >>> 0) + 4294967296 * c : NaN;
		  try {
		    if (isNaN(b)) {
		      return 61;
		    }
		    var f = Tb(a);
		    hc(f, b, d);
		    Ya = [f.position >>> 0, (Xa = f.position, 1.0 <= +Math.abs(Xa) ? 0.0 < Xa ? +Math.floor(Xa / 4294967296.0) >>> 0 : ~~+Math.ceil((Xa - +(~~Xa >>> 0)) / 4294967296.0) >>> 0 : 0)];
		    D[e >> 2] = Ya[0];
		    D[e + 4 >> 2] = Ya[1];
		    f.Ka && 0 === b && 0 === d && (f.Ka = null);
		    return 0;
		  } catch (g) {
		    if ("undefined" == typeof lc || "ErrnoError" !== g.name) {
		      throw g;
		    }
		    return g.$;
		  }
		}, fd_write:function(a, b, c, d) {
		  try {
		    a: {
		      var e = Tb(a);
		      a = b;
		      for (var f, g = b = 0; g < c; g++) {
		        var k = M[a >> 2], p = M[a + 4 >> 2];
		        a += 8;
		        var n = e, t = k, x = p, y = f, l = z;
		        if (0 > x || 0 > y) {
		          throw new N(28);
		        }
		        if (null === n.W) {
		          throw new N(8);
		        }
		        if (0 === (n.flags & 2097155)) {
		          throw new N(8);
		        }
		        if (16384 === (n.node.mode & 61440)) {
		          throw new N(31);
		        }
		        if (!n.m.write) {
		          throw new N(28);
		        }
		        n.seekable && n.flags & 1024 && hc(n, 0, 2);
		        var u = "undefined" != typeof y;
		        if (!u) {
		          y = n.position;
		        } else if (!n.seekable) {
		          throw new N(70);
		        }
		        var q = n.m.write(n, l, t, x, y, void 0);
		        u || (n.position += q);
		        var C = q;
		        if (0 > C) {
		          var E = -1;
		          break a;
		        }
		        b += C;
		        "undefined" != typeof f && (f += C);
		      }
		      E = b;
		    }
		    M[d >> 2] = E;
		    return 0;
		  } catch (w) {
		    if ("undefined" == typeof lc || "ErrnoError" !== w.name) {
		      throw w;
		    }
		    return w.$;
		  }
		}, strftime_l:(a, b, c, d) => Ud(a, b, c, d)}, X = function() {
		  function a(c) {
		    X = c.exports;
		    Aa = X.memory;
		    Ia();
		    gd = X.__indirect_function_table;
		    Ka.unshift(X.__wasm_call_ctors);
		    Na--;
		    m.monitorRunDependencies?.(Na);
		    0 == Na && (Pa && (c = Pa, Pa = null, c()));
		    return X;
		  }
		  var b = {env:Yd, wasi_snapshot_preview1:Yd,};
		  Na++;
		  m.monitorRunDependencies?.(Na);
		  if (m.instantiateWasm) {
		    try {
		      return m.instantiateWasm(b, a);
		    } catch (c) {
		      ya(`Module.instantiateWasm callback failed with error: ${c}`), ca(c);
		    }
		  }
		  Sa ||= Ra("canvas_advanced.wasm") ? "canvas_advanced.wasm" : m.locateFile ? m.locateFile("canvas_advanced.wasm", sa) : sa + "canvas_advanced.wasm";
		  Wa(b, function(c) {
		    a(c.instance);
		  }).catch(ca);
		  return {};
		}(), Bc = a => (Bc = X.free)(a), Xd = a => (Xd = X.malloc)(a), Ac = a => (Ac = X.__getTypeName)(a), Za = m._ma_device__on_notification_unlocked = a => (Za = m._ma_device__on_notification_unlocked = X.ma_device__on_notification_unlocked)(a);
		m._ma_malloc_emscripten = (a, b) => (m._ma_malloc_emscripten = X.ma_malloc_emscripten)(a, b);
		m._ma_free_emscripten = (a, b) => (m._ma_free_emscripten = X.ma_free_emscripten)(a, b);
		var $a = m._ma_device_process_pcm_frames_capture__webaudio = (a, b, c) => ($a = m._ma_device_process_pcm_frames_capture__webaudio = X.ma_device_process_pcm_frames_capture__webaudio)(a, b, c), ab = m._ma_device_process_pcm_frames_playback__webaudio = (a, b, c) => (ab = m._ma_device_process_pcm_frames_playback__webaudio = X.ma_device_process_pcm_frames_playback__webaudio)(a, b, c);
		m.dynCall_iiji = (a, b, c, d, e) => (m.dynCall_iiji = X.dynCall_iiji)(a, b, c, d, e);
		m.dynCall_jiji = (a, b, c, d, e) => (m.dynCall_jiji = X.dynCall_jiji)(a, b, c, d, e);
		m.dynCall_iiiji = (a, b, c, d, e, f) => (m.dynCall_iiiji = X.dynCall_iiiji)(a, b, c, d, e, f);
		m.dynCall_iij = (a, b, c, d) => (m.dynCall_iij = X.dynCall_iij)(a, b, c, d);
		m.dynCall_jii = (a, b, c) => (m.dynCall_jii = X.dynCall_jii)(a, b, c);
		m.dynCall_viijii = (a, b, c, d, e, f, g) => (m.dynCall_viijii = X.dynCall_viijii)(a, b, c, d, e, f, g);
		m.dynCall_iiiiij = (a, b, c, d, e, f, g) => (m.dynCall_iiiiij = X.dynCall_iiiiij)(a, b, c, d, e, f, g);
		m.dynCall_iiiiijj = (a, b, c, d, e, f, g, k, p) => (m.dynCall_iiiiijj = X.dynCall_iiiiijj)(a, b, c, d, e, f, g, k, p);
		m.dynCall_iiiiiijj = (a, b, c, d, e, f, g, k, p, n) => (m.dynCall_iiiiiijj = X.dynCall_iiiiiijj)(a, b, c, d, e, f, g, k, p, n);
		var Zd;
		Pa = function $d() {
		  Zd || ae();
		  Zd || (Pa = $d);
		};
		function ae() {
		  function a() {
		    if (!Zd && (Zd = true, m.calledRun = true, !Ba)) {
		      m.noFSInit || ic || (ic = true, m.stdin = m.stdin, m.stdout = m.stdout, m.stderr = m.stderr, m.stdin ? jc("stdin", m.stdin) : ec("/dev/tty", "/dev/stdin"), m.stdout ? jc("stdout", null, m.stdout) : ec("/dev/tty", "/dev/stdout"), m.stderr ? jc("stderr", null, m.stderr) : ec("/dev/tty1", "/dev/stderr"), fc("/dev/stdin", 0), fc("/dev/stdout", 1), fc("/dev/stderr", 1));
		      Jb = false;
		      cb(Ka);
		      ba(m);
		      if (m.onRuntimeInitialized) {
		        m.onRuntimeInitialized();
		      }
		      if (m.postRun) {
		        for ("function" == typeof m.postRun && (m.postRun = [m.postRun]); m.postRun.length;) {
		          var b = m.postRun.shift();
		          La.unshift(b);
		        }
		      }
		      cb(La);
		    }
		  }
		  if (!(0 < Na)) {
		    if (m.preRun) {
		      for ("function" == typeof m.preRun && (m.preRun = [m.preRun]); m.preRun.length;) {
		        Ma();
		      }
		    }
		    cb(Ja);
		    0 < Na || (m.setStatus ? (m.setStatus("Running..."), setTimeout(function() {
		      setTimeout(function() {
		        m.setStatus("");
		      }, 1);
		      a();
		    }, 1)) : a());
		  }
		}
		if (m.preInit) {
		  for ("function" == typeof m.preInit && (m.preInit = [m.preInit]); 0 < m.preInit.length;) {
		    m.preInit.pop()();
		  }
		}
		ae();
		moduleRtn = da;



		  return moduleRtn;
		}
		);
		})();
		/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rive);


		/***/ }),
		/* 2 */
		/***/ ((module) => {

		module.exports = /*#__PURE__*/JSON.parse('{"name":"@rive-app/canvas","version":"2.32.0","description":"Rive\'s canvas based web api.","main":"rive.js","homepage":"https://rive.app","repository":{"type":"git","url":"https://github.com/rive-app/rive-wasm/tree/master/js"},"keywords":["rive","animation"],"author":"Rive","contributors":["Luigi Rosso <luigi@rive.app> (https://rive.app)","Maxwell Talbot <max@rive.app> (https://rive.app)","Arthur Vivian <arthur@rive.app> (https://rive.app)","Umberto Sonnino <umberto@rive.app> (https://rive.app)","Matthew Sullivan <matt.j.sullivan@gmail.com> (mailto:matt.j.sullivan@gmail.com)"],"license":"MIT","files":["rive.js","rive.js.map","rive.wasm","rive_fallback.wasm","rive.d.ts","rive_advanced.mjs.d.ts"],"typings":"rive.d.ts","dependencies":{},"browser":{"fs":false,"path":false}}');

		/***/ }),
		/* 3 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   Animation: () => (/* reexport safe */ _Animation__WEBPACK_IMPORTED_MODULE_0__.Animation)
		/* harmony export */ });
		/* harmony import */ var _Animation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);



		/***/ }),
		/* 4 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   Animation: () => (/* binding */ Animation)
		/* harmony export */ });
		/**
		 * Represents an animation that can be played on an Artboard.
		 * Wraps animations and instances from the runtime and keeps track of playback state.
		 *
		 * The `Animation` class manages the state and behavior of a single animation instance,
		 * including its current time, loop count, and ability to scrub to a specific time.
		 *
		 * The class provides methods to advance the animation, apply its interpolated keyframe
		 * values to the Artboard, and clean up the underlying animation instance when the
		 * animation is no longer needed.
		 */
		var Animation = /** @class */ (function () {
		    /**
		     * Constructs a new animation
		     * @constructor
		     * @param {any} animation: runtime animation object
		     * @param {any} instance: runtime animation instance object
		     */
		    function Animation(animation, artboard, runtime, playing) {
		        this.animation = animation;
		        this.artboard = artboard;
		        this.playing = playing;
		        this.loopCount = 0;
		        /**
		         * The time to which the animation should move to on the next render.
		         * If not null, the animation will scrub to this time instead of advancing by the given time.
		         */
		        this.scrubTo = null;
		        this.instance = new runtime.LinearAnimationInstance(animation, artboard);
		    }
		    Object.defineProperty(Animation.prototype, "name", {
		        /**
		         * Returns the animation's name
		         */
		        get: function () {
		            return this.animation.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animation.prototype, "time", {
		        /**
		         * Returns the animation's name
		         */
		        get: function () {
		            return this.instance.time;
		        },
		        /**
		         * Sets the animation's current time
		         */
		        set: function (value) {
		            this.instance.time = value;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animation.prototype, "loopValue", {
		        /**
		         * Returns the animation's loop type
		         */
		        get: function () {
		            return this.animation.loopValue;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animation.prototype, "needsScrub", {
		        /**
		         * Indicates whether the animation needs to be scrubbed.
		         * @returns `true` if the animation needs to be scrubbed, `false` otherwise.
		         */
		        get: function () {
		            return this.scrubTo !== null;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Advances the animation by the give time. If the animation needs scrubbing,
		     * time is ignored and the stored scrub value is used.
		     * @param time the time to advance the animation by if no scrubbing required
		     */
		    Animation.prototype.advance = function (time) {
		        if (this.scrubTo === null) {
		            this.instance.advance(time);
		        }
		        else {
		            this.instance.time = 0;
		            this.instance.advance(this.scrubTo);
		            this.scrubTo = null;
		        }
		    };
		    /**
		     * Apply interpolated keyframe values to the artboard. This should be called after calling
		     * .advance() on an animation instance so that new values are applied to properties.
		     *
		     * Note: This does not advance the artboard, which updates all objects on the artboard
		     * @param mix - Mix value for the animation from 0 to 1
		     */
		    Animation.prototype.apply = function (mix) {
		        this.instance.apply(mix);
		    };
		    /**
		     * Deletes the backing Wasm animation instance; once this is called, this
		     * animation is no more.
		     */
		    Animation.prototype.cleanup = function () {
		        this.instance.delete();
		    };
		    return Animation;
		}());



		/***/ }),
		/* 5 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   AudioAssetWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.AudioAssetWrapper),
		/* harmony export */   AudioWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.AudioWrapper),
		/* harmony export */   BLANK_URL: () => (/* reexport safe */ _sanitizeUrl__WEBPACK_IMPORTED_MODULE_1__.BLANK_URL),
		/* harmony export */   CustomFileAssetLoaderWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.CustomFileAssetLoaderWrapper),
		/* harmony export */   FileAssetWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.FileAssetWrapper),
		/* harmony export */   FileFinalizer: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.FileFinalizer),
		/* harmony export */   FontAssetWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.FontAssetWrapper),
		/* harmony export */   FontWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.FontWrapper),
		/* harmony export */   ImageAssetWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.ImageAssetWrapper),
		/* harmony export */   ImageWrapper: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.ImageWrapper),
		/* harmony export */   createFinalization: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.createFinalization),
		/* harmony export */   finalizationRegistry: () => (/* reexport safe */ _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__.finalizationRegistry),
		/* harmony export */   registerTouchInteractions: () => (/* reexport safe */ _registerTouchInteractions__WEBPACK_IMPORTED_MODULE_0__.registerTouchInteractions),
		/* harmony export */   sanitizeUrl: () => (/* reexport safe */ _sanitizeUrl__WEBPACK_IMPORTED_MODULE_1__.sanitizeUrl)
		/* harmony export */ });
		/* harmony import */ var _registerTouchInteractions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
		/* harmony import */ var _sanitizeUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7);
		/* harmony import */ var _finalizationRegistry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);





		/***/ }),
		/* 6 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   registerTouchInteractions: () => (/* binding */ registerTouchInteractions)
		/* harmony export */ });
		var _this = undefined;
		/**
		 * Returns the clientX and clientY properties from touch or mouse events. Also
		 * calls preventDefault() on the event if it is a touchstart or touchmove to prevent
		 * scrolling the page on mobile devices
		 * @param event - Either a TouchEvent or a MouseEvent
		 * @returns - Coordinates of the clientX and clientY properties from the touch/mouse event
		 */
		var getClientCoordinates = function (event, isTouchScrollEnabled, enableMultiTouch) {
		    var _a, _b;
		    var coordinates = [];
		    if (["touchstart", "touchmove"].indexOf(event.type) > -1 &&
		        ((_a = event.changedTouches) === null || _a === void 0 ? void 0 : _a.length)) {
		        // This flag, if false, prevents touch events on the canvas default behavior
		        // which may prevent scrolling if a drag motion on the canvas is performed
		        if (!isTouchScrollEnabled) {
		            event.preventDefault();
		        }
		        var cnt = 0;
		        var totalTouches = enableMultiTouch
		            ? event.changedTouches.length
		            : 1;
		        while (cnt < totalTouches) {
		            var touch = event.changedTouches[cnt];
		            coordinates.push({
		                clientX: touch.clientX,
		                clientY: touch.clientY,
		                identifier: touch.identifier,
		            });
		            cnt++;
		        }
		    }
		    else if (event.type === "touchend" &&
		        ((_b = event.changedTouches) === null || _b === void 0 ? void 0 : _b.length)) {
		        var cnt = 0;
		        var totalTouches = enableMultiTouch
		            ? event.changedTouches.length
		            : 1;
		        while (cnt < totalTouches) {
		            var touch = event.changedTouches[cnt];
		            coordinates.push({
		                clientX: touch.clientX,
		                clientY: touch.clientY,
		                identifier: touch.identifier,
		            });
		            cnt++;
		        }
		    }
		    else {
		        coordinates.push({
		            clientX: event.clientX,
		            clientY: event.clientY,
		            identifier: 0,
		        });
		    }
		    return coordinates;
		};
		/**
		 * Registers mouse move/up/down callback handlers on the canvas to send meaningful coordinates to
		 * the state machine pointer move/up/down functions based on cursor interaction
		 */
		var registerTouchInteractions = function (_a) {
		    var canvas = _a.canvas, artboard = _a.artboard, _b = _a.stateMachines, stateMachines = _b === void 0 ? [] : _b, renderer = _a.renderer, rive = _a.rive, fit = _a.fit, alignment = _a.alignment, _c = _a.isTouchScrollEnabled, isTouchScrollEnabled = _c === void 0 ? false : _c, _d = _a.dispatchPointerExit, dispatchPointerExit = _d === void 0 ? true : _d, _e = _a.enableMultiTouch, enableMultiTouch = _e === void 0 ? false : _e, _f = _a.layoutScaleFactor, layoutScaleFactor = _f === void 0 ? 1.0 : _f;
		    if (!canvas ||
		        !stateMachines.length ||
		        !renderer ||
		        !rive ||
		        !artboard ||
		        typeof window === "undefined") {
		        return null;
		    }
		    /**
		     * After a touchend event, some browsers may fire synthetic mouse events
		     * (mouseover, mousedown, mousemove, mouseup) if the touch interaction did not cause
		     * any default action (such as scrolling).
		     *
		     * This is done to simulate the behavior of a mouse for applications that do not support
		     * touch events.
		     *
		     * We're keeping track of the previous event to not send the synthetic mouse events if the
		     * touch event was a click (touchstart -> touchend).
		     *
		     * This is only needed when `isTouchScrollEnabled` is false
		     * When true, `preventDefault()` is called which prevents this behaviour.
		     **/
		    var _prevEventType = null;
		    var _syntheticEventsActive = false;
		    var processEventCallback = function (event) {
		        // Exit early out of all synthetic mouse events
		        // https://stackoverflow.com/questions/9656990/how-to-prevent-simulated-mouse-events-in-mobile-browsers
		        // https://stackoverflow.com/questions/25572070/javascript-touchend-versus-click-dilemma
		        if (_syntheticEventsActive && event instanceof MouseEvent) {
		            // Synthetic event finished
		            if (event.type == "mouseup") {
		                _syntheticEventsActive = false;
		            }
		            return;
		        }
		        // Test if it's a "touch click". This could cause the browser to send
		        // synthetic mouse events.
		        _syntheticEventsActive =
		            isTouchScrollEnabled &&
		                event.type === "touchend" &&
		                _prevEventType === "touchstart";
		        _prevEventType = event.type;
		        var boundingRect = event.currentTarget.getBoundingClientRect();
		        var coordinateSets = getClientCoordinates(event, isTouchScrollEnabled, enableMultiTouch);
		        var forwardMatrix = rive.computeAlignment(fit, alignment, {
		            minX: 0,
		            minY: 0,
		            maxX: boundingRect.width,
		            maxY: boundingRect.height,
		        }, artboard.bounds, layoutScaleFactor);
		        var invertedMatrix = new rive.Mat2D();
		        forwardMatrix.invert(invertedMatrix);
		        coordinateSets.forEach(function (coordinateSet) {
		            var clientX = coordinateSet.clientX;
		            var clientY = coordinateSet.clientY;
		            if (!clientX && !clientY) {
		                return;
		            }
		            var canvasX = clientX - boundingRect.left;
		            var canvasY = clientY - boundingRect.top;
		            var canvasCoordinatesVector = new rive.Vec2D(canvasX, canvasY);
		            var transformedVector = rive.mapXY(invertedMatrix, canvasCoordinatesVector);
		            var transformedX = transformedVector.x();
		            var transformedY = transformedVector.y();
		            coordinateSet.transformedX = transformedX;
		            coordinateSet.transformedY = transformedY;
		            transformedVector.delete();
		            canvasCoordinatesVector.delete();
		        });
		        invertedMatrix.delete();
		        forwardMatrix.delete();
		        switch (event.type) {
		            /**
		             * There's a 2px buffer for a hitRadius when translating the pointer coordinates
		             * down to the state machine. In cases where the hitbox is about that much away
		             * from the Artboard border, we don't have exact precision on determining pointer
		             * exit. We're therefore adding to the translated coordinates on mouseout of a canvas
		             * to ensure that we report the mouse has truly exited the hitarea.
		             * https://github.com/rive-app/rive-cpp/blob/master/src/animation/state_machine_instance.cpp#L336
		             *
		             */
		            case "mouseout":
		                var _loop_1 = function (stateMachine) {
		                    if (dispatchPointerExit) {
		                        coordinateSets.forEach(function (coordinateSet) {
		                            stateMachine.pointerExit(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                        });
		                    }
		                    else {
		                        coordinateSets.forEach(function (coordinateSet) {
		                            stateMachine.pointerMove(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                        });
		                    }
		                };
		                for (var _i = 0, stateMachines_1 = stateMachines; _i < stateMachines_1.length; _i++) {
		                    var stateMachine = stateMachines_1[_i];
		                    _loop_1(stateMachine);
		                }
		                break;
		            // Pointer moving/hovering on the canvas
		            case "touchmove":
		            case "mouseover":
		            case "mousemove": {
		                var _loop_2 = function (stateMachine) {
		                    coordinateSets.forEach(function (coordinateSet) {
		                        stateMachine.pointerMove(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                    });
		                };
		                for (var _a = 0, stateMachines_2 = stateMachines; _a < stateMachines_2.length; _a++) {
		                    var stateMachine = stateMachines_2[_a];
		                    _loop_2(stateMachine);
		                }
		                break;
		            }
		            // Pointer click initiated but not released yet on the canvas
		            case "touchstart":
		            case "mousedown": {
		                var _loop_3 = function (stateMachine) {
		                    coordinateSets.forEach(function (coordinateSet) {
		                        stateMachine.pointerDown(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                    });
		                };
		                for (var _b = 0, stateMachines_3 = stateMachines; _b < stateMachines_3.length; _b++) {
		                    var stateMachine = stateMachines_3[_b];
		                    _loop_3(stateMachine);
		                }
		                break;
		            }
		            // Pointer click released on the canvas
		            case "touchend": {
		                var _loop_4 = function (stateMachine) {
		                    coordinateSets.forEach(function (coordinateSet) {
		                        stateMachine.pointerUp(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                        stateMachine.pointerExit(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                    });
		                };
		                for (var _c = 0, stateMachines_4 = stateMachines; _c < stateMachines_4.length; _c++) {
		                    var stateMachine = stateMachines_4[_c];
		                    _loop_4(stateMachine);
		                }
		                break;
		            }
		            case "mouseup": {
		                var _loop_5 = function (stateMachine) {
		                    coordinateSets.forEach(function (coordinateSet) {
		                        stateMachine.pointerUp(coordinateSet.transformedX, coordinateSet.transformedY, coordinateSet.identifier);
		                    });
		                };
		                for (var _d = 0, stateMachines_5 = stateMachines; _d < stateMachines_5.length; _d++) {
		                    var stateMachine = stateMachines_5[_d];
		                    _loop_5(stateMachine);
		                }
		                break;
		            }
		        }
		    };
		    var callback = processEventCallback.bind(_this);
		    canvas.addEventListener("mouseover", callback);
		    canvas.addEventListener("mouseout", callback);
		    canvas.addEventListener("mousemove", callback);
		    canvas.addEventListener("mousedown", callback);
		    canvas.addEventListener("mouseup", callback);
		    canvas.addEventListener("touchmove", callback, {
		        passive: isTouchScrollEnabled,
		    });
		    canvas.addEventListener("touchstart", callback, {
		        passive: isTouchScrollEnabled,
		    });
		    canvas.addEventListener("touchend", callback);
		    return function () {
		        canvas.removeEventListener("mouseover", callback);
		        canvas.removeEventListener("mouseout", callback);
		        canvas.removeEventListener("mousemove", callback);
		        canvas.removeEventListener("mousedown", callback);
		        canvas.removeEventListener("mouseup", callback);
		        canvas.removeEventListener("touchmove", callback);
		        canvas.removeEventListener("touchstart", callback);
		        canvas.removeEventListener("touchend", callback);
		    };
		};


		/***/ }),
		/* 7 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   BLANK_URL: () => (/* binding */ BLANK_URL),
		/* harmony export */   sanitizeUrl: () => (/* binding */ sanitizeUrl)
		/* harmony export */ });
		// Reference: https://github.com/braintree/sanitize-url/tree/main
		var invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
		var htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
		var htmlCtrlEntityRegex = /&(newline|tab);/gi;
		var ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
		var urlSchemeRegex = /^.+(:|&colon;)/gim;
		var relativeFirstCharacters = [".", "/"];
		var BLANK_URL = "about:blank";
		function isRelativeUrlWithoutProtocol(url) {
		    return relativeFirstCharacters.indexOf(url[0]) > -1;
		}
		// adapted from https://stackoverflow.com/a/29824550/2601552
		function decodeHtmlCharacters(str) {
		    var removedNullByte = str.replace(ctrlCharactersRegex, "");
		    return removedNullByte.replace(htmlEntitiesRegex, function (match, dec) {
		        return String.fromCharCode(dec);
		    });
		}
		function sanitizeUrl(url) {
		    if (!url) {
		        return BLANK_URL;
		    }
		    var sanitizedUrl = decodeHtmlCharacters(url)
		        .replace(htmlCtrlEntityRegex, "")
		        .replace(ctrlCharactersRegex, "")
		        .trim();
		    if (!sanitizedUrl) {
		        return BLANK_URL;
		    }
		    if (isRelativeUrlWithoutProtocol(sanitizedUrl)) {
		        return sanitizedUrl;
		    }
		    var urlSchemeParseResults = sanitizedUrl.match(urlSchemeRegex);
		    if (!urlSchemeParseResults) {
		        return sanitizedUrl;
		    }
		    var urlScheme = urlSchemeParseResults[0];
		    if (invalidProtocolRegex.test(urlScheme)) {
		        return BLANK_URL;
		    }
		    return sanitizedUrl;
		}


		/***/ }),
		/* 8 */
		/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   AudioAssetWrapper: () => (/* binding */ AudioAssetWrapper),
		/* harmony export */   AudioWrapper: () => (/* binding */ AudioWrapper),
		/* harmony export */   CustomFileAssetLoaderWrapper: () => (/* binding */ CustomFileAssetLoaderWrapper),
		/* harmony export */   FileAssetWrapper: () => (/* binding */ FileAssetWrapper),
		/* harmony export */   FileFinalizer: () => (/* binding */ FileFinalizer),
		/* harmony export */   FontAssetWrapper: () => (/* binding */ FontAssetWrapper),
		/* harmony export */   FontWrapper: () => (/* binding */ FontWrapper),
		/* harmony export */   ImageAssetWrapper: () => (/* binding */ ImageAssetWrapper),
		/* harmony export */   ImageWrapper: () => (/* binding */ ImageWrapper),
		/* harmony export */   createFinalization: () => (/* binding */ createFinalization),
		/* harmony export */   finalizationRegistry: () => (/* binding */ finalizationRegistry)
		/* harmony export */ });
		var __extends = (function () {
		    var extendStatics = function (d, b) {
		        extendStatics = Object.setPrototypeOf ||
		            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
		            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
		        return extendStatics(d, b);
		    };
		    return function (d, b) {
		        if (typeof b !== "function" && b !== null)
		            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
		        extendStatics(d, b);
		        function __() { this.constructor = d; }
		        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		    };
		})();
		var FileFinalizer = /** @class */ (function () {
		    function FileFinalizer(file) {
		        this.selfUnref = false;
		        this._file = file;
		    }
		    FileFinalizer.prototype.unref = function () {
		        if (this._file) {
		            this._file.unref();
		        }
		    };
		    return FileFinalizer;
		}());
		var ObjectFinalizer = /** @class */ (function () {
		    function ObjectFinalizer(finalizableObject) {
		        this._finalizableObject = finalizableObject;
		    }
		    ObjectFinalizer.prototype.unref = function () {
		        this._finalizableObject.unref();
		    };
		    return ObjectFinalizer;
		}());
		var AssetWrapper = /** @class */ (function () {
		    function AssetWrapper() {
		        this.selfUnref = false;
		    }
		    AssetWrapper.prototype.unref = function () { };
		    return AssetWrapper;
		}());
		var ImageWrapper = /** @class */ (function (_super) {
		    __extends(ImageWrapper, _super);
		    function ImageWrapper(image) {
		        var _this = _super.call(this) || this;
		        _this._nativeImage = image;
		        return _this;
		    }
		    Object.defineProperty(ImageWrapper.prototype, "nativeImage", {
		        get: function () {
		            return this._nativeImage;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ImageWrapper.prototype.unref = function () {
		        if (this.selfUnref) {
		            this._nativeImage.unref();
		        }
		    };
		    return ImageWrapper;
		}(AssetWrapper));
		var AudioWrapper = /** @class */ (function (_super) {
		    __extends(AudioWrapper, _super);
		    function AudioWrapper(audio) {
		        var _this = _super.call(this) || this;
		        _this._nativeAudio = audio;
		        return _this;
		    }
		    Object.defineProperty(AudioWrapper.prototype, "nativeAudio", {
		        get: function () {
		            return this._nativeAudio;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    AudioWrapper.prototype.unref = function () {
		        if (this.selfUnref) {
		            this._nativeAudio.unref();
		        }
		    };
		    return AudioWrapper;
		}(AssetWrapper));
		var FontWrapper = /** @class */ (function (_super) {
		    __extends(FontWrapper, _super);
		    function FontWrapper(font) {
		        var _this = _super.call(this) || this;
		        _this._nativeFont = font;
		        return _this;
		    }
		    Object.defineProperty(FontWrapper.prototype, "nativeFont", {
		        get: function () {
		            return this._nativeFont;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    FontWrapper.prototype.unref = function () {
		        if (this.selfUnref) {
		            this._nativeFont.unref();
		        }
		    };
		    return FontWrapper;
		}(AssetWrapper));
		var CustomFileAssetLoaderWrapper = /** @class */ (function () {
		    function CustomFileAssetLoaderWrapper(runtime, loaderCallback) {
		        this._assetLoaderCallback = loaderCallback;
		        this.assetLoader = new runtime.CustomFileAssetLoader({
		            loadContents: this.loadContents.bind(this),
		        });
		    }
		    CustomFileAssetLoaderWrapper.prototype.loadContents = function (asset, bytes) {
		        var assetWrapper;
		        if (asset.isImage) {
		            assetWrapper = new ImageAssetWrapper(asset);
		        }
		        else if (asset.isAudio) {
		            assetWrapper = new AudioAssetWrapper(asset);
		        }
		        else if (asset.isFont) {
		            assetWrapper = new FontAssetWrapper(asset);
		        }
		        return this._assetLoaderCallback(assetWrapper, bytes);
		    };
		    return CustomFileAssetLoaderWrapper;
		}());
		/**
		 * Rive class representing a FileAsset with relevant metadata fields to describe
		 * an asset associated wtih the Rive File
		 */
		var FileAssetWrapper = /** @class */ (function () {
		    function FileAssetWrapper(nativeAsset) {
		        this._nativeFileAsset = nativeAsset;
		    }
		    FileAssetWrapper.prototype.decode = function (bytes) {
		        this._nativeFileAsset.decode(bytes);
		    };
		    Object.defineProperty(FileAssetWrapper.prototype, "name", {
		        get: function () {
		            return this._nativeFileAsset.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "fileExtension", {
		        get: function () {
		            return this._nativeFileAsset.fileExtension;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "uniqueFilename", {
		        get: function () {
		            return this._nativeFileAsset.uniqueFilename;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "isAudio", {
		        get: function () {
		            return this._nativeFileAsset.isAudio;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "isImage", {
		        get: function () {
		            return this._nativeFileAsset.isImage;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "isFont", {
		        get: function () {
		            return this._nativeFileAsset.isFont;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "cdnUuid", {
		        get: function () {
		            return this._nativeFileAsset.cdnUuid;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(FileAssetWrapper.prototype, "nativeFileAsset", {
		        get: function () {
		            return this._nativeFileAsset;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    return FileAssetWrapper;
		}());
		/**
		 * Rive class extending the FileAsset that exposes a `setRenderImage()` API with a
		 * decoded Image (via the `decodeImage()` API) to set a new Image on the Rive FileAsset
		 */
		var ImageAssetWrapper = /** @class */ (function (_super) {
		    __extends(ImageAssetWrapper, _super);
		    function ImageAssetWrapper() {
		        return _super !== null && _super.apply(this, arguments) || this;
		    }
		    ImageAssetWrapper.prototype.setRenderImage = function (image) {
		        this._nativeFileAsset.setRenderImage(image.nativeImage);
		    };
		    return ImageAssetWrapper;
		}(FileAssetWrapper));
		/**
		 * Rive class extending the FileAsset that exposes a `setAudioSource()` API with a
		 * decoded Audio (via the `decodeAudio()` API) to set a new Audio on the Rive FileAsset
		 */
		var AudioAssetWrapper = /** @class */ (function (_super) {
		    __extends(AudioAssetWrapper, _super);
		    function AudioAssetWrapper() {
		        return _super !== null && _super.apply(this, arguments) || this;
		    }
		    AudioAssetWrapper.prototype.setAudioSource = function (audio) {
		        this._nativeFileAsset.setAudioSource(audio.nativeAudio);
		    };
		    return AudioAssetWrapper;
		}(FileAssetWrapper));
		/**
		 * Rive class extending the FileAsset that exposes a `setFont()` API with a
		 * decoded Font (via the `decodeFont()` API) to set a new Font on the Rive FileAsset
		 */
		var FontAssetWrapper = /** @class */ (function (_super) {
		    __extends(FontAssetWrapper, _super);
		    function FontAssetWrapper() {
		        return _super !== null && _super.apply(this, arguments) || this;
		    }
		    FontAssetWrapper.prototype.setFont = function (font) {
		        this._nativeFileAsset.setFont(font.nativeFont);
		    };
		    return FontAssetWrapper;
		}(FileAssetWrapper));
		var FakeFinalizationRegistry = /** @class */ (function () {
		    function FakeFinalizationRegistry(_) {
		    }
		    FakeFinalizationRegistry.prototype.register = function (object) {
		        object.selfUnref = true;
		    };
		    FakeFinalizationRegistry.prototype.unregister = function (_) { };
		    return FakeFinalizationRegistry;
		}());
		var MyFinalizationRegistry = typeof FinalizationRegistry !== "undefined"
		    ? FinalizationRegistry
		    : FakeFinalizationRegistry;
		var finalizationRegistry = new MyFinalizationRegistry(function (ob) {
		    ob === null || ob === void 0 ? void 0 : ob.unref();
		});
		var createFinalization = function (target, finalizable) {
		    var finalizer = new ObjectFinalizer(finalizable);
		    finalizationRegistry.register(target, finalizer);
		};



		/***/ })
		/******/ 	]);
		/************************************************************************/
		/******/ 	// The module cache
		/******/ 	var __webpack_module_cache__ = {};
		/******/ 	
		/******/ 	// The require function
		/******/ 	function __webpack_require__(moduleId) {
		/******/ 		// Check if module is in cache
		/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
		/******/ 		if (cachedModule !== undefined) {
		/******/ 			return cachedModule.exports;
		/******/ 		}
		/******/ 		// Create a new module (and put it into the cache)
		/******/ 		var module = __webpack_module_cache__[moduleId] = {
		/******/ 			// no module.id needed
		/******/ 			// no module.loaded needed
		/******/ 			exports: {}
		/******/ 		};
		/******/ 	
		/******/ 		// Execute the module function
		/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
		/******/ 	
		/******/ 		// Return the exports of the module
		/******/ 		return module.exports;
		/******/ 	}
		/******/ 	
		/************************************************************************/
		/******/ 	/* webpack/runtime/define property getters */
		/******/ 	(() => {
		/******/ 		// define getter functions for harmony exports
		/******/ 		__webpack_require__.d = (exports, definition) => {
		/******/ 			for(var key in definition) {
		/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
		/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
		/******/ 				}
		/******/ 			}
		/******/ 		};
		/******/ 	})();
		/******/ 	
		/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
		/******/ 	(() => {
		/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
		/******/ 	})();
		/******/ 	
		/******/ 	/* webpack/runtime/make namespace object */
		/******/ 	(() => {
		/******/ 		// define __esModule on exports
		/******/ 		__webpack_require__.r = (exports) => {
		/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
		/******/ 			}
		/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
		/******/ 		};
		/******/ 	})();
		/******/ 	
		/************************************************************************/
		var __webpack_exports__ = {};
		// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
		(() => {
		__webpack_require__.r(__webpack_exports__);
		/* harmony export */ __webpack_require__.d(__webpack_exports__, {
		/* harmony export */   Alignment: () => (/* binding */ Alignment),
		/* harmony export */   DataEnum: () => (/* binding */ DataEnum),
		/* harmony export */   EventType: () => (/* binding */ EventType),
		/* harmony export */   Fit: () => (/* binding */ Fit),
		/* harmony export */   Layout: () => (/* binding */ Layout),
		/* harmony export */   LoopType: () => (/* binding */ LoopType),
		/* harmony export */   Rive: () => (/* binding */ Rive),
		/* harmony export */   RiveEventType: () => (/* binding */ RiveEventType),
		/* harmony export */   RiveFile: () => (/* binding */ RiveFile),
		/* harmony export */   RuntimeLoader: () => (/* binding */ RuntimeLoader),
		/* harmony export */   StateMachineInput: () => (/* binding */ StateMachineInput),
		/* harmony export */   StateMachineInputType: () => (/* binding */ StateMachineInputType),
		/* harmony export */   Testing: () => (/* binding */ Testing),
		/* harmony export */   ViewModel: () => (/* binding */ ViewModel),
		/* harmony export */   ViewModelInstance: () => (/* binding */ ViewModelInstance),
		/* harmony export */   ViewModelInstanceArtboard: () => (/* binding */ ViewModelInstanceArtboard),
		/* harmony export */   ViewModelInstanceAssetImage: () => (/* binding */ ViewModelInstanceAssetImage),
		/* harmony export */   ViewModelInstanceBoolean: () => (/* binding */ ViewModelInstanceBoolean),
		/* harmony export */   ViewModelInstanceColor: () => (/* binding */ ViewModelInstanceColor),
		/* harmony export */   ViewModelInstanceEnum: () => (/* binding */ ViewModelInstanceEnum),
		/* harmony export */   ViewModelInstanceList: () => (/* binding */ ViewModelInstanceList),
		/* harmony export */   ViewModelInstanceNumber: () => (/* binding */ ViewModelInstanceNumber),
		/* harmony export */   ViewModelInstanceString: () => (/* binding */ ViewModelInstanceString),
		/* harmony export */   ViewModelInstanceTrigger: () => (/* binding */ ViewModelInstanceTrigger),
		/* harmony export */   ViewModelInstanceValue: () => (/* binding */ ViewModelInstanceValue),
		/* harmony export */   decodeAudio: () => (/* binding */ decodeAudio),
		/* harmony export */   decodeFont: () => (/* binding */ decodeFont),
		/* harmony export */   decodeImage: () => (/* binding */ decodeImage)
		/* harmony export */ });
		/* harmony import */ var _rive_advanced_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
		/* harmony import */ var package_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
		/* harmony import */ var _animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
		/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
		var __extends = (function () {
		    var extendStatics = function (d, b) {
		        extendStatics = Object.setPrototypeOf ||
		            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
		            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
		        return extendStatics(d, b);
		    };
		    return function (d, b) {
		        if (typeof b !== "function" && b !== null)
		            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
		        extendStatics(d, b);
		        function __() { this.constructor = d; }
		        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		    };
		})();
		var __assign = function () {
		    __assign = Object.assign || function(t) {
		        for (var s, i = 1, n = arguments.length; i < n; i++) {
		            s = arguments[i];
		            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
		                t[p] = s[p];
		        }
		        return t;
		    };
		    return __assign.apply(this, arguments);
		};
		var __awaiter = function (thisArg, _arguments, P, generator) {
		    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
		    return new (P || (P = Promise))(function (resolve, reject) {
		        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
		        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
		        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
		        step((generator = generator.apply(thisArg, _arguments || [])).next());
		    });
		};
		var __generator = function (thisArg, body) {
		    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
		    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
		    function verb(n) { return function (v) { return step([n, v]); }; }
		    function step(op) {
		        if (f) throw new TypeError("Generator is already executing.");
		        while (g && (g = 0, op[0] && (_ = 0)), _) try {
		            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
		            if (y = 0, t) op = [op[0] & 2, t.value];
		            switch (op[0]) {
		                case 0: case 1: t = op; break;
		                case 4: _.label++; return { value: op[1], done: false };
		                case 5: _.label++; y = op[1]; op = [0]; continue;
		                case 7: op = _.ops.pop(); _.trys.pop(); continue;
		                default:
		                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
		                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
		                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
		                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
		                    if (t[2]) _.ops.pop();
		                    _.trys.pop(); continue;
		            }
		            op = body.call(thisArg, _);
		        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
		        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
		    }
		};
		var __spreadArray = function (to, from, pack) {
		    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
		        if (ar || !(i in from)) {
		            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
		            ar[i] = from[i];
		        }
		    }
		    return to.concat(ar || Array.prototype.slice.call(from));
		};




		var RiveError = /** @class */ (function (_super) {
		    __extends(RiveError, _super);
		    function RiveError() {
		        var _this = _super !== null && _super.apply(this, arguments) || this;
		        _this.isHandledError = true;
		        return _this;
		    }
		    return RiveError;
		}(Error));
		// #regions helpers
		var resolveErrorMessage = function (error) {
		    return error && error.isHandledError
		        ? error.message
		        : "Problem loading file; may be corrupt!";
		};
		// #region layout
		// Fit options for the canvas
		var Fit;
		(function (Fit) {
		    Fit["Cover"] = "cover";
		    Fit["Contain"] = "contain";
		    Fit["Fill"] = "fill";
		    Fit["FitWidth"] = "fitWidth";
		    Fit["FitHeight"] = "fitHeight";
		    Fit["None"] = "none";
		    Fit["ScaleDown"] = "scaleDown";
		    Fit["Layout"] = "layout";
		})(Fit || (Fit = {}));
		// Alignment options for the canvas
		var Alignment;
		(function (Alignment) {
		    Alignment["Center"] = "center";
		    Alignment["TopLeft"] = "topLeft";
		    Alignment["TopCenter"] = "topCenter";
		    Alignment["TopRight"] = "topRight";
		    Alignment["CenterLeft"] = "centerLeft";
		    Alignment["CenterRight"] = "centerRight";
		    Alignment["BottomLeft"] = "bottomLeft";
		    Alignment["BottomCenter"] = "bottomCenter";
		    Alignment["BottomRight"] = "bottomRight";
		})(Alignment || (Alignment = {}));
		// Alignment options for Rive animations in a HTML canvas
		var Layout = /** @class */ (function () {
		    function Layout(params) {
		        var _a, _b, _c, _d, _e, _f, _g;
		        this.fit = (_a = params === null || params === void 0 ? void 0 : params.fit) !== null && _a !== void 0 ? _a : Fit.Contain;
		        this.alignment = (_b = params === null || params === void 0 ? void 0 : params.alignment) !== null && _b !== void 0 ? _b : Alignment.Center;
		        this.layoutScaleFactor = (_c = params === null || params === void 0 ? void 0 : params.layoutScaleFactor) !== null && _c !== void 0 ? _c : 1;
		        this.minX = (_d = params === null || params === void 0 ? void 0 : params.minX) !== null && _d !== void 0 ? _d : 0;
		        this.minY = (_e = params === null || params === void 0 ? void 0 : params.minY) !== null && _e !== void 0 ? _e : 0;
		        this.maxX = (_f = params === null || params === void 0 ? void 0 : params.maxX) !== null && _f !== void 0 ? _f : 0;
		        this.maxY = (_g = params === null || params === void 0 ? void 0 : params.maxY) !== null && _g !== void 0 ? _g : 0;
		    }
		    // Alternative constructor to build a Layout from an interface/object
		    Layout.new = function (_a) {
		        var fit = _a.fit, alignment = _a.alignment, minX = _a.minX, minY = _a.minY, maxX = _a.maxX, maxY = _a.maxY;
		        console.warn("This function is deprecated: please use `new Layout({})` instead");
		        return new Layout({ fit: fit, alignment: alignment, minX: minX, minY: minY, maxX: maxX, maxY: maxY });
		    };
		    /**
		     * Makes a copy of the layout, replacing any specified parameters
		     */
		    Layout.prototype.copyWith = function (_a) {
		        var fit = _a.fit, alignment = _a.alignment, layoutScaleFactor = _a.layoutScaleFactor, minX = _a.minX, minY = _a.minY, maxX = _a.maxX, maxY = _a.maxY;
		        return new Layout({
		            fit: fit !== null && fit !== void 0 ? fit : this.fit,
		            alignment: alignment !== null && alignment !== void 0 ? alignment : this.alignment,
		            layoutScaleFactor: layoutScaleFactor !== null && layoutScaleFactor !== void 0 ? layoutScaleFactor : this.layoutScaleFactor,
		            minX: minX !== null && minX !== void 0 ? minX : this.minX,
		            minY: minY !== null && minY !== void 0 ? minY : this.minY,
		            maxX: maxX !== null && maxX !== void 0 ? maxX : this.maxX,
		            maxY: maxY !== null && maxY !== void 0 ? maxY : this.maxY,
		        });
		    };
		    // Returns fit for the Wasm runtime format
		    Layout.prototype.runtimeFit = function (rive) {
		        if (this.cachedRuntimeFit)
		            return this.cachedRuntimeFit;
		        var fit;
		        if (this.fit === Fit.Cover)
		            fit = rive.Fit.cover;
		        else if (this.fit === Fit.Contain)
		            fit = rive.Fit.contain;
		        else if (this.fit === Fit.Fill)
		            fit = rive.Fit.fill;
		        else if (this.fit === Fit.FitWidth)
		            fit = rive.Fit.fitWidth;
		        else if (this.fit === Fit.FitHeight)
		            fit = rive.Fit.fitHeight;
		        else if (this.fit === Fit.ScaleDown)
		            fit = rive.Fit.scaleDown;
		        else if (this.fit === Fit.Layout)
		            fit = rive.Fit.layout;
		        else
		            fit = rive.Fit.none;
		        this.cachedRuntimeFit = fit;
		        return fit;
		    };
		    // Returns alignment for the Wasm runtime format
		    Layout.prototype.runtimeAlignment = function (rive) {
		        if (this.cachedRuntimeAlignment)
		            return this.cachedRuntimeAlignment;
		        var alignment;
		        if (this.alignment === Alignment.TopLeft)
		            alignment = rive.Alignment.topLeft;
		        else if (this.alignment === Alignment.TopCenter)
		            alignment = rive.Alignment.topCenter;
		        else if (this.alignment === Alignment.TopRight)
		            alignment = rive.Alignment.topRight;
		        else if (this.alignment === Alignment.CenterLeft)
		            alignment = rive.Alignment.centerLeft;
		        else if (this.alignment === Alignment.CenterRight)
		            alignment = rive.Alignment.centerRight;
		        else if (this.alignment === Alignment.BottomLeft)
		            alignment = rive.Alignment.bottomLeft;
		        else if (this.alignment === Alignment.BottomCenter)
		            alignment = rive.Alignment.bottomCenter;
		        else if (this.alignment === Alignment.BottomRight)
		            alignment = rive.Alignment.bottomRight;
		        else
		            alignment = rive.Alignment.center;
		        this.cachedRuntimeAlignment = alignment;
		        return alignment;
		    };
		    return Layout;
		}());

		// Runtime singleton; use getInstance to provide a callback that returns the
		// Rive runtime
		var RuntimeLoader = /** @class */ (function () {
		    // Class is never instantiated
		    function RuntimeLoader() {
		    }
		    // Loads the runtime
		    RuntimeLoader.loadRuntime = function () {
		        _rive_advanced_mjs__WEBPACK_IMPORTED_MODULE_0__["default"]({
		            // Loads Wasm bundle
		            locateFile: function () { return RuntimeLoader.wasmURL; },
		        })
		            .then(function (rive) {
		            var _a;
		            RuntimeLoader.runtime = rive;
		            // Fire all the callbacks
		            while (RuntimeLoader.callBackQueue.length > 0) {
		                (_a = RuntimeLoader.callBackQueue.shift()) === null || _a === void 0 ? void 0 : _a(RuntimeLoader.runtime);
		            }
		        })
		            .catch(function (error) {
		            // Capture specific error details
		            var errorDetails = {
		                message: (error === null || error === void 0 ? void 0 : error.message) || "Unknown error",
		                type: (error === null || error === void 0 ? void 0 : error.name) || "Error",
		                // Some browsers may provide additional WebAssembly-specific details
		                wasmError: error instanceof WebAssembly.CompileError ||
		                    error instanceof WebAssembly.RuntimeError,
		                originalError: error,
		            };
		            // Log detailed error for debugging
		            console.debug("Rive WASM load error details:", errorDetails);
		            // In case unpkg fails, or the wasm was not supported, we try to load the fallback module from jsdelivr.
		            // This `rive_fallback.wasm` is compiled to support older architecture.
		            // TODO: (Gordon): preemptively test browser support and load the correct wasm file. Then use jsdelvr only if unpkg fails.
		            var backupJsdelivrUrl = "https://cdn.jsdelivr.net/npm/".concat(package_json__WEBPACK_IMPORTED_MODULE_1__.name, "@").concat(package_json__WEBPACK_IMPORTED_MODULE_1__.version, "/rive_fallback.wasm");
		            if (RuntimeLoader.wasmURL.toLowerCase() !== backupJsdelivrUrl) {
		                console.warn("Failed to load WASM from ".concat(RuntimeLoader.wasmURL, " (").concat(errorDetails.message, "), trying jsdelivr as a backup"));
		                RuntimeLoader.setWasmUrl(backupJsdelivrUrl);
		                RuntimeLoader.loadRuntime();
		            }
		            else {
		                var errorMessage = [
		                    "Could not load Rive WASM file from ".concat(RuntimeLoader.wasmURL, " or ").concat(backupJsdelivrUrl, "."),
		                    "Possible reasons:",
		                    "- Network connection is down",
		                    "- WebAssembly is not supported in this environment",
		                    "- The WASM file is corrupted or incompatible",
		                    "\nError details:",
		                    "- Type: ".concat(errorDetails.type),
		                    "- Message: ".concat(errorDetails.message),
		                    "- WebAssembly-specific error: ".concat(errorDetails.wasmError),
		                    "\nTo resolve, you may need to:",
		                    "1. Check your network connection",
		                    "2. Set a new WASM source via RuntimeLoader.setWasmUrl()",
		                    "3. Call RuntimeLoader.loadRuntime() again",
		                ].join("\n");
		                console.error(errorMessage);
		            }
		        });
		    };
		    // Provides a runtime instance via a callback
		    RuntimeLoader.getInstance = function (callback) {
		        // If it's not loading, start loading runtime
		        if (!RuntimeLoader.isLoading) {
		            RuntimeLoader.isLoading = true;
		            RuntimeLoader.loadRuntime();
		        }
		        if (!RuntimeLoader.runtime) {
		            RuntimeLoader.callBackQueue.push(callback);
		        }
		        else {
		            callback(RuntimeLoader.runtime);
		        }
		    };
		    // Provides a runtime instance via a promise
		    RuntimeLoader.awaitInstance = function () {
		        return new Promise(function (resolve) {
		            return RuntimeLoader.getInstance(function (rive) { return resolve(rive); });
		        });
		    };
		    // Manually sets the wasm url
		    RuntimeLoader.setWasmUrl = function (url) {
		        RuntimeLoader.wasmURL = url;
		    };
		    // Gets the current wasm url
		    RuntimeLoader.getWasmUrl = function () {
		        return RuntimeLoader.wasmURL;
		    };
		    // Flag to indicate that loading has started/completed
		    RuntimeLoader.isLoading = false;
		    // List of callbacks for the runtime that come in while loading
		    RuntimeLoader.callBackQueue = [];
		    // Path to the Wasm file; default path works for testing only;
		    // if embedded wasm is used then this is never used.
		    RuntimeLoader.wasmURL = "https://unpkg.com/".concat(package_json__WEBPACK_IMPORTED_MODULE_1__.name, "@").concat(package_json__WEBPACK_IMPORTED_MODULE_1__.version, "/rive.wasm");
		    return RuntimeLoader;
		}());

		// #endregion
		// #region state machines
		var StateMachineInputType;
		(function (StateMachineInputType) {
		    StateMachineInputType[StateMachineInputType["Number"] = 56] = "Number";
		    StateMachineInputType[StateMachineInputType["Trigger"] = 58] = "Trigger";
		    StateMachineInputType[StateMachineInputType["Boolean"] = 59] = "Boolean";
		})(StateMachineInputType || (StateMachineInputType = {}));
		/**
		 * An input for a state machine
		 */
		var StateMachineInput = /** @class */ (function () {
		    function StateMachineInput(type, runtimeInput) {
		        this.type = type;
		        this.runtimeInput = runtimeInput;
		    }
		    Object.defineProperty(StateMachineInput.prototype, "name", {
		        /**
		         * Returns the name of the input
		         */
		        get: function () {
		            return this.runtimeInput.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(StateMachineInput.prototype, "value", {
		        /**
		         * Returns the current value of the input
		         */
		        get: function () {
		            return this.runtimeInput.value;
		        },
		        /**
		         * Sets the value of the input
		         */
		        set: function (value) {
		            this.runtimeInput.value = value;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Fires a trigger; does nothing on Number or Boolean input types
		     */
		    StateMachineInput.prototype.fire = function () {
		        if (this.type === StateMachineInputType.Trigger) {
		            this.runtimeInput.fire();
		        }
		    };
		    /**
		     * Deletes the input
		     */
		    StateMachineInput.prototype.delete = function () {
		        this.runtimeInput = null;
		    };
		    return StateMachineInput;
		}());

		var RiveEventType;
		(function (RiveEventType) {
		    RiveEventType[RiveEventType["General"] = 128] = "General";
		    RiveEventType[RiveEventType["OpenUrl"] = 131] = "OpenUrl";
		})(RiveEventType || (RiveEventType = {}));
		var BaseArtboard = /** @class */ (function () {
		    function BaseArtboard(_isBindableArtboard) {
		        this.isBindableArtboard = false;
		        this.isBindableArtboard = _isBindableArtboard;
		    }
		    return BaseArtboard;
		}());
		var Artboard = /** @class */ (function (_super) {
		    __extends(Artboard, _super);
		    function Artboard(artboard, _file) {
		        var _this = _super.call(this, false) || this;
		        _this.nativeArtboard = artboard;
		        _this.file = _file;
		        return _this;
		    }
		    return Artboard;
		}(BaseArtboard));
		var BindableArtboard = /** @class */ (function (_super) {
		    __extends(BindableArtboard, _super);
		    function BindableArtboard(artboard) {
		        var _this = _super.call(this, true) || this;
		        _this.selfUnref = false;
		        _this.nativeArtboard = artboard;
		        return _this;
		    }
		    BindableArtboard.prototype.destroy = function () {
		        if (this.selfUnref) {
		            this.nativeArtboard.unref();
		        }
		    };
		    return BindableArtboard;
		}(BaseArtboard));
		var StateMachine = /** @class */ (function () {
		    /**
		     * @constructor
		     * @param stateMachine runtime state machine object
		     * @param instance runtime state machine instance object
		     */
		    function StateMachine(stateMachine, runtime, playing, artboard) {
		        this.stateMachine = stateMachine;
		        this.playing = playing;
		        this.artboard = artboard;
		        /**
		         * Caches the inputs from the runtime
		         */
		        this.inputs = [];
		        this.instance = new runtime.StateMachineInstance(stateMachine, artboard);
		        this.initInputs(runtime);
		    }
		    Object.defineProperty(StateMachine.prototype, "name", {
		        get: function () {
		            return this.stateMachine.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(StateMachine.prototype, "statesChanged", {
		        /**
		         * Returns a list of state names that have changed on this frame
		         */
		        get: function () {
		            var names = [];
		            for (var i = 0; i < this.instance.stateChangedCount(); i++) {
		                names.push(this.instance.stateChangedNameByIndex(i));
		            }
		            return names;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Advances the state machine instance by a given time.
		     * @param time - the time to advance the animation by in seconds
		     */
		    StateMachine.prototype.advance = function (time) {
		        this.instance.advance(time);
		    };
		    /**
		     * Advances the state machine instance by a given time and apply changes to artboard.
		     * @param time - the time to advance the animation by in seconds
		     */
		    StateMachine.prototype.advanceAndApply = function (time) {
		        this.instance.advanceAndApply(time);
		    };
		    /**
		     * Returns the number of events reported from the last advance call
		     * @returns Number of events reported
		     */
		    StateMachine.prototype.reportedEventCount = function () {
		        return this.instance.reportedEventCount();
		    };
		    /**
		     * Returns a RiveEvent object emitted from the last advance call at the given index
		     * of a list of potentially multiple events. If an event at the index is not found,
		     * undefined is returned.
		     * @param i index of the event reported in a list of potentially multiple events
		     * @returns RiveEvent or extended RiveEvent object returned, or undefined
		     */
		    StateMachine.prototype.reportedEventAt = function (i) {
		        return this.instance.reportedEventAt(i);
		    };
		    /**
		     * Fetches references to the state machine's inputs and caches them
		     * @param runtime an instance of the runtime; needed for the SMIInput types
		     */
		    StateMachine.prototype.initInputs = function (runtime) {
		        // Fetch the inputs from the runtime if we don't have them
		        for (var i = 0; i < this.instance.inputCount(); i++) {
		            var input = this.instance.input(i);
		            this.inputs.push(this.mapRuntimeInput(input, runtime));
		        }
		    };
		    /**
		     * Maps a runtime input to it's appropriate type
		     * @param input
		     */
		    StateMachine.prototype.mapRuntimeInput = function (input, runtime) {
		        if (input.type === runtime.SMIInput.bool) {
		            return new StateMachineInput(StateMachineInputType.Boolean, input.asBool());
		        }
		        else if (input.type === runtime.SMIInput.number) {
		            return new StateMachineInput(StateMachineInputType.Number, input.asNumber());
		        }
		        else if (input.type === runtime.SMIInput.trigger) {
		            return new StateMachineInput(StateMachineInputType.Trigger, input.asTrigger());
		        }
		    };
		    /**
		     * Deletes the backing Wasm state machine instance; once this is called, this
		     * state machine is no more.
		     */
		    StateMachine.prototype.cleanup = function () {
		        this.inputs.forEach(function (input) {
		            input.delete();
		        });
		        this.inputs.length = 0;
		        this.instance.delete();
		    };
		    StateMachine.prototype.bindViewModelInstance = function (viewModelInstance) {
		        if (viewModelInstance.runtimeInstance != null) {
		            this.instance.bindViewModelInstance(viewModelInstance.runtimeInstance);
		        }
		    };
		    return StateMachine;
		}());
		// #endregion
		// #region animator
		/**
		 * Manages animation
		 */
		var Animator = /** @class */ (function () {
		    /**
		     * Constructs a new animator
		     * @constructor
		     * @param runtime Rive runtime; needed to instance animations & state machines
		     * @param artboard the artboard that holds all animations and state machines
		     * @param animations optional list of animations
		     * @param stateMachines optional list of state machines
		     */
		    function Animator(runtime, artboard, eventManager, animations, stateMachines) {
		        if (animations === void 0) { animations = []; }
		        if (stateMachines === void 0) { stateMachines = []; }
		        this.runtime = runtime;
		        this.artboard = artboard;
		        this.eventManager = eventManager;
		        this.animations = animations;
		        this.stateMachines = stateMachines;
		    }
		    /**
		     * Adds animations and state machines by their names. If names are shared
		     * between animations & state machines, then the first one found will be
		     * created. Best not to use the same names for these in your Rive file.
		     * @param animatable the name(s) of animations and state machines to add
		     * @returns a list of names of the playing animations and state machines
		     */
		    Animator.prototype.add = function (animatables, playing, fireEvent) {
		        if (fireEvent === void 0) { fireEvent = true; }
		        animatables = mapToStringArray(animatables);
		        // If animatables is empty, play or pause everything
		        if (animatables.length === 0) {
		            this.animations.forEach(function (a) { return (a.playing = playing); });
		            this.stateMachines.forEach(function (m) { return (m.playing = playing); });
		        }
		        else {
		            // Play/pause already instanced items, or create new instances
		            var instancedAnimationNames = this.animations.map(function (a) { return a.name; });
		            var instancedMachineNames = this.stateMachines.map(function (m) { return m.name; });
		            for (var i = 0; i < animatables.length; i++) {
		                var aIndex = instancedAnimationNames.indexOf(animatables[i]);
		                var mIndex = instancedMachineNames.indexOf(animatables[i]);
		                if (aIndex >= 0 || mIndex >= 0) {
		                    if (aIndex >= 0) {
		                        // Animation is instanced, play/pause it
		                        this.animations[aIndex].playing = playing;
		                    }
		                    else {
		                        // State machine is instanced, play/pause it
		                        this.stateMachines[mIndex].playing = playing;
		                    }
		                }
		                else {
		                    // Try to create a new animation instance
		                    var anim = this.artboard.animationByName(animatables[i]);
		                    if (anim) {
		                        var newAnimation = new _animation__WEBPACK_IMPORTED_MODULE_2__.Animation(anim, this.artboard, this.runtime, playing);
		                        // Display the first frame of the specified animation
		                        newAnimation.advance(0);
		                        newAnimation.apply(1.0);
		                        this.animations.push(newAnimation);
		                    }
		                    else {
		                        // Try to create a new state machine instance
		                        var sm = this.artboard.stateMachineByName(animatables[i]);
		                        if (sm) {
		                            var newStateMachine = new StateMachine(sm, this.runtime, playing, this.artboard);
		                            this.stateMachines.push(newStateMachine);
		                        }
		                    }
		                }
		            }
		        }
		        // Fire play/paused events for animations
		        if (fireEvent) {
		            if (playing) {
		                this.eventManager.fire({
		                    type: EventType.Play,
		                    data: this.playing,
		                });
		            }
		            else {
		                this.eventManager.fire({
		                    type: EventType.Pause,
		                    data: this.paused,
		                });
		            }
		        }
		        return playing ? this.playing : this.paused;
		    };
		    /**
		     * Adds linear animations by their names.
		     * @param animatables the name(s) of animations to add
		     * @param playing whether animations should play on instantiation
		     */
		    Animator.prototype.initLinearAnimations = function (animatables, playing) {
		        // Play/pause already instanced items, or create new instances
		        // This validation is kept to maintain compatibility with current behavior.
		        // But given that it this is called during artboard initialization
		        // it should probably be safe to remove.
		        var instancedAnimationNames = this.animations.map(function (a) { return a.name; });
		        for (var i = 0; i < animatables.length; i++) {
		            var aIndex = instancedAnimationNames.indexOf(animatables[i]);
		            if (aIndex >= 0) {
		                this.animations[aIndex].playing = playing;
		            }
		            else {
		                // Try to create a new animation instance
		                var anim = this.artboard.animationByName(animatables[i]);
		                if (anim) {
		                    var newAnimation = new _animation__WEBPACK_IMPORTED_MODULE_2__.Animation(anim, this.artboard, this.runtime, playing);
		                    // Display the first frame of the specified animation
		                    newAnimation.advance(0);
		                    newAnimation.apply(1.0);
		                    this.animations.push(newAnimation);
		                }
		                else {
		                    console.error("Animation with name ".concat(animatables[i], " not found."));
		                }
		            }
		        }
		    };
		    /**
		     * Adds state machines by their names.
		     * @param animatables the name(s) of state machines to add
		     * @param playing whether state machines should play on instantiation
		     */
		    Animator.prototype.initStateMachines = function (animatables, playing) {
		        // Play/pause already instanced items, or create new instances
		        // This validation is kept to maintain compatibility with current behavior.
		        // But given that it this is called during artboard initialization
		        // it should probably be safe to remove.
		        var instancedStateMachineNames = this.stateMachines.map(function (a) { return a.name; });
		        for (var i = 0; i < animatables.length; i++) {
		            var aIndex = instancedStateMachineNames.indexOf(animatables[i]);
		            if (aIndex >= 0) {
		                this.stateMachines[aIndex].playing = playing;
		            }
		            else {
		                // Try to create a new state machine instance
		                var sm = this.artboard.stateMachineByName(animatables[i]);
		                if (sm) {
		                    var newStateMachine = new StateMachine(sm, this.runtime, playing, this.artboard);
		                    this.stateMachines.push(newStateMachine);
		                }
		                else {
		                    console.warn("State Machine with name ".concat(animatables[i], " not found."));
		                    // In order to maintain compatibility with current behavior, if a state machine is not found
		                    // we look for an animation with the same name
		                    this.initLinearAnimations([animatables[i]], playing);
		                }
		            }
		        }
		    };
		    /**
		     * Play the named animations/state machines
		     * @param animatables the names of the animations/machines to play; plays all if empty
		     * @returns a list of the playing items
		     */
		    Animator.prototype.play = function (animatables) {
		        return this.add(animatables, true);
		    };
		    /**
		     * Advance state machines if they are paused after initialization
		     */
		    Animator.prototype.advanceIfPaused = function () {
		        this.stateMachines.forEach(function (sm) {
		            if (!sm.playing) {
		                sm.advanceAndApply(0);
		            }
		        });
		    };
		    /**
		     * Pauses named animations and state machines, or everything if nothing is
		     * specified
		     * @param animatables names of the animations and state machines to pause
		     * @returns a list of names of the animations and state machines paused
		     */
		    Animator.prototype.pause = function (animatables) {
		        return this.add(animatables, false);
		    };
		    /**
		     * Set time of named animations
		     * @param animations names of the animations to scrub
		     * @param value time scrub value, a floating point number to which the playhead is jumped
		     * @returns a list of names of the animations that were scrubbed
		     */
		    Animator.prototype.scrub = function (animatables, value) {
		        var forScrubbing = this.animations.filter(function (a) {
		            return animatables.includes(a.name);
		        });
		        forScrubbing.forEach(function (a) { return (a.scrubTo = value); });
		        return forScrubbing.map(function (a) { return a.name; });
		    };
		    Object.defineProperty(Animator.prototype, "playing", {
		        /**
		         * Returns a list of names of all animations and state machines currently
		         * playing
		         */
		        get: function () {
		            return this.animations
		                .filter(function (a) { return a.playing; })
		                .map(function (a) { return a.name; })
		                .concat(this.stateMachines.filter(function (m) { return m.playing; }).map(function (m) { return m.name; }));
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animator.prototype, "paused", {
		        /**
		         * Returns a list of names of all animations and state machines currently
		         * paused
		         */
		        get: function () {
		            return this.animations
		                .filter(function (a) { return !a.playing; })
		                .map(function (a) { return a.name; })
		                .concat(this.stateMachines.filter(function (m) { return !m.playing; }).map(function (m) { return m.name; }));
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Stops and removes all named animations and state machines
		     * @param animatables animations and state machines to remove
		     * @returns a list of names of removed items
		     */
		    Animator.prototype.stop = function (animatables) {
		        var _this = this;
		        animatables = mapToStringArray(animatables);
		        // If nothing's specified, wipe them out, all of them
		        var removedNames = [];
		        // Stop everything
		        if (animatables.length === 0) {
		            removedNames = this.animations
		                .map(function (a) { return a.name; })
		                .concat(this.stateMachines.map(function (m) { return m.name; }));
		            // Clean up before emptying the arrays
		            this.animations.forEach(function (a) { return a.cleanup(); });
		            this.stateMachines.forEach(function (m) { return m.cleanup(); });
		            // Empty out the arrays
		            this.animations.splice(0, this.animations.length);
		            this.stateMachines.splice(0, this.stateMachines.length);
		        }
		        else {
		            // Remove only the named animations/state machines
		            var animationsToRemove = this.animations.filter(function (a) {
		                return animatables.includes(a.name);
		            });
		            animationsToRemove.forEach(function (a) {
		                a.cleanup();
		                _this.animations.splice(_this.animations.indexOf(a), 1);
		            });
		            var machinesToRemove = this.stateMachines.filter(function (m) {
		                return animatables.includes(m.name);
		            });
		            machinesToRemove.forEach(function (m) {
		                m.cleanup();
		                _this.stateMachines.splice(_this.stateMachines.indexOf(m), 1);
		            });
		            removedNames = animationsToRemove
		                .map(function (a) { return a.name; })
		                .concat(machinesToRemove.map(function (m) { return m.name; }));
		        }
		        this.eventManager.fire({
		            type: EventType.Stop,
		            data: removedNames,
		        });
		        // Return the list of animations removed
		        return removedNames;
		    };
		    Object.defineProperty(Animator.prototype, "isPlaying", {
		        /**
		         * Returns true if at least one animation is active
		         */
		        get: function () {
		            return (this.animations.reduce(function (acc, curr) { return acc || curr.playing; }, false) ||
		                this.stateMachines.reduce(function (acc, curr) { return acc || curr.playing; }, false));
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animator.prototype, "isPaused", {
		        /**
		         * Returns true if all animations are paused and there's at least one animation
		         */
		        get: function () {
		            return (!this.isPlaying &&
		                (this.animations.length > 0 || this.stateMachines.length > 0));
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Animator.prototype, "isStopped", {
		        /**
		         * Returns true if there are no playing or paused animations/state machines
		         */
		        get: function () {
		            return this.animations.length === 0 && this.stateMachines.length === 0;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * If there are no animations or state machines, add the first one found
		     * @returns the name of the animation or state machine instanced
		     */
		    Animator.prototype.atLeastOne = function (playing, fireEvent) {
		        if (fireEvent === void 0) { fireEvent = true; }
		        var instancedName;
		        if (this.animations.length === 0 && this.stateMachines.length === 0) {
		            if (this.artboard.animationCount() > 0) {
		                // Add the first animation
		                this.add([(instancedName = this.artboard.animationByIndex(0).name)], playing, fireEvent);
		            }
		            else if (this.artboard.stateMachineCount() > 0) {
		                // Add the first state machine
		                this.add([(instancedName = this.artboard.stateMachineByIndex(0).name)], playing, fireEvent);
		            }
		        }
		        return instancedName;
		    };
		    /**
		     * Checks if any animations have looped and if so, fire the appropriate event
		     */
		    Animator.prototype.handleLooping = function () {
		        for (var _i = 0, _a = this.animations.filter(function (a) { return a.playing; }); _i < _a.length; _i++) {
		            var animation = _a[_i];
		            // Emit if the animation looped
		            if (animation.loopValue === 0 && animation.loopCount) {
		                animation.loopCount = 0;
		                // This is a one-shot; if it has ended, delete the instance
		                this.stop(animation.name);
		            }
		            else if (animation.loopValue === 1 && animation.loopCount) {
		                this.eventManager.fire({
		                    type: EventType.Loop,
		                    data: { animation: animation.name, type: LoopType.Loop },
		                });
		                animation.loopCount = 0;
		            }
		            // Wasm indicates a loop at each time the animation
		            // changes direction, so a full loop/lap occurs every
		            // two loop counts
		            else if (animation.loopValue === 2 && animation.loopCount > 1) {
		                this.eventManager.fire({
		                    type: EventType.Loop,
		                    data: { animation: animation.name, type: LoopType.PingPong },
		                });
		                animation.loopCount = 0;
		            }
		        }
		    };
		    /**
		     * Checks if states have changed in state machines and fires a statechange
		     * event
		     */
		    Animator.prototype.handleStateChanges = function () {
		        var statesChanged = [];
		        for (var _i = 0, _a = this.stateMachines.filter(function (sm) { return sm.playing; }); _i < _a.length; _i++) {
		            var stateMachine = _a[_i];
		            statesChanged.push.apply(statesChanged, stateMachine.statesChanged);
		        }
		        if (statesChanged.length > 0) {
		            this.eventManager.fire({
		                type: EventType.StateChange,
		                data: statesChanged,
		            });
		        }
		    };
		    Animator.prototype.handleAdvancing = function (time) {
		        this.eventManager.fire({
		            type: EventType.Advance,
		            data: time,
		        });
		    };
		    return Animator;
		}());
		// #endregion
		// #region events
		/**
		 * Supported event types triggered in Rive
		 */
		var EventType;
		(function (EventType) {
		    EventType["Load"] = "load";
		    EventType["LoadError"] = "loaderror";
		    EventType["Play"] = "play";
		    EventType["Pause"] = "pause";
		    EventType["Stop"] = "stop";
		    EventType["Loop"] = "loop";
		    EventType["Draw"] = "draw";
		    EventType["Advance"] = "advance";
		    EventType["StateChange"] = "statechange";
		    EventType["RiveEvent"] = "riveevent";
		    EventType["AudioStatusChange"] = "audiostatuschange";
		})(EventType || (EventType = {}));
		/**
		 * Looping types: one-shot, loop, and ping-pong
		 */
		var LoopType;
		(function (LoopType) {
		    LoopType["OneShot"] = "oneshot";
		    LoopType["Loop"] = "loop";
		    LoopType["PingPong"] = "pingpong";
		})(LoopType || (LoopType = {}));
		// Manages Rive events and listeners
		var EventManager = /** @class */ (function () {
		    function EventManager(listeners) {
		        if (listeners === void 0) { listeners = []; }
		        this.listeners = listeners;
		    }
		    // Gets listeners of specified type
		    EventManager.prototype.getListeners = function (type) {
		        return this.listeners.filter(function (e) { return e.type === type; });
		    };
		    // Adds a listener
		    EventManager.prototype.add = function (listener) {
		        if (!this.listeners.includes(listener)) {
		            this.listeners.push(listener);
		        }
		    };
		    /**
		     * Removes a listener
		     * @param listener the listener with the callback to be removed
		     */
		    EventManager.prototype.remove = function (listener) {
		        // We can't simply look for the listener as it'll be a different instance to
		        // one originally subscribed. Find all the listeners of the right type and
		        // then check their callbacks which should match.
		        for (var i = 0; i < this.listeners.length; i++) {
		            var currentListener = this.listeners[i];
		            if (currentListener.type === listener.type) {
		                if (currentListener.callback === listener.callback) {
		                    this.listeners.splice(i, 1);
		                    break;
		                }
		            }
		        }
		    };
		    /**
		     * Clears all listeners of specified type, or every listener if no type is
		     * specified
		     * @param type the type of listeners to clear, or all listeners if not
		     * specified
		     */
		    EventManager.prototype.removeAll = function (type) {
		        var _this = this;
		        if (!type) {
		            this.listeners.splice(0, this.listeners.length);
		        }
		        else {
		            this.listeners
		                .filter(function (l) { return l.type === type; })
		                .forEach(function (l) { return _this.remove(l); });
		        }
		    };
		    // Fires an event
		    EventManager.prototype.fire = function (event) {
		        var eventListeners = this.getListeners(event.type);
		        eventListeners.forEach(function (listener) { return listener.callback(event); });
		    };
		    return EventManager;
		}());
		// Manages a queue of tasks
		var TaskQueueManager = /** @class */ (function () {
		    function TaskQueueManager(eventManager) {
		        this.eventManager = eventManager;
		        this.queue = [];
		    }
		    // Adds a task top the queue
		    TaskQueueManager.prototype.add = function (task) {
		        this.queue.push(task);
		    };
		    // Processes all tasks in the queue
		    TaskQueueManager.prototype.process = function () {
		        while (this.queue.length > 0) {
		            var task = this.queue.shift();
		            if (task === null || task === void 0 ? void 0 : task.action) {
		                task.action();
		            }
		            if (task === null || task === void 0 ? void 0 : task.event) {
		                this.eventManager.fire(task.event);
		            }
		        }
		    };
		    return TaskQueueManager;
		}());
		// #endregion
		// #region Audio
		var SystemAudioStatus;
		(function (SystemAudioStatus) {
		    SystemAudioStatus[SystemAudioStatus["AVAILABLE"] = 0] = "AVAILABLE";
		    SystemAudioStatus[SystemAudioStatus["UNAVAILABLE"] = 1] = "UNAVAILABLE";
		})(SystemAudioStatus || (SystemAudioStatus = {}));
		// Class to handle audio context availability and status changes
		var AudioManager = /** @class */ (function (_super) {
		    __extends(AudioManager, _super);
		    function AudioManager() {
		        var _this = _super !== null && _super.apply(this, arguments) || this;
		        _this._started = false;
		        _this._enabled = false;
		        _this._status = SystemAudioStatus.UNAVAILABLE;
		        return _this;
		    }
		    AudioManager.prototype.delay = function (time) {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                return [2 /*return*/, new Promise(function (resolve) { return setTimeout(resolve, time); })];
		            });
		        });
		    };
		    AudioManager.prototype.timeout = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                return [2 /*return*/, new Promise(function (_, reject) { return setTimeout(reject, 50); })];
		            });
		        });
		    };
		    // Alerts animations on status changes and removes the listeners to avoid alerting twice.
		    AudioManager.prototype.reportToListeners = function () {
		        this.fire({ type: EventType.AudioStatusChange });
		        this.removeAll();
		    };
		    /**
		     * The audio context has been resolved.
		     * Alert any listeners that we can now play audio.
		     * Rive will now play audio at the configured volume.
		     */
		    AudioManager.prototype.enableAudio = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                if (!this._enabled) {
		                    this._enabled = true;
		                    this._status = SystemAudioStatus.AVAILABLE;
		                    this.reportToListeners();
		                }
		                return [2 /*return*/];
		            });
		        });
		    };
		    /**
		     * Check if we are able to play audio.
		     *
		     * We currently check the audio context, when resume() returns before a timeout we know that the
		     * audio context is running and we can enable audio.
		     */
		    AudioManager.prototype.testAudio = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_b) {
		                switch (_b.label) {
		                    case 0:
		                        if (!(this._status === SystemAudioStatus.UNAVAILABLE &&
		                            this._audioContext !== null)) return [3 /*break*/, 4];
		                        _b.label = 1;
		                    case 1:
		                        _b.trys.push([1, 3, , 4]);
		                        return [4 /*yield*/, Promise.race([this._audioContext.resume(), this.timeout()])];
		                    case 2:
		                        _b.sent();
		                        this.enableAudio();
		                        return [3 /*break*/, 4];
		                    case 3:
		                        _b.sent();
		                        return [3 /*break*/, 4];
		                    case 4: return [2 /*return*/];
		                }
		            });
		        });
		    };
		    /**
		     * Establish audio for use with rive.
		     * We both test if we can use audio intermittently and listen for user interaction.
		     * The aim is to enable audio playback as soon as the browser allows this.
		     */
		    AudioManager.prototype._establishAudio = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                switch (_a.label) {
		                    case 0:
		                        if (!!this._started) return [3 /*break*/, 5];
		                        this._started = true;
		                        if (!(typeof window == "undefined")) return [3 /*break*/, 1];
		                        this.enableAudio();
		                        return [3 /*break*/, 5];
		                    case 1:
		                        this._audioContext = new AudioContext();
		                        this.listenForUserAction();
		                        _a.label = 2;
		                    case 2:
		                        if (!(this._status === SystemAudioStatus.UNAVAILABLE)) return [3 /*break*/, 5];
		                        return [4 /*yield*/, this.testAudio()];
		                    case 3:
		                        _a.sent();
		                        return [4 /*yield*/, this.delay(1000)];
		                    case 4:
		                        _a.sent();
		                        return [3 /*break*/, 2];
		                    case 5: return [2 /*return*/];
		                }
		            });
		        });
		    };
		    AudioManager.prototype.listenForUserAction = function () {
		        var _this = this;
		        // NOTE: AudioContexts are ready immediately if requested in a ui callback
		        // we *could* re request one in this listener.
		        var _clickListener = function () { return __awaiter(_this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                // note this has "better" results than calling `await this.testAudio()`
		                // as we force audio to be enabled in the current thread, rather than chancing
		                // the thread to be passed over for some other async context
		                this.enableAudio();
		                return [2 /*return*/];
		            });
		        }); };
		        // NOTE: we should test this on mobile/pads
		        document.addEventListener("pointerdown", _clickListener, {
		            once: true,
		        });
		    };
		    /**
		     * Establish the audio context for rive, this lets rive know that we can play audio.
		     */
		    AudioManager.prototype.establishAudio = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            return __generator(this, function (_a) {
		                this._establishAudio();
		                return [2 /*return*/];
		            });
		        });
		    };
		    Object.defineProperty(AudioManager.prototype, "systemVolume", {
		        get: function () {
		            if (this._status === SystemAudioStatus.UNAVAILABLE) {
		                // We do an immediate test to avoid depending on the delay of the running test
		                this.testAudio();
		                return 0;
		            }
		            return 1;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(AudioManager.prototype, "status", {
		        get: function () {
		            return this._status;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    return AudioManager;
		}(EventManager));
		var audioManager = new AudioManager();
		var FakeResizeObserver = /** @class */ (function () {
		    function FakeResizeObserver() {
		    }
		    FakeResizeObserver.prototype.observe = function () { };
		    FakeResizeObserver.prototype.unobserve = function () { };
		    FakeResizeObserver.prototype.disconnect = function () { };
		    return FakeResizeObserver;
		}());
		var MyResizeObserver = globalThis.ResizeObserver || FakeResizeObserver;
		/**
		 * This class takes care of any observers that will be attached to an animation.
		 * It should be treated as a singleton because observers are much more performant
		 * when used for observing multiple elements by a single instance.
		 */
		var ObjectObservers = /** @class */ (function () {
		    function ObjectObservers() {
		        var _this = this;
		        this._elementsMap = new Map();
		        /**
		         * Resize observers trigger both when the element changes its size and also when the
		         * element is added or removed from the document.
		         */
		        this._onObservedEntry = function (entry) {
		            var observed = _this._elementsMap.get(entry.target);
		            if (observed !== null) {
		                observed.onResize(entry.target.clientWidth == 0 || entry.target.clientHeight == 0);
		            }
		            else {
		                _this._resizeObserver.unobserve(entry.target);
		            }
		        };
		        this._onObserved = function (entries) {
		            entries.forEach(_this._onObservedEntry);
		        };
		        this._resizeObserver = new MyResizeObserver(this._onObserved);
		    }
		    // Adds an observable element
		    ObjectObservers.prototype.add = function (element, onResize) {
		        var observed = {
		            onResize: onResize,
		            element: element,
		        };
		        this._elementsMap.set(element, observed);
		        this._resizeObserver.observe(element);
		        return observed;
		    };
		    // Removes an observable element
		    ObjectObservers.prototype.remove = function (observed) {
		        this._resizeObserver.unobserve(observed.element);
		        this._elementsMap.delete(observed.element);
		    };
		    return ObjectObservers;
		}());
		var observers = new ObjectObservers();
		var RiveFile = /** @class */ (function () {
		    function RiveFile(params) {
		        // Allow the runtime to automatically load assets hosted in Rive's runtime.
		        this.enableRiveAssetCDN = true;
		        this.referenceCount = 0;
		        this.destroyed = false;
		        this.selfUnref = false;
		        this.bindableArtboards = [];
		        this.src = params.src;
		        this.buffer = params.buffer;
		        if (params.assetLoader)
		            this.assetLoader = params.assetLoader;
		        this.enableRiveAssetCDN =
		            typeof params.enableRiveAssetCDN == "boolean"
		                ? params.enableRiveAssetCDN
		                : true;
		        // New event management system
		        this.eventManager = new EventManager();
		        if (params.onLoad)
		            this.on(EventType.Load, params.onLoad);
		        if (params.onLoadError)
		            this.on(EventType.LoadError, params.onLoadError);
		    }
		    RiveFile.prototype.releaseFile = function () {
		        var _a;
		        if (this.selfUnref) {
		            (_a = this.file) === null || _a === void 0 ? void 0 : _a.unref();
		        }
		        this.file = null;
		    };
		    RiveFile.prototype.releaseBindableArtboards = function () {
		        this.bindableArtboards.forEach(function (bindableArtboard) {
		            return bindableArtboard.destroy();
		        });
		    };
		    RiveFile.prototype.initData = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            var _a, loader, loaderWrapper, _b, fileFinalizer;
		            return __generator(this, function (_c) {
		                switch (_c.label) {
		                    case 0:
		                        if (!this.src) return [3 /*break*/, 2];
		                        _a = this;
		                        return [4 /*yield*/, loadRiveFile(this.src)];
		                    case 1:
		                        _a.buffer = _c.sent();
		                        _c.label = 2;
		                    case 2:
		                        if (this.destroyed) {
		                            return [2 /*return*/];
		                        }
		                        if (this.assetLoader) {
		                            loaderWrapper = new _utils__WEBPACK_IMPORTED_MODULE_3__.CustomFileAssetLoaderWrapper(this.runtime, this.assetLoader);
		                            loader = loaderWrapper.assetLoader;
		                        }
		                        // Load the Rive file
		                        _b = this;
		                        return [4 /*yield*/, this.runtime.load(new Uint8Array(this.buffer), loader, this.enableRiveAssetCDN)];
		                    case 3:
		                        // Load the Rive file
		                        _b.file = _c.sent();
		                        fileFinalizer = new _utils__WEBPACK_IMPORTED_MODULE_3__.FileFinalizer(this.file);
		                        _utils__WEBPACK_IMPORTED_MODULE_3__.finalizationRegistry.register(this, fileFinalizer);
		                        if (this.destroyed) {
		                            this.releaseFile();
		                            return [2 /*return*/];
		                        }
		                        if (this.file !== null) {
		                            this.eventManager.fire({
		                                type: EventType.Load,
		                                data: this,
		                            });
		                        }
		                        else {
		                            this.fireLoadError(RiveFile.fileLoadErrorMessage);
		                        }
		                        return [2 /*return*/];
		                }
		            });
		        });
		    };
		    RiveFile.prototype.init = function () {
		        return __awaiter(this, void 0, void 0, function () {
		            var _a, error_1;
		            return __generator(this, function (_b) {
		                switch (_b.label) {
		                    case 0:
		                        // If no source file url specified, it's a bust
		                        if (!this.src && !this.buffer) {
		                            this.fireLoadError(RiveFile.missingErrorMessage);
		                            return [2 /*return*/];
		                        }
		                        _b.label = 1;
		                    case 1:
		                        _b.trys.push([1, 4, , 5]);
		                        _a = this;
		                        return [4 /*yield*/, RuntimeLoader.awaitInstance()];
		                    case 2:
		                        _a.runtime = _b.sent();
		                        if (this.destroyed) {
		                            return [2 /*return*/];
		                        }
		                        return [4 /*yield*/, this.initData()];
		                    case 3:
		                        _b.sent();
		                        return [3 /*break*/, 5];
		                    case 4:
		                        error_1 = _b.sent();
		                        this.fireLoadError(error_1 instanceof Error ? error_1.message : RiveFile.fileLoadErrorMessage);
		                        return [3 /*break*/, 5];
		                    case 5: return [2 /*return*/];
		                }
		            });
		        });
		    };
		    RiveFile.prototype.fireLoadError = function (message) {
		        this.eventManager.fire({
		            type: EventType.LoadError,
		            data: message,
		        });
		        throw new Error(message);
		    };
		    /**
		     * Subscribe to Rive-generated events
		     * @param type the type of event to subscribe to
		     * @param callback callback to fire when the event occurs
		     */
		    RiveFile.prototype.on = function (type, callback) {
		        this.eventManager.add({
		            type: type,
		            callback: callback,
		        });
		    };
		    /**
		     * Unsubscribes from a Rive-generated event
		     * @param type the type of event to unsubscribe from
		     * @param callback the callback to unsubscribe
		     */
		    RiveFile.prototype.off = function (type, callback) {
		        this.eventManager.remove({
		            type: type,
		            callback: callback,
		        });
		    };
		    RiveFile.prototype.cleanup = function () {
		        this.referenceCount -= 1;
		        if (this.referenceCount <= 0) {
		            this.removeAllRiveEventListeners();
		            this.releaseFile();
		            this.releaseBindableArtboards();
		            this.destroyed = true;
		        }
		    };
		    /**
		     * Unsubscribes all Rive listeners from an event type, or everything if no type is
		     * given
		     * @param type the type of event to unsubscribe from, or all types if
		     * undefined
		     */
		    RiveFile.prototype.removeAllRiveEventListeners = function (type) {
		        this.eventManager.removeAll(type);
		    };
		    RiveFile.prototype.getInstance = function () {
		        if (this.file !== null) {
		            this.referenceCount += 1;
		            return this.file;
		        }
		    };
		    RiveFile.prototype.destroyIfUnused = function () {
		        if (this.referenceCount <= 0) {
		            this.cleanup();
		        }
		    };
		    RiveFile.prototype.createBindableArtboard = function (nativeBindableArtboard) {
		        if (nativeBindableArtboard != null) {
		            var bindableArtboard = new BindableArtboard(nativeBindableArtboard);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(bindableArtboard, bindableArtboard.nativeArtboard);
		            this.bindableArtboards.push(bindableArtboard);
		            return bindableArtboard;
		        }
		        return null;
		    };
		    /**
		     * @deprecated This function is deprecated. For better stability and memory management
		     * use `getBindableArtboard()` instead.
		     * @param {string} name - The name of the artboard.
		     * @returns {Artboard} The artboard to bind to.
		     */
		    RiveFile.prototype.getArtboard = function (name) {
		        var nativeArtboard = this.file.artboardByName(name);
		        if (nativeArtboard != null) {
		            return new Artboard(nativeArtboard, this);
		        }
		    };
		    RiveFile.prototype.getBindableArtboard = function (name) {
		        var nativeArtboard = this.file.bindableArtboardByName(name);
		        return this.createBindableArtboard(nativeArtboard);
		    };
		    RiveFile.prototype.getDefaultBindableArtboard = function () {
		        var nativeArtboard = this.file.bindableArtboardDefault();
		        return this.createBindableArtboard(nativeArtboard);
		    };
		    RiveFile.prototype.internalBindableArtboardFromArtboard = function (artboard) {
		        var nativeBindableArtboard = this.file.internalBindableArtboardFromArtboard(artboard);
		        return this.createBindableArtboard(nativeBindableArtboard);
		    };
		    // Error message for missing source or buffer
		    RiveFile.missingErrorMessage = "Rive source file or data buffer required";
		    // Error message for file load error
		    RiveFile.fileLoadErrorMessage = "The file failed to load";
		    return RiveFile;
		}());

		var Rive = /** @class */ (function () {
		    function Rive(params) {
		        var _this = this;
		        var _a;
		        // Tracks if a Rive file is loaded
		        this.loaded = false;
		        // Tracks if a Rive file is destroyed
		        this.destroyed = false;
		        // Reference of an object that handles any observers for the animation
		        this._observed = null;
		        /**
		         * Tracks if a Rive file is loaded; we need this in addition to loaded as some
		         * commands (e.g. contents) can be called as soon as the file is loaded.
		         * However, playback commands need to be queued and run in order once initial
		         * animations and autoplay has been sorted out. This applies to play, pause,
		         * and start.
		         */
		        this.readyForPlaying = false;
		        // Runtime artboard
		        this.artboard = null;
		        // place to clear up event listeners
		        this.eventCleanup = null;
		        this.shouldDisableRiveListeners = false;
		        this.automaticallyHandleEvents = false;
		        this.dispatchPointerExit = true;
		        // Allow all pointers to be passed to the runtime
		        this.enableMultiTouch = false;
		        // Allow the runtime to automatically load assets hosted in Rive's runtime.
		        this.enableRiveAssetCDN = true;
		        // Keep a local value of the set volume to update it asynchronously
		        this._volume = 1;
		        // Keep a local value of the set width to update it asynchronously
		        this._artboardWidth = undefined;
		        // Keep a local value of the set height to update it asynchronously
		        this._artboardHeight = undefined;
		        // Keep a local value of the device pixel ratio used in rendering and canvas/artboard resizing
		        this._devicePixelRatioUsed = 1;
		        // Whether the canvas element's size is 0
		        this._hasZeroSize = false;
		        // Audio event listener
		        this._audioEventListener = null;
		        // draw method bound to the class
		        this._boundDraw = null;
		        this._viewModelInstance = null;
		        this._dataEnums = null;
		        // Durations to generate a frame for the last second. Used for performance profiling.
		        this.durations = [];
		        this.frameTimes = [];
		        this.frameCount = 0;
		        this.isTouchScrollEnabled = false;
		        this.onCanvasResize = function (hasZeroSize) {
		            var toggledDisplay = _this._hasZeroSize !== hasZeroSize;
		            _this._hasZeroSize = hasZeroSize;
		            if (!hasZeroSize) {
		                if (toggledDisplay) {
		                    _this.resizeDrawingSurfaceToCanvas();
		                }
		            }
		            else if (!_this._layout.maxX || !_this._layout.maxY) {
		                _this.resizeToCanvas();
		            }
		        };
		        /**
		         * Used be draw to track when a second of active rendering time has passed.
		         * Used for debugging purposes
		         */
		        this.renderSecondTimer = 0;
		        this._boundDraw = this.draw.bind(this);
		        this.canvas = params.canvas;
		        if (params.canvas.constructor === HTMLCanvasElement) {
		            this._observed = observers.add(this.canvas, this.onCanvasResize);
		        }
		        this.src = params.src;
		        this.buffer = params.buffer;
		        this.riveFile = params.riveFile;
		        this.layout = (_a = params.layout) !== null && _a !== void 0 ? _a : new Layout();
		        this.shouldDisableRiveListeners = !!params.shouldDisableRiveListeners;
		        this.isTouchScrollEnabled = !!params.isTouchScrollEnabled;
		        this.automaticallyHandleEvents = !!params.automaticallyHandleEvents;
		        this.dispatchPointerExit =
		            params.dispatchPointerExit === false
		                ? params.dispatchPointerExit
		                : this.dispatchPointerExit;
		        this.enableMultiTouch = !!params.enableMultiTouch;
		        this.enableRiveAssetCDN =
		            params.enableRiveAssetCDN === undefined
		                ? true
		                : params.enableRiveAssetCDN;
		        // New event management system
		        this.eventManager = new EventManager();
		        if (params.onLoad)
		            this.on(EventType.Load, params.onLoad);
		        if (params.onLoadError)
		            this.on(EventType.LoadError, params.onLoadError);
		        if (params.onPlay)
		            this.on(EventType.Play, params.onPlay);
		        if (params.onPause)
		            this.on(EventType.Pause, params.onPause);
		        if (params.onStop)
		            this.on(EventType.Stop, params.onStop);
		        if (params.onLoop)
		            this.on(EventType.Loop, params.onLoop);
		        if (params.onStateChange)
		            this.on(EventType.StateChange, params.onStateChange);
		        if (params.onAdvance)
		            this.on(EventType.Advance, params.onAdvance);
		        /**
		         * @deprecated Use camelCase'd versions instead.
		         */
		        if (params.onload && !params.onLoad)
		            this.on(EventType.Load, params.onload);
		        if (params.onloaderror && !params.onLoadError)
		            this.on(EventType.LoadError, params.onloaderror);
		        if (params.onplay && !params.onPlay)
		            this.on(EventType.Play, params.onplay);
		        if (params.onpause && !params.onPause)
		            this.on(EventType.Pause, params.onpause);
		        if (params.onstop && !params.onStop)
		            this.on(EventType.Stop, params.onstop);
		        if (params.onloop && !params.onLoop)
		            this.on(EventType.Loop, params.onloop);
		        if (params.onstatechange && !params.onStateChange)
		            this.on(EventType.StateChange, params.onstatechange);
		        /**
		         * Asset loading
		         */
		        if (params.assetLoader)
		            this.assetLoader = params.assetLoader;
		        // Hook up the task queue
		        this.taskQueue = new TaskQueueManager(this.eventManager);
		        this.init({
		            src: this.src,
		            buffer: this.buffer,
		            riveFile: this.riveFile,
		            autoplay: params.autoplay,
		            autoBind: params.autoBind,
		            animations: params.animations,
		            stateMachines: params.stateMachines,
		            artboard: params.artboard,
		            useOffscreenRenderer: params.useOffscreenRenderer,
		        });
		    }
		    Object.defineProperty(Rive.prototype, "viewModelCount", {
		        get: function () {
		            return this.file.viewModelCount();
		        },
		        enumerable: false,
		        configurable: true
		    });
		    // Alternative constructor to build a Rive instance from an interface/object
		    Rive.new = function (params) {
		        console.warn("This function is deprecated: please use `new Rive({})` instead");
		        return new Rive(params);
		    };
		    // Event handler for when audio context becomes available
		    Rive.prototype.onSystemAudioChanged = function () {
		        this.volume = this._volume;
		    };
		    // Initializes the Rive object either from constructor or load()
		    Rive.prototype.init = function (_a) {
		        var _this = this;
		        var src = _a.src, buffer = _a.buffer, riveFile = _a.riveFile, animations = _a.animations, stateMachines = _a.stateMachines, artboard = _a.artboard, _b = _a.autoplay, autoplay = _b === void 0 ? false : _b, _c = _a.useOffscreenRenderer, useOffscreenRenderer = _c === void 0 ? false : _c, _d = _a.autoBind, autoBind = _d === void 0 ? false : _d;
		        if (this.destroyed) {
		            return;
		        }
		        this.src = src;
		        this.buffer = buffer;
		        this.riveFile = riveFile;
		        // If no source file url specified, it's a bust
		        if (!this.src && !this.buffer && !this.riveFile) {
		            throw new RiveError(Rive.missingErrorMessage);
		        }
		        // List of animations that should be initialized.
		        var startingAnimationNames = mapToStringArray(animations);
		        // List of state machines that should be initialized
		        var startingStateMachineNames = mapToStringArray(stateMachines);
		        // Ensure loaded is marked as false if loading new file
		        this.loaded = false;
		        this.readyForPlaying = false;
		        // Ensure the runtime is loaded
		        RuntimeLoader.awaitInstance()
		            .then(function (runtime) {
		            if (_this.destroyed) {
		                return;
		            }
		            _this.runtime = runtime;
		            _this.removeRiveListeners();
		            _this.deleteRiveRenderer();
		            // Get the canvas where you want to render the animation and create a renderer
		            _this.renderer = _this.runtime.makeRenderer(_this.canvas, useOffscreenRenderer);
		            // Initial size adjustment based on devicePixelRatio if no width/height are
		            // specified explicitly
		            if (!(_this.canvas.width || _this.canvas.height)) {
		                _this.resizeDrawingSurfaceToCanvas();
		            }
		            // Load Rive data from a source uri or a data buffer
		            _this.initData(artboard, startingAnimationNames, startingStateMachineNames, autoplay, autoBind)
		                .then(function (hasInitialized) {
		                if (hasInitialized) {
		                    return _this.setupRiveListeners();
		                }
		            })
		                .catch(function (e) {
		                console.error(e);
		            });
		        })
		            .catch(function (e) {
		            console.error(e);
		        });
		    };
		    /**
		     * Setup Rive Listeners on the canvas
		     * @param riveListenerOptions - Enables TouchEvent events on the canvas. Set to true to allow
		     * touch scrolling on the canvas element on touch-enabled devices
		     * i.e. { isTouchScrollEnabled: true }
		     */
		    Rive.prototype.setupRiveListeners = function (riveListenerOptions) {
		        var _this = this;
		        if (this.eventCleanup) {
		            this.eventCleanup();
		        }
		        if (!this.shouldDisableRiveListeners) {
		            var activeStateMachines = (this.animator.stateMachines || [])
		                .filter(function (sm) { return sm.playing && _this.runtime.hasListeners(sm.instance); })
		                .map(function (sm) { return sm.instance; });
		            var touchScrollEnabledOption = this.isTouchScrollEnabled;
		            var dispatchPointerExit = this.dispatchPointerExit;
		            var enableMultiTouch = this.enableMultiTouch;
		            if (riveListenerOptions &&
		                "isTouchScrollEnabled" in riveListenerOptions) {
		                touchScrollEnabledOption = riveListenerOptions.isTouchScrollEnabled;
		            }
		            this.eventCleanup = (0, _utils__WEBPACK_IMPORTED_MODULE_3__.registerTouchInteractions)({
		                canvas: this.canvas,
		                artboard: this.artboard,
		                stateMachines: activeStateMachines,
		                renderer: this.renderer,
		                rive: this.runtime,
		                fit: this._layout.runtimeFit(this.runtime),
		                alignment: this._layout.runtimeAlignment(this.runtime),
		                isTouchScrollEnabled: touchScrollEnabledOption,
		                dispatchPointerExit: dispatchPointerExit,
		                enableMultiTouch: enableMultiTouch,
		                layoutScaleFactor: this._layout.layoutScaleFactor,
		            });
		        }
		    };
		    /**
		     * Remove Rive Listeners setup on the canvas
		     */
		    Rive.prototype.removeRiveListeners = function () {
		        if (this.eventCleanup) {
		            this.eventCleanup();
		            this.eventCleanup = null;
		        }
		    };
		    /**
		     * If the instance has audio and the system audio is not ready
		     * we hook the instance to the audio manager
		     */
		    Rive.prototype.initializeAudio = function () {
		        var _this = this;
		        var _a;
		        // Initialize audio if needed
		        if (audioManager.status == SystemAudioStatus.UNAVAILABLE) {
		            if (((_a = this.artboard) === null || _a === void 0 ? void 0 : _a.hasAudio) && this._audioEventListener === null) {
		                this._audioEventListener = {
		                    type: EventType.AudioStatusChange,
		                    callback: function () { return _this.onSystemAudioChanged(); },
		                };
		                audioManager.add(this._audioEventListener);
		                audioManager.establishAudio();
		            }
		        }
		    };
		    Rive.prototype.initArtboardSize = function () {
		        if (!this.artboard)
		            return;
		        // Use preset values if they are not undefined
		        this._artboardWidth = this.artboard.width =
		            this._artboardWidth || this.artboard.width;
		        this._artboardHeight = this.artboard.height =
		            this._artboardHeight || this.artboard.height;
		    };
		    // Initializes runtime with Rive data and preps for playing.
		    // Returns true for successful initialization.
		    Rive.prototype.initData = function (artboardName, animationNames, stateMachineNames, autoplay, autoBind) {
		        return __awaiter(this, void 0, void 0, function () {
		            var riveFile, error_2, msg;
		            var _a;
		            return __generator(this, function (_b) {
		                switch (_b.label) {
		                    case 0:
		                        _b.trys.push([0, 3, , 4]);
		                        if (!(this.riveFile == null)) return [3 /*break*/, 2];
		                        riveFile = new RiveFile({
		                            src: this.src,
		                            buffer: this.buffer,
		                            enableRiveAssetCDN: this.enableRiveAssetCDN,
		                            assetLoader: this.assetLoader,
		                        });
		                        this.riveFile = riveFile;
		                        return [4 /*yield*/, riveFile.init()];
		                    case 1:
		                        _b.sent();
		                        if (this.destroyed) {
		                            // In the very unlikely scenario where the rive file created by this Rive is shared by
		                            // another rive file, we only want to destroy it if this file is the only owner.
		                            riveFile.destroyIfUnused();
		                            return [2 /*return*/, false];
		                        }
		                        _b.label = 2;
		                    case 2:
		                        this.file = this.riveFile.getInstance();
		                        // Initialize and draw frame
		                        this.initArtboard(artboardName, animationNames, stateMachineNames, autoplay, autoBind);
		                        // Initialize the artboard size
		                        this.initArtboardSize();
		                        // Check for audio
		                        this.initializeAudio();
		                        // Everything's set up, emit a load event
		                        this.loaded = true;
		                        this.eventManager.fire({
		                            type: EventType.Load,
		                            data: (_a = this.src) !== null && _a !== void 0 ? _a : "buffer",
		                        });
		                        // Only initialize paused state machines after the load event has been fired
		                        // to allow users to initialize inputs and view models before the first advance
		                        this.animator.advanceIfPaused();
		                        // Flag ready for playback commands and clear the task queue; this order
		                        // is important or it may infinitely recurse
		                        this.readyForPlaying = true;
		                        this.taskQueue.process();
		                        this.drawFrame();
		                        return [2 /*return*/, true];
		                    case 3:
		                        error_2 = _b.sent();
		                        msg = resolveErrorMessage(error_2);
		                        console.warn(msg);
		                        this.eventManager.fire({ type: EventType.LoadError, data: msg });
		                        return [2 /*return*/, Promise.reject(msg)];
		                    case 4: return [2 /*return*/];
		                }
		            });
		        });
		    };
		    // Initialize for playback
		    Rive.prototype.initArtboard = function (artboardName, animationNames, stateMachineNames, autoplay, autoBind) {
		        if (!this.file) {
		            return;
		        }
		        // Fetch the artboard
		        var rootArtboard = artboardName
		            ? this.file.artboardByName(artboardName)
		            : this.file.defaultArtboard();
		        // Check we have a working artboard
		        if (!rootArtboard) {
		            var msg = "Invalid artboard name or no default artboard";
		            console.warn(msg);
		            this.eventManager.fire({ type: EventType.LoadError, data: msg });
		            return;
		        }
		        this.artboard = rootArtboard;
		        rootArtboard.volume = this._volume * audioManager.systemVolume;
		        // Initialize the animator
		        this.animator = new Animator(this.runtime, this.artboard, this.eventManager);
		        // Initialize the animations; as loaded hasn't happened yet, we need to
		        // suppress firing the play/pause events until the load event has fired. To
		        // do this we tell the animator to suppress firing events, and add event
		        // firing to the task queue.
		        var instanceNames;
		        if (animationNames.length > 0 || stateMachineNames.length > 0) {
		            instanceNames = animationNames.concat(stateMachineNames);
		            this.animator.initLinearAnimations(animationNames, autoplay);
		            this.animator.initStateMachines(stateMachineNames, autoplay);
		        }
		        else {
		            instanceNames = [this.animator.atLeastOne(autoplay, false)];
		        }
		        // Queue up firing the playback events
		        this.taskQueue.add({
		            event: {
		                type: autoplay ? EventType.Play : EventType.Pause,
		                data: instanceNames,
		            },
		        });
		        if (autoBind) {
		            var viewModel = this.file.defaultArtboardViewModel(rootArtboard);
		            if (viewModel !== null) {
		                var runtimeInstance = viewModel.defaultInstance();
		                if (runtimeInstance !== null) {
		                    var viewModelInstance = new ViewModelInstance(runtimeInstance, null);
		                    (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, viewModelInstance.runtimeInstance);
		                    this.bindViewModelInstance(viewModelInstance);
		                }
		            }
		        }
		    };
		    // Draws the current artboard frame
		    Rive.prototype.drawFrame = function () {
		        var _a, _b;
		        if ((_a = document === null || document === void 0 ? void 0 : document.timeline) === null || _a === void 0 ? void 0 : _a.currentTime) {
		            if (this.loaded && this.artboard && !this.frameRequestId) {
		                this._boundDraw(document.timeline.currentTime);
		                (_b = this.runtime) === null || _b === void 0 ? void 0 : _b.resolveAnimationFrame();
		            }
		        }
		        else {
		            this.startRendering();
		        }
		    };
		    /**
		     * Draw rendering loop; renders animation frames at the correct time interval.
		     * @param time the time at which to render a frame
		     */
		    Rive.prototype.draw = function (time, onSecond) {
		        var _a;
		        // Clear the frameRequestId, as we're now rendering a fresh frame
		        this.frameRequestId = null;
		        var before = performance.now();
		        // On the first pass, make sure lastTime has a valid value
		        if (!this.lastRenderTime) {
		            this.lastRenderTime = time;
		        }
		        // Handle the onSecond callback
		        this.renderSecondTimer += time - this.lastRenderTime;
		        if (this.renderSecondTimer > 5000) {
		            this.renderSecondTimer = 0;
		            onSecond === null || onSecond === void 0 ? void 0 : onSecond();
		        }
		        // Calculate the elapsed time between frames in seconds
		        var elapsedTime = (time - this.lastRenderTime) / 1000;
		        this.lastRenderTime = time;
		        // - Advance non-paused animations by the elapsed number of seconds
		        // - Advance any animations that require scrubbing
		        // - Advance to the first frame even when autoplay is false
		        var activeAnimations = this.animator.animations
		            .filter(function (a) { return a.playing || a.needsScrub; })
		            // The scrubbed animations must be applied first to prevent weird artifacts
		            // if the playing animations conflict with the scrubbed animating attribuates.
		            .sort(function (first) { return (first.needsScrub ? -1 : 1); });
		        for (var _i = 0, activeAnimations_1 = activeAnimations; _i < activeAnimations_1.length; _i++) {
		            var animation = activeAnimations_1[_i];
		            animation.advance(elapsedTime);
		            if (animation.instance.didLoop) {
		                animation.loopCount += 1;
		            }
		            animation.apply(1.0);
		        }
		        // - Advance non-paused state machines by the elapsed number of seconds
		        // - Advance to the first frame even when autoplay is false
		        var activeStateMachines = this.animator.stateMachines.filter(function (a) { return a.playing; });
		        for (var _b = 0, activeStateMachines_1 = activeStateMachines; _b < activeStateMachines_1.length; _b++) {
		            var stateMachine = activeStateMachines_1[_b];
		            // Check for events before the current frame's state machine advance
		            var numEventsReported = stateMachine.reportedEventCount();
		            if (numEventsReported) {
		                for (var i = 0; i < numEventsReported; i++) {
		                    var event_1 = stateMachine.reportedEventAt(i);
		                    if (event_1) {
		                        if (event_1.type === RiveEventType.OpenUrl) {
		                            this.eventManager.fire({
		                                type: EventType.RiveEvent,
		                                data: event_1,
		                            });
		                            // Handle the event side effect if explicitly enabled
		                            if (this.automaticallyHandleEvents) {
		                                var newAnchorTag = document.createElement("a");
		                                var _c = event_1, url = _c.url, target = _c.target;
		                                var sanitizedUrl = (0, _utils__WEBPACK_IMPORTED_MODULE_3__.sanitizeUrl)(url);
		                                url && newAnchorTag.setAttribute("href", sanitizedUrl);
		                                target && newAnchorTag.setAttribute("target", target);
		                                if (sanitizedUrl && sanitizedUrl !== _utils__WEBPACK_IMPORTED_MODULE_3__.BLANK_URL) {
		                                    newAnchorTag.click();
		                                }
		                            }
		                        }
		                        else {
		                            this.eventManager.fire({
		                                type: EventType.RiveEvent,
		                                data: event_1,
		                            });
		                        }
		                    }
		                }
		            }
		            stateMachine.advanceAndApply(elapsedTime);
		            // stateMachine.instance.apply(this.artboard);
		        }
		        // Once the animations have been applied to the artboard, advance it
		        // by the elapsed time.
		        if (this.animator.stateMachines.length == 0) {
		            this.artboard.advance(elapsedTime);
		        }
		        var renderer = this.renderer;
		        // Canvas must be wiped to prevent artifacts
		        renderer.clear();
		        renderer.save();
		        // Update the renderer alignment if necessary
		        this.alignRenderer();
		        // Do not draw on 0 canvas size
		        if (!this._hasZeroSize) {
		            this.artboard.draw(renderer);
		        }
		        renderer.restore();
		        renderer.flush();
		        // Check for any animations that looped
		        this.animator.handleLooping();
		        // Check for any state machines that had a state change
		        this.animator.handleStateChanges();
		        // Report advanced time
		        this.animator.handleAdvancing(elapsedTime);
		        // Add duration to create frame to durations array
		        this.frameCount++;
		        var after = performance.now();
		        this.frameTimes.push(after);
		        this.durations.push(after - before);
		        while (this.frameTimes[0] <= after - 1000) {
		            this.frameTimes.shift();
		            this.durations.shift();
		        }
		        (_a = this._viewModelInstance) === null || _a === void 0 ? void 0 : _a.handleCallbacks();
		        // Calling requestAnimationFrame will rerun draw() at the correct rate:
		        // https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API/Tutorial/Basic_animations
		        if (this.animator.isPlaying) {
		            // Request a new rendering frame
		            this.startRendering();
		        }
		        else if (this.animator.isPaused) {
		            // Reset the end time so on playback it starts at the correct frame
		            this.lastRenderTime = 0;
		        }
		        else if (this.animator.isStopped) {
		            // Reset animation instances, artboard and time
		            // TODO: implement this properly when we have instancing
		            // this.initArtboard();
		            // this.drawFrame();
		            this.lastRenderTime = 0;
		        }
		    };
		    /**
		     * Align the renderer
		     */
		    Rive.prototype.alignRenderer = function () {
		        var _a = this, renderer = _a.renderer, runtime = _a.runtime, _layout = _a._layout, artboard = _a.artboard;
		        // Align things up safe in the knowledge we can restore if changed
		        renderer.align(_layout.runtimeFit(runtime), _layout.runtimeAlignment(runtime), {
		            minX: _layout.minX,
		            minY: _layout.minY,
		            maxX: _layout.maxX,
		            maxY: _layout.maxY,
		        }, artboard.bounds, this._devicePixelRatioUsed * _layout.layoutScaleFactor);
		    };
		    Object.defineProperty(Rive.prototype, "fps", {
		        get: function () {
		            return this.durations.length;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "frameTime", {
		        get: function () {
		            if (this.durations.length === 0) {
		                return 0;
		            }
		            return (this.durations.reduce(function (a, b) { return a + b; }, 0) / this.durations.length).toFixed(4);
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Cleans up all Wasm-generated objects that need to be manually destroyed:
		     * artboard instances, animation instances, state machine instances,
		     * renderer instance, file and runtime.
		     *
		     * Once this is called, you will need to initialise a new instance of the
		     * Rive class
		     */
		    Rive.prototype.cleanup = function () {
		        var _a, _b;
		        this.destroyed = true;
		        // Stop the renderer if it hasn't already been stopped.
		        this.stopRendering();
		        // Clean up any artboard, animation or state machine instances.
		        this.cleanupInstances();
		        // Remove from observer
		        if (this._observed !== null) {
		            observers.remove(this._observed);
		        }
		        this.removeRiveListeners();
		        if (this.file) {
		            (_a = this.riveFile) === null || _a === void 0 ? void 0 : _a.cleanup();
		            this.file = null;
		        }
		        this.riveFile = null;
		        this.deleteRiveRenderer();
		        if (this._audioEventListener !== null) {
		            audioManager.remove(this._audioEventListener);
		            this._audioEventListener = null;
		        }
		        (_b = this._viewModelInstance) === null || _b === void 0 ? void 0 : _b.cleanup();
		        this._viewModelInstance = null;
		        this._dataEnums = null;
		    };
		    /**
		     * Cleans up the Renderer object. Only call this API if you no longer
		     * need to render Rive content in your session.
		     */
		    Rive.prototype.deleteRiveRenderer = function () {
		        var _a;
		        (_a = this.renderer) === null || _a === void 0 ? void 0 : _a.delete();
		        this.renderer = null;
		    };
		    /**
		     * Cleans up any Wasm-generated objects that need to be manually destroyed:
		     * artboard instances, animation instances, state machine instances.
		     *
		     * Once this is called, things will need to be reinitialized or bad things
		     * might happen.
		     */
		    Rive.prototype.cleanupInstances = function () {
		        if (this.eventCleanup !== null) {
		            this.eventCleanup();
		        }
		        // Delete all animation and state machine instances
		        this.stop();
		        if (this.artboard) {
		            this.artboard.delete();
		            this.artboard = null;
		        }
		    };
		    /**
		     * Tries to query the setup Artboard for a text run node with the given name.
		     *
		     * @param textRunName - Name of the text run node associated with a text object
		     * @returns - TextValueRun node or undefined if the text run cannot be queried
		     */
		    Rive.prototype.retrieveTextRun = function (textRunName) {
		        var _a;
		        if (!textRunName) {
		            console.warn("No text run name provided");
		            return;
		        }
		        if (!this.artboard) {
		            console.warn("Tried to access text run, but the Artboard is null");
		            return;
		        }
		        var textRun = this.artboard.textRun(textRunName);
		        if (!textRun) {
		            console.warn("Could not access a text run with name '".concat(textRunName, "' in the '").concat((_a = this.artboard) === null || _a === void 0 ? void 0 : _a.name, "' Artboard. Note that you must rename a text run node in the Rive editor to make it queryable at runtime."));
		            return;
		        }
		        return textRun;
		    };
		    /**
		     * Returns a string from a given text run node name, or undefined if the text run
		     * cannot be queried.
		     *
		     * @param textRunName - Name of the text run node associated with a text object
		     * @returns - String value of the text run node or undefined
		     */
		    Rive.prototype.getTextRunValue = function (textRunName) {
		        var textRun = this.retrieveTextRun(textRunName);
		        return textRun ? textRun.text : undefined;
		    };
		    /**
		     * Sets a text value for a given text run node name if possible
		     *
		     * @param textRunName - Name of the text run node associated with a text object
		     * @param textRunValue - String value to set on the text run node
		     */
		    Rive.prototype.setTextRunValue = function (textRunName, textRunValue) {
		        var textRun = this.retrieveTextRun(textRunName);
		        if (textRun) {
		            textRun.text = textRunValue;
		        }
		    };
		    // Plays specified animations; if none specified, it unpauses everything.
		    Rive.prototype.play = function (animationNames, autoplay) {
		        var _this = this;
		        animationNames = mapToStringArray(animationNames);
		        // If the file's not loaded, queue up the play
		        if (!this.readyForPlaying) {
		            this.taskQueue.add({
		                action: function () { return _this.play(animationNames, autoplay); },
		            });
		            return;
		        }
		        this.animator.play(animationNames);
		        if (this.eventCleanup) {
		            this.eventCleanup();
		        }
		        this.setupRiveListeners();
		        this.startRendering();
		    };
		    // Pauses specified animations; if none specified, pauses all.
		    Rive.prototype.pause = function (animationNames) {
		        var _this = this;
		        animationNames = mapToStringArray(animationNames);
		        // If the file's not loaded, early out, nothing to pause
		        if (!this.readyForPlaying) {
		            this.taskQueue.add({
		                action: function () { return _this.pause(animationNames); },
		            });
		            return;
		        }
		        if (this.eventCleanup) {
		            this.eventCleanup();
		        }
		        this.animator.pause(animationNames);
		    };
		    Rive.prototype.scrub = function (animationNames, value) {
		        var _this = this;
		        animationNames = mapToStringArray(animationNames);
		        // If the file's not loaded, early out, nothing to pause
		        if (!this.readyForPlaying) {
		            this.taskQueue.add({
		                action: function () { return _this.scrub(animationNames, value); },
		            });
		            return;
		        }
		        // Scrub the animation time; we draw a single frame here so that if
		        // nothing's currently playing, the scrubbed animation is still rendered/
		        this.animator.scrub(animationNames, value || 0);
		        this.drawFrame();
		    };
		    // Stops specified animations; if none specifies, stops them all.
		    Rive.prototype.stop = function (animationNames) {
		        var _this = this;
		        animationNames = mapToStringArray(animationNames);
		        // If the file's not loaded, early out, nothing to pause
		        if (!this.readyForPlaying) {
		            this.taskQueue.add({
		                action: function () { return _this.stop(animationNames); },
		            });
		            return;
		        }
		        // If there is no artboard, this.animator will be undefined
		        if (this.animator) {
		            this.animator.stop(animationNames);
		        }
		        if (this.eventCleanup) {
		            this.eventCleanup();
		        }
		    };
		    /**
		     * Resets the animation
		     * @param artboard the name of the artboard, or default if none given
		     * @param animations the names of animations for playback
		     * @param stateMachines the names of state machines for playback
		     * @param autoplay whether to autoplay when reset, defaults to false
		     *
		     */
		    Rive.prototype.reset = function (params) {
		        var _a, _b;
		        // Get the current artboard, animations, state machines, and playback states
		        var artBoardName = params === null || params === void 0 ? void 0 : params.artboard;
		        var animationNames = mapToStringArray(params === null || params === void 0 ? void 0 : params.animations);
		        var stateMachineNames = mapToStringArray(params === null || params === void 0 ? void 0 : params.stateMachines);
		        var autoplay = (_a = params === null || params === void 0 ? void 0 : params.autoplay) !== null && _a !== void 0 ? _a : false;
		        var autoBind = (_b = params === null || params === void 0 ? void 0 : params.autoBind) !== null && _b !== void 0 ? _b : false;
		        // Stop everything and clean up
		        this.cleanupInstances();
		        // Reinitialize an artboard instance with the state
		        this.initArtboard(artBoardName, animationNames, stateMachineNames, autoplay, autoBind);
		        this.taskQueue.process();
		    };
		    // Loads a new Rive file, keeping listeners in place
		    Rive.prototype.load = function (params) {
		        this.file = null;
		        // Stop all animations
		        this.stop();
		        // Reinitialize
		        this.init(params);
		    };
		    Object.defineProperty(Rive.prototype, "layout", {
		        /**
		         * Returns the current layout. Note that layout should be treated as
		         * immutable. If you want to change the layout, create a new one use the
		         * layout setter
		         */
		        get: function () {
		            return this._layout;
		        },
		        // Sets a new layout
		        set: function (layout) {
		            this._layout = layout;
		            // If the maxX or maxY are 0, then set them to the canvas width and height
		            if (!layout.maxX || !layout.maxY) {
		                this.resizeToCanvas();
		            }
		            if (this.loaded && !this.animator.isPlaying) {
		                this.drawFrame();
		            }
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Sets the layout bounds to the current canvas size; this is typically called
		     * when the canvas is resized
		     */
		    Rive.prototype.resizeToCanvas = function () {
		        this._layout = this.layout.copyWith({
		            minX: 0,
		            minY: 0,
		            maxX: this.canvas.width,
		            maxY: this.canvas.height,
		        });
		    };
		    /**
		     * Accounts for devicePixelRatio as a multiplier to render the size of the canvas drawing surface.
		     * Uses the size of the backing canvas to set new width/height attributes. Need to re-render
		     * and resize the layout to match the new drawing surface afterwards.
		     * Useful function for consumers to include in a window resize listener.
		     *
		     * This method will set the {@link devicePixelRatioUsed} property.
		     *
		     * Optionally, you can provide a {@link customDevicePixelRatio} to provide a
		     * custom value.
		     */
		    Rive.prototype.resizeDrawingSurfaceToCanvas = function (customDevicePixelRatio) {
		        if (this.canvas instanceof HTMLCanvasElement && !!window) {
		            var _a = this.canvas.getBoundingClientRect(), width = _a.width, height = _a.height;
		            var dpr = customDevicePixelRatio || window.devicePixelRatio || 1;
		            this.devicePixelRatioUsed = dpr;
		            this.canvas.width = dpr * width;
		            this.canvas.height = dpr * height;
		            this.resizeToCanvas();
		            this.drawFrame();
		            if (this.layout.fit === Fit.Layout) {
		                var scaleFactor = this._layout.layoutScaleFactor;
		                this.artboard.width = width / scaleFactor;
		                this.artboard.height = height / scaleFactor;
		            }
		        }
		    };
		    Object.defineProperty(Rive.prototype, "source", {
		        // Returns the animation source, which may be undefined
		        get: function () {
		            return this.src;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "activeArtboard", {
		        /**
		         * Returns the name of the active artboard
		         */
		        get: function () {
		            return this.artboard ? this.artboard.name : "";
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "animationNames", {
		        // Returns a list of animation names on the chosen artboard
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded || !this.artboard) {
		                return [];
		            }
		            var animationNames = [];
		            for (var i = 0; i < this.artboard.animationCount(); i++) {
		                animationNames.push(this.artboard.animationByIndex(i).name);
		            }
		            return animationNames;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "stateMachineNames", {
		        /**
		         * Returns a list of state machine names from the current artboard
		         */
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded || !this.artboard) {
		                return [];
		            }
		            var stateMachineNames = [];
		            for (var i = 0; i < this.artboard.stateMachineCount(); i++) {
		                stateMachineNames.push(this.artboard.stateMachineByIndex(i).name);
		            }
		            return stateMachineNames;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Returns the inputs for the specified instanced state machine, or an empty
		     * list if the name is invalid or the state machine is not instanced
		     * @param name the state machine name
		     * @returns the inputs for the named state machine
		     */
		    Rive.prototype.stateMachineInputs = function (name) {
		        // If the file's not loaded, early out, nothing to pause
		        if (!this.loaded) {
		            return;
		        }
		        var stateMachine = this.animator.stateMachines.find(function (m) { return m.name === name; });
		        return stateMachine === null || stateMachine === void 0 ? void 0 : stateMachine.inputs;
		    };
		    // Returns the input with the provided name at the given path
		    Rive.prototype.retrieveInputAtPath = function (name, path) {
		        if (!name) {
		            console.warn("No input name provided for path '".concat(path, "'"));
		            return;
		        }
		        if (!this.artboard) {
		            console.warn("Tried to access input: '".concat(name, "', at path: '").concat(path, "', but the Artboard is null"));
		            return;
		        }
		        var input = this.artboard.inputByPath(name, path);
		        if (!input) {
		            console.warn("Could not access an input with name: '".concat(name, "', at path:'").concat(path, "'"));
		            return;
		        }
		        return input;
		    };
		    /**
		     * Set the boolean input with the provided name at the given path with value
		     * @param input the state machine input name
		     * @param value the value to set the input to
		     * @param path the path the input is located at an artboard level
		     */
		    Rive.prototype.setBooleanStateAtPath = function (inputName, value, path) {
		        var input = this.retrieveInputAtPath(inputName, path);
		        if (!input)
		            return;
		        if (input.type === StateMachineInputType.Boolean) {
		            input.asBool().value = value;
		        }
		        else {
		            console.warn("Input with name: '".concat(inputName, "', at path:'").concat(path, "' is not a boolean"));
		        }
		    };
		    /**
		     * Set the number input with the provided name at the given path with value
		     * @param input the state machine input name
		     * @param value the value to set the input to
		     * @param path the path the input is located at an artboard level
		     */
		    Rive.prototype.setNumberStateAtPath = function (inputName, value, path) {
		        var input = this.retrieveInputAtPath(inputName, path);
		        if (!input)
		            return;
		        if (input.type === StateMachineInputType.Number) {
		            input.asNumber().value = value;
		        }
		        else {
		            console.warn("Input with name: '".concat(inputName, "', at path:'").concat(path, "' is not a number"));
		        }
		    };
		    /**
		     * Fire the trigger with the provided name at the given path
		     * @param input the state machine input name
		     * @param path the path the input is located at an artboard level
		     */
		    Rive.prototype.fireStateAtPath = function (inputName, path) {
		        var input = this.retrieveInputAtPath(inputName, path);
		        if (!input)
		            return;
		        if (input.type === StateMachineInputType.Trigger) {
		            input.asTrigger().fire();
		        }
		        else {
		            console.warn("Input with name: '".concat(inputName, "', at path:'").concat(path, "' is not a trigger"));
		        }
		    };
		    // Returns the TextValueRun object for the provided name at the given path
		    Rive.prototype.retrieveTextAtPath = function (name, path) {
		        if (!name) {
		            console.warn("No text name provided for path '".concat(path, "'"));
		            return;
		        }
		        if (!path) {
		            console.warn("No path provided for text '".concat(name, "'"));
		            return;
		        }
		        if (!this.artboard) {
		            console.warn("Tried to access text: '".concat(name, "', at path: '").concat(path, "', but the Artboard is null"));
		            return;
		        }
		        var text = this.artboard.textByPath(name, path);
		        if (!text) {
		            console.warn("Could not access text with name: '".concat(name, "', at path:'").concat(path, "'"));
		            return;
		        }
		        return text;
		    };
		    /**
		     * Retrieves the text value for a specified text run at a given path
		     * @param textName The name of the text run
		     * @param path The path to the text run within the artboard
		     * @returns The text value of the text run, or undefined if not found
		     *
		     * @example
		     * // Get the text value for a text run named "title" at one nested artboard deep
		     * const titleText = riveInstance.getTextRunValueAtPath("title", "artboard1");
		     *
		     * @example
		     * // Get the text value for a text run named "subtitle" within a nested group two artboards deep
		     * const subtitleText = riveInstance.getTextRunValueAtPath("subtitle", "group/nestedGroup");
		     *
		     * @remarks
		     * If the text run cannot be found at the specified path, a warning will be logged to the console.
		     */
		    Rive.prototype.getTextRunValueAtPath = function (textName, path) {
		        var run = this.retrieveTextAtPath(textName, path);
		        if (!run) {
		            console.warn("Could not get text with name: '".concat(textName, "', at path:'").concat(path, "'"));
		            return;
		        }
		        return run.text;
		    };
		    /**
		     * Sets the text value for a specified text run at a given path
		     * @param textName The name of the text run
		     * @param value The new text value to set
		     * @param path The path to the text run within the artboard
		     * @returns void
		     *
		     * @example
		     * // Set the text value for a text run named "title" at one nested artboard deep
		     * riveInstance.setTextRunValueAtPath("title", "New Title", "artboard1");
		     *
		     * @example
		     * // Set the text value for a text run named "subtitle" within a nested group two artboards deep
		     * riveInstance.setTextRunValueAtPath("subtitle", "New Subtitle", "group/nestedGroup");
		     *
		     * @remarks
		     * If the text run cannot be found at the specified path, a warning will be logged to the console.
		     */
		    Rive.prototype.setTextRunValueAtPath = function (textName, value, path) {
		        var run = this.retrieveTextAtPath(textName, path);
		        if (!run) {
		            console.warn("Could not set text with name: '".concat(textName, "', at path:'").concat(path, "'"));
		            return;
		        }
		        run.text = value;
		    };
		    Object.defineProperty(Rive.prototype, "playingStateMachineNames", {
		        // Returns a list of playing machine names
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded) {
		                return [];
		            }
		            return this.animator.stateMachines
		                .filter(function (m) { return m.playing; })
		                .map(function (m) { return m.name; });
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "playingAnimationNames", {
		        // Returns a list of playing animation names
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded) {
		                return [];
		            }
		            return this.animator.animations.filter(function (a) { return a.playing; }).map(function (a) { return a.name; });
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "pausedAnimationNames", {
		        // Returns a list of paused animation names
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded) {
		                return [];
		            }
		            return this.animator.animations
		                .filter(function (a) { return !a.playing; })
		                .map(function (a) { return a.name; });
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "pausedStateMachineNames", {
		        /**
		         *  Returns a list of paused machine names
		         * @returns a list of state machine names that are paused
		         */
		        get: function () {
		            // If the file's not loaded, we got nothing to return
		            if (!this.loaded) {
		                return [];
		            }
		            return this.animator.stateMachines
		                .filter(function (m) { return !m.playing; })
		                .map(function (m) { return m.name; });
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "isPlaying", {
		        /**
		         * @returns true if any animation is playing
		         */
		        get: function () {
		            return this.animator.isPlaying;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "isPaused", {
		        /**
		         * @returns true if all instanced animations are paused
		         */
		        get: function () {
		            return this.animator.isPaused;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "isStopped", {
		        /**
		         * @returns true if no animations are playing or paused
		         */
		        get: function () {
		            return this.animator.isStopped;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "bounds", {
		        /**
		         * @returns the bounds of the current artboard, or undefined if the artboard
		         * isn't loaded yet.
		         */
		        get: function () {
		            return this.artboard ? this.artboard.bounds : undefined;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Subscribe to Rive-generated events
		     * @param type the type of event to subscribe to
		     * @param callback callback to fire when the event occurs
		     */
		    Rive.prototype.on = function (type, callback) {
		        this.eventManager.add({
		            type: type,
		            callback: callback,
		        });
		    };
		    /**
		     * Unsubscribes from a Rive-generated event
		     * @param type the type of event to unsubscribe from
		     * @param callback the callback to unsubscribe
		     */
		    Rive.prototype.off = function (type, callback) {
		        this.eventManager.remove({
		            type: type,
		            callback: callback,
		        });
		    };
		    /**
		     * Unsubscribes from a Rive-generated event
		     * @deprecated
		     * @param callback the callback to unsubscribe from
		     */
		    Rive.prototype.unsubscribe = function (type, callback) {
		        console.warn("This function is deprecated: please use `off()` instead.");
		        this.off(type, callback);
		    };
		    /**
		     * Unsubscribes all Rive listeners from an event type, or everything if no type is
		     * given
		     * @param type the type of event to unsubscribe from, or all types if
		     * undefined
		     */
		    Rive.prototype.removeAllRiveEventListeners = function (type) {
		        this.eventManager.removeAll(type);
		    };
		    /**
		     * Unsubscribes all listeners from an event type, or everything if no type is
		     * given
		     * @deprecated
		     * @param type the type of event to unsubscribe from, or all types if
		     * undefined
		     */
		    Rive.prototype.unsubscribeAll = function (type) {
		        console.warn("This function is deprecated: please use `removeAllRiveEventListeners()` instead.");
		        this.removeAllRiveEventListeners(type);
		    };
		    /**
		     * Stops the rendering loop; this is different from pausing in that it doesn't
		     * change the state of any animation. It stops rendering from occurring. This
		     * is designed for situations such as when Rive isn't visible.
		     *
		     * The only way to start rendering again is to call `startRendering`.
		     * Animations that are marked as playing will start from the position that
		     * they would have been at if rendering had not been stopped.
		     */
		    Rive.prototype.stopRendering = function () {
		        if (this.loaded && this.frameRequestId) {
		            if (this.runtime.cancelAnimationFrame) {
		                this.runtime.cancelAnimationFrame(this.frameRequestId);
		            }
		            else {
		                cancelAnimationFrame(this.frameRequestId);
		            }
		            this.frameRequestId = null;
		        }
		    };
		    /**
		     * Starts the rendering loop if it has been previously stopped. If the
		     * renderer is already active, then this will have zero effect.
		     */
		    Rive.prototype.startRendering = function () {
		        if (this.loaded && this.artboard && !this.frameRequestId) {
		            if (this.runtime.requestAnimationFrame) {
		                this.frameRequestId = this.runtime.requestAnimationFrame(this._boundDraw);
		            }
		            else {
		                this.frameRequestId = requestAnimationFrame(this._boundDraw);
		            }
		        }
		    };
		    /**
		     * Enables frames-per-second (FPS) reporting for the runtime
		     * If no callback is provided, Rive will append a fixed-position div at the top-right corner of
		     * the page with the FPS reading
		     * @param fpsCallback - Callback from the runtime during the RAF loop that supplies the FPS value
		     */
		    Rive.prototype.enableFPSCounter = function (fpsCallback) {
		        this.runtime.enableFPSCounter(fpsCallback);
		    };
		    /**
		     * Disables frames-per-second (FPS) reporting for the runtime
		     */
		    Rive.prototype.disableFPSCounter = function () {
		        this.runtime.disableFPSCounter();
		    };
		    Object.defineProperty(Rive.prototype, "contents", {
		        /**
		         * Returns the contents of a Rive file: the artboards, animations, and state machines
		         */
		        get: function () {
		            if (!this.loaded) {
		                return undefined;
		            }
		            var riveContents = {
		                artboards: [],
		            };
		            for (var i = 0; i < this.file.artboardCount(); i++) {
		                var artboard = this.file.artboardByIndex(i);
		                var artboardContents = {
		                    name: artboard.name,
		                    animations: [],
		                    stateMachines: [],
		                };
		                for (var j = 0; j < artboard.animationCount(); j++) {
		                    var animation = artboard.animationByIndex(j);
		                    artboardContents.animations.push(animation.name);
		                }
		                for (var k = 0; k < artboard.stateMachineCount(); k++) {
		                    var stateMachine = artboard.stateMachineByIndex(k);
		                    var name_1 = stateMachine.name;
		                    var instance = new this.runtime.StateMachineInstance(stateMachine, artboard);
		                    var inputContents = [];
		                    for (var l = 0; l < instance.inputCount(); l++) {
		                        var input = instance.input(l);
		                        inputContents.push({ name: input.name, type: input.type });
		                    }
		                    artboardContents.stateMachines.push({
		                        name: name_1,
		                        inputs: inputContents,
		                    });
		                }
		                riveContents.artboards.push(artboardContents);
		            }
		            return riveContents;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "volume", {
		        /**
		         * Getter / Setter for the volume of the artboard
		         */
		        get: function () {
		            if (this.artboard && this.artboard.volume !== this._volume) {
		                this._volume = this.artboard.volume;
		            }
		            return this._volume;
		        },
		        set: function (value) {
		            this._volume = value;
		            if (this.artboard) {
		                this.artboard.volume = value * audioManager.systemVolume;
		            }
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "artboardWidth", {
		        /**
		         * The width of the artboard.
		         *
		         * This will return 0 if the artboard is not loaded yet and a custom
		         * width has not been set.
		         *
		         * Do not set this value manually when using {@link resizeDrawingSurfaceToCanvas}
		         * with a {@link Layout.fit} of {@link Fit.Layout}, as the artboard width is
		         * automatically set.
		         */
		        get: function () {
		            var _a;
		            if (this.artboard) {
		                return this.artboard.width;
		            }
		            return (_a = this._artboardWidth) !== null && _a !== void 0 ? _a : 0;
		        },
		        set: function (value) {
		            this._artboardWidth = value;
		            if (this.artboard) {
		                this.artboard.width = value;
		            }
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(Rive.prototype, "artboardHeight", {
		        /**
		         * The height of the artboard.
		         *
		         * This will return 0 if the artboard is not loaded yet and a custom
		         * height has not been set.
		         *
		         * Do not set this value manually when using {@link resizeDrawingSurfaceToCanvas}
		         * with a {@link Layout.fit} of {@link Fit.Layout}, as the artboard height is
		         * automatically set.
		         */
		        get: function () {
		            var _a;
		            if (this.artboard) {
		                return this.artboard.height;
		            }
		            return (_a = this._artboardHeight) !== null && _a !== void 0 ? _a : 0;
		        },
		        set: function (value) {
		            this._artboardHeight = value;
		            if (this.artboard) {
		                this.artboard.height = value;
		            }
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Reset the artboard size to its original values.
		     */
		    Rive.prototype.resetArtboardSize = function () {
		        if (this.artboard) {
		            this.artboard.resetArtboardSize();
		            this._artboardWidth = this.artboard.width;
		            this._artboardHeight = this.artboard.height;
		        }
		        else {
		            // If the artboard isn't loaded, we need to reset the custom width and height
		            this._artboardWidth = undefined;
		            this._artboardHeight = undefined;
		        }
		    };
		    Object.defineProperty(Rive.prototype, "devicePixelRatioUsed", {
		        /**
		         * The device pixel ratio used in rendering and canvas/artboard resizing.
		         *
		         * This value will be overidden by the device pixel ratio used in
		         * {@link resizeDrawingSurfaceToCanvas}. If you use that method, do not set this value.
		         */
		        get: function () {
		            return this._devicePixelRatioUsed;
		        },
		        set: function (value) {
		            this._devicePixelRatioUsed = value;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    /**
		     * Initialize the data context with the view model instance.
		     */
		    Rive.prototype.bindViewModelInstance = function (viewModelInstance) {
		        var _a;
		        if (this.artboard && !this.destroyed) {
		            if (viewModelInstance && viewModelInstance.runtimeInstance) {
		                viewModelInstance.internalIncrementReferenceCount();
		                (_a = this._viewModelInstance) === null || _a === void 0 ? void 0 : _a.cleanup();
		                this._viewModelInstance = viewModelInstance;
		                if (this.animator.stateMachines.length > 0) {
		                    this.animator.stateMachines.forEach(function (stateMachine) {
		                        return stateMachine.bindViewModelInstance(viewModelInstance);
		                    });
		                }
		                else {
		                    this.artboard.bindViewModelInstance(viewModelInstance.runtimeInstance);
		                }
		            }
		        }
		    };
		    Object.defineProperty(Rive.prototype, "viewModelInstance", {
		        get: function () {
		            return this._viewModelInstance;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Rive.prototype.viewModelByIndex = function (index) {
		        var viewModel = this.file.viewModelByIndex(index);
		        if (viewModel !== null) {
		            return new ViewModel(viewModel);
		        }
		        return null;
		    };
		    Rive.prototype.viewModelByName = function (name) {
		        var viewModel = this.file.viewModelByName(name);
		        if (viewModel !== null) {
		            return new ViewModel(viewModel);
		        }
		        return null;
		    };
		    Rive.prototype.enums = function () {
		        if (this._dataEnums === null) {
		            var dataEnums = this.file.enums();
		            this._dataEnums = dataEnums.map(function (dataEnum) {
		                return new DataEnum(dataEnum);
		            });
		        }
		        return this._dataEnums;
		    };
		    Rive.prototype.defaultViewModel = function () {
		        if (this.artboard) {
		            var viewModel = this.file.defaultArtboardViewModel(this.artboard);
		            if (viewModel) {
		                return new ViewModel(viewModel);
		            }
		        }
		        return null;
		    };
		    /**
		     * @deprecated This function is deprecated. For better stability and memory management
		     * use `getBindableArtboard()` instead.
		     * @param {string} name - The name of the artboard.
		     * @returns {Artboard} The artboard to bind to.
		     */
		    Rive.prototype.getArtboard = function (name) {
		        var _a, _b;
		        return (_b = (_a = this.riveFile) === null || _a === void 0 ? void 0 : _a.getArtboard(name)) !== null && _b !== void 0 ? _b : null;
		    };
		    Rive.prototype.getBindableArtboard = function (name) {
		        var _a, _b;
		        return (_b = (_a = this.riveFile) === null || _a === void 0 ? void 0 : _a.getBindableArtboard(name)) !== null && _b !== void 0 ? _b : null;
		    };
		    Rive.prototype.getDefaultBindableArtboard = function () {
		        var _a, _b;
		        return (_b = (_a = this.riveFile) === null || _a === void 0 ? void 0 : _a.getDefaultBindableArtboard()) !== null && _b !== void 0 ? _b : null;
		    };
		    // Error message for missing source or buffer
		    Rive.missingErrorMessage = "Rive source file or data buffer required";
		    // Error message for removed rive file
		    Rive.cleanupErrorMessage = "Attempt to use file after calling cleanup.";
		    return Rive;
		}());

		var ViewModel = /** @class */ (function () {
		    function ViewModel(viewModel) {
		        this._viewModel = viewModel;
		    }
		    Object.defineProperty(ViewModel.prototype, "instanceCount", {
		        get: function () {
		            return this._viewModel.instanceCount;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(ViewModel.prototype, "name", {
		        get: function () {
		            return this._viewModel.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModel.prototype.instanceByIndex = function (index) {
		        var instance = this._viewModel.instanceByIndex(index);
		        if (instance !== null) {
		            var viewModelInstance = new ViewModelInstance(instance, null);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, instance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    ViewModel.prototype.instanceByName = function (name) {
		        var instance = this._viewModel.instanceByName(name);
		        if (instance !== null) {
		            var viewModelInstance = new ViewModelInstance(instance, null);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, instance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    ViewModel.prototype.defaultInstance = function () {
		        var runtimeInstance = this._viewModel.defaultInstance();
		        if (runtimeInstance !== null) {
		            var viewModelInstance = new ViewModelInstance(runtimeInstance, null);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, runtimeInstance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    ViewModel.prototype.instance = function () {
		        var runtimeInstance = this._viewModel.instance();
		        if (runtimeInstance !== null) {
		            var viewModelInstance = new ViewModelInstance(runtimeInstance, null);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, runtimeInstance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    Object.defineProperty(ViewModel.prototype, "properties", {
		        get: function () {
		            return this._viewModel.getProperties();
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(ViewModel.prototype, "instanceNames", {
		        get: function () {
		            return this._viewModel.getInstanceNames();
		        },
		        enumerable: false,
		        configurable: true
		    });
		    return ViewModel;
		}());

		var DataEnum = /** @class */ (function () {
		    function DataEnum(dataEnum) {
		        this._dataEnum = dataEnum;
		    }
		    Object.defineProperty(DataEnum.prototype, "name", {
		        get: function () {
		            return this._dataEnum.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(DataEnum.prototype, "values", {
		        get: function () {
		            return this._dataEnum.values;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    return DataEnum;
		}());

		var PropertyType;
		(function (PropertyType) {
		    PropertyType["Number"] = "number";
		    PropertyType["String"] = "string";
		    PropertyType["Boolean"] = "boolean";
		    PropertyType["Color"] = "color";
		    PropertyType["Trigger"] = "trigger";
		    PropertyType["Enum"] = "enum";
		    PropertyType["List"] = "list";
		    PropertyType["Image"] = "image";
		    PropertyType["Artboard"] = "artboard";
		})(PropertyType || (PropertyType = {}));
		var ViewModelInstance = /** @class */ (function () {
		    function ViewModelInstance(runtimeInstance, parent) {
		        this._parents = [];
		        this._children = [];
		        this._viewModelInstances = new Map();
		        this._propertiesWithCallbacks = [];
		        this._referenceCount = 0;
		        this.selfUnref = false;
		        this._runtimeInstance = runtimeInstance;
		        if (parent !== null) {
		            this._parents.push(parent);
		        }
		    }
		    Object.defineProperty(ViewModelInstance.prototype, "runtimeInstance", {
		        get: function () {
		            return this._runtimeInstance;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(ViewModelInstance.prototype, "nativeInstance", {
		        get: function () {
		            return this._runtimeInstance;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstance.prototype.handleCallbacks = function () {
		        if (this._propertiesWithCallbacks.length !== 0) {
		            this._propertiesWithCallbacks.forEach(function (property) {
		                property.handleCallbacks();
		            });
		            this._propertiesWithCallbacks.forEach(function (property) {
		                property.clearChanges();
		            });
		        }
		        this._children.forEach(function (child) { return child.handleCallbacks(); });
		    };
		    ViewModelInstance.prototype.addParent = function (parent) {
		        if (!this._parents.includes(parent)) {
		            this._parents.push(parent);
		            if (this._propertiesWithCallbacks.length > 0 ||
		                this._children.length > 0) {
		                parent.addToViewModelCallbacks(this);
		            }
		        }
		    };
		    ViewModelInstance.prototype.removeParent = function (parent) {
		        var index = this._parents.indexOf(parent);
		        if (index !== -1) {
		            var parent_1 = this._parents[index];
		            parent_1.removeFromViewModelCallbacks(this);
		            this._parents.splice(index, 1);
		        }
		    };
		    /*
		     * method for internal use, it shouldn't be called externally
		     */
		    ViewModelInstance.prototype.addToPropertyCallbacks = function (property) {
		        var _this = this;
		        if (!this._propertiesWithCallbacks.includes(property)) {
		            this._propertiesWithCallbacks.push(property);
		            if (this._propertiesWithCallbacks.length > 0) {
		                this._parents.forEach(function (parent) {
		                    parent.addToViewModelCallbacks(_this);
		                });
		            }
		        }
		    };
		    /*
		     * method for internal use, it shouldn't be called externally
		     */
		    ViewModelInstance.prototype.removeFromPropertyCallbacks = function (property) {
		        var _this = this;
		        if (this._propertiesWithCallbacks.includes(property)) {
		            this._propertiesWithCallbacks = this._propertiesWithCallbacks.filter(function (prop) { return prop !== property; });
		            if (this._children.length === 0 &&
		                this._propertiesWithCallbacks.length === 0) {
		                this._parents.forEach(function (parent) {
		                    parent.removeFromViewModelCallbacks(_this);
		                });
		            }
		        }
		    };
		    /*
		     * method for internal use, it shouldn't be called externally
		     */
		    ViewModelInstance.prototype.addToViewModelCallbacks = function (instance) {
		        var _this = this;
		        if (!this._children.includes(instance)) {
		            this._children.push(instance);
		            this._parents.forEach(function (parent) {
		                parent.addToViewModelCallbacks(_this);
		            });
		        }
		    };
		    /*
		     * method for internal use, it shouldn't be called externally
		     */
		    ViewModelInstance.prototype.removeFromViewModelCallbacks = function (instance) {
		        var _this = this;
		        if (this._children.includes(instance)) {
		            this._children = this._children.filter(function (child) { return child !== instance; });
		            if (this._children.length === 0 &&
		                this._propertiesWithCallbacks.length === 0) {
		                this._parents.forEach(function (parent) {
		                    parent.removeFromViewModelCallbacks(_this);
		                });
		            }
		        }
		    };
		    ViewModelInstance.prototype.clearCallbacks = function () {
		        this._propertiesWithCallbacks.forEach(function (property) {
		            property.clearCallbacks();
		        });
		    };
		    ViewModelInstance.prototype.propertyFromPath = function (path, type) {
		        var pathSegments = path.split("/");
		        return this.propertyFromPathSegments(pathSegments, 0, type);
		    };
		    ViewModelInstance.prototype.viewModelFromPathSegments = function (pathSegments, index) {
		        var viewModelInstance = this.internalViewModelInstance(pathSegments[index]);
		        if (viewModelInstance !== null) {
		            if (index == pathSegments.length - 1) {
		                return viewModelInstance;
		            }
		            else {
		                return viewModelInstance.viewModelFromPathSegments(pathSegments, index++);
		            }
		        }
		        return null;
		    };
		    ViewModelInstance.prototype.propertyFromPathSegments = function (pathSegments, index, type) {
		        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;
		        if (index < pathSegments.length - 1) {
		            var viewModelInstance = this.internalViewModelInstance(pathSegments[index]);
		            if (viewModelInstance !== null) {
		                return viewModelInstance.propertyFromPathSegments(pathSegments, index + 1, type);
		            }
		            else {
		                return null;
		            }
		        }
		        var instance = null;
		        switch (type) {
		            case PropertyType.Number:
		                instance = (_b = (_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.number(pathSegments[index])) !== null && _b !== void 0 ? _b : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceNumber(instance, this);
		                }
		                break;
		            case PropertyType.String:
		                instance = (_d = (_c = this._runtimeInstance) === null || _c === void 0 ? void 0 : _c.string(pathSegments[index])) !== null && _d !== void 0 ? _d : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceString(instance, this);
		                }
		                break;
		            case PropertyType.Boolean:
		                instance = (_f = (_e = this._runtimeInstance) === null || _e === void 0 ? void 0 : _e.boolean(pathSegments[index])) !== null && _f !== void 0 ? _f : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceBoolean(instance, this);
		                }
		                break;
		            case PropertyType.Color:
		                instance = (_h = (_g = this._runtimeInstance) === null || _g === void 0 ? void 0 : _g.color(pathSegments[index])) !== null && _h !== void 0 ? _h : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceColor(instance, this);
		                }
		                break;
		            case PropertyType.Trigger:
		                instance = (_k = (_j = this._runtimeInstance) === null || _j === void 0 ? void 0 : _j.trigger(pathSegments[index])) !== null && _k !== void 0 ? _k : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceTrigger(instance, this);
		                }
		                break;
		            case PropertyType.Enum:
		                instance = (_m = (_l = this._runtimeInstance) === null || _l === void 0 ? void 0 : _l.enum(pathSegments[index])) !== null && _m !== void 0 ? _m : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceEnum(instance, this);
		                }
		                break;
		            case PropertyType.List:
		                instance = (_p = (_o = this._runtimeInstance) === null || _o === void 0 ? void 0 : _o.list(pathSegments[index])) !== null && _p !== void 0 ? _p : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceList(instance, this);
		                }
		                break;
		            case PropertyType.Image:
		                instance = (_r = (_q = this._runtimeInstance) === null || _q === void 0 ? void 0 : _q.image(pathSegments[index])) !== null && _r !== void 0 ? _r : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceAssetImage(instance, this);
		                }
		                break;
		            case PropertyType.Artboard:
		                instance = (_t = (_s = this._runtimeInstance) === null || _s === void 0 ? void 0 : _s.artboard(pathSegments[index])) !== null && _t !== void 0 ? _t : null;
		                if (instance !== null) {
		                    return new ViewModelInstanceArtboard(instance, this);
		                }
		                break;
		        }
		        return null;
		    };
		    ViewModelInstance.prototype.internalViewModelInstance = function (name) {
		        var _a;
		        if (this._viewModelInstances.has(name)) {
		            return this._viewModelInstances.get(name);
		        }
		        var viewModelRuntimeInstance = (_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.viewModel(name);
		        if (viewModelRuntimeInstance !== null) {
		            var viewModelInstance = new ViewModelInstance(viewModelRuntimeInstance, this);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, viewModelRuntimeInstance);
		            viewModelInstance.internalIncrementReferenceCount();
		            this._viewModelInstances.set(name, viewModelInstance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    /**
		     * method to access a property instance of type number belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the number property
		     */
		    ViewModelInstance.prototype.number = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Number);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type string belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the string property
		     */
		    ViewModelInstance.prototype.string = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.String);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type boolean belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the boolean property
		     */
		    ViewModelInstance.prototype.boolean = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Boolean);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type color belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the ttrigger property
		     */
		    ViewModelInstance.prototype.color = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Color);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type trigger belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the trigger property
		     */
		    ViewModelInstance.prototype.trigger = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Trigger);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type enum belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the enum property
		     */
		    ViewModelInstance.prototype.enum = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Enum);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a property instance of type list belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the list property
		     */
		    ViewModelInstance.prototype.list = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.List);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a view model property instance belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the image property
		     */
		    ViewModelInstance.prototype.image = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Image);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access an artboard property instance belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the image property
		     */
		    ViewModelInstance.prototype.artboard = function (path) {
		        var viewmodelInstanceValue = this.propertyFromPath(path, PropertyType.Artboard);
		        return viewmodelInstanceValue;
		    };
		    /**
		     * method to access a view model property instance belonging
		     * to the view model instance or to a nested view model instance
		     * @param path - path to the view model property
		     */
		    ViewModelInstance.prototype.viewModel = function (path) {
		        var pathSegments = path.split("/");
		        var parentViewModelInstance = pathSegments.length > 1
		            ? this.viewModelFromPathSegments(pathSegments.slice(0, pathSegments.length - 1), 0)
		            : this;
		        if (parentViewModelInstance != null) {
		            return parentViewModelInstance.internalViewModelInstance(pathSegments[pathSegments.length - 1]);
		        }
		        return null;
		    };
		    ViewModelInstance.prototype.internalReplaceViewModel = function (name, value) {
		        var _a;
		        if (value.runtimeInstance !== null) {
		            var result = ((_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.replaceViewModel(name, value.runtimeInstance)) ||
		                false;
		            if (result) {
		                value.internalIncrementReferenceCount();
		                var oldInstance_1 = this.internalViewModelInstance(name);
		                if (oldInstance_1 !== null) {
		                    oldInstance_1.removeParent(this);
		                    if (this._children.includes(oldInstance_1)) {
		                        this._children = this._children.filter(function (child) { return child !== oldInstance_1; });
		                    }
		                    oldInstance_1.cleanup();
		                }
		                this._viewModelInstances.set(name, value);
		                value.addParent(this);
		            }
		            return result;
		        }
		        return false;
		    };
		    /**
		     * method to replace a view model property with another view model value
		     * @param path - path to the view model property
		     * @param value - view model that will replace the original
		     */
		    ViewModelInstance.prototype.replaceViewModel = function (path, value) {
		        var _a;
		        var pathSegments = path.split("/");
		        var viewModelInstance = pathSegments.length > 1
		            ? this.viewModelFromPathSegments(pathSegments.slice(0, pathSegments.length - 1), 0)
		            : this;
		        return ((_a = viewModelInstance === null || viewModelInstance === void 0 ? void 0 : viewModelInstance.internalReplaceViewModel(pathSegments[pathSegments.length - 1], value)) !== null && _a !== void 0 ? _a : false);
		    };
		    /*
		     * method to add one to the reference counter of the instance.
		     * Use if the file owning the reference is destroyed but the instance needs to stay around
		     */
		    ViewModelInstance.prototype.incrementReferenceCount = function () {
		        var _a;
		        this._referenceCount++;
		        (_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.incrementReferenceCount();
		    };
		    /*
		     * method to subtract one to the reference counter of the instance.
		     * Use if incrementReferenceCount has been called
		     */
		    ViewModelInstance.prototype.decrementReferenceCount = function () {
		        var _a;
		        this._referenceCount--;
		        (_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.decrementReferenceCount();
		    };
		    Object.defineProperty(ViewModelInstance.prototype, "properties", {
		        get: function () {
		            var _a;
		            return (((_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.getProperties().map(function (prop) { return (__assign({}, prop)); })) || []);
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstance.prototype.internalIncrementReferenceCount = function () {
		        this._referenceCount++;
		    };
		    ViewModelInstance.prototype.cleanup = function () {
		        var _this = this;
		        var _a;
		        this._referenceCount--;
		        if (this._referenceCount <= 0) {
		            if (this.selfUnref) {
		                (_a = this._runtimeInstance) === null || _a === void 0 ? void 0 : _a.unref();
		            }
		            this._runtimeInstance = null;
		            this.clearCallbacks();
		            this._propertiesWithCallbacks = [];
		            this._viewModelInstances.forEach(function (value) {
		                value.cleanup();
		            });
		            this._viewModelInstances.clear();
		            var children = __spreadArray([], this._children, true);
		            this._children.length = 0;
		            var parents = __spreadArray([], this._parents, true);
		            this._parents.length = 0;
		            children.forEach(function (child) {
		                child.removeParent(_this);
		            });
		            parents.forEach(function (parent) {
		                parent.removeFromViewModelCallbacks(_this);
		            });
		        }
		    };
		    return ViewModelInstance;
		}());

		var ViewModelInstanceValue = /** @class */ (function () {
		    function ViewModelInstanceValue(instance, parent) {
		        this.callbacks = [];
		        this._viewModelInstanceValue = instance;
		        this._parentViewModel = parent;
		    }
		    ViewModelInstanceValue.prototype.on = function (callback) {
		        // Since we don't clean the changed flag for properties that don't have listeners,
		        // we clean it the first time we add a listener to it
		        if (this.callbacks.length === 0) {
		            this._viewModelInstanceValue.clearChanges();
		        }
		        if (!this.callbacks.includes(callback)) {
		            this.callbacks.push(callback);
		            this._parentViewModel.addToPropertyCallbacks(this);
		        }
		    };
		    ViewModelInstanceValue.prototype.off = function (callback) {
		        if (!callback) {
		            this.callbacks.length = 0;
		        }
		        else {
		            this.callbacks = this.callbacks.filter(function (cb) { return cb !== callback; });
		        }
		        if (this.callbacks.length === 0) {
		            this._parentViewModel.removeFromPropertyCallbacks(this);
		        }
		    };
		    ViewModelInstanceValue.prototype.internalHandleCallback = function (callback) { };
		    ViewModelInstanceValue.prototype.handleCallbacks = function () {
		        var _this = this;
		        if (this._viewModelInstanceValue.hasChanged) {
		            this.callbacks.forEach(function (callback) {
		                _this.internalHandleCallback(callback);
		            });
		        }
		    };
		    ViewModelInstanceValue.prototype.clearChanges = function () {
		        this._viewModelInstanceValue.clearChanges();
		    };
		    ViewModelInstanceValue.prototype.clearCallbacks = function () {
		        this.callbacks.length = 0;
		    };
		    Object.defineProperty(ViewModelInstanceValue.prototype, "name", {
		        get: function () {
		            return this._viewModelInstanceValue.name;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    return ViewModelInstanceValue;
		}());

		var ViewModelInstanceString = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceString, _super);
		    function ViewModelInstanceString(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceString.prototype, "value", {
		        get: function () {
		            return this._viewModelInstanceValue.value;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.value = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceString.prototype.internalHandleCallback = function (callback) {
		        callback(this.value);
		    };
		    return ViewModelInstanceString;
		}(ViewModelInstanceValue));

		var ViewModelInstanceNumber = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceNumber, _super);
		    function ViewModelInstanceNumber(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceNumber.prototype, "value", {
		        get: function () {
		            return this._viewModelInstanceValue.value;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.value = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceNumber.prototype.internalHandleCallback = function (callback) {
		        callback(this.value);
		    };
		    return ViewModelInstanceNumber;
		}(ViewModelInstanceValue));

		var ViewModelInstanceBoolean = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceBoolean, _super);
		    function ViewModelInstanceBoolean(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceBoolean.prototype, "value", {
		        get: function () {
		            return this._viewModelInstanceValue.value;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.value = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceBoolean.prototype.internalHandleCallback = function (callback) {
		        callback(this.value);
		    };
		    return ViewModelInstanceBoolean;
		}(ViewModelInstanceValue));

		var ViewModelInstanceTrigger = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceTrigger, _super);
		    function ViewModelInstanceTrigger(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    ViewModelInstanceTrigger.prototype.trigger = function () {
		        return this._viewModelInstanceValue.trigger();
		    };
		    ViewModelInstanceTrigger.prototype.internalHandleCallback = function (callback) {
		        callback();
		    };
		    return ViewModelInstanceTrigger;
		}(ViewModelInstanceValue));

		var ViewModelInstanceEnum = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceEnum, _super);
		    function ViewModelInstanceEnum(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceEnum.prototype, "value", {
		        get: function () {
		            return this._viewModelInstanceValue.value;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.value = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(ViewModelInstanceEnum.prototype, "valueIndex", {
		        get: function () {
		            return this._viewModelInstanceValue
		                .valueIndex;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.valueIndex = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    Object.defineProperty(ViewModelInstanceEnum.prototype, "values", {
		        get: function () {
		            return this._viewModelInstanceValue.values;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceEnum.prototype.internalHandleCallback = function (callback) {
		        callback(this.value);
		    };
		    return ViewModelInstanceEnum;
		}(ViewModelInstanceValue));

		var ViewModelInstanceList = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceList, _super);
		    function ViewModelInstanceList(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceList.prototype, "length", {
		        get: function () {
		            return this._viewModelInstanceValue.size;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceList.prototype.addInstance = function (instance) {
		        if (instance.runtimeInstance != null) {
		            this._viewModelInstanceValue.addInstance(instance.runtimeInstance);
		            instance.addParent(this._parentViewModel);
		        }
		    };
		    ViewModelInstanceList.prototype.addInstanceAt = function (instance, index) {
		        if (instance.runtimeInstance != null) {
		            if (this._viewModelInstanceValue.addInstanceAt(instance.runtimeInstance, index)) {
		                instance.addParent(this._parentViewModel);
		                return true;
		            }
		        }
		        return false;
		    };
		    ViewModelInstanceList.prototype.removeInstance = function (instance) {
		        if (instance.runtimeInstance != null) {
		            this._viewModelInstanceValue.removeInstance(instance.runtimeInstance);
		            instance.removeParent(this._parentViewModel);
		        }
		    };
		    ViewModelInstanceList.prototype.removeInstanceAt = function (index) {
		        this._viewModelInstanceValue.removeInstanceAt(index);
		    };
		    ViewModelInstanceList.prototype.instanceAt = function (index) {
		        var runtimeInstance = this._viewModelInstanceValue.instanceAt(index);
		        if (runtimeInstance != null) {
		            var viewModelInstance = new ViewModelInstance(runtimeInstance, this._parentViewModel);
		            (0, _utils__WEBPACK_IMPORTED_MODULE_3__.createFinalization)(viewModelInstance, runtimeInstance);
		            return viewModelInstance;
		        }
		        return null;
		    };
		    ViewModelInstanceList.prototype.swap = function (a, b) {
		        this._viewModelInstanceValue.swap(a, b);
		    };
		    ViewModelInstanceList.prototype.internalHandleCallback = function (callback) {
		        callback();
		    };
		    return ViewModelInstanceList;
		}(ViewModelInstanceValue));

		var ViewModelInstanceColor = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceColor, _super);
		    function ViewModelInstanceColor(instance, parent) {
		        return _super.call(this, instance, parent) || this;
		    }
		    Object.defineProperty(ViewModelInstanceColor.prototype, "value", {
		        get: function () {
		            return this._viewModelInstanceValue.value;
		        },
		        set: function (val) {
		            this._viewModelInstanceValue.value = val;
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceColor.prototype.rgb = function (r, g, b) {
		        this._viewModelInstanceValue.rgb(r, g, b);
		    };
		    ViewModelInstanceColor.prototype.rgba = function (r, g, b, a) {
		        this._viewModelInstanceValue.argb(a, r, g, b);
		    };
		    ViewModelInstanceColor.prototype.argb = function (a, r, g, b) {
		        this._viewModelInstanceValue.argb(a, r, g, b);
		    };
		    // Value 0 to 255
		    ViewModelInstanceColor.prototype.alpha = function (a) {
		        this._viewModelInstanceValue.alpha(a);
		    };
		    // Value 0 to 1
		    ViewModelInstanceColor.prototype.opacity = function (o) {
		        this._viewModelInstanceValue.alpha(Math.round(Math.max(0, Math.min(1, o)) * 255));
		    };
		    ViewModelInstanceColor.prototype.internalHandleCallback = function (callback) {
		        callback(this.value);
		    };
		    return ViewModelInstanceColor;
		}(ViewModelInstanceValue));

		var ViewModelInstanceAssetImage = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceAssetImage, _super);
		    function ViewModelInstanceAssetImage(instance, root) {
		        return _super.call(this, instance, root) || this;
		    }
		    Object.defineProperty(ViewModelInstanceAssetImage.prototype, "value", {
		        set: function (image) {
		            var _a;
		            this._viewModelInstanceValue.value((_a = image === null || image === void 0 ? void 0 : image.nativeImage) !== null && _a !== void 0 ? _a : null);
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceAssetImage.prototype.internalHandleCallback = function (callback) {
		        callback();
		    };
		    return ViewModelInstanceAssetImage;
		}(ViewModelInstanceValue));

		var ViewModelInstanceArtboard = /** @class */ (function (_super) {
		    __extends(ViewModelInstanceArtboard, _super);
		    function ViewModelInstanceArtboard(instance, root) {
		        return _super.call(this, instance, root) || this;
		    }
		    Object.defineProperty(ViewModelInstanceArtboard.prototype, "value", {
		        set: function (artboard) {
		            var _a;
		            var bindableArtboard;
		            if (artboard.isBindableArtboard) {
		                bindableArtboard = artboard;
		            }
		            else {
		                bindableArtboard = artboard.file.internalBindableArtboardFromArtboard(artboard.nativeArtboard);
		            }
		            this._viewModelInstanceValue.value((_a = bindableArtboard === null || bindableArtboard === void 0 ? void 0 : bindableArtboard.nativeArtboard) !== null && _a !== void 0 ? _a : null);
		        },
		        enumerable: false,
		        configurable: true
		    });
		    ViewModelInstanceArtboard.prototype.internalHandleCallback = function (callback) {
		        callback();
		    };
		    return ViewModelInstanceArtboard;
		}(ViewModelInstanceValue));

		// Loads Rive data from a URI via fetch.
		var loadRiveFile = function (src) { return __awaiter(void 0, void 0, void 0, function () {
		    var req, res, buffer;
		    return __generator(this, function (_a) {
		        switch (_a.label) {
		            case 0:
		                req = new Request(src);
		                return [4 /*yield*/, fetch(req)];
		            case 1:
		                res = _a.sent();
		                return [4 /*yield*/, res.arrayBuffer()];
		            case 2:
		                buffer = _a.sent();
		                return [2 /*return*/, buffer];
		        }
		    });
		}); };
		// #endregion
		// #region utility functions
		/*
		 * Utility function to ensure an object is a string array
		 */
		var mapToStringArray = function (obj) {
		    if (typeof obj === "string") {
		        return [obj];
		    }
		    else if (obj instanceof Array) {
		        return obj;
		    }
		    // If obj is undefined, return empty array
		    return [];
		};
		// #endregion
		// #region testing utilities
		// Exports to only be used for tests
		var Testing = {
		    EventManager: EventManager,
		    TaskQueueManager: TaskQueueManager,
		};
		// #endregion
		// #region asset loaders
		/**
		 * Decodes bytes into an audio asset.
		 *
		 * Be sure to call `.unref()` on the audio once it is no longer needed. This
		 * allows the engine to clean it up when it is not used by any more animations.
		 */
		var decodeAudio = function (bytes) { return __awaiter(void 0, void 0, void 0, function () {
		    var decodedPromise, audio, audioWrapper;
		    return __generator(this, function (_a) {
		        switch (_a.label) {
		            case 0:
		                decodedPromise = new Promise(function (resolve) {
		                    return RuntimeLoader.getInstance(function (rive) {
		                        rive.decodeAudio(bytes, resolve);
		                    });
		                });
		                return [4 /*yield*/, decodedPromise];
		            case 1:
		                audio = _a.sent();
		                audioWrapper = new _utils__WEBPACK_IMPORTED_MODULE_3__.AudioWrapper(audio);
		                _utils__WEBPACK_IMPORTED_MODULE_3__.finalizationRegistry.register(audioWrapper, audio);
		                return [2 /*return*/, audioWrapper];
		        }
		    });
		}); };
		/**
		 * Decodes bytes into an image.
		 *
		 * Be sure to call `.unref()` on the image once it is no longer needed. This
		 * allows the engine to clean it up when it is not used by any more animations.
		 */
		var decodeImage = function (bytes) { return __awaiter(void 0, void 0, void 0, function () {
		    var decodedPromise, image, imageWrapper;
		    return __generator(this, function (_a) {
		        switch (_a.label) {
		            case 0:
		                decodedPromise = new Promise(function (resolve) {
		                    return RuntimeLoader.getInstance(function (rive) {
		                        rive.decodeImage(bytes, resolve);
		                    });
		                });
		                return [4 /*yield*/, decodedPromise];
		            case 1:
		                image = _a.sent();
		                imageWrapper = new _utils__WEBPACK_IMPORTED_MODULE_3__.ImageWrapper(image);
		                _utils__WEBPACK_IMPORTED_MODULE_3__.finalizationRegistry.register(imageWrapper, image);
		                return [2 /*return*/, imageWrapper];
		        }
		    });
		}); };
		/**
		 * Decodes bytes into a font.
		 *
		 * Be sure to call `.unref()` on the font once it is no longer needed. This
		 * allows the engine to clean it up when it is not used by any more animations.
		 */
		var decodeFont = function (bytes) { return __awaiter(void 0, void 0, void 0, function () {
		    var decodedPromise, font, fontWrapper;
		    return __generator(this, function (_a) {
		        switch (_a.label) {
		            case 0:
		                decodedPromise = new Promise(function (resolve) {
		                    return RuntimeLoader.getInstance(function (rive) {
		                        rive.decodeFont(bytes, resolve);
		                    });
		                });
		                return [4 /*yield*/, decodedPromise];
		            case 1:
		                font = _a.sent();
		                fontWrapper = new _utils__WEBPACK_IMPORTED_MODULE_3__.FontWrapper(font);
		                _utils__WEBPACK_IMPORTED_MODULE_3__.finalizationRegistry.register(fontWrapper, font);
		                return [2 /*return*/, fontWrapper];
		        }
		    });
		}); };
		// #endregion

		})();

		/******/ 	return __webpack_exports__;
		/******/ })()
		;
		});
		
	} (rive$1));
	return rive$1.exports;
}

var riveExports = requireRive();

const lidoAvatarCss = () => `.lido-canvas{height:100%;width:100%}`;

const LidoAvatar = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * The unique identifier for the column component.
         */
        this.id = '';
        /**
         * The value associated with the column component. Typically used for internal logic.
         */
        this.value = '';
        /**
         * The height of the column component (CSS value, e.g., '100px', '50%').
         */
        this.height = '';
        /**
         * The width of the column component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * The x-coordinate (left position) of the column within its container (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * The y-coordinate (top position) of the column within its container (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * The z-index of the column to control stacking order.
         */
        this.z = '0';
        /**
         * The background color of the column (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * Defines the type of the column, which can be used for styling or specific logic handling.
         */
        this.type = '';
        /**
         * The tab index value, used to set the tab order of the column for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * A boolean that controls whether the column is visible (`true`) or hidden (`false`).
         */
        this.visible = false;
        /**
         * Audio file URL or identifier for sound that will be associated with the column.
         */
        this.audio = '';
        /**
         * Source URL of the Rive (.riv) file
         */
        this.src = '';
        /**
         * Event handler for a touch event, where a custom function can be triggered when the column is touched.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler for when the column is entered, which can be used to initiate specific behaviors on entry.
         */
        this.onEntry = '';
        /**
          * Delay in milliseconds to make the cell visible after mount.
          */
        this.delayVisible = '';
        /**
         * Initializes the Rive animation instance after the component is rendered.
         * It selects the canvas element, loads the Rive file, and starts the animation.
         * The animation surface is resized to fit the canvas, and the instance is stored in the service.
         */
        this.initializeRive = rivSrc => {
            const riveService = RiveService.getInstance();
            const canvas = this.el.querySelector('canvas');
            this.riveInstance = new riveExports.Rive({
                src: rivSrc,
                canvas: canvas,
                stateMachines: 'State Machine 1',
                autoplay: true,
                onLoad: () => {
                    // Some avatars expose an idle animation instead of the expected state machine.
                    if (!this.riveInstance.stateMachineNames.includes('State Machine 1')) {
                        const idleAnimation = this.riveInstance.animationNames.find(name => name.toLowerCase() === 'idle');
                        if (idleAnimation) {
                            this.riveInstance.play(idleAnimation);
                        }
                    }
                    this.riveInstance.resizeDrawingSurfaceToCanvas();
                    riveService.setRiveInstance(this.riveInstance);
                },
            });
        };
    }
    /**
     * This lifecycle hook is called after the component is rendered in the DOM.
     * It initializes events for the column based on the provided type.
     */
    async componentDidLoad() {
        riveExports.RuntimeLoader.setWasmUrl(LidoAvatar.RIVE_WASM_URL);
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        // const resolvedPath = this.src.startsWith('http')
        //   ? this.src // Use the provided URL if it's an HTTP/HTTPS link
        //   : getAssetPath(this.src); // Otherwise, resolve it as an asset path
        this.initializeRive(convertUrlToRelative(this.src));
    }
    render() {
        // Inline styles applied to the column, mainly for positioning and background.
        const style = {
            height: this.height,
            width: this.width,
            backgroundColor: this.bgColor,
            top: this.y,
            left: this.x,
            display: this.visible ? 'flex' : 'none',
            zIndex: this.z,
        };
        return (h(Host, { key: 'ee5d3168685321a1af3dd11ef63ff41aec102416', id: this.id, type: this.type, "tab-index": this.tabIndex, value: this.value, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, src: this.src }, h("canvas", { key: '61edcf1e26ee3c6beaa35852b493b11d697aad9b', class: "lido-canvas" })));
    }
    static get assetsDirs() { return ["."]; }
    get el() { return getElement(this); }
};
LidoAvatar.RIVE_WASM_URL = 'https://unpkg.com/@rive-app/canvas@2.32.0/rive.wasm';
LidoAvatar.style = lidoAvatarCss();

const lidoBalanceCss = () => `#lido-balance{position:relative;height:500px;width:1205px;top:20%;left:-91px;z-index:0}.lido-balance-symbol{position:absolute;top:64%;left:50%;transform:translate(-50%, -50%);font-size:5vw;font-weight:bold;color:black;pointer-events:none;z-index:999}@media (orientation: portrait){.lido-balance-shadow{height:100px;position:absolute;top:80%;left:28%}}.balance-plate-feedback{position:absolute;top:52%;width:34%;height:12px;border-radius:0 0 8px 8px;opacity:0.95;box-shadow:0 9px 10px -2px rgba(70, 0, 0, 0.6);pointer-events:none;z-index:95}.balance-plate-feedback[aria-hidden='true']{display:none}.balance-plate-feedback.left{left:2.5%}.balance-plate-feedback.right{right:2.5%}.balance-plate-feedback::after{content:'';position:absolute;top:100%;left:4%;width:92%;height:11px;border-radius:0 0 8px 8px;background:inherit;opacity:0.75;filter:blur(5px);pointer-events:none}@media (orientation: landscape){.lido-balance-shadow{height:100px;position:absolute;top:90%;left:33%}}@media (orientation: portrait){#pivotimg{position:absolute;height:auto;width:23%;bottom:18%;left:38%;z-index:100}}#pivotimg::after{content:"";position:absolute;bottom:-30px;left:50%;transform:translateX(-50%);width:120%;height:60px;background-image:var(--lido-balance-shadow-url);background-size:contain;background-repeat:no-repeat;background-position:center;pointer-events:none;z-index:10}@media (orientation: landscape){#pivotimg{position:absolute;height:auto;width:23%;bottom:8%;left:38%;z-index:100}}.lido-balance .pivot svg{width:100%;height:auto}#scaleimg{position:absolute;width:73%;height:auto;top:61%;left:14%;z-index:90}.lido-balance .scale svg{width:100%;height:auto}@media (orientation: landscape){#handlerimg{position:absolute;width:35%;height:auto;top:49%;left:2%}}@media (orientation:portrait ){#handlerimg{position:absolute;width:35%;height:auto;top:53%;left:2%}}.lido-balance .handler svg{width:100%;height:auto;fill:brown}@media (orientation: landscape){#handimg{position:absolute;width:35%;height:auto;top:49%;right:2%}}@media (orientation:portrait){#handimg{position:absolute;width:35%;height:auto;top:53%;right:2%}}.lido-balance .hand svg{width:100%;height:auto;fill:brown}.pivot svg path:nth-of-type(1){fill:brown}.pivot svg path[d^="M78.9414"]{fill:white}`;

const LidoBalance = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * URL of the pivot (base stand) image used in the balance visualization.
         */
        this.pivotimage = '';
        /**
         * URL of the scale (bar) image that tilts based on the weight difference.
         */
        this.scaleimage = '';
        /**
         * URL of the handler (side stands / hooks) image for the balance.
         */
        this.handlerimage = '';
        /**
         * Fill color applied to all loaded SVGs (pivot, scale, handler).
         * Defaults to "brown".
         */
        this.fill = 'brown';
        /**
         * Initial tilt value of the balance.
         * Negative = tilts left, Positive = tilts right.
         */
        this.tilt = 0;
        /**
         * Maximum allowed tilt angle (in degrees) for the balance bar.
         */
        this.maxTilt = 9.5;
        /**
         * Action(s) to execute when the component enters the DOM.
         * Example: trigger animations or audio cues.
         */
        this.onEntry = '';
        /**
         * CSS height of the component (responsive values allowed).
         * Default: "auto".
         */
        this.height = 'auto';
        /**
         * CSS width of the component (responsive values allowed).
         * Default: "auto".
         */
        this.width = 'auto';
        /**
         * Horizontal (X-axis) offset for positioning the component.
         * Default: "0px".
         */
        this.x = '0px';
        /**
         * Vertical (Y-axis) offset for positioning the component.
         * Default: "0px".
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the component.
         * Default: "0".
         */
        this.z = '0';
        /**
         * Controls component visibility.
         * Accepts boolean (`true`/`false`) or string ("true"/"false").
         */
        this.visible = false;
        /**
         * CSS margin applied to the outer container.
         */
        this.margin = '';
        /**
         * CSS padding applied to the outer container.
         */
        this.padding = '';
        /**
         * Balance symbol shown when `showSymbol` is true.
         * Default: "=".
         */
        this.balanceSymbol = '=';
        /**
         * Whether the balance symbol is currently displayed.
         * Can be toggled with `revealSymbol()` and `hideSymbol()`.
         */
        this.showSymbol = false;
        /**
         * Operation type used to calculate balance values.
         * Supported: "count", "add", "subtract", etc.
         */
        this.operation = 'count';
        /**
         * SVG markup of the pivot element after applying fill/stroke modifications.
         */
        this.pivotSvg = '';
        /**
         * SVG markup of the scale element after applying fill/stroke modifications.
         */
        this.scaleSvg = '';
        /**
         * SVG markup of the handler element after applying fill/stroke modifications.
         */
        this.handlerSvg = '';
        /**
         * Computed inline styles applied to the component host.
         * Updates dynamically based on orientation and props.
         */
        this.style = {};
        /**
         * Final effective tilt value (after clamping/updates).
         */
        this.tiltf = 0;
        /**
         * Current computed value of the left side of the balance.
         */
        this.leftVal = 0;
        /**
         * Current computed value of the right side of the balance.
         */
        this.rightVal = 0;
        this.feedbackColor = '';
        this.currentAngle = 0;
    }
    async revealSymbol() {
        this.showSymbol = true;
    }
    async hideSymbol() {
        this.showSymbol = false;
    }
    async setFeedbackColor(color = '') {
        this.feedbackColor = color;
    }
    async componentWillLoad() {
        this.initializeInitialSymbol();
        this.updateStyles();
        this.pivotSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.pivotimage));
        this.scaleSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.scaleimage));
        this.handlerSvg = await this.fetchAndApplyFill(convertUrlToRelative(this.handlerimage));
    }
    initializeInitialSymbol() {
        var _a, _b;
        const container = (_a = this.el) === null || _a === void 0 ? void 0 : _a.closest('lido-container');
        const objective = (_b = container === null || container === void 0 ? void 0 : container.getAttribute('objective')) === null || _b === void 0 ? void 0 : _b.trim();
        if (objective === '>' || objective === '<' || objective === '=')
            this.balanceSymbol = objective;
        this.showSymbol = true;
    }
    componentDidLoad() {
        this.animateBalance();
        this.leftParentEl = document.getElementById("leftparent");
        this.rightParentEl = document.getElementById("rightparent");
        initEventsForElement(this.el);
    }
    disconnectedCallback() {
        if (this.animationFrameId != null)
            cancelAnimationFrame(this.animationFrameId);
    }
    async fetchAndApplyFill(url) {
        try {
            const res = await fetch(url);
            if (!res.ok)
                return '';
            let svg = await res.text();
            svg = svg.replace(/fill="[^"]*"/g, '');
            svg = svg.replace(/stroke="[^"]*"/g, '');
            svg = svg.replace(/<svg([^>]*)>/, `<svg$1 fill="${this.fill}" stroke="${this.fill}">`);
            return svg;
        }
        catch (e) {
            console.error('SVG fetch failed:', e);
            return '';
        }
    }
    tiltChanged(newValue) {
        this.tiltf = newValue;
    }
    async updateTilt(leftVal, rightVal) {
        const diff = rightVal - leftVal;
        const newTilt = Math.max(-5, Math.min(5, diff));
        await new Promise(res => setTimeout(res, 700));
        this.tiltf = newTilt;
    }
    animateBalance() {
        const rotate = () => {
            let targetAngle = (this.tiltf / 5) * this.maxTilt;
            if (targetAngle > this.maxTilt)
                targetAngle = this.maxTilt;
            if (targetAngle < -this.maxTilt)
                targetAngle = -this.maxTilt;
            this.currentAngle += (targetAngle - this.currentAngle) * 0.1;
            if (this.currentAngle > this.maxTilt)
                this.currentAngle = this.maxTilt;
            if (this.currentAngle < -this.maxTilt)
                this.currentAngle = -this.maxTilt;
            if (this.scaleEl) {
                this.scaleEl.style.transform = `rotate(${this.currentAngle}deg)`;
                this.scaleEl.style.transformOrigin = '50% 80%';
            }
            if (this.leftParentEl && this.rightParentEl) {
                const isPortrait = window.innerHeight > window.innerWidth;
                const maxOffset = isPortrait ? 40 : 60;
                const offset = (this.currentAngle / this.maxTilt) * maxOffset;
                this.leftParentEl.style.transform = `translateY(${-offset}px)`;
                this.rightParentEl.style.transform = `translateY(${offset}px)`;
            }
            if (this.leftHandleEl && this.rightHandleEl) {
                const isPortrait = window.innerHeight > window.innerWidth;
                const maxOffset = isPortrait ? 40 : 60;
                const offset = (this.currentAngle / this.maxTilt) * maxOffset;
                this.leftHandleEl.style.transform = `translateY(${-offset}px)`;
                this.rightHandleEl.style.transform = `translateY(${offset}px)`;
                const feedbackOffset = (this.currentAngle / this.maxTilt) * maxOffset;
                if (this.leftFeedbackEl)
                    this.leftFeedbackEl.style.transform = `translateY(${-feedbackOffset}px)`;
                if (this.rightFeedbackEl)
                    this.rightFeedbackEl.style.transform = `translateY(${feedbackOffset}px)`;
            }
            this.animationFrameId = requestAnimationFrame(rotate);
        };
        rotate();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === "true" ? 'flex' : 'none',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            '--lido-balance-shadow-url': `url(${getAssetPath('assets/Shadow.svg')})`,
        };
    }
    render() {
        return (h(Host, { key: 'b455b2b5d330a2125f7fb8b4e2165d2e6e6bc1a0', id: "lido-balance", "bg-color": "red", onEntry: this.onEntry, class: "lido-balance", tilt: this.tilt.toString(), style: this.style, operation: this.operation.toString(), "pivot-image": this.pivotSvg, "scale-image": this.scaleSvg, "handler-image": this.handlerSvg }, h("div", { key: '657f471d397dd7e3476d5b6e35ee4495c8f2db4c', innerHTML: this.pivotSvg, id: "pivotimg", class: "pivot" }), h("div", { key: '7b91e1919db1fdbcddf79f43a9ad51695b7c806f', innerHTML: this.scaleSvg, id: "scaleimg", class: "scale", ref: (el) => (this.scaleEl = el) }), h("div", { key: '137a1440d55776d0771d8cd71741202c224896db', innerHTML: this.handlerSvg, id: "handlerimg", class: "handler", ref: (el) => (this.leftHandleEl = el) }), h("div", { key: 'd6e0deae63a4e219757240e585d582fb5a72a071', innerHTML: this.handlerSvg, id: "handimg", class: "hand", ref: (el) => (this.rightHandleEl = el) }), h("div", { key: 'ef51f98937cf10c017c8289359c92c24e7316a16', class: "balance-plate-feedback left", ref: (el) => (this.leftFeedbackEl = el), style: { backgroundColor: this.feedbackColor }, "aria-hidden": !this.feedbackColor }), h("div", { key: 'f21aade8543977b657a4d2fbcd623cf8769459a0', class: "balance-plate-feedback right", ref: (el) => (this.rightFeedbackEl = el), style: { backgroundColor: this.feedbackColor }, "aria-hidden": !this.feedbackColor }), h("div", { key: '0470afcef443dbeb69a7d651220d5ff50be3836e', id: "balanceSymbol", class: "lido-balance-symbol", "aria-hidden": !this.showSymbol }, this.showSymbol ? this.balanceSymbol : '')));
    }
    static get assetsDirs() { return ["assets"]; }
    get el() { return getElement(this); }
    static get watchers() { return {
        "tilt": [{
                "tiltChanged": 0
            }]
    }; }
};
LidoBalance.style = lidoBalanceCss();

const lidoCalculatorCss = () => `#lidoCalculator{border-radius:19px;border:5px solid #029A9A;position:relative;display:flex;flex-direction:column;padding:2%;box-sizing:border-box}.lido-calculator-btn-special{--btn-bg-color:#014D4D !important;background-color:#014D4D !important;--btn-shadow-color:#0a2f2f !important}.lido-calculator-btn-default{--btn-bg-color:#029A9A !important;background-color:#029A9A !important;color:#000;--btn-shadow-color:#0f4242 !important}#lido-calculator-penIcon{--btn-bg-color:#FB7038 !important;--btn-shadow-px:0 8px 0 !important;--btn-shadow-color:#D74B12 !important;border-radius:5px !important}.lido-calculator-displayParent{width:89%;height:107px;background-color:rgb(68, 186, 186);border-radius:5px;margin:14px auto 17px auto;overflow:hidden;display:flex;align-items:end}.lido-calculator-display{width:97%;height:94px;background:#029A9A;color:#fff;text-align:right;display:flex;justify-content:flex-end;align-items:center;font-size:72px;font-weight:700;font-family:'Baloo Bhai 2', serif;border-radius:5px 0px 0px 5px;box-sizing:border-box;margin:0 0px -6px auto}.lido-calculator-buttons{flex:1;display:grid;grid-template-columns:repeat(3, 1fr);grid-auto-rows:1fr;gap:0%;width:100%;justify-items:center;align-items:center;position:relative;top:-1%}.lido-calculator-buttons lido-text{display:flex !important;justify-content:center;align-items:center;width:100px !important;height:88px !important;font-size:80px !important;font-weight:700 !important;color:#fff;border-radius:5px !important;cursor:pointer;text-align:center;line-height:1;box-sizing:border-box;transition:transform 0.1s}.lido-calculator-buttons lido-text:active{transform:scale(0.95)}`;

const LidoCalculator = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        this.onOk = createEvent(this, "onOk");
        /** Width of the calculator component (default: '479px') */
        this.width = '479px';
        /**
          * Controls component visibility.
          * Accepts boolean (`true`/`false`) or string ("true"/"false").
        */
        this.visible = false;
        /** Height of the calculator component (default: '711px') */
        this.height = '711px';
        /** Objective or identifier for activity-based logic or validation */
        this.objective = '';
        /** Code or actions to execute when the component is first rendered */
        this.onEntry = '';
        /** X-position of the calculator (can be px, %, etc.) */
        this.x = '0px';
        /** Y-position of the calculator (can be px, %, etc.) */
        this.y = '0px';
        /** Background color for the calculator container */
        this.bgColor = '#60DADA';
        /** Icon URL for the pen image shown on the calculator UI */
        this.penIcon = '';
        /** Current display value shown in the calculator screen */
        this.displayValue = '';
        /** Inline style object for dynamic positioning and layout control */
        this.style = {};
        this.userAnswers = []; // store all calculator inputs
        this.tempInputs = []; // store inputs before clearing display
    }
    updateValueAttr() {
        this.el.setAttribute('value', this.displayValue);
    }
    componentWillLoad() {
        if (!this.objective) {
            const container = this.el.closest('lido-container');
            if (container) {
                this.objective = (container.getAttribute('objective') || '').replace('=', '').trim();
            }
        }
        this.updateValueAttr();
    }
    handleClick(value) {
        const MAX_LENGTH = 8;
        if (value === 'OK') {
            this.verifyAnswer();
        }
        else if (value === '←') {
            this.displayValue = this.displayValue.slice(0, -1);
        }
        else {
            if (this.displayValue.length < MAX_LENGTH) {
                this.displayValue += value;
            }
        }
        this.updateValueAttr();
    }
    async verifyAnswer() {
        var _a;
        const userInput = this.displayValue.trim();
        if (!userInput)
            return;
        let isCorrect = false;
        const container = this.el.closest('lido-container');
        if (!container)
            return;
        if (this.objective && this.objective != '' && !this.objective.includes(',')) {
            isCorrect = Number(userInput) === Number(this.objective);
        }
        // --- Multiple Objectives ---
        else if (this.objective && this.objective.includes(',')) {
            const isContinueOnCorrect = container.getAttribute('is-continue-on-correct') === 'true';
            const objectives = this.objective.split(',').map(obj => obj.trim());
            const currentIndex = this.userAnswers.length;
            // Compare current input with corresponding objective 
            if (currentIndex < objectives.length && Number(userInput) === Number(objectives[currentIndex])) {
                isCorrect = true;
            }
            //  Store behavior based on mode
            if (isContinueOnCorrect) {
                // PRACTICE MODE → store only correct answers 
                if (isCorrect) {
                    this.userAnswers.push(Number(userInput));
                }
            }
            else {
                // TEST MODE → store all user inputs 
                this.userAnswers.push(Number(userInput));
            }
        }
        else if (this.objective === '') {
            const equationAttr = container.getAttribute('equationCheck') || '';
            if (!equationAttr)
                return;
            try {
                const calculatedValue = equationCheck(equationAttr);
                isCorrect = Number(calculatedValue) === Number(userInput.trim());
            }
            catch (err) {
                console.error('Error evaluating equation:', err);
                isCorrect = false;
            }
        }
        this.onOk.emit(isCorrect);
        const okbtn = document.getElementById("btn-11");
        if (isCorrect) {
            const isNimbleTable = container.getAttribute('template-id') === 'nimbleTable';
            const isMultiObjective = this.objective.includes(',');
            if (!(isNimbleTable && isMultiObjective)) {
                container.setAttribute("game-completed", "true");
            }
            this.tempInputs.push(userInput);
            const existingSelected = JSON.parse((_a = container.getAttribute(SelectedValuesKey)) !== null && _a !== void 0 ? _a : '[]');
            const cleanedSelected = Array.isArray(existingSelected)
                ? existingSelected.filter(v => String(v).trim() !== '')
                : [];
            const tempValue = this.tempInputs[this.tempInputs.length - 1];
            if (String(tempValue).trim() !== '') {
                cleanedSelected.push(tempValue);
            }
            container.setAttribute(SelectedValuesKey, JSON.stringify(cleanedSelected));
            okbtn.style.pointerEvents = 'none'; // Disable OK button to prevent multiple clicks
            this.displayValue = "";
            storingEachActivityScore(isCorrect, CalculatorOk);
            if (isNimbleTable && isMultiObjective) {
                const activeCell = container.querySelector("[type='calculate']");
                if (activeCell) {
                    const activeCellAudio = activeCell.getAttribute('audio') || '';
                    if (activeCellAudio.trim()) {
                        activeCell.style.boxShadow = 'none !important';
                        activeCell.setAttribute('onCorrect', "this.speak='true'");
                        AudioPlayer.getI().play(activeCell);
                    }
                }
            }
            const onCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onCorrect')) || '';
            await executeActions(onCorrect, container);
            const hasScrollAction = onCorrect.includes('scrollCellAfterEquationSolved');
            if (!hasScrollAction) {
                if (!isMultiObjective) {
                    calculateScore();
                    triggerNextContainer();
                }
                else {
                    const objectives = this.objective.split(',').map(obj => obj.trim());
                    const allSolved = this.userAnswers.length >= objectives.length;
                    if (allSolved) {
                        container.setAttribute("game-completed", "true");
                        calculateScore();
                        triggerNextContainer();
                    }
                }
            }
        }
        else {
            okbtn.style.pointerEvents = 'none'; // Disable OK button to prevent multiple clicks
            this.displayValue = "";
            storingEachActivityScore(isCorrect, CalculatorOk);
            const onInCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onInCorrect')) || '';
            const onCorrect = (container === null || container === void 0 ? void 0 : container.getAttribute('onCorrect')) || '';
            const isContinueOnCorrect = container.getAttribute('is-continue-on-correct') === 'true';
            if (!isContinueOnCorrect) {
                await executeActions(onCorrect, container);
            }
            else {
                await executeActions(onInCorrect, container);
            }
            if (!isContinueOnCorrect) {
                container.setAttribute("game-completed", "true");
                calculateScore();
                triggerNextContainer();
            }
        }
        okbtn.style.pointerEvents = 'auto'; // Re-enable OK button after processing
    }
    render() {
        const numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '←', '0', 'OK'];
        return (h(Host, { key: 'e8249dda090212d327b68b47d42a123de6a890c9', onEntry: this.onEntry, id: "lidoCalculator", style: { width: this.width, height: this.height, backgroundColor: this.bgColor, left: this.x, top: this.y } }, h("lido-cell", { key: '54d093a3dd6a6e5850c881d224290bd6cf9c3690', visible: "true", height: "94px", width: "60px" }, h("lido-text", { key: '7145c80b2477493a8a87f6d098164293732861bf', visible: "true", id: "lido-calculator-penIcon", type: "click", height: "80px", x: "204%", width: "89px", onEntry: "this.position='relative';", class: "top-icon" }, h("img", { key: '7242feedd5172b555df683c747bbef778a9cdcd7', src: convertUrlToRelative(this.penIcon), alt: "pen", style: { width: '100%', height: '100%' } }))), h("div", { key: '6145a4f89da352c3576e6d51a1e260e335778fbb', class: "lido-calculator-displayParent" }, h("div", { key: '04e07b724d912d43b08c7a1e15c605d0fd30c7be', class: "lido-calculator-display" }, this.displayValue)), h("div", { key: '19839d02863ca1e27fddb4093f191171e237f143', class: "lido-calculator-buttons" }, numbers.map((num, i) => (h("lido-text", { id: `btn-${i}`, string: num, visible: "true", type: "click", class: {
                'lido-calculator-btn-special': num === '←' || num === 'OK',
                'lido-calculator-btn-default': num !== '←' && num !== 'OK'
            }, onClick: () => this.handleClick(num) }))))));
    }
    get el() { return getElement(this); }
};
LidoCalculator.style = lidoCalculatorCss();

const lidoCanvasCss = () => `:host{box-sizing:border-box}.lido-canvas{background:transparent;border:none;border-radius:0;overflow:hidden;box-sizing:border-box}#lido-exit-button{padding:6px 14px;border:none;background:transparent;color:#fff;border-radius:6px;cursor:pointer;font-size:14px;position:absolute;top:0;right:0;z-index:15}canvas{touch-action:none;display:block;width:100%;height:100%;z-index:10}`;

const LidoCanvas = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        //  Width of the canvas containe
        this.width = '800px';
        // Height of the canvas container
        this.height = '700px';
        // Controls component visibility
        this.visible = false;
        // Z-index for stacking order
        this.z = '0';
        // X-offset position for the canvas
        this.x = '0px';
        // y-offset position for the canvas
        this.y = '0px';
        // Actions to execute when component loads
        this.onEntry = '';
        // Flag to track drawing state
        this.drawing = false;
        this.style = {};
        this.handleWindowPointerUp = () => this.stop();
        this.handleWindowResize = () => this.updateStyles();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            width: parseProp(this.width, orientation),
            height: parseProp(this.height, orientation),
            left: parseProp(this.x, orientation),
            top: parseProp(this.y, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'block' : 'none',
            position: 'absolute',
        };
        if (this.canvas) {
            this.canvas.width = parseInt(parseProp(this.width, orientation));
            this.canvas.height = parseInt(parseProp(this.height, orientation));
            this.ctx.strokeStyle = '#000';
            this.ctx.lineWidth = 10;
            this.ctx.lineCap = 'round';
            this.ctx.lineJoin = 'round';
            // this.loadBackground();
        }
    }
    componentDidLoad() {
        this.canvas = this.el.shadowRoot.querySelector('#lido-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.ctx.strokeStyle = '#000';
        this.ctx.lineWidth = 10;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.updateStyles();
        // this.loadBackground();
        this.canvas.addEventListener('pointerdown', e => this.start(e));
        this.canvas.addEventListener('pointermove', e => this.move(e));
        window.addEventListener('pointerup', this.handleWindowPointerUp);
        window.addEventListener('resize', this.handleWindowResize);
    }
    disconnectedCallback() {
        window.removeEventListener('pointerup', this.handleWindowPointerUp);
        window.removeEventListener('resize', this.handleWindowResize);
    }
    loadBackground() {
        if (!this.bgImage) {
            this.ctx.fillStyle = '#fff';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            return;
        }
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = this.bgImage;
        img.onload = () => {
            this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
        };
    }
    getPos(e) {
        const r = this.canvas.getBoundingClientRect();
        return {
            x: (e.clientX - r.left) * (this.canvas.width / r.width),
            y: (e.clientY - r.top) * (this.canvas.height / r.height),
        };
    }
    start(e) {
        this.drawing = true;
        const pos = this.getPos(e);
        this.ctx.beginPath();
        this.ctx.moveTo(pos.x, pos.y);
    }
    move(e) {
        if (!this.drawing)
            return;
        const pos = this.getPos(e);
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();
    }
    stop() {
        this.drawing = false;
        this.ctx.closePath();
    }
    clearCanvas() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    render() {
        return (h(Host, { key: '6bb47f06656ce667d23236e9f3c3a8f383885a43', id: "lido-canvas", class: "lido-canvas", style: this.style }, h("button", { key: 'fd0d1217bda63071fbf6496c2538c2a944b14181', id: "lido-exit-button", onClick: () => this.clearCanvas() }), h("canvas", { key: 'ed0333972bb7ce0fc4e14c81bb466ea895ce65e0', id: "lido-canvas" })));
    }
    get el() { return getElement(this); }
};
LidoCanvas.style = lidoCanvasCss();

const lidoCellCss = () => `.lido-col{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);padding:15px;border-radius:10px;display:flex;justify-content:space-around;flex-direction:column;align-items:center}.lido-col>*{}.lido-row{display:flex;justify-content:space-around;align-items:center;}.lido-row>*{}.lido-wrap{display:grid;grid-gap:10px;grid-template-columns:repeat(auto-fill, minmax(186px, auto))}.lido-wrap>*{padding:10px;box-sizing:border-box}.lido-flex{display:flex;flex-wrap:wrap;align-content:flex-start;gap:10px}.lido-pos{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);display:flex;justify-content:space-around;flex-direction:column;position:fixed}.lido-pos>*{position:absolute}.lido-random{position:relative;width:100%;height:100%}.lido-random>*{position:absolute}.lido-col::-webkit-scrollbar,.lido-wrap::-webkit-scrollbar,.lido-flex::-webkit-scrollbar{width:var(--scrollbar-width);height:var(--scrollbar-width)}.lido-col::-webkit-scrollbar-thumb,.lido-wrap::-webkit-scrollbar-thumb,.lido-flex::-webkit-scrollbar-thumb{background-color:#888;border-radius:10px;border:3px solid transparent;background-clip:content-box}.lido-col::-webkit-scrollbar-track,.lido-wrap::-webkit-scrollbar-track,.lido-flex::-webkit-scrollbar-track{background:#f1f1f1}`;

const LidoCell = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Defines the width of the scrollbar within the cell (e.g., '14px').
         * Defaults to '0px' if not specified, effectively hiding the scrollbar.
         */
        this.scrollbarWidth = '';
        /**
         * The unique identifier for the column component.
         */
        this.id = '';
        /**
         * The value associated with the column component. Typically used for internal logic.
         */
        this.value = '';
        /**
         * The height of the column component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the column component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * The x-coordinate (left position) of the column within its container (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * The y-coordinate (top position) of the column within its container (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * The z-index of the column to control stacking order.
         */
        this.z = '0';
        /**
         * The gap between child elements inside the column (CSS value, e.g., '10px', '5px 10px').
         * This is applicable when the layout is set to `wrap` or `flex`.
         */
        this.gap = '0';
        /**
         * The background color of the column (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * Defines the type of the column, which can be used for styling or specific logic handling.
         */
        this.type = '';
        /**
         * The tab index value, used to set the tab order of the column for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * A boolean that controls whether the column is visible (`true`) or hidden (`false`).
         */
        this.visible = 'false';
        /**
         * Audio file URL or identifier for sound that will be associated with the column.
         */
        this.audio = '';
        /**
         * Event handler for a touch event, where a custom function can be triggered when the column is touched.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler for when the column is entered, which can be used to initiate specific behaviors on entry.
         */
        this.onEntry = '';
        /**
         * The number of child elements that should be displayed inside the row.
         * This value is dynamically adjusted based on `minLength` and `maxLength`.
         */
        this.childElementsLength = 9999;
        /**
         * The minimum number of child elements that must be displayed inside the row.
         * If `childElementsLength` is less than this value, additional elements may be shown to meet this minimum.
         */
        this.minLength = 0;
        /**
         * The maximum number of child elements that can be displayed inside the row.
         * If `childElementsLength` exceeds this value, excess elements will be hidden.
         */
        this.maxLength = 9999;
        /**
         * Determines the layout behavior of the component's children.
         *
         * - `wrap`: Applies a grid layout to the children, allowing them to wrap automatically in a grid format.
         * - `flex`: Applies a flex layout with wrapping behavior (`flex-wrap`).
         * - `col`: Arranges children in a single column using a vertical flex direction.
         * - `row`: Arranges children in a single row using a horizontal flex direction.
         * - `pos`: Applies absolute positioning to children, allowing manual placement using `x` and `y` values.
         * - `random`: Positions child elements randomly within the container using absolute positioning.
         *
         * Default: `'wrap'`
         */
        this.layout = 'wrap';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS align-items property to control the alignment of flex items.
         * Example: 'flex-start', 'flex-end', 'center', 'baseline', 'stretch'.
         */
        this.alignItems = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * CSS flex direction for the component, which can be used to control the layout of child elements.
         * Accepts values like 'row', 'column', etc.
         */
        this.flexDirection = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
    }
    /**
     * This lifecycle hook is called after the component is rendered in the DOM.
     * It initializes events for the column based on the provided type.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        // Select all direct child elements of the component
        // const slotElements = this.el.querySelectorAll('.lido-random > *');
        // if (!slotElements) return;
        // // Iterate over each child and apply random positions
        // slotElements.forEach((child: HTMLElement) => {
        //   const randomTop = Math.random() * 100; // Random value between 0 and 100 for vertical position
        //   const randomLeft = Math.random() * 100; // Random value between 0 and 100 for horizontal position
        //   child.style.top = `${randomTop}%`;
        //   child.style.left = `${randomLeft}%`;
        // });
        setTimeout(() => {
            const check_random_attr = this.el.className.includes('lido-random') ? this.el : null;
            if (check_random_attr) {
                const parentcontainer = check_random_attr.parentElement;
                if (!parentcontainer)
                    return;
                // Get parent size
                const parentWidth = parentcontainer.offsetWidth;
                const parentHeight = parentcontainer.offsetHeight;
                // Place child elements randomly inside parent
                const children = Array.from(check_random_attr.children);
                children.forEach(child => {
                    const childWidth = child.offsetWidth;
                    const childHeight = child.offsetHeight;
                    const maxLeft = parentWidth - childWidth;
                    const maxTop = parentHeight - childHeight;
                    const randLeft = Math.random() * maxLeft;
                    const randTop = Math.random() * maxTop;
                    child.style.position = 'absolute';
                    child.style.left = `${randLeft}px`;
                    child.style.top = `${randTop}px`;
                });
            }
        }, 50);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            'height': parseProp(this.height, orientation),
            'width': parseProp(this.width, orientation),
            'backgroundColor': parseProp(this.bgColor, orientation),
            'top': parseProp(this.y, orientation),
            'left': parseProp(this.x, orientation),
            'zIndex': this.z,
            'margin': parseProp(this.margin, orientation),
            'padding': parseProp(this.padding, orientation),
            'borderRadius': parseProp(this.borderRadius, orientation),
            'gap': parseProp(this.gap, orientation),
            '--scrollbar-width': parseProp(this.scrollbarWidth || '0px', orientation),
            'display': JSON.parse(parseProp(`${this.visible}`, orientation))
                ? parseProp(this.layout, orientation) === 'wrap'
                    ? 'grid'
                    : parseProp(this.layout, orientation) === 'pos' || parseProp(this.layout, orientation) === 'random'
                        ? 'block'
                        : 'flex'
                : 'none',
            'flexDirection': this.flexDirection ? parseProp(this.flexDirection, orientation) : '',
            'alignItems': this.alignItems ? parseProp(this.alignItems, orientation) : '',
        };
        this.el.className = `lido-${parseProp(this.layout, orientation)}`;
    }
    render() {
        return (h(Host, { key: '73bdf9dd33fdd8322c35465de011697da112193a', id: this.id, class: "lido-cell", value: this.value, type: this.type, "tab-index": this.tabIndex, style: this.style, minDrops: this.minDrops, maxDrops: this.maxDrops, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "flex-direction": this.flexDirection, "disable-speak": this.disableSpeak }, h("slot", { key: '6e9d4507b36716f04853d39ef66015441782aa88' })));
    }
    get el() { return getElement(this); }
};
LidoCell.style = lidoCellCss();

const lidoColCss = () => `.lido-col{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);padding:15px;border-radius:10px;display:flex;justify-content:space-around;flex-direction:column;align-items:center}.lido-col>*{}`;

const LidoCol = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * This lifecycle hook is called after the component is rendered in the DOM.
     * It initializes events for the column based on the provided type.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const borderImg = this.borderImage ? convertUrlToRelative(this.borderImage) : '';
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: this.visible ? 'flex' : 'none', // Toggle visibility
            flexDirection: !this.direction ? 'column' : parseProp(this.direction, orientation),
            borderImage: `url(${borderImg})`,
            borderImageSlice: borderImg ? '0 fill' : '',
            boxShadow: this.boxShadow ? this.boxShadow : 'unset',
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: '334206d6054442fec787cfb479a68ae164404730', id: this.id, class: "lido-col", type: this.type, "tab-index": this.tabIndex, value: this.value, style: this.style, minDrops: this.minDrops, maxDrops: this.maxDrops, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: '590cd219bc5a02e6b96eafe108fb8b310daf941d' })));
    }
    get el() { return getElement(this); }
};
LidoCol.style = lidoColCss();

const isString = obj => typeof obj === 'string';
const defer = () => {
  let res;
  let rej;
  const promise = new Promise((resolve, reject) => {
    res = resolve;
    rej = reject;
  });
  promise.resolve = res;
  promise.reject = rej;
  return promise;
};
const makeString = object => {
  if (object == null) return '';
  return '' + object;
};
const copy = (a, s, t) => {
  a.forEach(m => {
    if (s[m]) t[m] = s[m];
  });
};
const lastOfPathSeparatorRegExp = /###/g;
const cleanKey = key => key && key.indexOf('###') > -1 ? key.replace(lastOfPathSeparatorRegExp, '.') : key;
const canNotTraverseDeeper = object => !object || isString(object);
const getLastOfPath = (object, path, Empty) => {
  const stack = !isString(path) ? path : path.split('.');
  let stackIndex = 0;
  while (stackIndex < stack.length - 1) {
    if (canNotTraverseDeeper(object)) return {};
    const key = cleanKey(stack[stackIndex]);
    if (!object[key] && Empty) object[key] = new Empty();
    if (Object.prototype.hasOwnProperty.call(object, key)) {
      object = object[key];
    } else {
      object = {};
    }
    ++stackIndex;
  }
  if (canNotTraverseDeeper(object)) return {};
  return {
    obj: object,
    k: cleanKey(stack[stackIndex])
  };
};
const setPath = (object, path, newValue) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  if (obj !== undefined || path.length === 1) {
    obj[k] = newValue;
    return;
  }
  let e = path[path.length - 1];
  let p = path.slice(0, path.length - 1);
  let last = getLastOfPath(object, p, Object);
  while (last.obj === undefined && p.length) {
    e = `${p[p.length - 1]}.${e}`;
    p = p.slice(0, p.length - 1);
    last = getLastOfPath(object, p, Object);
    if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== 'undefined') {
      last.obj = undefined;
    }
  }
  last.obj[`${last.k}.${e}`] = newValue;
};
const pushPath = (object, path, newValue, concat) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  obj[k] = obj[k] || [];
  obj[k].push(newValue);
};
const getPath = (object, path) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path);
  if (!obj) return undefined;
  if (!Object.prototype.hasOwnProperty.call(obj, k)) return undefined;
  return obj[k];
};
const getPathWithDefaults = (data, defaultData, key) => {
  const value = getPath(data, key);
  if (value !== undefined) {
    return value;
  }
  return getPath(defaultData, key);
};
const deepExtend = (target, source, overwrite) => {
  for (const prop in source) {
    if (prop !== '__proto__' && prop !== 'constructor') {
      if (prop in target) {
        if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
          if (overwrite) target[prop] = source[prop];
        } else {
          deepExtend(target[prop], source[prop], overwrite);
        }
      } else {
        target[prop] = source[prop];
      }
    }
  }
  return target;
};
const regexEscape = str => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
var _entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;'
};
const escape = data => {
  if (isString(data)) {
    return data.replace(/[&<>"'\/]/g, s => _entityMap[s]);
  }
  return data;
};
class RegExpCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.regExpMap = new Map();
    this.regExpQueue = [];
  }
  getRegExp(pattern) {
    const regExpFromCache = this.regExpMap.get(pattern);
    if (regExpFromCache !== undefined) {
      return regExpFromCache;
    }
    const regExpNew = new RegExp(pattern);
    if (this.regExpQueue.length === this.capacity) {
      this.regExpMap.delete(this.regExpQueue.shift());
    }
    this.regExpMap.set(pattern, regExpNew);
    this.regExpQueue.push(pattern);
    return regExpNew;
  }
}
const chars = [' ', ',', '?', '!', ';'];
const looksLikeObjectPathRegExpCache = new RegExpCache(20);
const looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
  nsSeparator = nsSeparator || '';
  keySeparator = keySeparator || '';
  const possibleChars = chars.filter(c => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
  if (possibleChars.length === 0) return true;
  const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map(c => c === '?' ? '\\?' : c).join('|')})`);
  let matched = !r.test(key);
  if (!matched) {
    const ki = key.indexOf(keySeparator);
    if (ki > 0 && !r.test(key.substring(0, ki))) {
      matched = true;
    }
  }
  return matched;
};
const deepFind = (obj, path, keySeparator = '.') => {
  if (!obj) return undefined;
  if (obj[path]) {
    if (!Object.prototype.hasOwnProperty.call(obj, path)) return undefined;
    return obj[path];
  }
  const tokens = path.split(keySeparator);
  let current = obj;
  for (let i = 0; i < tokens.length;) {
    if (!current || typeof current !== 'object') {
      return undefined;
    }
    let next;
    let nextPath = '';
    for (let j = i; j < tokens.length; ++j) {
      if (j !== i) {
        nextPath += keySeparator;
      }
      nextPath += tokens[j];
      next = current[nextPath];
      if (next !== undefined) {
        if (['string', 'number', 'boolean'].indexOf(typeof next) > -1 && j < tokens.length - 1) {
          continue;
        }
        i += j - i + 1;
        break;
      }
    }
    current = next;
  }
  return current;
};
const getCleanedCode = code => code?.replace(/_/g, '-');

const consoleLogger = {
  type: 'logger',
  log(args) {
    this.output('log', args);
  },
  warn(args) {
    this.output('warn', args);
  },
  error(args) {
    this.output('error', args);
  },
  output(type, args) {
    console?.[type]?.apply?.(console, args);
  }
};
class Logger {
  constructor(concreteLogger, options = {}) {
    this.init(concreteLogger, options);
  }
  init(concreteLogger, options = {}) {
    this.prefix = options.prefix || 'i18next:';
    this.logger = concreteLogger || consoleLogger;
    this.options = options;
    this.debug = options.debug;
  }
  log(...args) {
    return this.forward(args, 'log', '', true);
  }
  warn(...args) {
    return this.forward(args, 'warn', '', true);
  }
  error(...args) {
    return this.forward(args, 'error', '');
  }
  deprecate(...args) {
    return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
  }
  forward(args, lvl, prefix, debugOnly) {
    if (debugOnly && !this.debug) return null;
    if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
    return this.logger[lvl](args);
  }
  create(moduleName) {
    return new Logger(this.logger, {
      ...{
        prefix: `${this.prefix}:${moduleName}:`
      },
      ...this.options
    });
  }
  clone(options) {
    options = options || this.options;
    options.prefix = options.prefix || this.prefix;
    return new Logger(this.logger, options);
  }
}
var baseLogger = new Logger();

class EventEmitter {
  constructor() {
    this.observers = {};
  }
  on(events, listener) {
    events.split(' ').forEach(event => {
      if (!this.observers[event]) this.observers[event] = new Map();
      const numListeners = this.observers[event].get(listener) || 0;
      this.observers[event].set(listener, numListeners + 1);
    });
    return this;
  }
  off(event, listener) {
    if (!this.observers[event]) return;
    if (!listener) {
      delete this.observers[event];
      return;
    }
    this.observers[event].delete(listener);
  }
  emit(event, ...args) {
    if (this.observers[event]) {
      const cloned = Array.from(this.observers[event].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer(...args);
        }
      });
    }
    if (this.observers['*']) {
      const cloned = Array.from(this.observers['*'].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer.apply(observer, [event, ...args]);
        }
      });
    }
  }
}

class ResourceStore extends EventEmitter {
  constructor(data, options = {
    ns: ['translation'],
    defaultNS: 'translation'
  }) {
    super();
    this.data = data || {};
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    if (this.options.ignoreJSONStructure === undefined) {
      this.options.ignoreJSONStructure = true;
    }
  }
  addNamespaces(ns) {
    if (this.options.ns.indexOf(ns) < 0) {
      this.options.ns.push(ns);
    }
  }
  removeNamespaces(ns) {
    const index = this.options.ns.indexOf(ns);
    if (index > -1) {
      this.options.ns.splice(index, 1);
    }
  }
  getResource(lng, ns, key, options = {}) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    const ignoreJSONStructure = options.ignoreJSONStructure !== undefined ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
    let path;
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
    } else {
      path = [lng, ns];
      if (key) {
        if (Array.isArray(key)) {
          path.push(...key);
        } else if (isString(key) && keySeparator) {
          path.push(...key.split(keySeparator));
        } else {
          path.push(key);
        }
      }
    }
    const result = getPath(this.data, path);
    if (!result && !ns && !key && lng.indexOf('.') > -1) {
      lng = path[0];
      ns = path[1];
      key = path.slice(2).join('.');
    }
    if (result || !ignoreJSONStructure || !isString(key)) return result;
    return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
  }
  addResource(lng, ns, key, value, options = {
    silent: false
  }) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    let path = [lng, ns];
    if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      value = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    setPath(this.data, path, value);
    if (!options.silent) this.emit('added', lng, ns, key, value);
  }
  addResources(lng, ns, resources, options = {
    silent: false
  }) {
    for (const m in resources) {
      if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], {
        silent: true
      });
    }
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  addResourceBundle(lng, ns, resources, deep, overwrite, options = {
    silent: false,
    skipCopy: false
  }) {
    let path = [lng, ns];
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      deep = resources;
      resources = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    let pack = getPath(this.data, path) || {};
    if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
    if (deep) {
      deepExtend(pack, resources, overwrite);
    } else {
      pack = {
        ...pack,
        ...resources
      };
    }
    setPath(this.data, path, pack);
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  removeResourceBundle(lng, ns) {
    if (this.hasResourceBundle(lng, ns)) {
      delete this.data[lng][ns];
    }
    this.removeNamespaces(ns);
    this.emit('removed', lng, ns);
  }
  hasResourceBundle(lng, ns) {
    return this.getResource(lng, ns) !== undefined;
  }
  getResourceBundle(lng, ns) {
    if (!ns) ns = this.options.defaultNS;
    return this.getResource(lng, ns);
  }
  getDataByLanguage(lng) {
    return this.data[lng];
  }
  hasLanguageSomeTranslations(lng) {
    const data = this.getDataByLanguage(lng);
    const n = data && Object.keys(data) || [];
    return !!n.find(v => data[v] && Object.keys(data[v]).length > 0);
  }
  toJSON() {
    return this.data;
  }
}

var postProcessor = {
  processors: {},
  addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle(processors, value, key, options, translator) {
    processors.forEach(processor => {
      value = this.processors[processor]?.process(value, key, options, translator) ?? value;
    });
    return value;
  }
};

const PATH_KEY = Symbol('i18next/PATH_KEY');
function createProxy() {
  const state = [];
  const handler = Object.create(null);
  let proxy;
  handler.get = (target, key) => {
    proxy?.revoke?.();
    if (key === PATH_KEY) return state;
    state.push(key);
    proxy = Proxy.revocable(target, handler);
    return proxy.proxy;
  };
  return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
  const {
    [PATH_KEY]: path
  } = selector(createProxy());
  const keySeparator = opts?.keySeparator ?? '.';
  const nsSeparator = opts?.nsSeparator ?? ':';
  if (path.length > 1 && nsSeparator) {
    const ns = opts?.ns;
    const nsArray = Array.isArray(ns) ? ns : null;
    if (nsArray && nsArray.length > 1 && nsArray.slice(1).includes(path[0])) {
      return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
    }
  }
  return path.join(keySeparator);
}

const checkedLoadedFor = {};
const shouldHandleAsObject = res => !isString(res) && typeof res !== 'boolean' && typeof res !== 'number';
class Translator extends EventEmitter {
  constructor(services, options = {}) {
    super();
    copy(['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'], services, this);
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    this.logger = baseLogger.create('translator');
  }
  changeLanguage(lng) {
    if (lng) this.language = lng;
  }
  exists(key, o = {
    interpolation: {}
  }) {
    const opt = {
      ...o
    };
    if (key == null) return false;
    const resolved = this.resolve(key, opt);
    if (resolved?.res === undefined) return false;
    const isObject = shouldHandleAsObject(resolved.res);
    if (opt.returnObjects === false && isObject) {
      return false;
    }
    return true;
  }
  extractFromKey(key, opt) {
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    let namespaces = opt.ns || this.options.defaultNS || [];
    const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
    const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
    if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
      const m = key.match(this.interpolator.nestingRegexp);
      if (m && m.length > 0) {
        return {
          key,
          namespaces: isString(namespaces) ? [namespaces] : namespaces
        };
      }
      const parts = key.split(nsSeparator);
      if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
      key = parts.join(keySeparator);
    }
    return {
      key,
      namespaces: isString(namespaces) ? [namespaces] : namespaces
    };
  }
  translate(keys, o, lastKey) {
    let opt = typeof o === 'object' ? {
      ...o
    } : o;
    if (typeof opt !== 'object' && this.options.overloadTranslationOptionHandler) {
      opt = this.options.overloadTranslationOptionHandler(arguments);
    }
    if (typeof opt === 'object') opt = {
      ...opt
    };
    if (!opt) opt = {};
    if (keys == null) return '';
    if (typeof keys === 'function') keys = keysFromSelector(keys, {
      ...this.options,
      ...opt
    });
    if (!Array.isArray(keys)) keys = [String(keys)];
    keys = keys.map(k => typeof k === 'function' ? keysFromSelector(k, {
      ...this.options,
      ...opt
    }) : String(k));
    const returnDetails = opt.returnDetails !== undefined ? opt.returnDetails : this.options.returnDetails;
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    const {
      key,
      namespaces
    } = this.extractFromKey(keys[keys.length - 1], opt);
    const namespace = namespaces[namespaces.length - 1];
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const lng = opt.lng || this.language;
    const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
    if (lng?.toLowerCase() === 'cimode') {
      if (appendNamespaceToCIMode) {
        if (returnDetails) {
          return {
            res: `${namespace}${nsSeparator}${key}`,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt)
          };
        }
        return `${namespace}${nsSeparator}${key}`;
      }
      if (returnDetails) {
        return {
          res: key,
          usedKey: key,
          exactUsedKey: key,
          usedLng: lng,
          usedNS: namespace,
          usedParams: this.getUsedParamsDetails(opt)
        };
      }
      return key;
    }
    const resolved = this.resolve(keys, opt);
    let res = resolved?.res;
    const resUsedKey = resolved?.usedKey || key;
    const resExactUsedKey = resolved?.exactUsedKey || key;
    const noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
    const joinArrays = opt.joinArrays !== undefined ? opt.joinArrays : this.options.joinArrays;
    const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
    const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
    const hasDefaultValue = Translator.hasDefaultValue(opt);
    const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : '';
    const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, {
      ordinal: false
    }) : '';
    const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
    const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
    let resForObjHndl = res;
    if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
      resForObjHndl = defaultValue;
    }
    const handleAsObject = shouldHandleAsObject(resForObjHndl);
    const resType = Object.prototype.toString.apply(resForObjHndl);
    if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && noObject.indexOf(resType) < 0 && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
      if (!opt.returnObjects && !this.options.returnObjects) {
        if (!this.options.returnedObjectHandler) {
          this.logger.warn('accessing an object - but returnObjects options is not enabled!');
        }
        const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
          ...opt,
          ns: namespaces
        }) : `key '${key} (${this.language})' returned an object instead of string.`;
        if (returnDetails) {
          resolved.res = r;
          resolved.usedParams = this.getUsedParamsDetails(opt);
          return resolved;
        }
        return r;
      }
      if (keySeparator) {
        const resTypeIsArray = Array.isArray(resForObjHndl);
        const copy = resTypeIsArray ? [] : {};
        const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
        for (const m in resForObjHndl) {
          if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
            const deepKey = `${newKeyToUse}${keySeparator}${m}`;
            if (hasDefaultValue && !res) {
              copy[m] = this.translate(deepKey, {
                ...opt,
                defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : undefined,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            } else {
              copy[m] = this.translate(deepKey, {
                ...opt,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            }
            if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
          }
        }
        res = copy;
      }
    } else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
      res = res.join(joinArrays);
      if (res) res = this.extendTranslation(res, keys, opt, lastKey);
    } else {
      let usedDefault = false;
      let usedKey = false;
      if (!this.isValidLookup(res) && hasDefaultValue) {
        usedDefault = true;
        res = defaultValue;
      }
      if (!this.isValidLookup(res)) {
        usedKey = true;
        res = key;
      }
      const missingKeyNoValueFallbackToKey = opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
      const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? undefined : res;
      const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
      if (usedKey || usedDefault || updateMissing) {
        this.logger.log(updateMissing ? 'updateKey' : 'missingKey', lng, namespace, key, updateMissing ? defaultValue : res);
        if (keySeparator) {
          const fk = this.resolve(key, {
            ...opt,
            keySeparator: false
          });
          if (fk && fk.res) this.logger.warn('Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.');
        }
        let lngs = [];
        const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
        if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
          for (let i = 0; i < fallbackLngs.length; i++) {
            lngs.push(fallbackLngs[i]);
          }
        } else if (this.options.saveMissingTo === 'all') {
          lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
        } else {
          lngs.push(opt.lng || this.language);
        }
        const send = (l, k, specificDefaultValue) => {
          const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
          if (this.options.missingKeyHandler) {
            this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
          } else if (this.backendConnector?.saveMissing) {
            this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
          }
          this.emit('missingKey', l, namespace, k, res);
        };
        if (this.options.saveMissing) {
          if (this.options.saveMissingPlurals && needsPluralHandling) {
            lngs.forEach(language => {
              const suffixes = this.pluralResolver.getSuffixes(language, opt);
              if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0) {
                suffixes.push(`${this.options.pluralSeparator}zero`);
              }
              suffixes.forEach(suffix => {
                send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
              });
            });
          } else {
            send(lngs, key, defaultValue);
          }
        }
      }
      res = this.extendTranslation(res, keys, opt, resolved, lastKey);
      if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
        res = `${namespace}${nsSeparator}${key}`;
      }
      if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
        res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : undefined, opt);
      }
    }
    if (returnDetails) {
      resolved.res = res;
      resolved.usedParams = this.getUsedParamsDetails(opt);
      return resolved;
    }
    return res;
  }
  extendTranslation(res, key, opt, resolved, lastKey) {
    if (this.i18nFormat?.parse) {
      res = this.i18nFormat.parse(res, {
        ...this.options.interpolation.defaultVariables,
        ...opt
      }, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, {
        resolved
      });
    } else if (!opt.skipInterpolation) {
      if (opt.interpolation) this.interpolator.init({
        ...opt,
        ...{
          interpolation: {
            ...this.options.interpolation,
            ...opt.interpolation
          }
        }
      });
      const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== undefined ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
      let nestBef;
      if (skipOnVariables) {
        const nb = res.match(this.interpolator.nestingRegexp);
        nestBef = nb && nb.length;
      }
      let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
      if (this.options.interpolation.defaultVariables) data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
      res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
      if (skipOnVariables) {
        const na = res.match(this.interpolator.nestingRegexp);
        const nestAft = na && na.length;
        if (nestBef < nestAft) opt.nest = false;
      }
      if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
      if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
        if (lastKey?.[0] === args[0] && !opt.context) {
          this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
          return null;
        }
        return this.translate(...args, key);
      }, opt);
      if (opt.interpolation) this.interpolator.reset();
    }
    const postProcess = opt.postProcess || this.options.postProcess;
    const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
    if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
      res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
        i18nResolved: {
          ...resolved,
          usedParams: this.getUsedParamsDetails(opt)
        },
        ...opt
      } : opt, this);
    }
    return res;
  }
  resolve(keys, opt = {}) {
    let found;
    let usedKey;
    let exactUsedKey;
    let usedLng;
    let usedNS;
    if (isString(keys)) keys = [keys];
    if (Array.isArray(keys)) keys = keys.map(k => typeof k === 'function' ? keysFromSelector(k, {
      ...this.options,
      ...opt
    }) : k);
    keys.forEach(k => {
      if (this.isValidLookup(found)) return;
      const extracted = this.extractFromKey(k, opt);
      const key = extracted.key;
      usedKey = key;
      let namespaces = extracted.namespaces;
      if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
      const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const needsContextHandling = opt.context !== undefined && (isString(opt.context) || typeof opt.context === 'number') && opt.context !== '';
      const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
      namespaces.forEach(ns => {
        if (this.isValidLookup(found)) return;
        usedNS = ns;
        if (!checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
          checkedLoadedFor[`${codes[0]}-${ns}`] = true;
          this.logger.warn(`key "${usedKey}" for languages "${codes.join(', ')}" won't get resolved as namespace "${usedNS}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
        }
        codes.forEach(code => {
          if (this.isValidLookup(found)) return;
          usedLng = code;
          const finalKeys = [key];
          if (this.i18nFormat?.addLookupKeys) {
            this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
          } else {
            let pluralSuffix;
            if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
            const zeroSuffix = `${this.options.pluralSeparator}zero`;
            const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
            if (needsPluralHandling) {
              if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
              }
              finalKeys.push(key + pluralSuffix);
              if (needsZeroSuffixLookup) {
                finalKeys.push(key + zeroSuffix);
              }
            }
            if (needsContextHandling) {
              const contextKey = `${key}${this.options.contextSeparator || '_'}${opt.context}`;
              finalKeys.push(contextKey);
              if (needsPluralHandling) {
                if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                  finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                finalKeys.push(contextKey + pluralSuffix);
                if (needsZeroSuffixLookup) {
                  finalKeys.push(contextKey + zeroSuffix);
                }
              }
            }
          }
          let possibleKey;
          while (possibleKey = finalKeys.pop()) {
            if (!this.isValidLookup(found)) {
              exactUsedKey = possibleKey;
              found = this.getResource(code, ns, possibleKey, opt);
            }
          }
        });
      });
    });
    return {
      res: found,
      usedKey,
      exactUsedKey,
      usedLng,
      usedNS
    };
  }
  isValidLookup(res) {
    return res !== undefined && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === '');
  }
  getResource(code, ns, key, options = {}) {
    if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
    return this.resourceStore.getResource(code, ns, key, options);
  }
  getUsedParamsDetails(options = {}) {
    const optionsKeys = ['defaultValue', 'ordinal', 'context', 'replace', 'lng', 'lngs', 'fallbackLng', 'ns', 'keySeparator', 'nsSeparator', 'returnObjects', 'returnDetails', 'joinArrays', 'postProcess', 'interpolation'];
    const useOptionsReplaceForData = options.replace && !isString(options.replace);
    let data = useOptionsReplaceForData ? options.replace : options;
    if (useOptionsReplaceForData && typeof options.count !== 'undefined') {
      data.count = options.count;
    }
    if (this.options.interpolation.defaultVariables) {
      data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
    }
    if (!useOptionsReplaceForData) {
      data = {
        ...data
      };
      for (const key of optionsKeys) {
        delete data[key];
      }
    }
    return data;
  }
  static hasDefaultValue(options) {
    const prefix = 'defaultValue';
    for (const option in options) {
      if (Object.prototype.hasOwnProperty.call(options, option) && prefix === option.substring(0, prefix.length) && undefined !== options[option]) {
        return true;
      }
    }
    return false;
  }
}

class LanguageUtil {
  constructor(options) {
    this.options = options;
    this.supportedLngs = this.options.supportedLngs || false;
    this.logger = baseLogger.create('languageUtils');
  }
  getScriptPartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return null;
    const p = code.split('-');
    if (p.length === 2) return null;
    p.pop();
    if (p[p.length - 1].toLowerCase() === 'x') return null;
    return this.formatLanguageCode(p.join('-'));
  }
  getLanguagePartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return code;
    const p = code.split('-');
    return this.formatLanguageCode(p[0]);
  }
  formatLanguageCode(code) {
    if (isString(code) && code.indexOf('-') > -1) {
      let formattedCode;
      try {
        formattedCode = Intl.getCanonicalLocales(code)[0];
      } catch (e) {}
      if (formattedCode && this.options.lowerCaseLng) {
        formattedCode = formattedCode.toLowerCase();
      }
      if (formattedCode) return formattedCode;
      if (this.options.lowerCaseLng) {
        return code.toLowerCase();
      }
      return code;
    }
    return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
  }
  isSupportedCode(code) {
    if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
      code = this.getLanguagePartFromCode(code);
    }
    return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
  }
  getBestMatchFromCodes(codes) {
    if (!codes) return null;
    let found;
    codes.forEach(code => {
      if (found) return;
      const cleanedLng = this.formatLanguageCode(code);
      if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
    });
    if (!found && this.options.supportedLngs) {
      codes.forEach(code => {
        if (found) return;
        const lngScOnly = this.getScriptPartFromCode(code);
        if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
        const lngOnly = this.getLanguagePartFromCode(code);
        if (this.isSupportedCode(lngOnly)) return found = lngOnly;
        found = this.options.supportedLngs.find(supportedLng => {
          if (supportedLng === lngOnly) return supportedLng;
          if (supportedLng.indexOf('-') < 0 && lngOnly.indexOf('-') < 0) return;
          if (supportedLng.indexOf('-') > 0 && lngOnly.indexOf('-') < 0 && supportedLng.substring(0, supportedLng.indexOf('-')) === lngOnly) return supportedLng;
          if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
        });
      });
    }
    if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
    return found;
  }
  getFallbackCodes(fallbacks, code) {
    if (!fallbacks) return [];
    if (typeof fallbacks === 'function') fallbacks = fallbacks(code);
    if (isString(fallbacks)) fallbacks = [fallbacks];
    if (Array.isArray(fallbacks)) return fallbacks;
    if (!code) return fallbacks.default || [];
    let found = fallbacks[code];
    if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
    if (!found) found = fallbacks[this.formatLanguageCode(code)];
    if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
    if (!found) found = fallbacks.default;
    return found || [];
  }
  toResolveHierarchy(code, fallbackCode) {
    const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
    const codes = [];
    const addCode = c => {
      if (!c) return;
      if (this.isSupportedCode(c)) {
        codes.push(c);
      } else {
        this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
      }
    };
    if (isString(code) && (code.indexOf('-') > -1 || code.indexOf('_') > -1)) {
      if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
      if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly') addCode(this.getScriptPartFromCode(code));
      if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
    } else if (isString(code)) {
      addCode(this.formatLanguageCode(code));
    }
    fallbackCodes.forEach(fc => {
      if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
    });
    return codes;
  }
}

const suffixesOrder = {
  zero: 0,
  one: 1,
  two: 2,
  few: 3,
  many: 4,
  other: 5
};
const dummyRule = {
  select: count => count === 1 ? 'one' : 'other',
  resolvedOptions: () => ({
    pluralCategories: ['one', 'other']
  })
};
class PluralResolver {
  constructor(languageUtils, options = {}) {
    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create('pluralResolver');
    this.pluralRulesCache = {};
  }
  clearCache() {
    this.pluralRulesCache = {};
  }
  getRule(code, options = {}) {
    const cleanedCode = getCleanedCode(code === 'dev' ? 'en' : code);
    const type = options.ordinal ? 'ordinal' : 'cardinal';
    const cacheKey = JSON.stringify({
      cleanedCode,
      type
    });
    if (cacheKey in this.pluralRulesCache) {
      return this.pluralRulesCache[cacheKey];
    }
    let rule;
    try {
      rule = new Intl.PluralRules(cleanedCode, {
        type
      });
    } catch (err) {
      if (typeof Intl === 'undefined') {
        this.logger.error('No Intl support, please use an Intl polyfill!');
        return dummyRule;
      }
      if (!code.match(/-|_/)) return dummyRule;
      const lngPart = this.languageUtils.getLanguagePartFromCode(code);
      rule = this.getRule(lngPart, options);
    }
    this.pluralRulesCache[cacheKey] = rule;
    return rule;
  }
  needsPlural(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    return rule?.resolvedOptions().pluralCategories.length > 1;
  }
  getPluralFormsOfKey(code, key, options = {}) {
    return this.getSuffixes(code, options).map(suffix => `${key}${suffix}`);
  }
  getSuffixes(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    if (!rule) return [];
    return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map(pluralCategory => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${pluralCategory}`);
  }
  getSuffix(code, count, options = {}) {
    const rule = this.getRule(code, options);
    if (rule) {
      return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${rule.select(count)}`;
    }
    this.logger.warn(`no plural rule found for: ${code}`);
    return this.getSuffix('dev', count, options);
  }
}

const deepFindWithDefaults = (data, defaultData, key, keySeparator = '.', ignoreJSONStructure = true) => {
  let path = getPathWithDefaults(data, defaultData, key);
  if (!path && ignoreJSONStructure && isString(key)) {
    path = deepFind(data, key, keySeparator);
    if (path === undefined) path = deepFind(defaultData, key, keySeparator);
  }
  return path;
};
const regexSafe = val => val.replace(/\$/g, '$$$$');
class Interpolator {
  constructor(options = {}) {
    this.logger = baseLogger.create('interpolator');
    this.options = options;
    this.format = options?.interpolation?.format || (value => value);
    this.init(options);
  }
  init(options = {}) {
    if (!options.interpolation) options.interpolation = {
      escapeValue: true
    };
    const {
      escape: escape$1,
      escapeValue,
      useRawValueToEscape,
      prefix,
      prefixEscaped,
      suffix,
      suffixEscaped,
      formatSeparator,
      unescapeSuffix,
      unescapePrefix,
      nestingPrefix,
      nestingPrefixEscaped,
      nestingSuffix,
      nestingSuffixEscaped,
      nestingOptionsSeparator,
      maxReplaces,
      alwaysFormat
    } = options.interpolation;
    this.escape = escape$1 !== undefined ? escape$1 : escape;
    this.escapeValue = escapeValue !== undefined ? escapeValue : true;
    this.useRawValueToEscape = useRawValueToEscape !== undefined ? useRawValueToEscape : false;
    this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || '{{';
    this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || '}}';
    this.formatSeparator = formatSeparator || ',';
    this.unescapePrefix = unescapeSuffix ? '' : unescapePrefix || '-';
    this.unescapeSuffix = this.unescapePrefix ? '' : unescapeSuffix || '';
    this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape('$t(');
    this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(')');
    this.nestingOptionsSeparator = nestingOptionsSeparator || ',';
    this.maxReplaces = maxReplaces || 1000;
    this.alwaysFormat = alwaysFormat !== undefined ? alwaysFormat : false;
    this.resetRegExp();
  }
  reset() {
    if (this.options) this.init(this.options);
  }
  resetRegExp() {
    const getOrResetRegExp = (existingRegExp, pattern) => {
      if (existingRegExp?.source === pattern) {
        existingRegExp.lastIndex = 0;
        return existingRegExp;
      }
      return new RegExp(pattern, 'g');
    };
    this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
    this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
    this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
  }
  interpolate(str, data, lng, options) {
    let match;
    let value;
    let replaces;
    const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
    const handleFormat = key => {
      if (key.indexOf(this.formatSeparator) < 0) {
        const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
        return this.alwaysFormat ? this.format(path, undefined, lng, {
          ...options,
          ...data,
          interpolationkey: key
        }) : path;
      }
      const p = key.split(this.formatSeparator);
      const k = p.shift().trim();
      const f = p.join(this.formatSeparator).trim();
      return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
        ...options,
        ...data,
        interpolationkey: k
      });
    };
    this.resetRegExp();
    const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
    const skipOnVariables = options?.interpolation?.skipOnVariables !== undefined ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
    const todos = [{
      regex: this.regexpUnescape,
      safeValue: val => regexSafe(val)
    }, {
      regex: this.regexp,
      safeValue: val => this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)
    }];
    todos.forEach(todo => {
      replaces = 0;
      while (match = todo.regex.exec(str)) {
        const matchedVar = match[1].trim();
        value = handleFormat(matchedVar);
        if (value === undefined) {
          if (typeof missingInterpolationHandler === 'function') {
            const temp = missingInterpolationHandler(str, match, options);
            value = isString(temp) ? temp : '';
          } else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) {
            value = '';
          } else if (skipOnVariables) {
            value = match[0];
            continue;
          } else {
            this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
            value = '';
          }
        } else if (!isString(value) && !this.useRawValueToEscape) {
          value = makeString(value);
        }
        const safeValue = todo.safeValue(value);
        str = str.replace(match[0], safeValue);
        if (skipOnVariables) {
          todo.regex.lastIndex += value.length;
          todo.regex.lastIndex -= match[0].length;
        } else {
          todo.regex.lastIndex = 0;
        }
        replaces++;
        if (replaces >= this.maxReplaces) {
          break;
        }
      }
    });
    return str;
  }
  nest(str, fc, options = {}) {
    let match;
    let value;
    let clonedOptions;
    const handleHasOptions = (key, inheritedOptions) => {
      const sep = this.nestingOptionsSeparator;
      if (key.indexOf(sep) < 0) return key;
      const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
      let optionsString = `{${c[1]}`;
      key = c[0];
      optionsString = this.interpolate(optionsString, clonedOptions);
      const matchedSingleQuotes = optionsString.match(/'/g);
      const matchedDoubleQuotes = optionsString.match(/"/g);
      if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) {
        optionsString = optionsString.replace(/'/g, '"');
      }
      try {
        clonedOptions = JSON.parse(optionsString);
        if (inheritedOptions) clonedOptions = {
          ...inheritedOptions,
          ...clonedOptions
        };
      } catch (e) {
        this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
        return `${key}${sep}${optionsString}`;
      }
      if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1) delete clonedOptions.defaultValue;
      return key;
    };
    while (match = this.nestingRegexp.exec(str)) {
      let formatters = [];
      clonedOptions = {
        ...options
      };
      clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
      clonedOptions.applyPostProcessor = false;
      delete clonedOptions.defaultValue;
      const keyEndIndex = /{.*}/.test(match[1]) ? match[1].lastIndexOf('}') + 1 : match[1].indexOf(this.formatSeparator);
      if (keyEndIndex !== -1) {
        formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map(elem => elem.trim()).filter(Boolean);
        match[1] = match[1].slice(0, keyEndIndex);
      }
      value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
      if (value && match[0] === str && !isString(value)) return value;
      if (!isString(value)) value = makeString(value);
      if (!value) {
        this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
        value = '';
      }
      if (formatters.length) {
        value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
          ...options,
          interpolationkey: match[1].trim()
        }), value.trim());
      }
      str = str.replace(match[0], value);
      this.regexp.lastIndex = 0;
    }
    return str;
  }
}

const parseFormatStr = formatStr => {
  let formatName = formatStr.toLowerCase().trim();
  const formatOptions = {};
  if (formatStr.indexOf('(') > -1) {
    const p = formatStr.split('(');
    formatName = p[0].toLowerCase().trim();
    const optStr = p[1].substring(0, p[1].length - 1);
    if (formatName === 'currency' && optStr.indexOf(':') < 0) {
      if (!formatOptions.currency) formatOptions.currency = optStr.trim();
    } else if (formatName === 'relativetime' && optStr.indexOf(':') < 0) {
      if (!formatOptions.range) formatOptions.range = optStr.trim();
    } else {
      const opts = optStr.split(';');
      opts.forEach(opt => {
        if (opt) {
          const [key, ...rest] = opt.split(':');
          const val = rest.join(':').trim().replace(/^'+|'+$/g, '');
          const trimmedKey = key.trim();
          if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
          if (val === 'false') formatOptions[trimmedKey] = false;
          if (val === 'true') formatOptions[trimmedKey] = true;
          if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
        }
      });
    }
  }
  return {
    formatName,
    formatOptions
  };
};
const createCachedFormatter = fn => {
  const cache = {};
  return (v, l, o) => {
    let optForCache = o;
    if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
      optForCache = {
        ...optForCache,
        [o.interpolationkey]: undefined
      };
    }
    const key = l + JSON.stringify(optForCache);
    let frm = cache[key];
    if (!frm) {
      frm = fn(getCleanedCode(l), o);
      cache[key] = frm;
    }
    return frm(v);
  };
};
const createNonCachedFormatter = fn => (v, l, o) => fn(getCleanedCode(l), o)(v);
class Formatter {
  constructor(options = {}) {
    this.logger = baseLogger.create('formatter');
    this.options = options;
    this.init(options);
  }
  init(services, options = {
    interpolation: {}
  }) {
    this.formatSeparator = options.interpolation.formatSeparator || ',';
    const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
    this.formats = {
      number: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      currency: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt,
          style: 'currency'
        });
        return val => formatter.format(val);
      }),
      datetime: cf((lng, opt) => {
        const formatter = new Intl.DateTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      relativetime: cf((lng, opt) => {
        const formatter = new Intl.RelativeTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val, opt.range || 'day');
      }),
      list: cf((lng, opt) => {
        const formatter = new Intl.ListFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      })
    };
  }
  add(name, fc) {
    this.formats[name.toLowerCase().trim()] = fc;
  }
  addCached(name, fc) {
    this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
  }
  format(value, format, lng, options = {}) {
    const formats = format.split(this.formatSeparator);
    if (formats.length > 1 && formats[0].indexOf('(') > 1 && formats[0].indexOf(')') < 0 && formats.find(f => f.indexOf(')') > -1)) {
      const lastIndex = formats.findIndex(f => f.indexOf(')') > -1);
      formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
    }
    const result = formats.reduce((mem, f) => {
      const {
        formatName,
        formatOptions
      } = parseFormatStr(f);
      if (this.formats[formatName]) {
        let formatted = mem;
        try {
          const valOptions = options?.formatParams?.[options.interpolationkey] || {};
          const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
          formatted = this.formats[formatName](mem, l, {
            ...formatOptions,
            ...options,
            ...valOptions
          });
        } catch (error) {
          this.logger.warn(error);
        }
        return formatted;
      } else {
        this.logger.warn(`there was no format function for ${formatName}`);
      }
      return mem;
    }, value);
    return result;
  }
}

const removePending = (q, name) => {
  if (q.pending[name] !== undefined) {
    delete q.pending[name];
    q.pendingCount--;
  }
};
class Connector extends EventEmitter {
  constructor(backend, store, services, options = {}) {
    super();
    this.backend = backend;
    this.store = store;
    this.services = services;
    this.languageUtils = services.languageUtils;
    this.options = options;
    this.logger = baseLogger.create('backendConnector');
    this.waitingReads = [];
    this.maxParallelReads = options.maxParallelReads || 10;
    this.readingCalls = 0;
    this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
    this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
    this.state = {};
    this.queue = [];
    this.backend?.init?.(services, options.backend, options);
  }
  queueLoad(languages, namespaces, options, callback) {
    const toLoad = {};
    const pending = {};
    const toLoadLanguages = {};
    const toLoadNamespaces = {};
    languages.forEach(lng => {
      let hasAllNamespaces = true;
      namespaces.forEach(ns => {
        const name = `${lng}|${ns}`;
        if (!options.reload && this.store.hasResourceBundle(lng, ns)) {
          this.state[name] = 2;
        } else if (this.state[name] < 0) ; else if (this.state[name] === 1) {
          if (pending[name] === undefined) pending[name] = true;
        } else {
          this.state[name] = 1;
          hasAllNamespaces = false;
          if (pending[name] === undefined) pending[name] = true;
          if (toLoad[name] === undefined) toLoad[name] = true;
          if (toLoadNamespaces[ns] === undefined) toLoadNamespaces[ns] = true;
        }
      });
      if (!hasAllNamespaces) toLoadLanguages[lng] = true;
    });
    if (Object.keys(toLoad).length || Object.keys(pending).length) {
      this.queue.push({
        pending,
        pendingCount: Object.keys(pending).length,
        loaded: {},
        errors: [],
        callback
      });
    }
    return {
      toLoad: Object.keys(toLoad),
      pending: Object.keys(pending),
      toLoadLanguages: Object.keys(toLoadLanguages),
      toLoadNamespaces: Object.keys(toLoadNamespaces)
    };
  }
  loaded(name, err, data) {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    if (err) this.emit('failedLoading', lng, ns, err);
    if (!err && data) {
      this.store.addResourceBundle(lng, ns, data, undefined, undefined, {
        skipCopy: true
      });
    }
    this.state[name] = err ? -1 : 2;
    if (err && data) this.state[name] = 0;
    const loaded = {};
    this.queue.forEach(q => {
      pushPath(q.loaded, [lng], ns);
      removePending(q, name);
      if (err) q.errors.push(err);
      if (q.pendingCount === 0 && !q.done) {
        Object.keys(q.loaded).forEach(l => {
          if (!loaded[l]) loaded[l] = {};
          const loadedKeys = q.loaded[l];
          if (loadedKeys.length) {
            loadedKeys.forEach(n => {
              if (loaded[l][n] === undefined) loaded[l][n] = true;
            });
          }
        });
        q.done = true;
        if (q.errors.length) {
          q.callback(q.errors);
        } else {
          q.callback();
        }
      }
    });
    this.emit('loaded', loaded);
    this.queue = this.queue.filter(q => !q.done);
  }
  read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
    if (!lng.length) return callback(null, {});
    if (this.readingCalls >= this.maxParallelReads) {
      this.waitingReads.push({
        lng,
        ns,
        fcName,
        tried,
        wait,
        callback
      });
      return;
    }
    this.readingCalls++;
    const resolver = (err, data) => {
      this.readingCalls--;
      if (this.waitingReads.length > 0) {
        const next = this.waitingReads.shift();
        this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
      }
      if (err && data && tried < this.maxRetries) {
        setTimeout(() => {
          this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
        }, wait);
        return;
      }
      callback(err, data);
    };
    const fc = this.backend[fcName].bind(this.backend);
    if (fc.length === 2) {
      try {
        const r = fc(lng, ns);
        if (r && typeof r.then === 'function') {
          r.then(data => resolver(null, data)).catch(resolver);
        } else {
          resolver(null, r);
        }
      } catch (err) {
        resolver(err);
      }
      return;
    }
    return fc(lng, ns, resolver);
  }
  prepareLoading(languages, namespaces, options = {}, callback) {
    if (!this.backend) {
      this.logger.warn('No backend was added via i18next.use. Will not load resources.');
      return callback && callback();
    }
    if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
    if (isString(namespaces)) namespaces = [namespaces];
    const toLoad = this.queueLoad(languages, namespaces, options, callback);
    if (!toLoad.toLoad.length) {
      if (!toLoad.pending.length) callback();
      return null;
    }
    toLoad.toLoad.forEach(name => {
      this.loadOne(name);
    });
  }
  load(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {}, callback);
  }
  reload(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {
      reload: true
    }, callback);
  }
  loadOne(name, prefix = '') {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    this.read(lng, ns, 'read', undefined, undefined, (err, data) => {
      if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
      if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
      this.loaded(name, err, data);
    });
  }
  saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
    if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
      this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
      return;
    }
    if (key === undefined || key === null || key === '') return;
    if (this.backend?.create) {
      const opts = {
        ...options,
        isUpdate
      };
      const fc = this.backend.create.bind(this.backend);
      if (fc.length < 6) {
        try {
          let r;
          if (fc.length === 5) {
            r = fc(languages, namespace, key, fallbackValue, opts);
          } else {
            r = fc(languages, namespace, key, fallbackValue);
          }
          if (r && typeof r.then === 'function') {
            r.then(data => clb(null, data)).catch(clb);
          } else {
            clb(null, r);
          }
        } catch (err) {
          clb(err);
        }
      } else {
        fc(languages, namespace, key, fallbackValue, clb, opts);
      }
    }
    if (!languages || !languages[0]) return;
    this.store.addResource(languages[0], namespace, key, fallbackValue);
  }
}

const get = () => ({
  debug: false,
  initAsync: true,
  ns: ['translation'],
  defaultNS: ['translation'],
  fallbackLng: ['dev'],
  fallbackNS: false,
  supportedLngs: false,
  nonExplicitSupportedLngs: false,
  load: 'all',
  preload: false,
  simplifyPluralSuffix: true,
  keySeparator: '.',
  nsSeparator: ':',
  pluralSeparator: '_',
  contextSeparator: '_',
  partialBundledLanguages: false,
  saveMissing: false,
  updateMissing: false,
  saveMissingTo: 'fallback',
  saveMissingPlurals: true,
  missingKeyHandler: false,
  missingInterpolationHandler: false,
  postProcess: false,
  postProcessPassResolved: false,
  returnNull: false,
  returnEmptyString: true,
  returnObjects: false,
  joinArrays: false,
  returnedObjectHandler: false,
  parseMissingKeyHandler: false,
  appendNamespaceToMissingKey: false,
  appendNamespaceToCIMode: false,
  overloadTranslationOptionHandler: args => {
    let ret = {};
    if (typeof args[1] === 'object') ret = args[1];
    if (isString(args[1])) ret.defaultValue = args[1];
    if (isString(args[2])) ret.tDescription = args[2];
    if (typeof args[2] === 'object' || typeof args[3] === 'object') {
      const options = args[3] || args[2];
      Object.keys(options).forEach(key => {
        ret[key] = options[key];
      });
    }
    return ret;
  },
  interpolation: {
    escapeValue: true,
    format: value => value,
    prefix: '{{',
    suffix: '}}',
    formatSeparator: ',',
    unescapePrefix: '-',
    nestingPrefix: '$t(',
    nestingSuffix: ')',
    nestingOptionsSeparator: ',',
    maxReplaces: 1000,
    skipOnVariables: true
  },
  cacheInBuiltFormats: true
});
const transformOptions = options => {
  if (isString(options.ns)) options.ns = [options.ns];
  if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
  if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
  if (options.supportedLngs?.indexOf?.('cimode') < 0) {
    options.supportedLngs = options.supportedLngs.concat(['cimode']);
  }
  if (typeof options.initImmediate === 'boolean') options.initAsync = options.initImmediate;
  return options;
};

const noop = () => {};
const bindMemberFunctions = inst => {
  const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
  mems.forEach(mem => {
    if (typeof inst[mem] === 'function') {
      inst[mem] = inst[mem].bind(inst);
    }
  });
};
const SUPPORT_NOTICE_KEY = '__i18next_supportNoticeShown';
const getSupportNoticeShown = () => {
  if (typeof globalThis !== 'undefined' && !!globalThis[SUPPORT_NOTICE_KEY]) return true;
  if (typeof process !== 'undefined' && process.env && process.env.I18NEXT_NO_SUPPORT_NOTICE) return true;
  if (typeof process !== 'undefined' && process.env && "production" === 'production') return true;
  return false;
};
const setSupportNoticeShown = () => {
  if (typeof globalThis !== 'undefined') globalThis[SUPPORT_NOTICE_KEY] = true;
};
const usesLocize = inst => {
  if (inst?.modules?.backend?.name?.indexOf('Locize') > 0) return true;
  if (inst?.modules?.backend?.constructor?.name?.indexOf('Locize') > 0) return true;
  if (inst?.options?.backend?.backends) {
    if (inst.options.backend.backends.some(b => b?.name?.indexOf('Locize') > 0 || b?.constructor?.name?.indexOf('Locize') > 0)) return true;
  }
  if (inst?.options?.backend?.projectId) return true;
  if (inst?.options?.backend?.backendOptions) {
    if (inst.options.backend.backendOptions.some(b => b?.projectId)) return true;
  }
  return false;
};
class I18n extends EventEmitter {
  constructor(options = {}, callback) {
    super();
    this.options = transformOptions(options);
    this.services = {};
    this.logger = baseLogger;
    this.modules = {
      external: []
    };
    bindMemberFunctions(this);
    if (callback && !this.isInitialized && !options.isClone) {
      if (!this.options.initAsync) {
        this.init(options, callback);
        return this;
      }
      setTimeout(() => {
        this.init(options, callback);
      }, 0);
    }
  }
  init(options = {}, callback) {
    this.isInitializing = true;
    if (typeof options === 'function') {
      callback = options;
      options = {};
    }
    if (options.defaultNS == null && options.ns) {
      if (isString(options.ns)) {
        options.defaultNS = options.ns;
      } else if (options.ns.indexOf('translation') < 0) {
        options.defaultNS = options.ns[0];
      }
    }
    const defOpts = get();
    this.options = {
      ...defOpts,
      ...this.options,
      ...transformOptions(options)
    };
    this.options.interpolation = {
      ...defOpts.interpolation,
      ...this.options.interpolation
    };
    if (options.keySeparator !== undefined) {
      this.options.userDefinedKeySeparator = options.keySeparator;
    }
    if (options.nsSeparator !== undefined) {
      this.options.userDefinedNsSeparator = options.nsSeparator;
    }
    if (typeof this.options.overloadTranslationOptionHandler !== 'function') {
      this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
    }
    if (this.options.showSupportNotice !== false && !usesLocize(this) && !getSupportNoticeShown()) {
      if (typeof console !== 'undefined' && typeof console.info !== 'undefined') console.info('🌐 i18next is made possible by our own product, Locize — consider powering your project with managed localization (AI, CDN, integrations): https://locize.com 💙');
      setSupportNoticeShown();
    }
    const createClassOnDemand = ClassOrObject => {
      if (!ClassOrObject) return null;
      if (typeof ClassOrObject === 'function') return new ClassOrObject();
      return ClassOrObject;
    };
    if (!this.options.isClone) {
      if (this.modules.logger) {
        baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
      } else {
        baseLogger.init(null, this.options);
      }
      let formatter;
      if (this.modules.formatter) {
        formatter = this.modules.formatter;
      } else {
        formatter = Formatter;
      }
      const lu = new LanguageUtil(this.options);
      this.store = new ResourceStore(this.options.resources, this.options);
      const s = this.services;
      s.logger = baseLogger;
      s.resourceStore = this.store;
      s.languageUtils = lu;
      s.pluralResolver = new PluralResolver(lu, {
        prepend: this.options.pluralSeparator,
        simplifyPluralSuffix: this.options.simplifyPluralSuffix
      });
      const usingLegacyFormatFunction = this.options.interpolation.format && this.options.interpolation.format !== defOpts.interpolation.format;
      if (usingLegacyFormatFunction) {
        this.logger.deprecate(`init: you are still using the legacy format function, please use the new approach: https://www.i18next.com/translation-function/formatting`);
      }
      if (formatter && (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)) {
        s.formatter = createClassOnDemand(formatter);
        if (s.formatter.init) s.formatter.init(s, this.options);
        this.options.interpolation.format = s.formatter.format.bind(s.formatter);
      }
      s.interpolator = new Interpolator(this.options);
      s.utils = {
        hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
      };
      s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
      s.backendConnector.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      if (this.modules.languageDetector) {
        s.languageDetector = createClassOnDemand(this.modules.languageDetector);
        if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
      }
      if (this.modules.i18nFormat) {
        s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
        if (s.i18nFormat.init) s.i18nFormat.init(this);
      }
      this.translator = new Translator(this.services, this.options);
      this.translator.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      this.modules.external.forEach(m => {
        if (m.init) m.init(this);
      });
    }
    this.format = this.options.interpolation.format;
    if (!callback) callback = noop;
    if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
      const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
      if (codes.length > 0 && codes[0] !== 'dev') this.options.lng = codes[0];
    }
    if (!this.services.languageDetector && !this.options.lng) {
      this.logger.warn('init: no languageDetector is used and no lng is defined');
    }
    const storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
    storeApi.forEach(fcName => {
      this[fcName] = (...args) => this.store[fcName](...args);
    });
    const storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
    storeApiChained.forEach(fcName => {
      this[fcName] = (...args) => {
        this.store[fcName](...args);
        return this;
      };
    });
    const deferred = defer();
    const load = () => {
      const finish = (err, t) => {
        this.isInitializing = false;
        if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn('init: i18next is already initialized. You should call init just once!');
        this.isInitialized = true;
        if (!this.options.isClone) this.logger.log('initialized', this.options);
        this.emit('initialized', this.options);
        deferred.resolve(t);
        callback(err, t);
      };
      if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
      this.changeLanguage(this.options.lng, finish);
    };
    if (this.options.resources || !this.options.initAsync) {
      load();
    } else {
      setTimeout(load, 0);
    }
    return deferred;
  }
  loadResources(language, callback = noop) {
    let usedCallback = callback;
    const usedLng = isString(language) ? language : this.language;
    if (typeof language === 'function') usedCallback = language;
    if (!this.options.resources || this.options.partialBundledLanguages) {
      if (usedLng?.toLowerCase() === 'cimode' && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
      const toLoad = [];
      const append = lng => {
        if (!lng) return;
        if (lng === 'cimode') return;
        const lngs = this.services.languageUtils.toResolveHierarchy(lng);
        lngs.forEach(l => {
          if (l === 'cimode') return;
          if (toLoad.indexOf(l) < 0) toLoad.push(l);
        });
      };
      if (!usedLng) {
        const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        fallbacks.forEach(l => append(l));
      } else {
        append(usedLng);
      }
      this.options.preload?.forEach?.(l => append(l));
      this.services.backendConnector.load(toLoad, this.options.ns, e => {
        if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
        usedCallback(e);
      });
    } else {
      usedCallback(null);
    }
  }
  reloadResources(lngs, ns, callback) {
    const deferred = defer();
    if (typeof lngs === 'function') {
      callback = lngs;
      lngs = undefined;
    }
    if (typeof ns === 'function') {
      callback = ns;
      ns = undefined;
    }
    if (!lngs) lngs = this.languages;
    if (!ns) ns = this.options.ns;
    if (!callback) callback = noop;
    this.services.backendConnector.reload(lngs, ns, err => {
      deferred.resolve();
      callback(err);
    });
    return deferred;
  }
  use(module) {
    if (!module) throw new Error('You are passing an undefined module! Please check the object you are passing to i18next.use()');
    if (!module.type) throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');
    if (module.type === 'backend') {
      this.modules.backend = module;
    }
    if (module.type === 'logger' || module.log && module.warn && module.error) {
      this.modules.logger = module;
    }
    if (module.type === 'languageDetector') {
      this.modules.languageDetector = module;
    }
    if (module.type === 'i18nFormat') {
      this.modules.i18nFormat = module;
    }
    if (module.type === 'postProcessor') {
      postProcessor.addPostProcessor(module);
    }
    if (module.type === 'formatter') {
      this.modules.formatter = module;
    }
    if (module.type === '3rdParty') {
      this.modules.external.push(module);
    }
    return this;
  }
  setResolvedLanguage(l) {
    if (!l || !this.languages) return;
    if (['cimode', 'dev'].indexOf(l) > -1) return;
    for (let li = 0; li < this.languages.length; li++) {
      const lngInLngs = this.languages[li];
      if (['cimode', 'dev'].indexOf(lngInLngs) > -1) continue;
      if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
        this.resolvedLanguage = lngInLngs;
        break;
      }
    }
    if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
      this.resolvedLanguage = l;
      this.languages.unshift(l);
    }
  }
  changeLanguage(lng, callback) {
    this.isLanguageChangingTo = lng;
    const deferred = defer();
    this.emit('languageChanging', lng);
    const setLngProps = l => {
      this.language = l;
      this.languages = this.services.languageUtils.toResolveHierarchy(l);
      this.resolvedLanguage = undefined;
      this.setResolvedLanguage(l);
    };
    const done = (err, l) => {
      if (l) {
        if (this.isLanguageChangingTo === lng) {
          setLngProps(l);
          this.translator.changeLanguage(l);
          this.isLanguageChangingTo = undefined;
          this.emit('languageChanged', l);
          this.logger.log('languageChanged', l);
        }
      } else {
        this.isLanguageChangingTo = undefined;
      }
      deferred.resolve((...args) => this.t(...args));
      if (callback) callback(err, (...args) => this.t(...args));
    };
    const setLng = lngs => {
      if (!lng && !lngs && this.services.languageDetector) lngs = [];
      const fl = isString(lngs) ? lngs : lngs && lngs[0];
      const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
      if (l) {
        if (!this.language) {
          setLngProps(l);
        }
        if (!this.translator.language) this.translator.changeLanguage(l);
        this.services.languageDetector?.cacheUserLanguage?.(l);
      }
      this.loadResources(l, err => {
        done(err, l);
      });
    };
    if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
      setLng(this.services.languageDetector.detect());
    } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
      if (this.services.languageDetector.detect.length === 0) {
        this.services.languageDetector.detect().then(setLng);
      } else {
        this.services.languageDetector.detect(setLng);
      }
    } else {
      setLng(lng);
    }
    return deferred;
  }
  getFixedT(lng, ns, keyPrefix) {
    const fixedT = (key, opts, ...rest) => {
      let o;
      if (typeof opts !== 'object') {
        o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
      } else {
        o = {
          ...opts
        };
      }
      o.lng = o.lng || fixedT.lng;
      o.lngs = o.lngs || fixedT.lngs;
      o.ns = o.ns || fixedT.ns;
      if (o.keyPrefix !== '') o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
      const selectorOpts = {
        ...this.options,
        ...o
      };
      if (typeof o.keyPrefix === 'function') o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
      const keySeparator = this.options.keySeparator || '.';
      let resultKey;
      if (o.keyPrefix && Array.isArray(key)) {
        resultKey = key.map(k => {
          if (typeof k === 'function') k = keysFromSelector(k, selectorOpts);
          return `${o.keyPrefix}${keySeparator}${k}`;
        });
      } else {
        if (typeof key === 'function') key = keysFromSelector(key, selectorOpts);
        resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
      }
      return this.t(resultKey, o);
    };
    if (isString(lng)) {
      fixedT.lng = lng;
    } else {
      fixedT.lngs = lng;
    }
    fixedT.ns = ns;
    fixedT.keyPrefix = keyPrefix;
    return fixedT;
  }
  t(...args) {
    return this.translator?.translate(...args);
  }
  exists(...args) {
    return this.translator?.exists(...args);
  }
  setDefaultNamespace(ns) {
    this.options.defaultNS = ns;
  }
  hasLoadedNamespace(ns, options = {}) {
    if (!this.isInitialized) {
      this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
      return false;
    }
    if (!this.languages || !this.languages.length) {
      this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
      return false;
    }
    const lng = options.lng || this.resolvedLanguage || this.languages[0];
    const fallbackLng = this.options ? this.options.fallbackLng : false;
    const lastLng = this.languages[this.languages.length - 1];
    if (lng.toLowerCase() === 'cimode') return true;
    const loadNotPending = (l, n) => {
      const loadState = this.services.backendConnector.state[`${l}|${n}`];
      return loadState === -1 || loadState === 0 || loadState === 2;
    };
    if (options.precheck) {
      const preResult = options.precheck(this, loadNotPending);
      if (preResult !== undefined) return preResult;
    }
    if (this.hasResourceBundle(lng, ns)) return true;
    if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
    if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
    return false;
  }
  loadNamespaces(ns, callback) {
    const deferred = defer();
    if (!this.options.ns) {
      if (callback) callback();
      return Promise.resolve();
    }
    if (isString(ns)) ns = [ns];
    ns.forEach(n => {
      if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
    });
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  loadLanguages(lngs, callback) {
    const deferred = defer();
    if (isString(lngs)) lngs = [lngs];
    const preloaded = this.options.preload || [];
    const newLngs = lngs.filter(lng => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng));
    if (!newLngs.length) {
      if (callback) callback();
      return Promise.resolve();
    }
    this.options.preload = preloaded.concat(newLngs);
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  dir(lng) {
    if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
    if (!lng) return 'rtl';
    try {
      const l = new Intl.Locale(lng);
      if (l && l.getTextInfo) {
        const ti = l.getTextInfo();
        if (ti && ti.direction) return ti.direction;
      }
    } catch (e) {}
    const rtlLngs = ['ar', 'shu', 'sqr', 'ssh', 'xaa', 'yhd', 'yud', 'aao', 'abh', 'abv', 'acm', 'acq', 'acw', 'acx', 'acy', 'adf', 'ads', 'aeb', 'aec', 'afb', 'ajp', 'apc', 'apd', 'arb', 'arq', 'ars', 'ary', 'arz', 'auz', 'avl', 'ayh', 'ayl', 'ayn', 'ayp', 'bbz', 'pga', 'he', 'iw', 'ps', 'pbt', 'pbu', 'pst', 'prp', 'prd', 'ug', 'ur', 'ydd', 'yds', 'yih', 'ji', 'yi', 'hbo', 'men', 'xmn', 'fa', 'jpr', 'peo', 'pes', 'prs', 'dv', 'sam', 'ckb'];
    const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
    if (lng.toLowerCase().indexOf('-latn') > 1) return 'ltr';
    return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf('-arab') > 1 ? 'rtl' : 'ltr';
  }
  static createInstance(options = {}, callback) {
    const instance = new I18n(options, callback);
    instance.createInstance = I18n.createInstance;
    return instance;
  }
  cloneInstance(options = {}, callback = noop) {
    const forkResourceStore = options.forkResourceStore;
    if (forkResourceStore) delete options.forkResourceStore;
    const mergedOptions = {
      ...this.options,
      ...options,
      ...{
        isClone: true
      }
    };
    const clone = new I18n(mergedOptions);
    if (options.debug !== undefined || options.prefix !== undefined) {
      clone.logger = clone.logger.clone(options);
    }
    const membersToCopy = ['store', 'services', 'language'];
    membersToCopy.forEach(m => {
      clone[m] = this[m];
    });
    clone.services = {
      ...this.services
    };
    clone.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    if (forkResourceStore) {
      const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
        prev[l] = {
          ...this.store.data[l]
        };
        prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
          acc[n] = {
            ...prev[l][n]
          };
          return acc;
        }, prev[l]);
        return prev;
      }, {});
      clone.store = new ResourceStore(clonedData, mergedOptions);
      clone.services.resourceStore = clone.store;
    }
    if (options.interpolation) {
      const defOpts = get();
      const mergedInterpolation = {
        ...defOpts.interpolation,
        ...this.options.interpolation,
        ...options.interpolation
      };
      const mergedForInterpolator = {
        ...mergedOptions,
        interpolation: mergedInterpolation
      };
      clone.services.interpolator = new Interpolator(mergedForInterpolator);
    }
    clone.translator = new Translator(clone.services, mergedOptions);
    clone.translator.on('*', (event, ...args) => {
      clone.emit(event, ...args);
    });
    clone.init(mergedOptions, callback);
    clone.translator.options = mergedOptions;
    clone.translator.backendConnector.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    return clone;
  }
  toJSON() {
    return {
      options: this.options,
      store: this.store,
      language: this.language,
      languages: this.languages,
      resolvedLanguage: this.resolvedLanguage
    };
  }
}
const instance = I18n.createInstance();

const {
  slice,
  forEach
} = [];
function defaults(obj) {
  forEach.call(slice.call(arguments, 1), source => {
    if (source) {
      for (const prop in source) {
        if (obj[prop] === undefined) obj[prop] = source[prop];
      }
    }
  });
  return obj;
}
function hasXSS(input) {
  if (typeof input !== 'string') return false;

  // Common XSS attack patterns
  const xssPatterns = [/<\s*script.*?>/i, /<\s*\/\s*script\s*>/i, /<\s*img.*?on\w+\s*=/i, /<\s*\w+\s*on\w+\s*=.*?>/i, /javascript\s*:/i, /vbscript\s*:/i, /expression\s*\(/i, /eval\s*\(/i, /alert\s*\(/i, /document\.cookie/i, /document\.write\s*\(/i, /window\.location/i, /innerHTML/i];
  return xssPatterns.some(pattern => pattern.test(input));
}

// eslint-disable-next-line no-control-regex
const fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
const serializeCookie = function (name, val) {
  let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
    path: '/'
  };
  const opt = options;
  const value = encodeURIComponent(val);
  let str = `${name}=${value}`;
  if (opt.maxAge > 0) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge)) throw new Error('maxAge should be a Number');
    str += `; Max-Age=${Math.floor(maxAge)}`;
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError('option domain is invalid');
    }
    str += `; Domain=${opt.domain}`;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError('option path is invalid');
    }
    str += `; Path=${opt.path}`;
  }
  if (opt.expires) {
    if (typeof opt.expires.toUTCString !== 'function') {
      throw new TypeError('option expires is invalid');
    }
    str += `; Expires=${opt.expires.toUTCString()}`;
  }
  if (opt.httpOnly) str += '; HttpOnly';
  if (opt.secure) str += '; Secure';
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === 'string' ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true:
        str += '; SameSite=Strict';
        break;
      case 'lax':
        str += '; SameSite=Lax';
        break;
      case 'strict':
        str += '; SameSite=Strict';
        break;
      case 'none':
        str += '; SameSite=None';
        break;
      default:
        throw new TypeError('option sameSite is invalid');
    }
  }
  if (opt.partitioned) str += '; Partitioned';
  return str;
};
const cookie = {
  create(name, value, minutes, domain) {
    let cookieOptions = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {
      path: '/',
      sameSite: 'strict'
    };
    if (minutes) {
      cookieOptions.expires = new Date();
      cookieOptions.expires.setTime(cookieOptions.expires.getTime() + minutes * 60 * 1000);
    }
    if (domain) cookieOptions.domain = domain;
    document.cookie = serializeCookie(name, value, cookieOptions);
  },
  read(name) {
    const nameEQ = `${name}=`;
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  },
  remove(name, domain) {
    this.create(name, '', -1, domain);
  }
};
var cookie$1 = {
  name: 'cookie',
  // Deconstruct the options object and extract the lookupCookie property
  lookup(_ref) {
    let {
      lookupCookie
    } = _ref;
    if (lookupCookie && typeof document !== 'undefined') {
      return cookie.read(lookupCookie) || undefined;
    }
    return undefined;
  },
  // Deconstruct the options object and extract the lookupCookie, cookieMinutes, cookieDomain, and cookieOptions properties
  cacheUserLanguage(lng, _ref2) {
    let {
      lookupCookie,
      cookieMinutes,
      cookieDomain,
      cookieOptions
    } = _ref2;
    if (lookupCookie && typeof document !== 'undefined') {
      cookie.create(lookupCookie, lng, cookieMinutes, cookieDomain, cookieOptions);
    }
  }
};

var querystring = {
  name: 'querystring',
  // Deconstruct the options object and extract the lookupQuerystring property
  lookup(_ref) {
    let {
      lookupQuerystring
    } = _ref;
    let found;
    if (typeof window !== 'undefined') {
      let {
        search
      } = window.location;
      if (!window.location.search && window.location.hash?.indexOf('?') > -1) {
        search = window.location.hash.substring(window.location.hash.indexOf('?'));
      }
      const query = search.substring(1);
      const params = query.split('&');
      for (let i = 0; i < params.length; i++) {
        const pos = params[i].indexOf('=');
        if (pos > 0) {
          const key = params[i].substring(0, pos);
          if (key === lookupQuerystring) {
            found = params[i].substring(pos + 1);
          }
        }
      }
    }
    return found;
  }
};

var hash = {
  name: 'hash',
  // Deconstruct the options object and extract the lookupHash property and the lookupFromHashIndex property
  lookup(_ref) {
    let {
      lookupHash,
      lookupFromHashIndex
    } = _ref;
    let found;
    if (typeof window !== 'undefined') {
      const {
        hash
      } = window.location;
      if (hash && hash.length > 2) {
        const query = hash.substring(1);
        if (lookupHash) {
          const params = query.split('&');
          for (let i = 0; i < params.length; i++) {
            const pos = params[i].indexOf('=');
            if (pos > 0) {
              const key = params[i].substring(0, pos);
              if (key === lookupHash) {
                found = params[i].substring(pos + 1);
              }
            }
          }
        }
        if (found) return found;
        if (!found && lookupFromHashIndex > -1) {
          const language = hash.match(/\/([a-zA-Z-]*)/g);
          if (!Array.isArray(language)) return undefined;
          const index = typeof lookupFromHashIndex === 'number' ? lookupFromHashIndex : 0;
          return language[index]?.replace('/', '');
        }
      }
    }
    return found;
  }
};

let hasLocalStorageSupport = null;
const localStorageAvailable = () => {
  if (hasLocalStorageSupport !== null) return hasLocalStorageSupport;
  try {
    hasLocalStorageSupport = typeof window !== 'undefined' && window.localStorage !== null;
    if (!hasLocalStorageSupport) {
      return false;
    }
    const testKey = 'i18next.translate.boo';
    window.localStorage.setItem(testKey, 'foo');
    window.localStorage.removeItem(testKey);
  } catch (e) {
    hasLocalStorageSupport = false;
  }
  return hasLocalStorageSupport;
};
var localStorage$1 = {
  name: 'localStorage',
  // Deconstruct the options object and extract the lookupLocalStorage property
  lookup(_ref) {
    let {
      lookupLocalStorage
    } = _ref;
    if (lookupLocalStorage && localStorageAvailable()) {
      return window.localStorage.getItem(lookupLocalStorage) || undefined; // Undefined ensures type consistency with the previous version of this function
    }
    return undefined;
  },
  // Deconstruct the options object and extract the lookupLocalStorage property
  cacheUserLanguage(lng, _ref2) {
    let {
      lookupLocalStorage
    } = _ref2;
    if (lookupLocalStorage && localStorageAvailable()) {
      window.localStorage.setItem(lookupLocalStorage, lng);
    }
  }
};

let hasSessionStorageSupport = null;
const sessionStorageAvailable = () => {
  if (hasSessionStorageSupport !== null) return hasSessionStorageSupport;
  try {
    hasSessionStorageSupport = typeof window !== 'undefined' && window.sessionStorage !== null;
    if (!hasSessionStorageSupport) {
      return false;
    }
    const testKey = 'i18next.translate.boo';
    window.sessionStorage.setItem(testKey, 'foo');
    window.sessionStorage.removeItem(testKey);
  } catch (e) {
    hasSessionStorageSupport = false;
  }
  return hasSessionStorageSupport;
};
var sessionStorage = {
  name: 'sessionStorage',
  lookup(_ref) {
    let {
      lookupSessionStorage
    } = _ref;
    if (lookupSessionStorage && sessionStorageAvailable()) {
      return window.sessionStorage.getItem(lookupSessionStorage) || undefined;
    }
    return undefined;
  },
  cacheUserLanguage(lng, _ref2) {
    let {
      lookupSessionStorage
    } = _ref2;
    if (lookupSessionStorage && sessionStorageAvailable()) {
      window.sessionStorage.setItem(lookupSessionStorage, lng);
    }
  }
};

var navigator$1 = {
  name: 'navigator',
  lookup(options) {
    const found = [];
    if (typeof navigator !== 'undefined') {
      const {
        languages,
        userLanguage,
        language
      } = navigator;
      if (languages) {
        // chrome only; not an array, so can't use .push.apply instead of iterating
        for (let i = 0; i < languages.length; i++) {
          found.push(languages[i]);
        }
      }
      if (userLanguage) {
        found.push(userLanguage);
      }
      if (language) {
        found.push(language);
      }
    }
    return found.length > 0 ? found : undefined;
  }
};

var htmlTag = {
  name: 'htmlTag',
  // Deconstruct the options object and extract the htmlTag property
  lookup(_ref) {
    let {
      htmlTag
    } = _ref;
    let found;
    const internalHtmlTag = htmlTag || (typeof document !== 'undefined' ? document.documentElement : null);
    if (internalHtmlTag && typeof internalHtmlTag.getAttribute === 'function') {
      found = internalHtmlTag.getAttribute('lang');
    }
    return found;
  }
};

var path = {
  name: 'path',
  // Deconstruct the options object and extract the lookupFromPathIndex property
  lookup(_ref) {
    let {
      lookupFromPathIndex
    } = _ref;
    if (typeof window === 'undefined') return undefined;
    const language = window.location.pathname.match(/\/([a-zA-Z-]*)/g);
    if (!Array.isArray(language)) return undefined;
    const index = typeof lookupFromPathIndex === 'number' ? lookupFromPathIndex : 0;
    return language[index]?.replace('/', '');
  }
};

var subdomain = {
  name: 'subdomain',
  lookup(_ref) {
    let {
      lookupFromSubdomainIndex
    } = _ref;
    // If given get the subdomain index else 1
    const internalLookupFromSubdomainIndex = typeof lookupFromSubdomainIndex === 'number' ? lookupFromSubdomainIndex + 1 : 1;
    // get all matches if window.location. is existing
    // first item of match is the match itself and the second is the first group match which should be the first subdomain match
    // is the hostname no public domain get the or option of localhost
    const language = typeof window !== 'undefined' && window.location?.hostname?.match(/^(\w{2,5})\.(([a-z0-9-]{1,63}\.[a-z]{2,6})|localhost)/i);

    // if there is no match (null) return undefined
    if (!language) return undefined;
    // return the given group match
    return language[internalLookupFromSubdomainIndex];
  }
};

// some environments, throws when accessing document.cookie
let canCookies = false;
try {
  canCookies = true;
  // eslint-disable-next-line no-empty
} catch (e) {}
const order = ['querystring', 'cookie', 'localStorage', 'sessionStorage', 'navigator', 'htmlTag'];
if (!canCookies) order.splice(1, 1);
const getDefaults = () => ({
  order,
  lookupQuerystring: 'lng',
  lookupCookie: 'i18next',
  lookupLocalStorage: 'i18nextLng',
  lookupSessionStorage: 'i18nextLng',
  // cache user language
  caches: ['localStorage'],
  excludeCacheFor: ['cimode'],
  // cookieMinutes: 10,
  // cookieDomain: 'myDomain'

  convertDetectedLanguage: l => l
});
class Browser {
  constructor(services) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    this.type = 'languageDetector';
    this.detectors = {};
    this.init(services, options);
  }
  init() {
    let services = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
      languageUtils: {}
    };
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    let i18nOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    this.services = services;
    this.options = defaults(options, this.options || {}, getDefaults());
    if (typeof this.options.convertDetectedLanguage === 'string' && this.options.convertDetectedLanguage.indexOf('15897') > -1) {
      this.options.convertDetectedLanguage = l => l.replace('-', '_');
    }

    // backwards compatibility
    if (this.options.lookupFromUrlIndex) this.options.lookupFromPathIndex = this.options.lookupFromUrlIndex;
    this.i18nOptions = i18nOptions;
    this.addDetector(cookie$1);
    this.addDetector(querystring);
    this.addDetector(localStorage$1);
    this.addDetector(sessionStorage);
    this.addDetector(navigator$1);
    this.addDetector(htmlTag);
    this.addDetector(path);
    this.addDetector(subdomain);
    this.addDetector(hash);
  }
  addDetector(detector) {
    this.detectors[detector.name] = detector;
    return this;
  }
  detect() {
    let detectionOrder = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.options.order;
    let detected = [];
    detectionOrder.forEach(detectorName => {
      if (this.detectors[detectorName]) {
        let lookup = this.detectors[detectorName].lookup(this.options);
        if (lookup && typeof lookup === 'string') lookup = [lookup];
        if (lookup) detected = detected.concat(lookup);
      }
    });
    detected = detected.filter(d => d !== undefined && d !== null && !hasXSS(d)).map(d => this.options.convertDetectedLanguage(d));
    if (this.services && this.services.languageUtils && this.services.languageUtils.getBestMatchFromCodes) return detected; // new i18next v19.5.0
    return detected.length > 0 ? detected[0] : null; // a little backward compatibility
  }
  cacheUserLanguage(lng) {
    let caches = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.options.caches;
    if (!caches) return;
    if (this.options.excludeCacheFor && this.options.excludeCacheFor.indexOf(lng) > -1) return;
    caches.forEach(cacheName => {
      if (this.detectors[cacheName]) this.detectors[cacheName].cacheUserLanguage(lng, this.options);
    });
  }
}
Browser.type = 'languageDetector';

const instruction$4 = {
	dragAndDrop: "Match the items by dragging and dropping them into the correct places.",
	mcq: "Select the correct answer from the options provided.",
	tracing: "Trace the shape by following the outline carefully.",
	flashcards: "Review the flashcards to reinforce your learning.",
	substractionWithImage: "substractionWithImageEngAudio",
	substractionWithoutImage: "substractionWithoutImageEngAudio",
	numberIdentificationWithImage: "numberIdentificationWithImageEngAudio",
	numberIdentificationWithoutImage: "numberIdentificationWithoutImageEngAudio",
	wordBuildingWithImage: "wordBuildingWithImageEngAudio",
	wordBuildingWithoutImage: "wordBuildingWithoutImageEngAudio",
	pictureClues: "pictureCluesEngAudio",
	pictureWordMatchMultipleImages: "pictureWordMatchMultipleImagesEngAudio",
	pictureWordMatchSingleImage: "pictureWordMatchSingleImageEngAudio",
	sentenceMatch: "sentenceMatchEngAudio",
	imageMatch: "imageMatchEngAudio",
	palStoryTale: "palStoryTaleEngAudio",
	palEgmaPatternMatching: "palEgmaPatternMatchingEngAudio",
	palEgmaWordProblemDragnDrop: "palEgmaWordProblemDragnDropEngAudio",
	palEgmaWordProblemClick: "palEgmaWordProblemClickEngAudio",
	palEgraOddOneOut: "palEgraOddOneOutEngAudio",
	palEgraArrangePictures: "palEgraArrangePicturesEngAudio",
	palEgraBuildWord: "palEgraBuildWordEngAudio",
	palEgraWordFormation: "palEgraWordFormationEngAudio",
	palInventedSpelling: "palInventedSpellingEngAudio",
	palLetterIdentification: "palLetterIdentificationEngAudio",
	palStoryMaking: "palStoryMakingEngAudio",
	palegmasumtogether: "palegmasumtogetherEngAudio",
	palegmamultioption: "palegmamultioptionEngAudio",
	palegraoptionaudio: "palegraoptionaudioEngAudio",
	palegrawordmatch: "palegrawordmatchEngAudio",
	palegramcqimages: "palegramcqimagesEngAudio"
};
var en = {
	"Do you want to exit? button": "Do you want to exit?",
	"Exit button": "Exit",
	"Continue playing button": "Continue playing",
	"Drop the elements to match the given symbol order": "Drop the elements to match the given symbol order",
	"Fill  in  the  blanks": "Fill  in  the  blanks",
	instruction: instruction$4
};

const instruction$3 = {
	dragAndDrop: "Faites glisser les objets vers le bon emplacement.",
	mcq: "Choisissez la bonne réponse parmi les options proposées.",
	tracing: "Tracez soigneusement la forme en suivant la ligne.",
	flashcards: "Regardez les cartes mémoire pour renforcer l’apprentissage."
};
var fr = {
	"Do you want to exit? button": "Voulez-vous quitter?",
	"Exit button": "Quitter",
	"Continue playing button": "Continuer à jouer",
	"Drop the elements to match the given symbol order": "Déposez les éléments pour correspondre au symbole donné",
	"Fill  in  the  blanks": "Remplissez les blancs",
	instruction: instruction$3
};

const instruction$2 = {
	dragAndDrop: "Match the items by dragging and dropping them into the correct places.",
	mcq: "Select the correct answer from the options provided.",
	tracing: "Trace the shape by following the outline carefully.",
	flashcards: "Review the flashcards to reinforce your learning.",
	substractionWithImage: "substractionWithImageHiAudio",
	substractionWithoutImage: "substractionWithoutImageHiAudio",
	numberIdentificationWithImage: "numberIdentificationWithImageHiAudio",
	numberIdentificationWithoutImage: "numberIdentificationWithoutImageHiAudio",
	wordBuildingWithImage: "wordBuildingWithImageHiAudio",
	wordBuildingWithoutImage: "wordBuildingWithoutImageHiAudio",
	pictureClues: "pictureCluesHiAudio",
	pictureWordMatchMultipleImages: "pictureWordMatchMultipleImagesHiAudio",
	pictureWordMatchSingleImage: "pictureWordMatchSingleImageHiAudio",
	sentenceMatch: "sentenceMatchHiAudio",
	imageMatch: "imageMatchHiAudio",
	palStoryTale: "palStoryTaleHiAudio",
	palEgmaPatternMatching: "palEgmaPatternMatchingHiAudio",
	palEgmaWordProblemDragnDrop: "palEgmaWordProblemDragnDropHiAudio",
	palEgmaWordProblemClick: "palEgmaWordProblemClickHiAudio",
	palEgraOddOneOut: "palEgraOddOneOutHiAudio",
	palEgraArrangePictures: "palEgraArrangePicturesHiAudio",
	palEgraBuildWord: "palEgraBuildWordHiAudio",
	palEgraWordFormation: "palEgraWordFormationHiAudio",
	palInventedSpelling: "palInventedSpellingHiAudio",
	palLetterIdentification: "palLetterIdentificationHiAudio",
	palStoryMaking: "palStoryMakingHiAudio",
	palegmasumtogether: "palegmasumtogetherHiAudio",
	palegmamultioption: "palegmamultioptionHiAudio",
	palegraoptionaudio: "palegraoptionaudioHiAudio",
	palegrawordmatch: "palegrawordmatchHiAudio",
	palegramcqimages: "palegramcqimagesHiAudio"
};
var hi = {
	"Do you want to exit? button": "क्या आप बाहर निकलना चाहते हैं?",
	"Exit button": "बाहर निकलें",
	"Continue playing button": "खेलना जारी रखें",
	"Drop the elements to match the given symbol order": "दिए गए चिन्ह से मिलाने के लिए तत्वों को ड्रॉप करें",
	"Fill  in  the  blanks": "रिक्त स्थान भरें",
	instruction: instruction$2
};

const instruction$1 = {
	dragAndDrop: "Match the items by dragging and dropping them into the correct places.",
	mcq: "Select the correct answer from the options provided.",
	tracing: "Trace the shape by following the outline carefully.",
	flashcards: "Review the flashcards to reinforce your learning.",
	substractionWithImage: "substractionWithImageKaAudio",
	substractionWithoutImage: "substractionWithoutImageKaAudio",
	numberIdentificationWithImage: "numberIdentificationWithImageKaAudio",
	numberIdentificationWithoutImage: "numberIdentificationWithoutImageKaAudio",
	wordBuildingWithImage: "wordBuildingWithImageKaAudio",
	wordBuildingWithoutImage: "wordBuildingWithoutImageKaAudio",
	pictureClues: "pictureCluesKaAudio",
	pictureWordMatchMultipleImages: "pictureWordMatchMultipleImagesKaAudio",
	pictureWordMatchSingleImage: "pictureWordMatchSingleImageKaAudio",
	sentenceMatch: "sentenceMatchKaAudio",
	imageMatch: "imageMatchKaAudio",
	palStoryTale: "palStoryTaleKaAudio",
	palEgmaPatternMatching: "palEgmaPatternMatchingKaAudio",
	palEgmaWordProblemDragnDrop: "palEgmaWordProblemDragnDropKaAudio",
	palEgmaWordProblemClick: "palEgmaWordProblemClickKaAudio",
	palEgraOddOneOut: "palEgraOddOneOutKaAudio",
	palEgraArrangePictures: "palEgraArrangePicturesKaAudio",
	palEgraBuildWord: "palEgraBuildWordKaAudio",
	palEgraWordFormation: "palEgraWordFormationKaAudio",
	palInventedSpelling: "palInventedSpellingKaAudio",
	palLetterIdentification: "palLetterIdentificationKaAudio",
	palStoryMaking: "palStoryMakingKaAudio",
	palegmasumtogether: "palegmasumtogetherKaAudio",
	palegmamultioption: "palegmamultioptionKaAudio",
	palegraoptionaudio: "palegraoptionaudioKaAudio",
	palegrawordmatch: "palegrawordmatchKaAudio",
	palegramcqimages: "palegramcqimagesKaAudio"
};
var kn = {
	"Do you want to exit? button": "ನೀವು ನಿರ್ಗಮಿಸಲು ಬಯಸುವಿರಾ?",
	"Exit button": "ನಿರ್ಗಮಿಸು",
	"Continue playing button": "ಆಟವನ್ನು ಮುಂದುವರಿಸಿ",
	"Drop the elements to match the given symbol order": "ನೀಡಿರುವ ಸಂಕೇತಕ್ಕೆ ಹೊಂದುವಂತೆ ಅಂಶಗಳನ್ನು ಬಿಡಿ",
	"Fill  in  the  blanks": "ಖಾಲಿ ಸ್ಥಳಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ",
	instruction: instruction$1
};

var te = {
	"Do you want to exit? button": "మీరు బయటకు వెళ్లాలనుకుంటున్నారా?",
	"Exit button": "బయటకు వెళ్ళు",
	"Continue playing button": "ఆటను కొనసాగించు",
	"Drop the elements to match the given symbol order": "ఇచ్చిన చిహ్నానికి సరిపడేలా అంశాలను డ్రాప్ చేయಂడಿ",
	"Fill  in  the  blanks": "ಖಾಲಿ ಸ್ಥಳಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ"
};

var pt = {
	"Do you want to exit? button": "Você deseja sair?",
	"Exit button": "Sair",
	"Continue playing button": "Continuar jogando",
	"Drop the elements to match the given symbol order": "Solte os elementos para corresponder à ordem dos símbolos fornecida",
	"Fill  in  the  blanks": "Preencha os espaços em branco"
};

const instruction = {
	dragAndDrop: "वस्तू योग्य ठिकाणी ओढून आणि सोडून जुळवा.",
	mcq: "दिलेल्या पर्यायांमधून योग्य उत्तर निवडा.",
	tracing: "रेषेचा काळजीपूर्वक मागोवा घेत आकृती काढा.",
	flashcards: "तुमचे शिक्षण मजबूत करण्यासाठी फ्लॅशकार्ड्स पाहा."
};
var mr = {
	"Do you want to exit? button": "तुम्हाला बाहेर पडायचे आहे का?",
	"Exit button": "बाहेर पडा",
	"Continue playing button": "खेळ सुरू ठेवा",
	instruction: instruction
};

instance
    .use(Browser)
    .init({
    resources: {
        en: { translation: en },
        fr: { translation: fr },
        hi: { translation: hi },
        kn: { translation: kn },
        te: { translation: te },
        pt: { translation: pt },
        mr: { translation: mr },
    },
    fallbackLng: 'en', // fallback if current lang not found
    debug: false,
    interpolation: {
        escapeValue: false, // Stencil already handles escaping
    },
    detection: {
        // optional: tune detection logic
        order: ['querystring', 'localStorage', 'navigator', 'htmlTag'],
        caches: ['localStorage'],
    },
});

const lidoContainerCss = () => `.lido-container{position:relative;height:100%;width:100%;background-color:var(--bgColor, transparent);display:flex;flex-direction:column;justify-content:center;align-items:center}lido-container[template-id="writeCard"] #arrow{box-sizing:border-box;border:10px solid transparent;box-shadow:0px 8px 0px 0px #8b310f;animation:flash-card-next-attention 1.4s ease-in-out infinite}lido-container[template-id="writeCard"] #arrow.fading{opacity:1 !important}@keyframes flash-card-next-attention{0%,100%{border-color:#ffc34d;filter:drop-shadow(0 0 0 rgba(255, 195, 77, 0))}50%{border-color:#fff1a8;filter:drop-shadow(0 0 10px rgba(255, 195, 77, 0.95))}}`;

const LidoContainer = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Language to apply to all texts */
        this.Lang = '';
        /**
         * Controls whether the drop zone displays a border; true shows the border, false hides it.
         */
        this.showDropBorder = true;
        /**
         * Enables appending the dragged element to the drop target after all correct drops are completed.
         */
        this.appendToDropOnCompletion = false;
        /**
         * Unique identifier for the container.
         */
        this.id = '';
        /**
         * Objective or purpose of the container. Can be used for internal logic or tracking.
         */
        this.objective = '';
        /**
         * Custom CSS styles to be applied to the container.
         * Allows for dynamic styling through inline styles or class names.
         */
        this.customStyle = '';
        /**
         * Value assigned to the container. This can be used for logic related to this component.
         */
        this.value = '';
        /**
         * The height of the container (CSS value).
         */
        this.height = 'auto';
        /**
         * The width of the container (CSS value).
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = 'auto';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the container.
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the container.
         */
        this.y = '0px';
        /**
         * Z-index to control the stacking order of the container.
         */
        this.z = '0';
        /**
         * Background color of the container (CSS color value).
         */
        this.bgColor = '';
        /**
         * The background image URL to be applied to the entire body.
         */
        this.bgImage = '';
        /**
         * Type of the container, which can be used for conditional logic or styling purposes.
         */
        this.type = '';
        /**
         * TabIndex for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Visibility flag for the container. If `true`, the container is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier of an audio file associated with the container.
         */
        this.audio = '';
        /**
         * Event handler triggered when the container is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the container is entered, useful for triggering animations or logic.
         */
        this.onEntry = '';
        /**
         * Boolean that controls the playability of the game.
         */
        this.canplay = true;
        /**
         * Indicates whether the "Check" button should be visible or not. Expected values: "true" or "false".
         */
        this.showCheck = false;
        /**
         * Specifies whether the activity should continue automatically upon a correct response. Expected values: "true" or "false".
         */
        this.isContinueOnCorrect = false;
        /**
         * Determines if the activity should proceed automatically only after a correct response.
         * Acceptable values: "true" or "false". Defaults to "false".
         */
        this.isAllowOnlyCorrect = false;
        /**
         * Base URL for the container.
         */
        this.baseUrl = '';
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Indicates whether the previous button should be displayed. Expected values: "true" or "false".
         */
        this.showPrevButton = 'false';
        /**
         * Indicates whether the next button should be displayed. Expected values: "true" or "false".
         */
        this.showNextButton = 'false';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and all its child components.
         */
        this.disableSpeak = false;
        /**
         * Identifies the template type used by this component (e.g., mcq, flashcard, tracing, dragAndDrop).
         */
        this.templateId = '';
        /**
         * When set to true, highlights each word individually during speech playback.
         */
        this.highlightWordByWord = false;
        /**
         * Stores the instruction audio/text key based on the current template.
         */
        this.instructName = '';
        /**
         * Indicates whether the speak action is currently active or in progress.
         */
        this.speakFlag = false;
        this.handleWindowResize = () => this.scaleContainer(this.el);
        this.handleWindowLoad = () => this.scaleContainer(this.el);
        this.isWriteCardContainer = () => this.templateId === 'writeCard';
        this.syncWriteCardArrowHighlight = () => {
            if (!this.isWriteCardContainer())
                return;
            const arrow = this.el.querySelector('#arrow');
            if (!arrow)
                return;
            const style = window.getComputedStyle(arrow);
            const hidden = style.display === 'none' ||
                style.visibility === 'hidden' ||
                style.opacity === '0';
            arrow.classList.toggle('flash-card-next-glowing', !hidden);
        };
        this.observeWriteCardArrow = () => {
            var _a;
            if (!this.isWriteCardContainer())
                return;
            (_a = this.writeCardArrowObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
            this.writeCardArrowObserver = new MutationObserver(() => this.syncWriteCardArrowHighlight());
            this.writeCardArrowObserver.observe(this.el, {
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'style', 'visible'],
            });
            this.syncWriteCardArrowHighlight();
        };
    }
    cleanupInteractionHandlers() {
        this.el.querySelectorAll('[type="drag"], [type="slide"], [move="true"]').forEach(element => {
            element.dispatchEvent(new Event(LIDO_INTERACTION_CLEANUP_EVENT));
        });
    }
    languageChanged(newLang) {
        const langToApply = newLang || this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
    }
    componentWillLoad() {
        const langToApply = this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
        this.resolveInstructionAudio();
    }
    resolveInstructionAudio() {
        var _a;
        this.instructName =
            (_a = {
                flashcard: "instruction.flashcards" /* templateAudio.flashcards */,
                mcq: "instruction.mcq" /* templateAudio.mcq */,
                tracing: "instruction.tracing" /* templateAudio.tracing */,
                dragAndDrop: "instruction.dragAndDrop" /* templateAudio.dragAndDrop */,
                "arrangeLetters": "arrangeLetters" /* templateAudio.arrangeLetters */,
                "balancing": "balancing" /* templateAudio.balancing */,
                "balloonPop": "balloonPop" /* templateAudio.balloonPop */,
                "blender": "blender" /* templateAudio.blender */,
                "bubbleType": "bubbleType" /* templateAudio.bubbleType */,
                "calculator": "calculator" /* templateAudio.calculator */,
                "categorize": "categorize" /* templateAudio.categorize */,
                "checkerBlocks": "checkerBlocks" /* templateAudio.checkerBlocks */,
                "createSentence": "createSentence" /* templateAudio.createSentence */,
                "fillAnswer": "fillAnswer" /* templateAudio.fillAnswer */,
                "fillBlank": "fillBlank" /* templateAudio.fillBlank */,
                "fillUp": "fillUp" /* templateAudio.fillUp */,
                "flashcardtemplate": "flashcard" /* templateAudio.flashcardtemplate */,
                "foodJar": "foodJar" /* templateAudio.foodJar */,
                "grid": "grid" /* templateAudio.grid */,
                "imageMatchWithQuestionImageAndMultiOption": "imageMatchWithQuestionImageAndMultiOption" /* templateAudio.imageMatchWithQuestionImageAndMultiOption */,
                "inventedSpelling": "inventedSpelling" /* templateAudio.inventedSpelling */,
                "jumpSentence": "jumpSentence" /* templateAudio.jumpSentence */,
                "letterBoard": "letterBoard" /* templateAudio.letterBoard */,
                "letterIdentification": "letterIdentification" /* templateAudio.letterIdentification */,
                "letterPairing": "letterPairing" /* templateAudio.letterPairing */,
                "makeSentence": "makeSentence" /* templateAudio.makeSentence */,
                "matchingCard": "matchingCard" /* templateAudio.matchingCard */,
                "multiplyBeeds": "multiplyBeeds" /* templateAudio.multiplyBeeds */,
                "nimbleTable": "nimbleTable" /* templateAudio.nimbleTable */,
                "numberBoardOneTwo": "numberBoardOneTwo" /* templateAudio.numberBoardOneTwo */,
                "numberPair": "numberPair" /* templateAudio.numberPair */,
                "openWindow": "openWindow" /* templateAudio.openWindow */,
                "orderTractor": "orderTractor" /* templateAudio.orderTractor */,
                "phonicTractor": "phonicTractor" /* templateAudio.phonicTractor */,
                "pictureMeaningCocos": "pictureMeaningCocos" /* templateAudio.pictureMeaningCocos */,
                "pictureWordMatch1": "pictureWordMatch1" /* templateAudio.pictureWordMatch1 */,
                "pictureWordMatch2": "pictureWordMatch2" /* templateAudio.pictureWordMatch2 */,
                "puzzleGame": "puzzleGame" /* templateAudio.puzzleGame */,
                "questionBoard": "questionBoard" /* templateAudio.questionBoard */,
                "quizLiteracySentenceSentence": "quizLiteracySentenceSentence" /* templateAudio.quizLiteracySentenceSentence */,
                "quizLiteracySoundOnlyImage": "quizLiteracySoundOnlyImage" /* templateAudio.quizLiteracySoundOnlyImage */,
                "quizLiteracySoundOnlySentence": "quizLiteracySoundOnlySentence" /* templateAudio.quizLiteracySoundOnlySentence */,
                "quizLiteracySoundOnlyWord": "quizLiteracySoundonlyWord" /* templateAudio.quizLiteracySoundOnlyWord */,
                "quizLiteracyAndShapes1": "quizLiteracyAndShapes1" /* templateAudio.quizLiteracyAndShapes1 */,
                "quizLiteracyImageWithText": "quizLiteracyImageWithText" /* templateAudio.quizLiteracyImageWithText */,
                "quizliteracyImageWord": "quizliteracyImageWord" /* templateAudio.quizliteracyImageWord */,
                "quizMathBiggerAndSmaller": "quizMathBiggerAndSmaller" /* templateAudio.quizMathBiggerAndSmaller */,
                "quizMathBiggestAndSmallest": "quizMathBiggestAndSmallest" /* templateAudio.quizMathBiggestAndSmallest */,
                "quizmathCustomNumberMagnitude": "quizmathCustomNumberMagnitude" /* templateAudio.quizmathCustomNumberMagnitude */,
                "quizMathHowMany": "quizMathHowMany" /* templateAudio.quizMathHowMany */,
                "quizmathMissingnumberDrag": "quizmathMissingnumberDrag" /* templateAudio.quizmathMissingnumberDrag */,
                "quizMathNumberIdentification": "quizMathNumberIdentification" /* templateAudio.quizMathNumberIdentification */,
                "quizMathOperationWithobjects": "quizMathOperationWithobjects" /* templateAudio.quizMathOperationWithobjects */,
                "quizMathoperationWithoutObjects": "quizMathoperationWithoutObjects" /* templateAudio.quizMathoperationWithoutObjects */,
                "quizMathRecognizeNumber": "quizMathRecognizeNumber" /* templateAudio.quizMathRecognizeNumber */,
                "quizMathShapes": "quizMathShapes" /* templateAudio.quizMathShapes */,
                "reorder": "reorder" /* templateAudio.reorder */,
                "rocketGame": "rocketGame" /* templateAudio.rocketGame */,
                "rowBlock": "rowBlock" /* templateAudio.rowBlock */,
                "sequenceBox1": "sequenceBox1" /* templateAudio.sequenceBox1 */,
                "shapeTractor": "shapeTractor" /* templateAudio.shapeTractor */,
                "spellDoor": "spellDoor" /* templateAudio.spellDoor */,
                "storyMaking": "storyMaking" /* templateAudio.storyMaking */,
                "storyTale": "storyTale" /* templateAudio.storyTale */,
                "sumTogether": "sumTogether" /* templateAudio.sumTogether */,
                "tag": "tag" /* templateAudio.tag */,
                "total": "total" /* templateAudio.total */,
                "writeCard": "writeCard" /* templateAudio.writeCard */,
                "writeLetter": "writeLetter" /* templateAudio.writeLetter */,
                "writeNumber": "writeNumber" /* templateAudio.writeNumber */,
                "writeSet": "writeSet" /* templateAudio.writeSet */,
                "writeWord": "writeWord" /* templateAudio.writeWord */,
                "numberIdentification": "numberIdentification" /* templateAudio.numberIdentification */,
                "wordBuildingWithAndWithoutImage": "wordBuildingWithAndWithoutImage" /* templateAudio.wordBuildingWithAndWithoutImage */,
                "subsWithAndWithoutImage": "subsWithAndWithoutImage" /* templateAudio.subsWithAndWithoutImage */,
                "sentenceMatchTemplate": "sentenceMatch" /* templateAudio.sentenceMatchTemplate */,
                "pictureClues": "pictureClues" /* templateAudio.pictureClues */,
                "palEgmaCalculateSumAndSumTogether": "palEgmaCalculateSumAndSumTogether" /* templateAudio.palEgmaCalculateSumAndSumTogether */,
                "palEgmaPatternMatching": "palEgmaPatternMatchingAudio" /* templateAudio.palEgmaPatternMatching */,
                "palEgmaWordProblem": "palEgmaWordProblem" /* templateAudio.palEgmaWordProblem */,
                "palEgraArrangePictures": "palEgraArrangePicturesAudio" /* templateAudio.palEgraArrangePictures */,
                "palEgraBuildWord": "palEgraBuildWordAudio" /* templateAudio.palEgraBuildWord */,
                "palEgraMCQWithImage": "palEgraMCQWithImage" /* templateAudio.palEgraMCQWithImage */,
                "palEgraOddOneOut": "palEgraOddOneOutAudio" /* templateAudio.palEgraOddOneOut */,
                "palEgraOptionWithAudio": "palEgraOptionWithAudio" /* templateAudio.palEgraOptionWithAudio */,
                "palEgraWordFormation": "palEgraWordFormationAudio" /* templateAudio.palEgraWordFormation */,
                "palEgraWordMatch": "palEgraWordMatch" /* templateAudio.palEgraWordMatch */,
                "substractionWithImage": "substractionWithImageAudio" /* templateAudio.substractionWithImage */,
                "substractionWithoutImage": "substractionWithoutImageAudio" /* templateAudio.substractionWithoutImage */,
                "numberIdentificationWithImage": "numberIdentificationWithImageAudio" /* templateAudio.numberIdentificationWithImage */,
                "numberIdentificationWithoutImage": "numberIdentificationWithoutImageAudio" /* templateAudio.numberIdentificationWithoutImage */,
                "wordBuildingWithImage": "wordBuildingWithImageAudio" /* templateAudio.wordBuildingWithImage */,
                "wordBuildingWithoutImage": "wordBuildingWithoutImageAudio" /* templateAudio.wordBuildingWithoutImage */,
                "pictureWordMatchMultipleImages": "pictureWordMatchMultipleImagesAudio" /* templateAudio.pictureWordMatchMultipleImages */,
                "pictureWordMatchSingleImage": "pictureWordMatchSingleImageAudio" /* templateAudio.pictureWordMatchSingleImage */,
                "sentenceMatch": "sentenceMatchAudio" /* templateAudio.sentenceMatch */,
                "imageMatch": "imageMatchAudio" /* templateAudio.imageMatch */,
                "palStoryTale": "palStoryTaleAudio" /* templateAudio.palStoryTale */,
                "palEgmaWordProblemDragnDrop": "palEgmaWordProblemDragnDropAudio" /* templateAudio.palEgmaWordProblemDragnDrop */,
                "palEgmaWordProblemClick": "palEgmaWordProblemClickAudio" /* templateAudio.palEgmaWordProblemClick */,
                "palInventedSpelling": "palInventedSpellingAudio" /* templateAudio.palInventedSpelling */,
                "palLetterIdentification": "palLetterIdentificationAudio" /* templateAudio.palLetterIdentification */,
                "palStoryMaking": "palStoryMakingAudio" /* templateAudio.palStoryMaking */,
                "palegmasumtogether": "palegmasumtogetherAudio" /* templateAudio.palegmasumtogether */,
                "palegmamultioption": "palegmamultioptionAudio" /* templateAudio.palegmamultioption */,
                "palegraoptionaudio": "palegraoptionAudio" /* templateAudio.palegraoptionaudio */,
                "palegrawordmatch": "palegrawordmatchAudio" /* templateAudio.palegrawordmatch */,
                "palegramcqimages": "palegramcqimagesAudio" /* templateAudio.palegramcqimages */,
                "drawShape": "drawshape" /* templateAudio.drawShape */,
                "drawshape": "drawshape" /* templateAudio.drawshape */,
            }[this.templateId]) !== null && _a !== void 0 ? _a : '';
        const home = document.querySelector('lido-home');
        if (!home)
            return;
        const existing = home.getAttribute(TemplateID) || '';
        this.speakFlag = existing.includes(this.templateId);
        if (!this.speakFlag) {
            home.setAttribute(TemplateID, [existing, this.templateId].filter(Boolean).join(','));
        }
    }
    resolveLanguage() {
        var _a, _b;
        const rootEl = this.el.closest('lido-root');
        const rootLang = (rootEl === null || rootEl === void 0 ? void 0 : rootEl.Lang) || '';
        if (rootLang === null || rootLang === void 0 ? void 0 : rootLang.trim())
            return rootLang;
        if ((_a = this.Lang) === null || _a === void 0 ? void 0 : _a.trim())
            return this.Lang;
        const xmlLang = this.el.getAttribute('Lang');
        if (xmlLang === null || xmlLang === void 0 ? void 0 : xmlLang.trim())
            return xmlLang;
        return (_b = this.el.textContent) === null || _b === void 0 ? void 0 : _b.trim();
    }
    convertToPixels(height, parentElement = document.body) {
        if (!height)
            return 0; // Handle empty or invalid input
        // Directly return numbers if already in pixels
        if (height.endsWith('px')) {
            return parseFloat(height);
        }
        // Convert relative units
        const tempElement = document.createElement('div');
        tempElement.style.position = 'absolute';
        tempElement.style.visibility = 'hidden';
        tempElement.style.height = height;
        parentElement.appendChild(tempElement);
        const computedHeight = tempElement.offsetHeight;
        parentElement.removeChild(tempElement);
        return computedHeight;
    }
    /**
     * Scales the container based on the window or screen size, maintaining the aspect ratio.
     * The container scales according to the minimum dimension of the screen.
     *
     * @param container The container element to be scaled.
     */
    scaleContainer(container) {
        // Calculate the scale factor based on the closest parent element's width and height (1600x900 reference)
        const parentElement = this.getClosestParentWithWidth();
        let scaleFactor = 0;
        if (parentElement) {
            const parentWidth = parentElement.clientWidth;
            const parentHeight = parentElement.clientHeight;
            const scaleX = parentWidth / 1600;
            const scaleY = parentHeight / 900;
            scaleFactor = Math.min(scaleX, scaleY);
        }
        // Center the container and apply scaling
        container.style.transform = `translate(-50%, -50%) scale(${scaleFactor != 0 ? scaleFactor : calculateScale()})`;
        container.style.left = '50%';
        container.style.top = '50%';
        container.style.position = 'absolute'; // Ensure proper positioning
        this.screenOrientation();
    }
    // Find and return the nearest parent element that has a measurable (non-zero) width
    getClosestParentWithWidth() {
        let parent = this.el.parentElement;
        while (parent) {
            if (parent.offsetWidth > 0) {
                return parent;
            }
            parent = parent.parentElement;
        }
        return null;
    }
    screenOrientation() {
        if (window.innerHeight > window.innerWidth) {
            this.el.style.height = '1600px';
            this.el.style.width = '900px';
        }
        else {
            this.el.style.height = '900px';
            this.el.style.width = '1600px';
        }
    }
    updateChildTextLanguage(lang) {
        const appliedLang = lang || instance.language || 'en';
        instance.changeLanguage(appliedLang);
        const texts = this.el.querySelectorAll('lido-text');
        texts.forEach((textEl) => {
            textEl.Lang = appliedLang;
            textEl.dispatchEvent(new CustomEvent('languageChanged', { bubbles: true }));
        });
    }
    /**
     * Lifecycle hook that runs after the component is loaded.
     * - It scales the container.
     * - It sets the background color of the body.
     * - Adds event listeners for `resize` and `load` to rescale the container on window size changes.
     */
    componentDidLoad() {
        this.scaleContainer(this.el);
        const backGroundImage = this.bgImage ? convertUrlToRelative(this.bgImage) : '';
        const standalone = this.el.closest('lido-standalone');
        const backgroundTarget = (standalone === null || standalone === void 0 ? void 0 : standalone.getAttribute('bg-image')) === 'true' ? standalone : document.body;
        backgroundTarget.style.backgroundColor = this.bgColor;
        backgroundTarget.style.backgroundImage = backGroundImage ? `url(${backGroundImage})` : 'none';
        backgroundTarget.style.backgroundPosition = backGroundImage ? 'bottom' : 'none';
        document.body.style.pointerEvents = 'auto';
        // Re-scale the container on window resize or load events
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
        if (this.templateId) {
            setTimeout(() => {
                this.el.setAttribute("onEntry", `${this.templateId}.speak='${!this.speakFlag}'; ` + this.el.getAttribute("onEntry"));
                initEventsForElement(this.el, this.type);
                this.observeWriteCardArrow();
            }, 100);
        }
        else {
            initEventsForElement(this.el, this.type);
            this.observeWriteCardArrow();
        }
        if (this.customStyle) {
            const styleElement = document.createElement('style');
            styleElement.innerHTML = this.customStyle;
            document.head.appendChild(styleElement);
        }
        const langToApply = this.resolveLanguage();
        this.updateChildTextLanguage(langToApply);
        setTimeout(() => {
            highlightElement();
        }, 100);
        resetFloatState();
        Timer.getI().start();
    }
    disconnectedCallback() {
        var _a;
        this.cleanupInteractionHandlers();
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
        (_a = this.writeCardArrowObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
        this.writeCardArrowObserver = undefined;
        document.body.style.backgroundColor = '';
        document.body.style.backgroundImage = '';
        resetFloatState();
        Timer.getI().stop();
    }
    render() {
        // Define the styles for the container element
        const style = {
            backgroundColor: this.bgColor,
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)', // Centering the container
            margin: this.margin,
            userSelect: 'none', // Prevent any field selection
        };
        return (h(Host, { key: '7dda29150fb62937c287d2471d22835bb6706358', id: "lido-container", Lang: this.Lang, "tab-index": 0, class: "lido-container", objective: this.objective, baseUrl: this.baseUrl, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, onTouch: this.onTouch, onInCorrect: this.onInCorrect, onCorrect: this.onCorrect, onEntry: this.onEntry, "show-check": `${this.showCheck}`, "is-continue-on-correct": `${this.isContinueOnCorrect}`, "is-allow-only-correct": `${this.isAllowOnlyCorrect}`, canplay: `${this.canplay}`, appendToDropOnCompletion: `${this.appendToDropOnCompletion}`, "show-prev-button": `${this.showPrevButton}`, "show-next-button": `${this.showNextButton}`, "show-drop-border": `${this.showDropBorder}`, "bg-image": this.bgImage, "exit-button-url": this.exitButtonUrl, "prev-button-url": this.prevButtonUrl, "next-button-url": this.nextButtonUrl, "speaker-button-url": this.speakerButtonUrl, "disable-speak": `${this.disableSpeak}`, "template-id": this.templateId, audio: this.audio, "highlight-word-by-word": `${this.highlightWordByWord}` }, h("lido-text", { key: 'ec794b41f31ffa85d6e73026ee1b8de0e2f526d4', visible: "false", id: this.templateId, audio: "", string: this.instructName }), h("slot", { key: 'daee700a7038716ba9658a3720cc3c350a4736e3' })));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "Lang": [{
                "languageChanged": 0
            }]
    }; }
};
LidoContainer.style = lidoContainerCss();

const lidoFlashCardCss = () => `.card{position:relative;width:100%;height:100%;transform-style:preserve-3d;transition:transform 0.6s ease;cursor:pointer}.card.flipped{transform:rotateY(180deg)}.card-face{position:absolute;width:100%;height:100%;backface-visibility:hidden;display:flex;align-items:center;justify-content:center}.card-back{transform:rotateY(180deg)}lido-container[template-id="flashcardtemplate"] #arrow{position:absolute !important;left:auto !important;top:50% !important;right:13.3% !important;transform:translateY(-50%);z-index:4 !important;overflow:visible;box-sizing:border-box;border:10px solid transparent;box-shadow:0px 8px 0px 0px #8b310f !important}lido-container[template-id="flashcardtemplate"] #arrow.flash-card-next-glowing{animation:flash-card-next-attention 1.4s ease-in-out infinite}@keyframes flash-card-next-attention{0%,100%{border-color:#ffc34d;filter:drop-shadow(0 0 0 rgba(255, 195, 77, 0))}50%{border-color:#fff1a8;filter:drop-shadow(0 0 10px rgba(255, 195, 77, 0.95))}}lido-container[template-id="flashcardtemplate"] #arrow:active{transform:translateY(calc(-50% + 8px)) !important;box-shadow:0px 0px 0px 0px !important}@media (orientation: portrait){lido-container[template-id="flashcardtemplate"] #arrow{right:-4.3% !important}}`;

const LidoFlash = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /* ---------- Generic Lido props (mirrors lido‑row) ---------- */
        /**
         * The value associated with the column component. Typically used for internal logic.
         */
        this.value = '';
        /**
         * The height of the column component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the column component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the column within its container (CSS value, e.g., '10px', '5%').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the column within its container (CSS value, e.g., '10px', '5%').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the column relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the column (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * Defines the type of the column, which can be used for styling or specific logic handling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * A boolean that controls whether the column is visible (`true`) or hidden (`false`).
         */
        this.visible = true;
        /**
         * Audio file URL or identifier for sound that will be associated with the column.
         */
        this.audio = '';
        /**
         * Event handler for a touch event, where a custom function can be triggered when the column is touched.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the column is entered, useful for triggering animations or logic.
         */
        this.onEntry = '';
        /**
         * Whether the card is flipped (back side visible).
         * `mutable` lets the component toggle itself on click;
         * `reflect` keeps the `<lido-flash-card flipped>` attribute in sync.
         */
        this.flipped = false;
        this.autoFlipAfter = 4500;
        this.narrationTarget = null;
        this.narrationHandled = false;
        this.instructionDone = false;
        this.instructionStarted = false;
        this.onAudioStarted = (event) => {
            var _a;
            const target = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.target;
            if (target === this.instructionText())
                this.instructionStarted = true;
            if (target && target === this.narrationTarget && !this.narrationHandled) {
                if (this.narrationGraceTimer)
                    window.clearTimeout(this.narrationGraceTimer);
                this.narrationGraceTimer = undefined;
            }
        };
        this.onAudioPlaying = (event) => {
            const detail = event.detail;
            const target = detail === null || detail === void 0 ? void 0 : detail.target;
            if ((target === null || target === void 0 ? void 0 : target.id) !== 'lido-avatar')
                return;
            if (detail.playbackContext !== this.goodJobPlaybackContext)
                return;
            const arrow = this.nextArrow();
            if (!arrow || !this.flipped)
                return;
            this.goodJobPlaybackId = detail.playbackId;
            arrow.classList.add('flash-card-next-glowing');
        };
        this.onAudioEnded = (event) => {
            var _a, _b, _c;
            const target = (_a = event.detail) === null || _a === void 0 ? void 0 : _a.target;
            const instruction = this.instructionText();
            if (!target || (target !== instruction && target.id !== 'lido-avatar' && !this.el.contains(target)))
                return;
            if (target === this.narrationTarget && !this.narrationHandled) {
                this.finishNarration(target);
                return;
            }
            if (this.narrationHandled && target === this.narrationTarget)
                return;
            if (target === this.instructionText()) {
                this.instructionDone = true;
                this.frontStartTimer = window.setTimeout(() => {
                    this.speakFront();
                }, 1200);
            }
            else if (target === this.frontText()) {
                if (this.flipped)
                    return;
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
            else if (target === this.backText()) {
                if (this.flipped)
                    this.showArrow();
            }
            else if (target.id === 'lido-avatar') {
                const playbackId = (_b = event.detail) === null || _b === void 0 ? void 0 : _b.playbackId;
                const playbackContext = (_c = event.detail) === null || _c === void 0 ? void 0 : _c.playbackContext;
                if (playbackContext !== this.goodJobPlaybackContext || playbackId !== this.goodJobPlaybackId)
                    return;
                this.goodJobPlaybackId = undefined;
                executeActions("this.avatarAnimate='Idle'", target);
            }
        };
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.style = {};
        /**
        * Delay in milliseconds to make the cell visible after mount.
        */
        this.delayVisible = '';
        /* ---------- Internal helpers ---------- */
        /** Compute responsive inline styles. */
        this.updateStyles = () => {
            const o = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
            this.style = {
                height: parseProp(this.height, o) || '200px',
                width: parseProp(this.width, o) || '200px',
                backgroundColor: parseProp(this.bgColor, o),
                top: parseProp(this.y, o),
                left: parseProp(this.x, o),
                zIndex: this.z,
                display: this.visible ? (this.display ? parseProp(this.display, o) : 'inline-block') : 'none',
                flexDirection: this.direction ? parseProp(this.direction, o) : undefined,
                margin: parseProp(this.margin, o),
            };
        };
        /** Toggle the card when it is clicked. */
        this.handleFlip = () => {
            var _a;
            if (this.autoFlipTimer)
                window.clearTimeout(this.autoFlipTimer);
            AudioPlayer.getI().stop();
            this.clearNarrationTimers();
            const goingBack = !this.flipped;
            this.flipped = !this.flipped;
            this.stopGoodJobGlow();
            this.setArrowVisible(false);
            if (goingBack) {
                const text = this.backText();
                if (text && ((_a = text.textContent) === null || _a === void 0 ? void 0 : _a.trim()))
                    this.startNarration(text);
                else
                    this.showArrow();
            }
            else {
                this.speakFront();
            }
        };
        this.instructionText = () => {
            const container = this.el.closest('lido-container');
            const id = container === null || container === void 0 ? void 0 : container.getAttribute('template-id');
            return id ? container === null || container === void 0 ? void 0 : container.querySelector(`[id="${id}"]`) : null;
        };
        this.frontText = () => this.el.querySelector('.card-front lido-text');
        this.backText = () => this.el.querySelector('.card-back lido-text');
        this.nextArrow = () => { var _a; return (_a = this.el.closest('lido-container')) === null || _a === void 0 ? void 0 : _a.querySelector('#arrow'); };
        this.stopGoodJobGlow = () => {
            var _a;
            this.goodJobPlaybackId = undefined;
            this.goodJobPlaybackContext = undefined;
            (_a = this.nextArrow()) === null || _a === void 0 ? void 0 : _a.classList.remove('flash-card-next-glowing');
        };
        this.speakFront = () => {
            var _a, _b;
            const text = this.frontText();
            if (this.instructionDone && !this.flipped && text && ((_a = text.textContent) === null || _a === void 0 ? void 0 : _a.trim())) {
                this.startNarration(text);
            }
            else if (this.instructionDone && !this.flipped && (!text || !((_b = text.textContent) === null || _b === void 0 ? void 0 : _b.trim()))) {
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
        };
        this.clearNarrationTimers = () => {
            if (this.narrationGraceTimer)
                window.clearTimeout(this.narrationGraceTimer);
            this.narrationGraceTimer = undefined;
            this.narrationTarget = null;
            this.narrationHandled = false;
        };
        this.continueAfterNarration = (target) => {
            if (target === this.instructionText()) {
                this.instructionDone = true;
                this.frontStartTimer = window.setTimeout(() => this.speakFront(), 1200);
            }
            else if (target === this.frontText()) {
                if (this.flipped)
                    return;
                if (this.autoFlipTimer)
                    window.clearTimeout(this.autoFlipTimer);
                this.autoFlipTimer = window.setTimeout(() => {
                    if (!this.flipped)
                        this.handleFlip();
                }, this.autoFlipAfter);
            }
            else if (target === this.backText()) {
                if (this.flipped)
                    this.showArrow();
            }
        };
        this.finishNarration = (target) => {
            if (target !== this.narrationTarget || this.narrationHandled)
                return;
            this.narrationHandled = true;
            if (this.narrationGraceTimer)
                window.clearTimeout(this.narrationGraceTimer);
            this.narrationGraceTimer = undefined;
            this.continueAfterNarration(target);
        };
        this.startNarration = (target) => {
            this.clearNarrationTimers();
            this.narrationTarget = target;
            this.narrationGraceTimer = window.setTimeout(() => {
                if (!this.narrationHandled)
                    this.finishNarration(target);
            }, LidoFlash.narrationStartGrace);
            executeActions("this.speak='true'", target);
        };
        this.showArrow = () => {
            if (!this.flipped)
                return;
            const container = this.el.closest('lido-container');
            if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) !== 'flashcardtemplate')
                return;
            const arrow = this.nextArrow();
            if (!arrow)
                return;
            // Existing ZIPs may not have the newer template onTouch action. Reuse
            // the same direct nextBtn action as the shared home arrow for them.
            if (!arrow.getAttribute('onTouch'))
                arrow.setAttribute('onTouch', "this.nextBtn='true';");
            const mascot = container.querySelector('#lido-avatar');
            const scaffoldAudio = arrow.getAttribute('audio');
            if (mascot && scaffoldAudio) {
                mascot.setAttribute('audio', scaffoldAudio);
            }
            this.setArrowVisible(true);
            // Keep the next action highlighted after mascot audio ends.
            arrow.classList.add('flash-card-next-glowing');
            if (mascot) {
                this.goodJobPlaybackContext = {};
                this.goodJobPlaybackId = undefined;
                executeActions("this.avatarAnimate='Idle speak'", mascot);
                AudioPlayer.getI().play(mascot, true, this.goodJobPlaybackContext);
            }
        };
        this.setArrowVisible = (visible) => {
            const container = this.el.closest('lido-container');
            if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) !== 'flashcardtemplate')
                return;
            const arrow = container.querySelector('#arrow');
            if (!arrow)
                return;
            arrow.visible = visible;
            arrow.setAttribute('visible', String(visible));
            // lido-cell's visible prop is a non-reflected string prop; keep the
            // rendered host in sync as well so an attribute update cannot leave its
            // previous inline display:none in place.
            arrow.style.display = visible ? 'block' : 'none';
            arrow.style.visibility = visible ? 'visible' : 'hidden';
            arrow.style.opacity = visible ? '1' : '0';
            arrow.style.pointerEvents = visible ? 'auto' : 'none';
            const arrowImage = arrow.querySelector('lido-image');
            if (arrowImage) {
                arrowImage.style.display = visible ? 'flex' : 'none';
                arrowImage.style.visibility = visible ? 'visible' : 'hidden';
                arrowImage.style.opacity = visible ? '1' : '0';
            }
            if (typeof arrow.updateStyles === 'function')
                arrow.updateStyles();
        };
    }
    /* ---------- Watches ---------- */
    /** React to external changes if you need side‑effects. */
    handleFlippedChange() {
        /* No side‑effects for now; re‑render happens automatically. */
    }
    /* ---------- Lifecycle ---------- */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.updateStyles);
        window.addEventListener('load', this.updateStyles);
    }
    componentDidLoad() {
        var _a;
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        window.addEventListener('lidoAudioStarted', this.onAudioStarted);
        window.addEventListener('lidoAudioPlaying', this.onAudioPlaying);
        window.addEventListener('lidoAudioEnded', this.onAudioEnded);
        const container = this.el.closest('lido-container');
        if ((container === null || container === void 0 ? void 0 : container.getAttribute('template-id')) === 'flashcardtemplate') {
            (_a = container.querySelector('#lido-avatar')) === null || _a === void 0 ? void 0 : _a.setAttribute('disable-speak', 'true');
            this.instructionStartTimer = window.setTimeout(() => {
                if (!this.instructionStarted && !this.instructionDone) {
                    const instruction = this.instructionText();
                    if (instruction)
                        this.startNarration(instruction);
                }
            }, 150);
        }
        // handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength, 'inline-block');
    }
    disconnectedCallback() {
        window.removeEventListener('lidoAudioEnded', this.onAudioEnded);
        window.removeEventListener('lidoAudioPlaying', this.onAudioPlaying);
        window.removeEventListener('lidoAudioStarted', this.onAudioStarted);
        if (this.autoFlipTimer)
            window.clearTimeout(this.autoFlipTimer);
        if (this.instructionStartTimer)
            window.clearTimeout(this.instructionStartTimer);
        if (this.frontStartTimer)
            window.clearTimeout(this.frontStartTimer);
        this.clearNarrationTimers();
        window.removeEventListener('resize', this.updateStyles);
        window.removeEventListener('load', this.updateStyles);
    }
    /* ---------- Render ---------- */
    render() {
        return (h(Host, { key: 'c8a504d780142a69a3d67826b992b33da7082151', value: this.value, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, type: this.type, onClick: (event) => {
                var _a, _b;
                if ((_b = (_a = event.target) === null || _a === void 0 ? void 0 : _a.closest) === null || _b === void 0 ? void 0 : _b.call(_a, '#lido-avatar'))
                    return;
                this.handleFlip();
            }, "disable-speak": this.disableSpeak }, h("div", { key: '5d862976d926dd31cc84c66b950aaa7605dfcf59', class: `card ${this.flipped ? 'flipped' : ''}` }, h("div", { key: 'cd8c47f12e1185a4f7b84f7fda9e6c15fc8ec063', class: "card-face card-front" }, this.front != null ? this.front : h("slot", { name: "front" })), h("div", { key: 'c2543a602a8172ce8e770efffd2190fc296ed95f', class: "card-face card-back" }, this.back != null ? this.back : h("slot", { name: "back" })))));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "flipped": [{
                "handleFlippedChange": 0
            }]
    }; }
};
LidoFlash.narrationStartGrace = 800;
LidoFlash.style = lidoFlashCardCss();

const lidoFloatCss = () => `.lido-float{position:relative}.lido-float>*{position:absolute;cursor:pointer}@keyframes float-up{from{top:var(--el-top)}to{top:-500px}}#removeShadow{box-shadow:unset !important}@keyframes float-lr{from{right:var(--el-left)}to{right:-500px}}`;

const LidoFloat = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the text element.
         */
        this.id = '';
        /**
         * Value associated with the text element, typically used for internal logic or tracking.
         */
        this.value = '';
        /**
         * Z-index for stacking order of the text component relative to other elements.
         */
        this.z = '0';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the text component. If `true`, the text is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * Direction of the float element's movement (e.g., 'leftToRight', 'bottomToTop').
         * This can be used to control the animation or positioning of the float elements.
         */
        this.floatDirection = 'bottomToTop';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.initializeFloatElement();
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    initializeFloatElement() {
        const floatElements = this.el.children;
        let delay = 0;
        Array.from(floatElements).forEach((el) => {
            const element = el;
            element.style.visibility = 'hidden';
            setTimeout(() => {
                element.style.visibility = 'visible';
                handleFloatElementPosition(element);
            }, delay);
            delay += 1000; // Stagger the visibility of each element by 1 second
            el.addEventListener('click', () => {
                handleElementClick(element);
            });
        });
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: this.floatDirection !== 'leftToRight' ? "100%" : parseProp(this.height, orientation),
            width: this.floatDirection === 'leftToRight' ? "100%" : parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            zIndex: this.z,
            display: this.visible ? 'flex' : 'none',
        };
    }
    render() {
        return (h(Host, { key: 'c461f1142dd6addd9ceb41ade183b044b875681f', class: "lido-float", "float-direction": this.floatDirection, id: this.id, "tab-index": this.tabIndex, style: this.style, onEntry: this.onEntry }, h("slot", { key: '240439bfda6a9e4e2d67e6ae2b5c878d99e632b3' })));
    }
    get el() { return getElement(this); }
};
LidoFloat.style = lidoFloatCss();

function commonjsRequire(path) {
	throw new Error('Could not dynamically require "' + path + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}

var jszip_min = {exports: {}};

/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/

var hasRequiredJszip_min;

function requireJszip_min () {
	if (hasRequiredJszip_min) return jszip_min.exports;
	hasRequiredJszip_min = 1;
	(function (module, exports) {
		!function(e){module.exports=e();}(function(){return function s(a,o,h){function u(r,e){if(!o[r]){if(!a[r]){var t="function"==typeof commonjsRequire&&commonjsRequire;if(!e&&t)return t(r,true);if(l)return l(r,true);var n=new Error("Cannot find module '"+r+"'");throw n.code="MODULE_NOT_FOUND",n}var i=o[r]={exports:{}};a[r][0].call(i.exports,function(e){var t=a[r][1][e];return u(t||e)},i,i.exports,s,a,o,h);}return o[r].exports}for(var l="function"==typeof commonjsRequire&&commonjsRequire,e=0;e<h.length;e++)u(h[e]);return u}({1:[function(e,t,r){var d=e("./utils"),c=e("./support"),p="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";r.encode=function(e){for(var t,r,n,i,s,a,o,h=[],u=0,l=e.length,f=l,c="string"!==d.getTypeOf(e);u<e.length;)f=l-u,n=c?(t=e[u++],r=u<l?e[u++]:0,u<l?e[u++]:0):(t=e.charCodeAt(u++),r=u<l?e.charCodeAt(u++):0,u<l?e.charCodeAt(u++):0),i=t>>2,s=(3&t)<<4|r>>4,a=1<f?(15&r)<<2|n>>6:64,o=2<f?63&n:64,h.push(p.charAt(i)+p.charAt(s)+p.charAt(a)+p.charAt(o));return h.join("")},r.decode=function(e){var t,r,n,i,s,a,o=0,h=0,u="data:";if(e.substr(0,u.length)===u)throw new Error("Invalid base64 input, it looks like a data url.");var l,f=3*(e=e.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(e.charAt(e.length-1)===p.charAt(64)&&f--,e.charAt(e.length-2)===p.charAt(64)&&f--,f%1!=0)throw new Error("Invalid base64 input, bad content length.");for(l=c.uint8array?new Uint8Array(0|f):new Array(0|f);o<e.length;)t=p.indexOf(e.charAt(o++))<<2|(i=p.indexOf(e.charAt(o++)))>>4,r=(15&i)<<4|(s=p.indexOf(e.charAt(o++)))>>2,n=(3&s)<<6|(a=p.indexOf(e.charAt(o++))),l[h++]=t,64!==s&&(l[h++]=r),64!==a&&(l[h++]=n);return l};},{"./support":30,"./utils":32}],2:[function(e,t,r){var n=e("./external"),i=e("./stream/DataWorker"),s=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function o(e,t,r,n,i){this.compressedSize=e,this.uncompressedSize=t,this.crc32=r,this.compression=n,this.compressedContent=i;}o.prototype={getContentWorker:function(){var e=new i(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),t=this;return e.on("end",function(){if(this.streamInfo.data_length!==t.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),e},getCompressedWorker:function(){return new i(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},o.createWorkerFrom=function(e,t,r){return e.pipe(new s).pipe(new a("uncompressedSize")).pipe(t.compressWorker(r)).pipe(new a("compressedSize")).withStreamInfo("compression",t)},t.exports=o;},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,t,r){var n=e("./stream/GenericWorker");r.STORE={magic:"\0\0",compressWorker:function(){return new n("STORE compression")},uncompressWorker:function(){return new n("STORE decompression")}},r.DEFLATE=e("./flate");},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,t,r){var n=e("./utils");var o=function(){for(var e,t=[],r=0;r<256;r++){e=r;for(var n=0;n<8;n++)e=1&e?3988292384^e>>>1:e>>>1;t[r]=e;}return t}();t.exports=function(e,t){return void 0!==e&&e.length?"string"!==n.getTypeOf(e)?function(e,t,r,n){var i=o,s=n+r;e^=-1;for(var a=n;a<s;a++)e=e>>>8^i[255&(e^t[a])];return  -1^e}(0|t,e,e.length,0):function(e,t,r,n){var i=o,s=n+r;e^=-1;for(var a=n;a<s;a++)e=e>>>8^i[255&(e^t.charCodeAt(a))];return  -1^e}(0|t,e,e.length,0):0};},{"./utils":32}],5:[function(e,t,r){r.base64=false,r.binary=false,r.dir=false,r.createFolders=true,r.date=null,r.compression=null,r.compressionOptions=null,r.comment=null,r.unixPermissions=null,r.dosPermissions=null;},{}],6:[function(e,t,r){var n=null;n="undefined"!=typeof Promise?Promise:e("lie"),t.exports={Promise:n};},{lie:37}],7:[function(e,t,r){var n="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Uint32Array,i=e("pako"),s=e("./utils"),a=e("./stream/GenericWorker"),o=n?"uint8array":"array";function h(e,t){a.call(this,"FlateWorker/"+e),this._pako=null,this._pakoAction=e,this._pakoOptions=t,this.meta={};}r.magic="\b\0",s.inherits(h,a),h.prototype.processChunk=function(e){this.meta=e.meta,null===this._pako&&this._createPako(),this._pako.push(s.transformTo(o,e.data),false);},h.prototype.flush=function(){a.prototype.flush.call(this),null===this._pako&&this._createPako(),this._pako.push([],true);},h.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null;},h.prototype._createPako=function(){this._pako=new i[this._pakoAction]({raw:true,level:this._pakoOptions.level||-1});var t=this;this._pako.onData=function(e){t.push({data:e,meta:t.meta});};},r.compressWorker=function(e){return new h("Deflate",e)},r.uncompressWorker=function(){return new h("Inflate",{})};},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,t,r){function A(e,t){var r,n="";for(r=0;r<t;r++)n+=String.fromCharCode(255&e),e>>>=8;return n}function n(e,t,r,n,i,s){var a,o,h=e.file,u=e.compression,l=s!==O.utf8encode,f=I.transformTo("string",s(h.name)),c=I.transformTo("string",O.utf8encode(h.name)),d=h.comment,p=I.transformTo("string",s(d)),m=I.transformTo("string",O.utf8encode(d)),_=c.length!==h.name.length,g=m.length!==d.length,b="",v="",y="",w=h.dir,k=h.date,x={crc32:0,compressedSize:0,uncompressedSize:0};t&&!r||(x.crc32=e.crc32,x.compressedSize=e.compressedSize,x.uncompressedSize=e.uncompressedSize);var S=0;t&&(S|=8),l||!_&&!g||(S|=2048);var z=0,C=0;w&&(z|=16),"UNIX"===i?(C=798,z|=function(e,t){var r=e;return e||(r=t?16893:33204),(65535&r)<<16}(h.unixPermissions,w)):(C=20,z|=function(e){return 63&(e||0)}(h.dosPermissions)),a=k.getUTCHours(),a<<=6,a|=k.getUTCMinutes(),a<<=5,a|=k.getUTCSeconds()/2,o=k.getUTCFullYear()-1980,o<<=4,o|=k.getUTCMonth()+1,o<<=5,o|=k.getUTCDate(),_&&(v=A(1,1)+A(B(f),4)+c,b+="up"+A(v.length,2)+v),g&&(y=A(1,1)+A(B(p),4)+m,b+="uc"+A(y.length,2)+y);var E="";return E+="\n\0",E+=A(S,2),E+=u.magic,E+=A(a,2),E+=A(o,2),E+=A(x.crc32,4),E+=A(x.compressedSize,4),E+=A(x.uncompressedSize,4),E+=A(f.length,2),E+=A(b.length,2),{fileRecord:R.LOCAL_FILE_HEADER+E+f+b,dirRecord:R.CENTRAL_FILE_HEADER+A(C,2)+E+A(p.length,2)+"\0\0\0\0"+A(z,4)+A(n,4)+f+b+p}}var I=e("../utils"),i=e("../stream/GenericWorker"),O=e("../utf8"),B=e("../crc32"),R=e("../signature");function s(e,t,r,n){i.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=t,this.zipPlatform=r,this.encodeFileName=n,this.streamFiles=e,this.accumulate=false,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[];}I.inherits(s,i),s.prototype.push=function(e){var t=e.meta.percent||0,r=this.entriesCount,n=this._sources.length;this.accumulate?this.contentBuffer.push(e):(this.bytesWritten+=e.data.length,i.prototype.push.call(this,{data:e.data,meta:{currentFile:this.currentFile,percent:r?(t+100*(r-n-1))/r:100}}));},s.prototype.openedSource=function(e){this.currentSourceOffset=this.bytesWritten,this.currentFile=e.file.name;var t=this.streamFiles&&!e.file.dir;if(t){var r=n(e,t,false,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:r.fileRecord,meta:{percent:0}});}else this.accumulate=true;},s.prototype.closedSource=function(e){this.accumulate=false;var t=this.streamFiles&&!e.file.dir,r=n(e,t,true,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(r.dirRecord),t)this.push({data:function(e){return R.DATA_DESCRIPTOR+A(e.crc32,4)+A(e.compressedSize,4)+A(e.uncompressedSize,4)}(e),meta:{percent:100}});else for(this.push({data:r.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null;},s.prototype.flush=function(){for(var e=this.bytesWritten,t=0;t<this.dirRecords.length;t++)this.push({data:this.dirRecords[t],meta:{percent:100}});var r=this.bytesWritten-e,n=function(e,t,r,n,i){var s=I.transformTo("string",i(n));return R.CENTRAL_DIRECTORY_END+"\0\0\0\0"+A(e,2)+A(e,2)+A(t,4)+A(r,4)+A(s.length,2)+s}(this.dirRecords.length,r,e,this.zipComment,this.encodeFileName);this.push({data:n,meta:{percent:100}});},s.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume();},s.prototype.registerPrevious=function(e){this._sources.push(e);var t=this;return e.on("data",function(e){t.processChunk(e);}),e.on("end",function(){t.closedSource(t.previous.streamInfo),t._sources.length?t.prepareNextSource():t.end();}),e.on("error",function(e){t.error(e);}),this},s.prototype.resume=function(){return !!i.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),true):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),true))},s.prototype.error=function(e){var t=this._sources;if(!i.prototype.error.call(this,e))return  false;for(var r=0;r<t.length;r++)try{t[r].error(e);}catch(e){}return  true},s.prototype.lock=function(){i.prototype.lock.call(this);for(var e=this._sources,t=0;t<e.length;t++)e[t].lock();},t.exports=s;},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,t,r){var u=e("../compressions"),n=e("./ZipFileWorker");r.generateWorker=function(e,a,t){var o=new n(a.streamFiles,t,a.platform,a.encodeFileName),h=0;try{e.forEach(function(e,t){h++;var r=function(e,t){var r=e||t,n=u[r];if(!n)throw new Error(r+" is not a valid compression method !");return n}(t.options.compression,a.compression),n=t.options.compressionOptions||a.compressionOptions||{},i=t.dir,s=t.date;t._compressWorker(r,n).withStreamInfo("file",{name:e,dir:i,date:s,comment:t.comment||"",unixPermissions:t.unixPermissions,dosPermissions:t.dosPermissions}).pipe(o);}),o.entriesCount=h;}catch(e){o.error(e);}return o};},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,t,r){function n(){if(!(this instanceof n))return new n;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var e=new n;for(var t in this)"function"!=typeof this[t]&&(e[t]=this[t]);return e};}(n.prototype=e("./object")).loadAsync=e("./load"),n.support=e("./support"),n.defaults=e("./defaults"),n.version="3.10.1",n.loadAsync=function(e,t){return (new n).loadAsync(e,t)},n.external=e("./external"),t.exports=n;},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,t,r){var u=e("./utils"),i=e("./external"),n=e("./utf8"),s=e("./zipEntries"),a=e("./stream/Crc32Probe"),l=e("./nodejsUtils");function f(n){return new i.Promise(function(e,t){var r=n.decompressed.getContentWorker().pipe(new a);r.on("error",function(e){t(e);}).on("end",function(){r.streamInfo.crc32!==n.decompressed.crc32?t(new Error("Corrupted zip : CRC32 mismatch")):e();}).resume();})}t.exports=function(e,o){var h=this;return o=u.extend(o||{},{base64:false,checkCRC32:false,optimizedBinaryString:false,createFolders:false,decodeFileName:n.utf8decode}),l.isNode&&l.isStream(e)?i.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):u.prepareContent("the loaded zip file",e,true,o.optimizedBinaryString,o.base64).then(function(e){var t=new s(o);return t.load(e),t}).then(function(e){var t=[i.Promise.resolve(e)],r=e.files;if(o.checkCRC32)for(var n=0;n<r.length;n++)t.push(f(r[n]));return i.Promise.all(t)}).then(function(e){for(var t=e.shift(),r=t.files,n=0;n<r.length;n++){var i=r[n],s=i.fileNameStr,a=u.resolve(i.fileNameStr);h.file(a,i.decompressed,{binary:true,optimizedBinaryString:true,date:i.date,dir:i.dir,comment:i.fileCommentStr.length?i.fileCommentStr:null,unixPermissions:i.unixPermissions,dosPermissions:i.dosPermissions,createFolders:o.createFolders}),i.dir||(h.file(a).unsafeOriginalName=s);}return t.zipComment.length&&(h.comment=t.zipComment),h})};},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,t,r){var n=e("../utils"),i=e("../stream/GenericWorker");function s(e,t){i.call(this,"Nodejs stream input adapter for "+e),this._upstreamEnded=false,this._bindStream(t);}n.inherits(s,i),s.prototype._bindStream=function(e){var t=this;(this._stream=e).pause(),e.on("data",function(e){t.push({data:e,meta:{percent:0}});}).on("error",function(e){t.isPaused?this.generatedError=e:t.error(e);}).on("end",function(){t.isPaused?t._upstreamEnded=true:t.end();});},s.prototype.pause=function(){return !!i.prototype.pause.call(this)&&(this._stream.pause(),true)},s.prototype.resume=function(){return !!i.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),true)},t.exports=s;},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,t,r){var i=e("readable-stream").Readable;function n(e,t,r){i.call(this,t),this._helper=e;var n=this;e.on("data",function(e,t){n.push(e)||n._helper.pause(),r&&r(t);}).on("error",function(e){n.emit("error",e);}).on("end",function(){n.push(null);});}e("../utils").inherits(n,i),n.prototype._read=function(){this._helper.resume();},t.exports=n;},{"../utils":32,"readable-stream":16}],14:[function(e,t,r){t.exports={isNode:"undefined"!=typeof Buffer,newBufferFrom:function(e,t){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(e,t);if("number"==typeof e)throw new Error('The "data" argument must not be a number');return new Buffer(e,t)},allocBuffer:function(e){if(Buffer.alloc)return Buffer.alloc(e);var t=new Buffer(e);return t.fill(0),t},isBuffer:function(e){return Buffer.isBuffer(e)},isStream:function(e){return e&&"function"==typeof e.on&&"function"==typeof e.pause&&"function"==typeof e.resume}};},{}],15:[function(e,t,r){function s(e,t,r){var n,i=u.getTypeOf(t),s=u.extend(r||{},f);s.date=s.date||new Date,null!==s.compression&&(s.compression=s.compression.toUpperCase()),"string"==typeof s.unixPermissions&&(s.unixPermissions=parseInt(s.unixPermissions,8)),s.unixPermissions&&16384&s.unixPermissions&&(s.dir=true),s.dosPermissions&&16&s.dosPermissions&&(s.dir=true),s.dir&&(e=g(e)),s.createFolders&&(n=_(e))&&b.call(this,n,true);var a="string"===i&&false===s.binary&&false===s.base64;r&&void 0!==r.binary||(s.binary=!a),(t instanceof c&&0===t.uncompressedSize||s.dir||!t||0===t.length)&&(s.base64=false,s.binary=true,t="",s.compression="STORE",i="string");var o=null;o=t instanceof c||t instanceof l?t:p.isNode&&p.isStream(t)?new m(e,t):u.prepareContent(e,t,s.binary,s.optimizedBinaryString,s.base64);var h=new d(e,o,s);this.files[e]=h;}var i=e("./utf8"),u=e("./utils"),l=e("./stream/GenericWorker"),a=e("./stream/StreamHelper"),f=e("./defaults"),c=e("./compressedObject"),d=e("./zipObject"),o=e("./generate"),p=e("./nodejsUtils"),m=e("./nodejs/NodejsStreamInputAdapter"),_=function(e){"/"===e.slice(-1)&&(e=e.substring(0,e.length-1));var t=e.lastIndexOf("/");return 0<t?e.substring(0,t):""},g=function(e){return "/"!==e.slice(-1)&&(e+="/"),e},b=function(e,t){return t=void 0!==t?t:f.createFolders,e=g(e),this.files[e]||s.call(this,e,null,{dir:true,createFolders:t}),this.files[e]};function h(e){return "[object RegExp]"===Object.prototype.toString.call(e)}var n={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(e){var t,r,n;for(t in this.files)n=this.files[t],(r=t.slice(this.root.length,t.length))&&t.slice(0,this.root.length)===this.root&&e(r,n);},filter:function(r){var n=[];return this.forEach(function(e,t){r(e,t)&&n.push(t);}),n},file:function(e,t,r){if(1!==arguments.length)return e=this.root+e,s.call(this,e,t,r),this;if(h(e)){var n=e;return this.filter(function(e,t){return !t.dir&&n.test(e)})}var i=this.files[this.root+e];return i&&!i.dir?i:null},folder:function(r){if(!r)return this;if(h(r))return this.filter(function(e,t){return t.dir&&r.test(e)});var e=this.root+r,t=b.call(this,e),n=this.clone();return n.root=t.name,n},remove:function(r){r=this.root+r;var e=this.files[r];if(e||("/"!==r.slice(-1)&&(r+="/"),e=this.files[r]),e&&!e.dir)delete this.files[r];else for(var t=this.filter(function(e,t){return t.name.slice(0,r.length)===r}),n=0;n<t.length;n++)delete this.files[t[n].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(e){var t,r={};try{if((r=u.extend(e||{},{streamFiles:false,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:i.utf8encode})).type=r.type.toLowerCase(),r.compression=r.compression.toUpperCase(),"binarystring"===r.type&&(r.type="string"),!r.type)throw new Error("No output type specified.");u.checkSupport(r.type),"darwin"!==r.platform&&"freebsd"!==r.platform&&"linux"!==r.platform&&"sunos"!==r.platform||(r.platform="UNIX"),"win32"===r.platform&&(r.platform="DOS");var n=r.comment||this.comment||"";t=o.generateWorker(this,r,n);}catch(e){(t=new l("error")).error(e);}return new a(t,r.type||"string",r.mimeType)},generateAsync:function(e,t){return this.generateInternalStream(e).accumulate(t)},generateNodeStream:function(e,t){return (e=e||{}).type||(e.type="nodebuffer"),this.generateInternalStream(e).toNodejsStream(t)}};t.exports=n;},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,t,r){t.exports=e("stream");},{stream:void 0}],17:[function(e,t,r){var n=e("./DataReader");function i(e){n.call(this,e);for(var t=0;t<this.data.length;t++)e[t]=255&e[t];}e("../utils").inherits(i,n),i.prototype.byteAt=function(e){return this.data[this.zero+e]},i.prototype.lastIndexOfSignature=function(e){for(var t=e.charCodeAt(0),r=e.charCodeAt(1),n=e.charCodeAt(2),i=e.charCodeAt(3),s=this.length-4;0<=s;--s)if(this.data[s]===t&&this.data[s+1]===r&&this.data[s+2]===n&&this.data[s+3]===i)return s-this.zero;return  -1},i.prototype.readAndCheckSignature=function(e){var t=e.charCodeAt(0),r=e.charCodeAt(1),n=e.charCodeAt(2),i=e.charCodeAt(3),s=this.readData(4);return t===s[0]&&r===s[1]&&n===s[2]&&i===s[3]},i.prototype.readData=function(e){if(this.checkOffset(e),0===e)return [];var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i;},{"../utils":32,"./DataReader":18}],18:[function(e,t,r){var n=e("../utils");function i(e){this.data=e,this.length=e.length,this.index=0,this.zero=0;}i.prototype={checkOffset:function(e){this.checkIndex(this.index+e);},checkIndex:function(e){if(this.length<this.zero+e||e<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+e+"). Corrupted zip ?")},setIndex:function(e){this.checkIndex(e),this.index=e;},skip:function(e){this.setIndex(this.index+e);},byteAt:function(){},readInt:function(e){var t,r=0;for(this.checkOffset(e),t=this.index+e-1;t>=this.index;t--)r=(r<<8)+this.byteAt(t);return this.index+=e,r},readString:function(e){return n.transformTo("string",this.readData(e))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var e=this.readInt(4);return new Date(Date.UTC(1980+(e>>25&127),(e>>21&15)-1,e>>16&31,e>>11&31,e>>5&63,(31&e)<<1))}},t.exports=i;},{"../utils":32}],19:[function(e,t,r){var n=e("./Uint8ArrayReader");function i(e){n.call(this,e);}e("../utils").inherits(i,n),i.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i;},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,t,r){var n=e("./DataReader");function i(e){n.call(this,e);}e("../utils").inherits(i,n),i.prototype.byteAt=function(e){return this.data.charCodeAt(this.zero+e)},i.prototype.lastIndexOfSignature=function(e){return this.data.lastIndexOf(e)-this.zero},i.prototype.readAndCheckSignature=function(e){return e===this.readData(4)},i.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i;},{"../utils":32,"./DataReader":18}],21:[function(e,t,r){var n=e("./ArrayReader");function i(e){n.call(this,e);}e("../utils").inherits(i,n),i.prototype.readData=function(e){if(this.checkOffset(e),0===e)return new Uint8Array(0);var t=this.data.subarray(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=i;},{"../utils":32,"./ArrayReader":17}],22:[function(e,t,r){var n=e("../utils"),i=e("../support"),s=e("./ArrayReader"),a=e("./StringReader"),o=e("./NodeBufferReader"),h=e("./Uint8ArrayReader");t.exports=function(e){var t=n.getTypeOf(e);return n.checkSupport(t),"string"!==t||i.uint8array?"nodebuffer"===t?new o(e):i.uint8array?new h(n.transformTo("uint8array",e)):new s(n.transformTo("array",e)):new a(e)};},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,t,r){r.LOCAL_FILE_HEADER="PK",r.CENTRAL_FILE_HEADER="PK",r.CENTRAL_DIRECTORY_END="PK",r.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK",r.ZIP64_CENTRAL_DIRECTORY_END="PK",r.DATA_DESCRIPTOR="PK\b";},{}],24:[function(e,t,r){var n=e("./GenericWorker"),i=e("../utils");function s(e){n.call(this,"ConvertWorker to "+e),this.destType=e;}i.inherits(s,n),s.prototype.processChunk=function(e){this.push({data:i.transformTo(this.destType,e.data),meta:e.meta});},t.exports=s;},{"../utils":32,"./GenericWorker":28}],25:[function(e,t,r){var n=e("./GenericWorker"),i=e("../crc32");function s(){n.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0);}e("../utils").inherits(s,n),s.prototype.processChunk=function(e){this.streamInfo.crc32=i(e.data,this.streamInfo.crc32||0),this.push(e);},t.exports=s;},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,t,r){var n=e("../utils"),i=e("./GenericWorker");function s(e){i.call(this,"DataLengthProbe for "+e),this.propName=e,this.withStreamInfo(e,0);}n.inherits(s,i),s.prototype.processChunk=function(e){if(e){var t=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=t+e.data.length;}i.prototype.processChunk.call(this,e);},t.exports=s;},{"../utils":32,"./GenericWorker":28}],27:[function(e,t,r){var n=e("../utils"),i=e("./GenericWorker");function s(e){i.call(this,"DataWorker");var t=this;this.dataIsReady=false,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=false,e.then(function(e){t.dataIsReady=true,t.data=e,t.max=e&&e.length||0,t.type=n.getTypeOf(e),t.isPaused||t._tickAndRepeat();},function(e){t.error(e);});}n.inherits(s,i),s.prototype.cleanUp=function(){i.prototype.cleanUp.call(this),this.data=null;},s.prototype.resume=function(){return !!i.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=true,n.delay(this._tickAndRepeat,[],this)),true)},s.prototype._tickAndRepeat=function(){this._tickScheduled=false,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(n.delay(this._tickAndRepeat,[],this),this._tickScheduled=true));},s.prototype._tick=function(){if(this.isPaused||this.isFinished)return  false;var e=null,t=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case "string":e=this.data.substring(this.index,t);break;case "uint8array":e=this.data.subarray(this.index,t);break;case "array":case "nodebuffer":e=this.data.slice(this.index,t);}return this.index=t,this.push({data:e,meta:{percent:this.max?this.index/this.max*100:0}})},t.exports=s;},{"../utils":32,"./GenericWorker":28}],28:[function(e,t,r){function n(e){this.name=e||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=true,this.isFinished=false,this.isLocked=false,this._listeners={data:[],end:[],error:[]},this.previous=null;}n.prototype={push:function(e){this.emit("data",e);},end:function(){if(this.isFinished)return  false;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=true;}catch(e){this.emit("error",e);}return  true},error:function(e){return !this.isFinished&&(this.isPaused?this.generatedError=e:(this.isFinished=true,this.emit("error",e),this.previous&&this.previous.error(e),this.cleanUp()),true)},on:function(e,t){return this._listeners[e].push(t),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[];},emit:function(e,t){if(this._listeners[e])for(var r=0;r<this._listeners[e].length;r++)this._listeners[e][r].call(this,t);},pipe:function(e){return e.registerPrevious(this)},registerPrevious:function(e){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=e.streamInfo,this.mergeStreamInfo(),this.previous=e;var t=this;return e.on("data",function(e){t.processChunk(e);}),e.on("end",function(){t.end();}),e.on("error",function(e){t.error(e);}),this},pause:function(){return !this.isPaused&&!this.isFinished&&(this.isPaused=true,this.previous&&this.previous.pause(),true)},resume:function(){if(!this.isPaused||this.isFinished)return  false;var e=this.isPaused=false;return this.generatedError&&(this.error(this.generatedError),e=true),this.previous&&this.previous.resume(),!e},flush:function(){},processChunk:function(e){this.push(e);},withStreamInfo:function(e,t){return this.extraStreamInfo[e]=t,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var e in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,e)&&(this.streamInfo[e]=this.extraStreamInfo[e]);},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=true,this.previous&&this.previous.lock();},toString:function(){var e="Worker "+this.name;return this.previous?this.previous+" -> "+e:e}},t.exports=n;},{}],29:[function(e,t,r){var h=e("../utils"),i=e("./ConvertWorker"),s=e("./GenericWorker"),u=e("../base64"),n=e("../support"),a=e("../external"),o=null;if(n.nodestream)try{o=e("../nodejs/NodejsStreamOutputAdapter");}catch(e){}function l(e,o){return new a.Promise(function(t,r){var n=[],i=e._internalType,s=e._outputType,a=e._mimeType;e.on("data",function(e,t){n.push(e),o&&o(t);}).on("error",function(e){n=[],r(e);}).on("end",function(){try{var e=function(e,t,r){switch(e){case "blob":return h.newBlob(h.transformTo("arraybuffer",t),r);case "base64":return u.encode(t);default:return h.transformTo(e,t)}}(s,function(e,t){var r,n=0,i=null,s=0;for(r=0;r<t.length;r++)s+=t[r].length;switch(e){case "string":return t.join("");case "array":return Array.prototype.concat.apply([],t);case "uint8array":for(i=new Uint8Array(s),r=0;r<t.length;r++)i.set(t[r],n),n+=t[r].length;return i;case "nodebuffer":return Buffer.concat(t);default:throw new Error("concat : unsupported type '"+e+"'")}}(i,n),a);t(e);}catch(e){r(e);}n=[];}).resume();})}function f(e,t,r){var n=t;switch(t){case "blob":case "arraybuffer":n="uint8array";break;case "base64":n="string";}try{this._internalType=n,this._outputType=t,this._mimeType=r,h.checkSupport(n),this._worker=e.pipe(new i(n)),e.lock();}catch(e){this._worker=new s("error"),this._worker.error(e);}}f.prototype={accumulate:function(e){return l(this,e)},on:function(e,t){var r=this;return "data"===e?this._worker.on(e,function(e){t.call(r,e.data,e.meta);}):this._worker.on(e,function(){h.delay(t,arguments,r);}),this},resume:function(){return h.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(e){if(h.checkSupport("nodestream"),"nodebuffer"!==this._outputType)throw new Error(this._outputType+" is not supported by this method");return new o(this,{objectMode:"nodebuffer"!==this._outputType},e)}},t.exports=f;},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,t,r){if(r.base64=true,r.array=true,r.string=true,r.arraybuffer="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof Uint8Array,r.nodebuffer="undefined"!=typeof Buffer,r.uint8array="undefined"!=typeof Uint8Array,"undefined"==typeof ArrayBuffer)r.blob=false;else {var n=new ArrayBuffer(0);try{r.blob=0===new Blob([n],{type:"application/zip"}).size;}catch(e){try{var i=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);i.append(n),r.blob=0===i.getBlob("application/zip").size;}catch(e){r.blob=false;}}}try{r.nodestream=!!e("readable-stream").Readable;}catch(e){r.nodestream=false;}},{"readable-stream":16}],31:[function(e,t,s){for(var o=e("./utils"),h=e("./support"),r=e("./nodejsUtils"),n=e("./stream/GenericWorker"),u=new Array(256),i=0;i<256;i++)u[i]=252<=i?6:248<=i?5:240<=i?4:224<=i?3:192<=i?2:1;u[254]=u[254]=1;function a(){n.call(this,"utf-8 decode"),this.leftOver=null;}function l(){n.call(this,"utf-8 encode");}s.utf8encode=function(e){return h.nodebuffer?r.newBufferFrom(e,"utf-8"):function(e){var t,r,n,i,s,a=e.length,o=0;for(i=0;i<a;i++)55296==(64512&(r=e.charCodeAt(i)))&&i+1<a&&56320==(64512&(n=e.charCodeAt(i+1)))&&(r=65536+(r-55296<<10)+(n-56320),i++),o+=r<128?1:r<2048?2:r<65536?3:4;for(t=h.uint8array?new Uint8Array(o):new Array(o),i=s=0;s<o;i++)55296==(64512&(r=e.charCodeAt(i)))&&i+1<a&&56320==(64512&(n=e.charCodeAt(i+1)))&&(r=65536+(r-55296<<10)+(n-56320),i++),r<128?t[s++]=r:(r<2048?t[s++]=192|r>>>6:(r<65536?t[s++]=224|r>>>12:(t[s++]=240|r>>>18,t[s++]=128|r>>>12&63),t[s++]=128|r>>>6&63),t[s++]=128|63&r);return t}(e)},s.utf8decode=function(e){return h.nodebuffer?o.transformTo("nodebuffer",e).toString("utf-8"):function(e){var t,r,n,i,s=e.length,a=new Array(2*s);for(t=r=0;t<s;)if((n=e[t++])<128)a[r++]=n;else if(4<(i=u[n]))a[r++]=65533,t+=i-1;else {for(n&=2===i?31:3===i?15:7;1<i&&t<s;)n=n<<6|63&e[t++],i--;1<i?a[r++]=65533:n<65536?a[r++]=n:(n-=65536,a[r++]=55296|n>>10&1023,a[r++]=56320|1023&n);}return a.length!==r&&(a.subarray?a=a.subarray(0,r):a.length=r),o.applyFromCharCode(a)}(e=o.transformTo(h.uint8array?"uint8array":"array",e))},o.inherits(a,n),a.prototype.processChunk=function(e){var t=o.transformTo(h.uint8array?"uint8array":"array",e.data);if(this.leftOver&&this.leftOver.length){if(h.uint8array){var r=t;(t=new Uint8Array(r.length+this.leftOver.length)).set(this.leftOver,0),t.set(r,this.leftOver.length);}else t=this.leftOver.concat(t);this.leftOver=null;}var n=function(e,t){var r;for((t=t||e.length)>e.length&&(t=e.length),r=t-1;0<=r&&128==(192&e[r]);)r--;return r<0?t:0===r?t:r+u[e[r]]>t?r:t}(t),i=t;n!==t.length&&(h.uint8array?(i=t.subarray(0,n),this.leftOver=t.subarray(n,t.length)):(i=t.slice(0,n),this.leftOver=t.slice(n,t.length))),this.push({data:s.utf8decode(i),meta:e.meta});},a.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null);},s.Utf8DecodeWorker=a,o.inherits(l,n),l.prototype.processChunk=function(e){this.push({data:s.utf8encode(e.data),meta:e.meta});},s.Utf8EncodeWorker=l;},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,t,a){var o=e("./support"),h=e("./base64"),r=e("./nodejsUtils"),u=e("./external");function n(e){return e}function l(e,t){for(var r=0;r<e.length;++r)t[r]=255&e.charCodeAt(r);return t}e("setimmediate"),a.newBlob=function(t,r){a.checkSupport("blob");try{return new Blob([t],{type:r})}catch(e){try{var n=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return n.append(t),n.getBlob(r)}catch(e){throw new Error("Bug : can't construct the Blob.")}}};var i={stringifyByChunk:function(e,t,r){var n=[],i=0,s=e.length;if(s<=r)return String.fromCharCode.apply(null,e);for(;i<s;)"array"===t||"nodebuffer"===t?n.push(String.fromCharCode.apply(null,e.slice(i,Math.min(i+r,s)))):n.push(String.fromCharCode.apply(null,e.subarray(i,Math.min(i+r,s)))),i+=r;return n.join("")},stringifyByChar:function(e){for(var t="",r=0;r<e.length;r++)t+=String.fromCharCode(e[r]);return t},applyCanBeUsed:{uint8array:function(){try{return o.uint8array&&1===String.fromCharCode.apply(null,new Uint8Array(1)).length}catch(e){return  false}}(),nodebuffer:function(){try{return o.nodebuffer&&1===String.fromCharCode.apply(null,r.allocBuffer(1)).length}catch(e){return  false}}()}};function s(e){var t=65536,r=a.getTypeOf(e),n=true;if("uint8array"===r?n=i.applyCanBeUsed.uint8array:"nodebuffer"===r&&(n=i.applyCanBeUsed.nodebuffer),n)for(;1<t;)try{return i.stringifyByChunk(e,r,t)}catch(e){t=Math.floor(t/2);}return i.stringifyByChar(e)}function f(e,t){for(var r=0;r<e.length;r++)t[r]=e[r];return t}a.applyFromCharCode=s;var c={};c.string={string:n,array:function(e){return l(e,new Array(e.length))},arraybuffer:function(e){return c.string.uint8array(e).buffer},uint8array:function(e){return l(e,new Uint8Array(e.length))},nodebuffer:function(e){return l(e,r.allocBuffer(e.length))}},c.array={string:s,array:n,arraybuffer:function(e){return new Uint8Array(e).buffer},uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return r.newBufferFrom(e)}},c.arraybuffer={string:function(e){return s(new Uint8Array(e))},array:function(e){return f(new Uint8Array(e),new Array(e.byteLength))},arraybuffer:n,uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return r.newBufferFrom(new Uint8Array(e))}},c.uint8array={string:s,array:function(e){return f(e,new Array(e.length))},arraybuffer:function(e){return e.buffer},uint8array:n,nodebuffer:function(e){return r.newBufferFrom(e)}},c.nodebuffer={string:s,array:function(e){return f(e,new Array(e.length))},arraybuffer:function(e){return c.nodebuffer.uint8array(e).buffer},uint8array:function(e){return f(e,new Uint8Array(e.length))},nodebuffer:n},a.transformTo=function(e,t){if(t=t||"",!e)return t;a.checkSupport(e);var r=a.getTypeOf(t);return c[r][e](t)},a.resolve=function(e){for(var t=e.split("/"),r=[],n=0;n<t.length;n++){var i=t[n];"."===i||""===i&&0!==n&&n!==t.length-1||(".."===i?r.pop():r.push(i));}return r.join("/")},a.getTypeOf=function(e){return "string"==typeof e?"string":"[object Array]"===Object.prototype.toString.call(e)?"array":o.nodebuffer&&r.isBuffer(e)?"nodebuffer":o.uint8array&&e instanceof Uint8Array?"uint8array":o.arraybuffer&&e instanceof ArrayBuffer?"arraybuffer":void 0},a.checkSupport=function(e){if(!o[e.toLowerCase()])throw new Error(e+" is not supported by this platform")},a.MAX_VALUE_16BITS=65535,a.MAX_VALUE_32BITS=-1,a.pretty=function(e){var t,r,n="";for(r=0;r<(e||"").length;r++)n+="\\x"+((t=e.charCodeAt(r))<16?"0":"")+t.toString(16).toUpperCase();return n},a.delay=function(e,t,r){setImmediate(function(){e.apply(r||null,t||[]);});},a.inherits=function(e,t){function r(){}r.prototype=t.prototype,e.prototype=new r;},a.extend=function(){var e,t,r={};for(e=0;e<arguments.length;e++)for(t in arguments[e])Object.prototype.hasOwnProperty.call(arguments[e],t)&&void 0===r[t]&&(r[t]=arguments[e][t]);return r},a.prepareContent=function(r,e,n,i,s){return u.Promise.resolve(e).then(function(n){return o.blob&&(n instanceof Blob||-1!==["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(n)))&&"undefined"!=typeof FileReader?new u.Promise(function(t,r){var e=new FileReader;e.onload=function(e){t(e.target.result);},e.onerror=function(e){r(e.target.error);},e.readAsArrayBuffer(n);}):n}).then(function(e){var t=a.getTypeOf(e);return t?("arraybuffer"===t?e=a.transformTo("uint8array",e):"string"===t&&(s?e=h.decode(e):n&&true!==i&&(e=function(e){return l(e,o.uint8array?new Uint8Array(e.length):new Array(e.length))}(e))),e):u.Promise.reject(new Error("Can't read the data of '"+r+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})};},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,t,r){var n=e("./reader/readerFor"),i=e("./utils"),s=e("./signature"),a=e("./zipEntry"),o=e("./support");function h(e){this.files=[],this.loadOptions=e;}h.prototype={checkSignature:function(e){if(!this.reader.readAndCheckSignature(e)){this.reader.index-=4;var t=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+i.pretty(t)+", expected "+i.pretty(e)+")")}},isSignature:function(e,t){var r=this.reader.index;this.reader.setIndex(e);var n=this.reader.readString(4)===t;return this.reader.setIndex(r),n},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var e=this.reader.readData(this.zipCommentLength),t=o.uint8array?"uint8array":"array",r=i.transformTo(t,e);this.zipComment=this.loadOptions.decodeFileName(r);},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var e,t,r,n=this.zip64EndOfCentralSize-44;0<n;)e=this.reader.readInt(2),t=this.reader.readInt(4),r=this.reader.readData(t),this.zip64ExtensibleData[e]={id:e,length:t,value:r};},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var e,t;for(e=0;e<this.files.length;e++)t=this.files[e],this.reader.setIndex(t.localHeaderOffset),this.checkSignature(s.LOCAL_FILE_HEADER),t.readLocalPart(this.reader),t.handleUTF8(),t.processAttributes();},readCentralDir:function(){var e;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);)(e=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(e);if(this.centralDirRecords!==this.files.length&&0!==this.centralDirRecords&&0===this.files.length)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var e=this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);if(e<0)throw !this.isSignature(0,s.LOCAL_FILE_HEADER)?new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html"):new Error("Corrupted zip: can't find end of central directory");this.reader.setIndex(e);var t=e;if(this.checkSignature(s.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===i.MAX_VALUE_16BITS||this.diskWithCentralDirStart===i.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===i.MAX_VALUE_16BITS||this.centralDirRecords===i.MAX_VALUE_16BITS||this.centralDirSize===i.MAX_VALUE_32BITS||this.centralDirOffset===i.MAX_VALUE_32BITS){if(this.zip64=true,(e=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(e),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,s.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral();}var r=this.centralDirOffset+this.centralDirSize;this.zip64&&(r+=20,r+=12+this.zip64EndOfCentralSize);var n=t-r;if(0<n)this.isSignature(t,s.CENTRAL_FILE_HEADER)||(this.reader.zero=n);else if(n<0)throw new Error("Corrupted zip: missing "+Math.abs(n)+" bytes.")},prepareReader:function(e){this.reader=n(e);},load:function(e){this.prepareReader(e),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles();}},t.exports=h;},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,t,r){var n=e("./reader/readerFor"),s=e("./utils"),i=e("./compressedObject"),a=e("./crc32"),o=e("./utf8"),h=e("./compressions"),u=e("./support");function l(e,t){this.options=e,this.loadOptions=t;}l.prototype={isEncrypted:function(){return 1==(1&this.bitFlag)},useUTF8:function(){return 2048==(2048&this.bitFlag)},readLocalPart:function(e){var t,r;if(e.skip(22),this.fileNameLength=e.readInt(2),r=e.readInt(2),this.fileName=e.readData(this.fileNameLength),e.skip(r),-1===this.compressedSize||-1===this.uncompressedSize)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if(null===(t=function(e){for(var t in h)if(Object.prototype.hasOwnProperty.call(h,t)&&h[t].magic===e)return h[t];return null}(this.compressionMethod)))throw new Error("Corrupted zip : compression "+s.pretty(this.compressionMethod)+" unknown (inner file : "+s.transformTo("string",this.fileName)+")");this.decompressed=new i(this.compressedSize,this.uncompressedSize,this.crc32,t,e.readData(this.compressedSize));},readCentralPart:function(e){this.versionMadeBy=e.readInt(2),e.skip(2),this.bitFlag=e.readInt(2),this.compressionMethod=e.readString(2),this.date=e.readDate(),this.crc32=e.readInt(4),this.compressedSize=e.readInt(4),this.uncompressedSize=e.readInt(4);var t=e.readInt(2);if(this.extraFieldsLength=e.readInt(2),this.fileCommentLength=e.readInt(2),this.diskNumberStart=e.readInt(2),this.internalFileAttributes=e.readInt(2),this.externalFileAttributes=e.readInt(4),this.localHeaderOffset=e.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");e.skip(t),this.readExtraFields(e),this.parseZIP64ExtraField(e),this.fileComment=e.readData(this.fileCommentLength);},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var e=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),0==e&&(this.dosPermissions=63&this.externalFileAttributes),3==e&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||"/"!==this.fileNameStr.slice(-1)||(this.dir=true);},parseZIP64ExtraField:function(){if(this.extraFields[1]){var e=n(this.extraFields[1].value);this.uncompressedSize===s.MAX_VALUE_32BITS&&(this.uncompressedSize=e.readInt(8)),this.compressedSize===s.MAX_VALUE_32BITS&&(this.compressedSize=e.readInt(8)),this.localHeaderOffset===s.MAX_VALUE_32BITS&&(this.localHeaderOffset=e.readInt(8)),this.diskNumberStart===s.MAX_VALUE_32BITS&&(this.diskNumberStart=e.readInt(4));}},readExtraFields:function(e){var t,r,n,i=e.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});e.index+4<i;)t=e.readInt(2),r=e.readInt(2),n=e.readData(r),this.extraFields[t]={id:t,length:r,value:n};e.setIndex(i);},handleUTF8:function(){var e=u.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=o.utf8decode(this.fileName),this.fileCommentStr=o.utf8decode(this.fileComment);else {var t=this.findExtraFieldUnicodePath();if(null!==t)this.fileNameStr=t;else {var r=s.transformTo(e,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(r);}var n=this.findExtraFieldUnicodeComment();if(null!==n)this.fileCommentStr=n;else {var i=s.transformTo(e,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(i);}}},findExtraFieldUnicodePath:function(){var e=this.extraFields[28789];if(e){var t=n(e.value);return 1!==t.readInt(1)?null:a(this.fileName)!==t.readInt(4)?null:o.utf8decode(t.readData(e.length-5))}return null},findExtraFieldUnicodeComment:function(){var e=this.extraFields[25461];if(e){var t=n(e.value);return 1!==t.readInt(1)?null:a(this.fileComment)!==t.readInt(4)?null:o.utf8decode(t.readData(e.length-5))}return null}},t.exports=l;},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,t,r){function n(e,t,r){this.name=e,this.dir=r.dir,this.date=r.date,this.comment=r.comment,this.unixPermissions=r.unixPermissions,this.dosPermissions=r.dosPermissions,this._data=t,this._dataBinary=r.binary,this.options={compression:r.compression,compressionOptions:r.compressionOptions};}var s=e("./stream/StreamHelper"),i=e("./stream/DataWorker"),a=e("./utf8"),o=e("./compressedObject"),h=e("./stream/GenericWorker");n.prototype={internalStream:function(e){var t=null,r="string";try{if(!e)throw new Error("No output type specified.");var n="string"===(r=e.toLowerCase())||"text"===r;"binarystring"!==r&&"text"!==r||(r="string"),t=this._decompressWorker();var i=!this._dataBinary;i&&!n&&(t=t.pipe(new a.Utf8EncodeWorker)),!i&&n&&(t=t.pipe(new a.Utf8DecodeWorker));}catch(e){(t=new h("error")).error(e);}return new s(t,r,"")},async:function(e,t){return this.internalStream(e).accumulate(t)},nodeStream:function(e,t){return this.internalStream(e||"nodebuffer").toNodejsStream(t)},_compressWorker:function(e,t){if(this._data instanceof o&&this._data.compression.magic===e.magic)return this._data.getCompressedWorker();var r=this._decompressWorker();return this._dataBinary||(r=r.pipe(new a.Utf8EncodeWorker)),o.createWorkerFrom(r,e,t)},_decompressWorker:function(){return this._data instanceof o?this._data.getContentWorker():this._data instanceof h?this._data:new i(this._data)}};for(var u=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],l=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<u.length;f++)n.prototype[u[f]]=l;t.exports=n;},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,l,t){(function(t){var r,n,e=t.MutationObserver||t.WebKitMutationObserver;if(e){var i=0,s=new e(u),a=t.document.createTextNode("");s.observe(a,{characterData:true}),r=function(){a.data=i=++i%2;};}else if(t.setImmediate||void 0===t.MessageChannel)r="document"in t&&"onreadystatechange"in t.document.createElement("script")?function(){var e=t.document.createElement("script");e.onreadystatechange=function(){u(),e.onreadystatechange=null,e.parentNode.removeChild(e),e=null;},t.document.documentElement.appendChild(e);}:function(){setTimeout(u,0);};else {var o=new t.MessageChannel;o.port1.onmessage=u,r=function(){o.port2.postMessage(0);};}var h=[];function u(){var e,t;n=true;for(var r=h.length;r;){for(t=h,h=[],e=-1;++e<r;)t[e]();r=h.length;}n=false;}l.exports=function(e){1!==h.push(e)||n||r();};}).call(this,"undefined"!=typeof commonjsGlobal?commonjsGlobal:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});},{}],37:[function(e,t,r){var i=e("immediate");function u(){}var l={},s=["REJECTED"],a=["FULFILLED"],n=["PENDING"];function o(e){if("function"!=typeof e)throw new TypeError("resolver must be a function");this.state=n,this.queue=[],this.outcome=void 0,e!==u&&d(this,e);}function h(e,t,r){this.promise=e,"function"==typeof t&&(this.onFulfilled=t,this.callFulfilled=this.otherCallFulfilled),"function"==typeof r&&(this.onRejected=r,this.callRejected=this.otherCallRejected);}function f(t,r,n){i(function(){var e;try{e=r(n);}catch(e){return l.reject(t,e)}e===t?l.reject(t,new TypeError("Cannot resolve promise with itself")):l.resolve(t,e);});}function c(e){var t=e&&e.then;if(e&&("object"==typeof e||"function"==typeof e)&&"function"==typeof t)return function(){t.apply(e,arguments);}}function d(t,e){var r=false;function n(e){r||(r=true,l.reject(t,e));}function i(e){r||(r=true,l.resolve(t,e));}var s=p(function(){e(i,n);});"error"===s.status&&n(s.value);}function p(e,t){var r={};try{r.value=e(t),r.status="success";}catch(e){r.status="error",r.value=e;}return r}(t.exports=o).prototype.finally=function(t){if("function"!=typeof t)return this;var r=this.constructor;return this.then(function(e){return r.resolve(t()).then(function(){return e})},function(e){return r.resolve(t()).then(function(){throw e})})},o.prototype.catch=function(e){return this.then(null,e)},o.prototype.then=function(e,t){if("function"!=typeof e&&this.state===a||"function"!=typeof t&&this.state===s)return this;var r=new this.constructor(u);this.state!==n?f(r,this.state===a?e:t,this.outcome):this.queue.push(new h(r,e,t));return r},h.prototype.callFulfilled=function(e){l.resolve(this.promise,e);},h.prototype.otherCallFulfilled=function(e){f(this.promise,this.onFulfilled,e);},h.prototype.callRejected=function(e){l.reject(this.promise,e);},h.prototype.otherCallRejected=function(e){f(this.promise,this.onRejected,e);},l.resolve=function(e,t){var r=p(c,t);if("error"===r.status)return l.reject(e,r.value);var n=r.value;if(n)d(e,n);else {e.state=a,e.outcome=t;for(var i=-1,s=e.queue.length;++i<s;)e.queue[i].callFulfilled(t);}return e},l.reject=function(e,t){e.state=s,e.outcome=t;for(var r=-1,n=e.queue.length;++r<n;)e.queue[r].callRejected(t);return e},o.resolve=function(e){if(e instanceof this)return e;return l.resolve(new this(u),e)},o.reject=function(e){var t=new this(u);return l.reject(t,e)},o.all=function(e){var r=this;if("[object Array]"!==Object.prototype.toString.call(e))return this.reject(new TypeError("must be an array"));var n=e.length,i=false;if(!n)return this.resolve([]);var s=new Array(n),a=0,t=-1,o=new this(u);for(;++t<n;)h(e[t],t);return o;function h(e,t){r.resolve(e).then(function(e){s[t]=e,++a!==n||i||(i=true,l.resolve(o,s));},function(e){i||(i=true,l.reject(o,e));});}},o.race=function(e){var t=this;if("[object Array]"!==Object.prototype.toString.call(e))return this.reject(new TypeError("must be an array"));var r=e.length,n=false;if(!r)return this.resolve([]);var i=-1,s=new this(u);for(;++i<r;)a=e[i],t.resolve(a).then(function(e){n||(n=true,l.resolve(s,e));},function(e){n||(n=true,l.reject(s,e));});var a;return s};},{immediate:36}],38:[function(e,t,r){var n={};(0, e("./lib/utils/common").assign)(n,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),t.exports=n;},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,t,r){var a=e("./zlib/deflate"),o=e("./utils/common"),h=e("./utils/strings"),i=e("./zlib/messages"),s=e("./zlib/zstream"),u=Object.prototype.toString,l=0,f=-1,c=0,d=8;function p(e){if(!(this instanceof p))return new p(e);this.options=o.assign({level:f,method:d,chunkSize:16384,windowBits:15,memLevel:8,strategy:c,to:""},e||{});var t=this.options;t.raw&&0<t.windowBits?t.windowBits=-t.windowBits:t.gzip&&0<t.windowBits&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg="",this.ended=false,this.chunks=[],this.strm=new s,this.strm.avail_out=0;var r=a.deflateInit2(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy);if(r!==l)throw new Error(i[r]);if(t.header&&a.deflateSetHeader(this.strm,t.header),t.dictionary){var n;if(n="string"==typeof t.dictionary?h.string2buf(t.dictionary):"[object ArrayBuffer]"===u.call(t.dictionary)?new Uint8Array(t.dictionary):t.dictionary,(r=a.deflateSetDictionary(this.strm,n))!==l)throw new Error(i[r]);this._dict_set=true;}}function n(e,t){var r=new p(t);if(r.push(e,true),r.err)throw r.msg||i[r.err];return r.result}p.prototype.push=function(e,t){var r,n,i=this.strm,s=this.options.chunkSize;if(this.ended)return  false;n=t===~~t?t:true===t?4:0,"string"==typeof e?i.input=h.string2buf(e):"[object ArrayBuffer]"===u.call(e)?i.input=new Uint8Array(e):i.input=e,i.next_in=0,i.avail_in=i.input.length;do{if(0===i.avail_out&&(i.output=new o.Buf8(s),i.next_out=0,i.avail_out=s),1!==(r=a.deflate(i,n))&&r!==l)return this.onEnd(r),!(this.ended=true);0!==i.avail_out&&(0!==i.avail_in||4!==n&&2!==n)||("string"===this.options.to?this.onData(h.buf2binstring(o.shrinkBuf(i.output,i.next_out))):this.onData(o.shrinkBuf(i.output,i.next_out)));}while((0<i.avail_in||0===i.avail_out)&&1!==r);return 4===n?(r=a.deflateEnd(this.strm),this.onEnd(r),this.ended=true,r===l):2!==n||(this.onEnd(l),!(i.avail_out=0))},p.prototype.onData=function(e){this.chunks.push(e);},p.prototype.onEnd=function(e){e===l&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=o.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg;},r.Deflate=p,r.deflate=n,r.deflateRaw=function(e,t){return (t=t||{}).raw=true,n(e,t)},r.gzip=function(e,t){return (t=t||{}).gzip=true,n(e,t)};},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,t,r){var c=e("./zlib/inflate"),d=e("./utils/common"),p=e("./utils/strings"),m=e("./zlib/constants"),n=e("./zlib/messages"),i=e("./zlib/zstream"),s=e("./zlib/gzheader"),_=Object.prototype.toString;function a(e){if(!(this instanceof a))return new a(e);this.options=d.assign({chunkSize:16384,windowBits:0,to:""},e||{});var t=this.options;t.raw&&0<=t.windowBits&&t.windowBits<16&&(t.windowBits=-t.windowBits,0===t.windowBits&&(t.windowBits=-15)),!(0<=t.windowBits&&t.windowBits<16)||e&&e.windowBits||(t.windowBits+=32),15<t.windowBits&&t.windowBits<48&&0==(15&t.windowBits)&&(t.windowBits|=15),this.err=0,this.msg="",this.ended=false,this.chunks=[],this.strm=new i,this.strm.avail_out=0;var r=c.inflateInit2(this.strm,t.windowBits);if(r!==m.Z_OK)throw new Error(n[r]);this.header=new s,c.inflateGetHeader(this.strm,this.header);}function o(e,t){var r=new a(t);if(r.push(e,true),r.err)throw r.msg||n[r.err];return r.result}a.prototype.push=function(e,t){var r,n,i,s,a,o,h=this.strm,u=this.options.chunkSize,l=this.options.dictionary,f=false;if(this.ended)return  false;n=t===~~t?t:true===t?m.Z_FINISH:m.Z_NO_FLUSH,"string"==typeof e?h.input=p.binstring2buf(e):"[object ArrayBuffer]"===_.call(e)?h.input=new Uint8Array(e):h.input=e,h.next_in=0,h.avail_in=h.input.length;do{if(0===h.avail_out&&(h.output=new d.Buf8(u),h.next_out=0,h.avail_out=u),(r=c.inflate(h,m.Z_NO_FLUSH))===m.Z_NEED_DICT&&l&&(o="string"==typeof l?p.string2buf(l):"[object ArrayBuffer]"===_.call(l)?new Uint8Array(l):l,r=c.inflateSetDictionary(this.strm,o)),r===m.Z_BUF_ERROR&&true===f&&(r=m.Z_OK,f=false),r!==m.Z_STREAM_END&&r!==m.Z_OK)return this.onEnd(r),!(this.ended=true);h.next_out&&(0!==h.avail_out&&r!==m.Z_STREAM_END&&(0!==h.avail_in||n!==m.Z_FINISH&&n!==m.Z_SYNC_FLUSH)||("string"===this.options.to?(i=p.utf8border(h.output,h.next_out),s=h.next_out-i,a=p.buf2string(h.output,i),h.next_out=s,h.avail_out=u-s,s&&d.arraySet(h.output,h.output,i,s,0),this.onData(a)):this.onData(d.shrinkBuf(h.output,h.next_out)))),0===h.avail_in&&0===h.avail_out&&(f=true);}while((0<h.avail_in||0===h.avail_out)&&r!==m.Z_STREAM_END);return r===m.Z_STREAM_END&&(n=m.Z_FINISH),n===m.Z_FINISH?(r=c.inflateEnd(this.strm),this.onEnd(r),this.ended=true,r===m.Z_OK):n!==m.Z_SYNC_FLUSH||(this.onEnd(m.Z_OK),!(h.avail_out=0))},a.prototype.onData=function(e){this.chunks.push(e);},a.prototype.onEnd=function(e){e===m.Z_OK&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=d.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg;},r.Inflate=a,r.inflate=o,r.inflateRaw=function(e,t){return (t=t||{}).raw=true,o(e,t)},r.ungzip=o;},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,t,r){var n="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Int32Array;r.assign=function(e){for(var t=Array.prototype.slice.call(arguments,1);t.length;){var r=t.shift();if(r){if("object"!=typeof r)throw new TypeError(r+"must be non-object");for(var n in r)r.hasOwnProperty(n)&&(e[n]=r[n]);}}return e},r.shrinkBuf=function(e,t){return e.length===t?e:e.subarray?e.subarray(0,t):(e.length=t,e)};var i={arraySet:function(e,t,r,n,i){if(t.subarray&&e.subarray)e.set(t.subarray(r,r+n),i);else for(var s=0;s<n;s++)e[i+s]=t[r+s];},flattenChunks:function(e){var t,r,n,i,s,a;for(t=n=0,r=e.length;t<r;t++)n+=e[t].length;for(a=new Uint8Array(n),t=i=0,r=e.length;t<r;t++)s=e[t],a.set(s,i),i+=s.length;return a}},s={arraySet:function(e,t,r,n,i){for(var s=0;s<n;s++)e[i+s]=t[r+s];},flattenChunks:function(e){return [].concat.apply([],e)}};r.setTyped=function(e){e?(r.Buf8=Uint8Array,r.Buf16=Uint16Array,r.Buf32=Int32Array,r.assign(r,i)):(r.Buf8=Array,r.Buf16=Array,r.Buf32=Array,r.assign(r,s));},r.setTyped(n);},{}],42:[function(e,t,r){var h=e("./common"),i=true,s=true;try{String.fromCharCode.apply(null,[0]);}catch(e){i=false;}try{String.fromCharCode.apply(null,new Uint8Array(1));}catch(e){s=false;}for(var u=new h.Buf8(256),n=0;n<256;n++)u[n]=252<=n?6:248<=n?5:240<=n?4:224<=n?3:192<=n?2:1;function l(e,t){if(t<65537&&(e.subarray&&s||!e.subarray&&i))return String.fromCharCode.apply(null,h.shrinkBuf(e,t));for(var r="",n=0;n<t;n++)r+=String.fromCharCode(e[n]);return r}u[254]=u[254]=1,r.string2buf=function(e){var t,r,n,i,s,a=e.length,o=0;for(i=0;i<a;i++)55296==(64512&(r=e.charCodeAt(i)))&&i+1<a&&56320==(64512&(n=e.charCodeAt(i+1)))&&(r=65536+(r-55296<<10)+(n-56320),i++),o+=r<128?1:r<2048?2:r<65536?3:4;for(t=new h.Buf8(o),i=s=0;s<o;i++)55296==(64512&(r=e.charCodeAt(i)))&&i+1<a&&56320==(64512&(n=e.charCodeAt(i+1)))&&(r=65536+(r-55296<<10)+(n-56320),i++),r<128?t[s++]=r:(r<2048?t[s++]=192|r>>>6:(r<65536?t[s++]=224|r>>>12:(t[s++]=240|r>>>18,t[s++]=128|r>>>12&63),t[s++]=128|r>>>6&63),t[s++]=128|63&r);return t},r.buf2binstring=function(e){return l(e,e.length)},r.binstring2buf=function(e){for(var t=new h.Buf8(e.length),r=0,n=t.length;r<n;r++)t[r]=e.charCodeAt(r);return t},r.buf2string=function(e,t){var r,n,i,s,a=t||e.length,o=new Array(2*a);for(r=n=0;r<a;)if((i=e[r++])<128)o[n++]=i;else if(4<(s=u[i]))o[n++]=65533,r+=s-1;else {for(i&=2===s?31:3===s?15:7;1<s&&r<a;)i=i<<6|63&e[r++],s--;1<s?o[n++]=65533:i<65536?o[n++]=i:(i-=65536,o[n++]=55296|i>>10&1023,o[n++]=56320|1023&i);}return l(o,n)},r.utf8border=function(e,t){var r;for((t=t||e.length)>e.length&&(t=e.length),r=t-1;0<=r&&128==(192&e[r]);)r--;return r<0?t:0===r?t:r+u[e[r]]>t?r:t};},{"./common":41}],43:[function(e,t,r){t.exports=function(e,t,r,n){for(var i=65535&e|0,s=e>>>16&65535|0,a=0;0!==r;){for(r-=a=2e3<r?2e3:r;s=s+(i=i+t[n++]|0)|0,--a;);i%=65521,s%=65521;}return i|s<<16|0};},{}],44:[function(e,t,r){t.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8};},{}],45:[function(e,t,r){var o=function(){for(var e,t=[],r=0;r<256;r++){e=r;for(var n=0;n<8;n++)e=1&e?3988292384^e>>>1:e>>>1;t[r]=e;}return t}();t.exports=function(e,t,r,n){var i=o,s=n+r;e^=-1;for(var a=n;a<s;a++)e=e>>>8^i[255&(e^t[a])];return  -1^e};},{}],46:[function(e,t,r){var h,c=e("../utils/common"),u=e("./trees"),d=e("./adler32"),p=e("./crc32"),n=e("./messages"),l=0,f=4,m=0,_=-2,g=-1,b=4,i=2,v=8,y=9,s=286,a=30,o=19,w=2*s+1,k=15,x=3,S=258,z=S+x+1,C=42,E=113,A=1,I=2,O=3,B=4;function R(e,t){return e.msg=n[t],t}function T(e){return (e<<1)-(4<e?9:0)}function D(e){for(var t=e.length;0<=--t;)e[t]=0;}function F(e){var t=e.state,r=t.pending;r>e.avail_out&&(r=e.avail_out),0!==r&&(c.arraySet(e.output,t.pending_buf,t.pending_out,r,e.next_out),e.next_out+=r,t.pending_out+=r,e.total_out+=r,e.avail_out-=r,t.pending-=r,0===t.pending&&(t.pending_out=0));}function N(e,t){u._tr_flush_block(e,0<=e.block_start?e.block_start:-1,e.strstart-e.block_start,t),e.block_start=e.strstart,F(e.strm);}function U(e,t){e.pending_buf[e.pending++]=t;}function P(e,t){e.pending_buf[e.pending++]=t>>>8&255,e.pending_buf[e.pending++]=255&t;}function L(e,t){var r,n,i=e.max_chain_length,s=e.strstart,a=e.prev_length,o=e.nice_match,h=e.strstart>e.w_size-z?e.strstart-(e.w_size-z):0,u=e.window,l=e.w_mask,f=e.prev,c=e.strstart+S,d=u[s+a-1],p=u[s+a];e.prev_length>=e.good_match&&(i>>=2),o>e.lookahead&&(o=e.lookahead);do{if(u[(r=t)+a]===p&&u[r+a-1]===d&&u[r]===u[s]&&u[++r]===u[s+1]){s+=2,r++;do{}while(u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&u[++s]===u[++r]&&s<c);if(n=S-(c-s),s=c-S,a<n){if(e.match_start=t,o<=(a=n))break;d=u[s+a-1],p=u[s+a];}}}while((t=f[t&l])>h&&0!=--i);return a<=e.lookahead?a:e.lookahead}function j(e){var t,r,n,i,s,a,o,h,u,l,f=e.w_size;do{if(i=e.window_size-e.lookahead-e.strstart,e.strstart>=f+(f-z)){for(c.arraySet(e.window,e.window,f,f,0),e.match_start-=f,e.strstart-=f,e.block_start-=f,t=r=e.hash_size;n=e.head[--t],e.head[t]=f<=n?n-f:0,--r;);for(t=r=f;n=e.prev[--t],e.prev[t]=f<=n?n-f:0,--r;);i+=f;}if(0===e.strm.avail_in)break;if(a=e.strm,o=e.window,h=e.strstart+e.lookahead,u=i,l=void 0,l=a.avail_in,u<l&&(l=u),r=0===l?0:(a.avail_in-=l,c.arraySet(o,a.input,a.next_in,l,h),1===a.state.wrap?a.adler=d(a.adler,o,l,h):2===a.state.wrap&&(a.adler=p(a.adler,o,l,h)),a.next_in+=l,a.total_in+=l,l),e.lookahead+=r,e.lookahead+e.insert>=x)for(s=e.strstart-e.insert,e.ins_h=e.window[s],e.ins_h=(e.ins_h<<e.hash_shift^e.window[s+1])&e.hash_mask;e.insert&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[s+x-1])&e.hash_mask,e.prev[s&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=s,s++,e.insert--,!(e.lookahead+e.insert<x)););}while(e.lookahead<z&&0!==e.strm.avail_in)}function Z(e,t){for(var r,n;;){if(e.lookahead<z){if(j(e),e.lookahead<z&&t===l)return A;if(0===e.lookahead)break}if(r=0,e.lookahead>=x&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+x-1])&e.hash_mask,r=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),0!==r&&e.strstart-r<=e.w_size-z&&(e.match_length=L(e,r)),e.match_length>=x)if(n=u._tr_tally(e,e.strstart-e.match_start,e.match_length-x),e.lookahead-=e.match_length,e.match_length<=e.max_lazy_match&&e.lookahead>=x){for(e.match_length--;e.strstart++,e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+x-1])&e.hash_mask,r=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart,0!=--e.match_length;);e.strstart++;}else e.strstart+=e.match_length,e.match_length=0,e.ins_h=e.window[e.strstart],e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+1])&e.hash_mask;else n=u._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++;if(n&&(N(e,false),0===e.strm.avail_out))return A}return e.insert=e.strstart<x-1?e.strstart:x-1,t===f?(N(e,true),0===e.strm.avail_out?O:B):e.last_lit&&(N(e,false),0===e.strm.avail_out)?A:I}function W(e,t){for(var r,n,i;;){if(e.lookahead<z){if(j(e),e.lookahead<z&&t===l)return A;if(0===e.lookahead)break}if(r=0,e.lookahead>=x&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+x-1])&e.hash_mask,r=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),e.prev_length=e.match_length,e.prev_match=e.match_start,e.match_length=x-1,0!==r&&e.prev_length<e.max_lazy_match&&e.strstart-r<=e.w_size-z&&(e.match_length=L(e,r),e.match_length<=5&&(1===e.strategy||e.match_length===x&&4096<e.strstart-e.match_start)&&(e.match_length=x-1)),e.prev_length>=x&&e.match_length<=e.prev_length){for(i=e.strstart+e.lookahead-x,n=u._tr_tally(e,e.strstart-1-e.prev_match,e.prev_length-x),e.lookahead-=e.prev_length-1,e.prev_length-=2;++e.strstart<=i&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+x-1])&e.hash_mask,r=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),0!=--e.prev_length;);if(e.match_available=0,e.match_length=x-1,e.strstart++,n&&(N(e,false),0===e.strm.avail_out))return A}else if(e.match_available){if((n=u._tr_tally(e,0,e.window[e.strstart-1]))&&N(e,false),e.strstart++,e.lookahead--,0===e.strm.avail_out)return A}else e.match_available=1,e.strstart++,e.lookahead--;}return e.match_available&&(n=u._tr_tally(e,0,e.window[e.strstart-1]),e.match_available=0),e.insert=e.strstart<x-1?e.strstart:x-1,t===f?(N(e,true),0===e.strm.avail_out?O:B):e.last_lit&&(N(e,false),0===e.strm.avail_out)?A:I}function M(e,t,r,n,i){this.good_length=e,this.max_lazy=t,this.nice_length=r,this.max_chain=n,this.func=i;}function H(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=v,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new c.Buf16(2*w),this.dyn_dtree=new c.Buf16(2*(2*a+1)),this.bl_tree=new c.Buf16(2*(2*o+1)),D(this.dyn_ltree),D(this.dyn_dtree),D(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new c.Buf16(k+1),this.heap=new c.Buf16(2*s+1),D(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new c.Buf16(2*s+1),D(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0;}function G(e){var t;return e&&e.state?(e.total_in=e.total_out=0,e.data_type=i,(t=e.state).pending=0,t.pending_out=0,t.wrap<0&&(t.wrap=-t.wrap),t.status=t.wrap?C:E,e.adler=2===t.wrap?0:1,t.last_flush=l,u._tr_init(t),m):R(e,_)}function K(e){var t=G(e);return t===m&&function(e){e.window_size=2*e.w_size,D(e.head),e.max_lazy_match=h[e.level].max_lazy,e.good_match=h[e.level].good_length,e.nice_match=h[e.level].nice_length,e.max_chain_length=h[e.level].max_chain,e.strstart=0,e.block_start=0,e.lookahead=0,e.insert=0,e.match_length=e.prev_length=x-1,e.match_available=0,e.ins_h=0;}(e.state),t}function Y(e,t,r,n,i,s){if(!e)return _;var a=1;if(t===g&&(t=6),n<0?(a=0,n=-n):15<n&&(a=2,n-=16),i<1||y<i||r!==v||n<8||15<n||t<0||9<t||s<0||b<s)return R(e,_);8===n&&(n=9);var o=new H;return (e.state=o).strm=e,o.wrap=a,o.gzhead=null,o.w_bits=n,o.w_size=1<<o.w_bits,o.w_mask=o.w_size-1,o.hash_bits=i+7,o.hash_size=1<<o.hash_bits,o.hash_mask=o.hash_size-1,o.hash_shift=~~((o.hash_bits+x-1)/x),o.window=new c.Buf8(2*o.w_size),o.head=new c.Buf16(o.hash_size),o.prev=new c.Buf16(o.w_size),o.lit_bufsize=1<<i+6,o.pending_buf_size=4*o.lit_bufsize,o.pending_buf=new c.Buf8(o.pending_buf_size),o.d_buf=1*o.lit_bufsize,o.l_buf=3*o.lit_bufsize,o.level=t,o.strategy=s,o.method=r,K(e)}h=[new M(0,0,0,0,function(e,t){var r=65535;for(r>e.pending_buf_size-5&&(r=e.pending_buf_size-5);;){if(e.lookahead<=1){if(j(e),0===e.lookahead&&t===l)return A;if(0===e.lookahead)break}e.strstart+=e.lookahead,e.lookahead=0;var n=e.block_start+r;if((0===e.strstart||e.strstart>=n)&&(e.lookahead=e.strstart-n,e.strstart=n,N(e,false),0===e.strm.avail_out))return A;if(e.strstart-e.block_start>=e.w_size-z&&(N(e,false),0===e.strm.avail_out))return A}return e.insert=0,t===f?(N(e,true),0===e.strm.avail_out?O:B):(e.strstart>e.block_start&&(N(e,false),e.strm.avail_out),A)}),new M(4,4,8,4,Z),new M(4,5,16,8,Z),new M(4,6,32,32,Z),new M(4,4,16,16,W),new M(8,16,32,32,W),new M(8,16,128,128,W),new M(8,32,128,256,W),new M(32,128,258,1024,W),new M(32,258,258,4096,W)],r.deflateInit=function(e,t){return Y(e,t,v,15,8,0)},r.deflateInit2=Y,r.deflateReset=K,r.deflateResetKeep=G,r.deflateSetHeader=function(e,t){return e&&e.state?2!==e.state.wrap?_:(e.state.gzhead=t,m):_},r.deflate=function(e,t){var r,n,i,s;if(!e||!e.state||5<t||t<0)return e?R(e,_):_;if(n=e.state,!e.output||!e.input&&0!==e.avail_in||666===n.status&&t!==f)return R(e,0===e.avail_out?-5:_);if(n.strm=e,r=n.last_flush,n.last_flush=t,n.status===C)if(2===n.wrap)e.adler=0,U(n,31),U(n,139),U(n,8),n.gzhead?(U(n,(n.gzhead.text?1:0)+(n.gzhead.hcrc?2:0)+(n.gzhead.extra?4:0)+(n.gzhead.name?8:0)+(n.gzhead.comment?16:0)),U(n,255&n.gzhead.time),U(n,n.gzhead.time>>8&255),U(n,n.gzhead.time>>16&255),U(n,n.gzhead.time>>24&255),U(n,9===n.level?2:2<=n.strategy||n.level<2?4:0),U(n,255&n.gzhead.os),n.gzhead.extra&&n.gzhead.extra.length&&(U(n,255&n.gzhead.extra.length),U(n,n.gzhead.extra.length>>8&255)),n.gzhead.hcrc&&(e.adler=p(e.adler,n.pending_buf,n.pending,0)),n.gzindex=0,n.status=69):(U(n,0),U(n,0),U(n,0),U(n,0),U(n,0),U(n,9===n.level?2:2<=n.strategy||n.level<2?4:0),U(n,3),n.status=E);else {var a=v+(n.w_bits-8<<4)<<8;a|=(2<=n.strategy||n.level<2?0:n.level<6?1:6===n.level?2:3)<<6,0!==n.strstart&&(a|=32),a+=31-a%31,n.status=E,P(n,a),0!==n.strstart&&(P(n,e.adler>>>16),P(n,65535&e.adler)),e.adler=1;}if(69===n.status)if(n.gzhead.extra){for(i=n.pending;n.gzindex<(65535&n.gzhead.extra.length)&&(n.pending!==n.pending_buf_size||(n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),F(e),i=n.pending,n.pending!==n.pending_buf_size));)U(n,255&n.gzhead.extra[n.gzindex]),n.gzindex++;n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),n.gzindex===n.gzhead.extra.length&&(n.gzindex=0,n.status=73);}else n.status=73;if(73===n.status)if(n.gzhead.name){i=n.pending;do{if(n.pending===n.pending_buf_size&&(n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),F(e),i=n.pending,n.pending===n.pending_buf_size)){s=1;break}s=n.gzindex<n.gzhead.name.length?255&n.gzhead.name.charCodeAt(n.gzindex++):0,U(n,s);}while(0!==s);n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),0===s&&(n.gzindex=0,n.status=91);}else n.status=91;if(91===n.status)if(n.gzhead.comment){i=n.pending;do{if(n.pending===n.pending_buf_size&&(n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),F(e),i=n.pending,n.pending===n.pending_buf_size)){s=1;break}s=n.gzindex<n.gzhead.comment.length?255&n.gzhead.comment.charCodeAt(n.gzindex++):0,U(n,s);}while(0!==s);n.gzhead.hcrc&&n.pending>i&&(e.adler=p(e.adler,n.pending_buf,n.pending-i,i)),0===s&&(n.status=103);}else n.status=103;if(103===n.status&&(n.gzhead.hcrc?(n.pending+2>n.pending_buf_size&&F(e),n.pending+2<=n.pending_buf_size&&(U(n,255&e.adler),U(n,e.adler>>8&255),e.adler=0,n.status=E)):n.status=E),0!==n.pending){if(F(e),0===e.avail_out)return n.last_flush=-1,m}else if(0===e.avail_in&&T(t)<=T(r)&&t!==f)return R(e,-5);if(666===n.status&&0!==e.avail_in)return R(e,-5);if(0!==e.avail_in||0!==n.lookahead||t!==l&&666!==n.status){var o=2===n.strategy?function(e,t){for(var r;;){if(0===e.lookahead&&(j(e),0===e.lookahead)){if(t===l)return A;break}if(e.match_length=0,r=u._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++,r&&(N(e,false),0===e.strm.avail_out))return A}return e.insert=0,t===f?(N(e,true),0===e.strm.avail_out?O:B):e.last_lit&&(N(e,false),0===e.strm.avail_out)?A:I}(n,t):3===n.strategy?function(e,t){for(var r,n,i,s,a=e.window;;){if(e.lookahead<=S){if(j(e),e.lookahead<=S&&t===l)return A;if(0===e.lookahead)break}if(e.match_length=0,e.lookahead>=x&&0<e.strstart&&(n=a[i=e.strstart-1])===a[++i]&&n===a[++i]&&n===a[++i]){s=e.strstart+S;do{}while(n===a[++i]&&n===a[++i]&&n===a[++i]&&n===a[++i]&&n===a[++i]&&n===a[++i]&&n===a[++i]&&n===a[++i]&&i<s);e.match_length=S-(s-i),e.match_length>e.lookahead&&(e.match_length=e.lookahead);}if(e.match_length>=x?(r=u._tr_tally(e,1,e.match_length-x),e.lookahead-=e.match_length,e.strstart+=e.match_length,e.match_length=0):(r=u._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++),r&&(N(e,false),0===e.strm.avail_out))return A}return e.insert=0,t===f?(N(e,true),0===e.strm.avail_out?O:B):e.last_lit&&(N(e,false),0===e.strm.avail_out)?A:I}(n,t):h[n.level].func(n,t);if(o!==O&&o!==B||(n.status=666),o===A||o===O)return 0===e.avail_out&&(n.last_flush=-1),m;if(o===I&&(1===t?u._tr_align(n):5!==t&&(u._tr_stored_block(n,0,0,false),3===t&&(D(n.head),0===n.lookahead&&(n.strstart=0,n.block_start=0,n.insert=0))),F(e),0===e.avail_out))return n.last_flush=-1,m}return t!==f?m:n.wrap<=0?1:(2===n.wrap?(U(n,255&e.adler),U(n,e.adler>>8&255),U(n,e.adler>>16&255),U(n,e.adler>>24&255),U(n,255&e.total_in),U(n,e.total_in>>8&255),U(n,e.total_in>>16&255),U(n,e.total_in>>24&255)):(P(n,e.adler>>>16),P(n,65535&e.adler)),F(e),0<n.wrap&&(n.wrap=-n.wrap),0!==n.pending?m:1)},r.deflateEnd=function(e){var t;return e&&e.state?(t=e.state.status)!==C&&69!==t&&73!==t&&91!==t&&103!==t&&t!==E&&666!==t?R(e,_):(e.state=null,t===E?R(e,-3):m):_},r.deflateSetDictionary=function(e,t){var r,n,i,s,a,o,h,u,l=t.length;if(!e||!e.state)return _;if(2===(s=(r=e.state).wrap)||1===s&&r.status!==C||r.lookahead)return _;for(1===s&&(e.adler=d(e.adler,t,l,0)),r.wrap=0,l>=r.w_size&&(0===s&&(D(r.head),r.strstart=0,r.block_start=0,r.insert=0),u=new c.Buf8(r.w_size),c.arraySet(u,t,l-r.w_size,r.w_size,0),t=u,l=r.w_size),a=e.avail_in,o=e.next_in,h=e.input,e.avail_in=l,e.next_in=0,e.input=t,j(r);r.lookahead>=x;){for(n=r.strstart,i=r.lookahead-(x-1);r.ins_h=(r.ins_h<<r.hash_shift^r.window[n+x-1])&r.hash_mask,r.prev[n&r.w_mask]=r.head[r.ins_h],r.head[r.ins_h]=n,n++,--i;);r.strstart=n,r.lookahead=x-1,j(r);}return r.strstart+=r.lookahead,r.block_start=r.strstart,r.insert=r.lookahead,r.lookahead=0,r.match_length=r.prev_length=x-1,r.match_available=0,e.next_in=o,e.input=h,e.avail_in=a,r.wrap=s,m},r.deflateInfo="pako deflate (from Nodeca project)";},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,t,r){t.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=false;};},{}],48:[function(e,t,r){t.exports=function(e,t){var r,n,i,s,a,o,h,u,l,f,c,d,p,m,_,g,b,v,y,w,k,x,S,z,C;r=e.state,n=e.next_in,z=e.input,i=n+(e.avail_in-5),s=e.next_out,C=e.output,a=s-(t-e.avail_out),o=s+(e.avail_out-257),h=r.dmax,u=r.wsize,l=r.whave,f=r.wnext,c=r.window,d=r.hold,p=r.bits,m=r.lencode,_=r.distcode,g=(1<<r.lenbits)-1,b=(1<<r.distbits)-1;e:do{p<15&&(d+=z[n++]<<p,p+=8,d+=z[n++]<<p,p+=8),v=m[d&g];t:for(;;){if(d>>>=y=v>>>24,p-=y,0===(y=v>>>16&255))C[s++]=65535&v;else {if(!(16&y)){if(0==(64&y)){v=m[(65535&v)+(d&(1<<y)-1)];continue t}if(32&y){r.mode=12;break e}e.msg="invalid literal/length code",r.mode=30;break e}w=65535&v,(y&=15)&&(p<y&&(d+=z[n++]<<p,p+=8),w+=d&(1<<y)-1,d>>>=y,p-=y),p<15&&(d+=z[n++]<<p,p+=8,d+=z[n++]<<p,p+=8),v=_[d&b];r:for(;;){if(d>>>=y=v>>>24,p-=y,!(16&(y=v>>>16&255))){if(0==(64&y)){v=_[(65535&v)+(d&(1<<y)-1)];continue r}e.msg="invalid distance code",r.mode=30;break e}if(k=65535&v,p<(y&=15)&&(d+=z[n++]<<p,(p+=8)<y&&(d+=z[n++]<<p,p+=8)),h<(k+=d&(1<<y)-1)){e.msg="invalid distance too far back",r.mode=30;break e}if(d>>>=y,p-=y,(y=s-a)<k){if(l<(y=k-y)&&r.sane){e.msg="invalid distance too far back",r.mode=30;break e}if(S=c,(x=0)===f){if(x+=u-y,y<w){for(w-=y;C[s++]=c[x++],--y;);x=s-k,S=C;}}else if(f<y){if(x+=u+f-y,(y-=f)<w){for(w-=y;C[s++]=c[x++],--y;);if(x=0,f<w){for(w-=y=f;C[s++]=c[x++],--y;);x=s-k,S=C;}}}else if(x+=f-y,y<w){for(w-=y;C[s++]=c[x++],--y;);x=s-k,S=C;}for(;2<w;)C[s++]=S[x++],C[s++]=S[x++],C[s++]=S[x++],w-=3;w&&(C[s++]=S[x++],1<w&&(C[s++]=S[x++]));}else {for(x=s-k;C[s++]=C[x++],C[s++]=C[x++],C[s++]=C[x++],2<(w-=3););w&&(C[s++]=C[x++],1<w&&(C[s++]=C[x++]));}break}}break}}while(n<i&&s<o);n-=w=p>>3,d&=(1<<(p-=w<<3))-1,e.next_in=n,e.next_out=s,e.avail_in=n<i?i-n+5:5-(n-i),e.avail_out=s<o?o-s+257:257-(s-o),r.hold=d,r.bits=p;};},{}],49:[function(e,t,r){var I=e("../utils/common"),O=e("./adler32"),B=e("./crc32"),R=e("./inffast"),T=e("./inftrees"),D=1,F=2,N=0,U=-2,P=1,n=852,i=592;function L(e){return (e>>>24&255)+(e>>>8&65280)+((65280&e)<<8)+((255&e)<<24)}function s(){this.mode=0,this.last=false,this.wrap=0,this.havedict=false,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new I.Buf16(320),this.work=new I.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0;}function a(e){var t;return e&&e.state?(t=e.state,e.total_in=e.total_out=t.total=0,e.msg="",t.wrap&&(e.adler=1&t.wrap),t.mode=P,t.last=0,t.havedict=0,t.dmax=32768,t.head=null,t.hold=0,t.bits=0,t.lencode=t.lendyn=new I.Buf32(n),t.distcode=t.distdyn=new I.Buf32(i),t.sane=1,t.back=-1,N):U}function o(e){var t;return e&&e.state?((t=e.state).wsize=0,t.whave=0,t.wnext=0,a(e)):U}function h(e,t){var r,n;return e&&e.state?(n=e.state,t<0?(r=0,t=-t):(r=1+(t>>4),t<48&&(t&=15)),t&&(t<8||15<t)?U:(null!==n.window&&n.wbits!==t&&(n.window=null),n.wrap=r,n.wbits=t,o(e))):U}function u(e,t){var r,n;return e?(n=new s,(e.state=n).window=null,(r=h(e,t))!==N&&(e.state=null),r):U}var l,f,c=true;function j(e){if(c){var t;for(l=new I.Buf32(512),f=new I.Buf32(32),t=0;t<144;)e.lens[t++]=8;for(;t<256;)e.lens[t++]=9;for(;t<280;)e.lens[t++]=7;for(;t<288;)e.lens[t++]=8;for(T(D,e.lens,0,288,l,0,e.work,{bits:9}),t=0;t<32;)e.lens[t++]=5;T(F,e.lens,0,32,f,0,e.work,{bits:5}),c=false;}e.lencode=l,e.lenbits=9,e.distcode=f,e.distbits=5;}function Z(e,t,r,n){var i,s=e.state;return null===s.window&&(s.wsize=1<<s.wbits,s.wnext=0,s.whave=0,s.window=new I.Buf8(s.wsize)),n>=s.wsize?(I.arraySet(s.window,t,r-s.wsize,s.wsize,0),s.wnext=0,s.whave=s.wsize):(n<(i=s.wsize-s.wnext)&&(i=n),I.arraySet(s.window,t,r-n,i,s.wnext),(n-=i)?(I.arraySet(s.window,t,r-n,n,0),s.wnext=n,s.whave=s.wsize):(s.wnext+=i,s.wnext===s.wsize&&(s.wnext=0),s.whave<s.wsize&&(s.whave+=i))),0}r.inflateReset=o,r.inflateReset2=h,r.inflateResetKeep=a,r.inflateInit=function(e){return u(e,15)},r.inflateInit2=u,r.inflate=function(e,t){var r,n,i,s,a,o,h,u,l,f,c,d,p,m,_,g,b,v,y,w,k,x,S,z,C=0,E=new I.Buf8(4),A=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!e||!e.state||!e.output||!e.input&&0!==e.avail_in)return U;12===(r=e.state).mode&&(r.mode=13),a=e.next_out,i=e.output,h=e.avail_out,s=e.next_in,n=e.input,o=e.avail_in,u=r.hold,l=r.bits,f=o,c=h,x=N;e:for(;;)switch(r.mode){case P:if(0===r.wrap){r.mode=13;break}for(;l<16;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(2&r.wrap&&35615===u){E[r.check=0]=255&u,E[1]=u>>>8&255,r.check=B(r.check,E,2,0),l=u=0,r.mode=2;break}if(r.flags=0,r.head&&(r.head.done=false),!(1&r.wrap)||(((255&u)<<8)+(u>>8))%31){e.msg="incorrect header check",r.mode=30;break}if(8!=(15&u)){e.msg="unknown compression method",r.mode=30;break}if(l-=4,k=8+(15&(u>>>=4)),0===r.wbits)r.wbits=k;else if(k>r.wbits){e.msg="invalid window size",r.mode=30;break}r.dmax=1<<k,e.adler=r.check=1,r.mode=512&u?10:12,l=u=0;break;case 2:for(;l<16;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(r.flags=u,8!=(255&r.flags)){e.msg="unknown compression method",r.mode=30;break}if(57344&r.flags){e.msg="unknown header flags set",r.mode=30;break}r.head&&(r.head.text=u>>8&1),512&r.flags&&(E[0]=255&u,E[1]=u>>>8&255,r.check=B(r.check,E,2,0)),l=u=0,r.mode=3;case 3:for(;l<32;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.head&&(r.head.time=u),512&r.flags&&(E[0]=255&u,E[1]=u>>>8&255,E[2]=u>>>16&255,E[3]=u>>>24&255,r.check=B(r.check,E,4,0)),l=u=0,r.mode=4;case 4:for(;l<16;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.head&&(r.head.xflags=255&u,r.head.os=u>>8),512&r.flags&&(E[0]=255&u,E[1]=u>>>8&255,r.check=B(r.check,E,2,0)),l=u=0,r.mode=5;case 5:if(1024&r.flags){for(;l<16;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.length=u,r.head&&(r.head.extra_len=u),512&r.flags&&(E[0]=255&u,E[1]=u>>>8&255,r.check=B(r.check,E,2,0)),l=u=0;}else r.head&&(r.head.extra=null);r.mode=6;case 6:if(1024&r.flags&&(o<(d=r.length)&&(d=o),d&&(r.head&&(k=r.head.extra_len-r.length,r.head.extra||(r.head.extra=new Array(r.head.extra_len)),I.arraySet(r.head.extra,n,s,d,k)),512&r.flags&&(r.check=B(r.check,n,d,s)),o-=d,s+=d,r.length-=d),r.length))break e;r.length=0,r.mode=7;case 7:if(2048&r.flags){if(0===o)break e;for(d=0;k=n[s+d++],r.head&&k&&r.length<65536&&(r.head.name+=String.fromCharCode(k)),k&&d<o;);if(512&r.flags&&(r.check=B(r.check,n,d,s)),o-=d,s+=d,k)break e}else r.head&&(r.head.name=null);r.length=0,r.mode=8;case 8:if(4096&r.flags){if(0===o)break e;for(d=0;k=n[s+d++],r.head&&k&&r.length<65536&&(r.head.comment+=String.fromCharCode(k)),k&&d<o;);if(512&r.flags&&(r.check=B(r.check,n,d,s)),o-=d,s+=d,k)break e}else r.head&&(r.head.comment=null);r.mode=9;case 9:if(512&r.flags){for(;l<16;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(u!==(65535&r.check)){e.msg="header crc mismatch",r.mode=30;break}l=u=0;}r.head&&(r.head.hcrc=r.flags>>9&1,r.head.done=true),e.adler=r.check=0,r.mode=12;break;case 10:for(;l<32;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}e.adler=r.check=L(u),l=u=0,r.mode=11;case 11:if(0===r.havedict)return e.next_out=a,e.avail_out=h,e.next_in=s,e.avail_in=o,r.hold=u,r.bits=l,2;e.adler=r.check=1,r.mode=12;case 12:if(5===t||6===t)break e;case 13:if(r.last){u>>>=7&l,l-=7&l,r.mode=27;break}for(;l<3;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}switch(r.last=1&u,l-=1,3&(u>>>=1)){case 0:r.mode=14;break;case 1:if(j(r),r.mode=20,6!==t)break;u>>>=2,l-=2;break e;case 2:r.mode=17;break;case 3:e.msg="invalid block type",r.mode=30;}u>>>=2,l-=2;break;case 14:for(u>>>=7&l,l-=7&l;l<32;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if((65535&u)!=(u>>>16^65535)){e.msg="invalid stored block lengths",r.mode=30;break}if(r.length=65535&u,l=u=0,r.mode=15,6===t)break e;case 15:r.mode=16;case 16:if(d=r.length){if(o<d&&(d=o),h<d&&(d=h),0===d)break e;I.arraySet(i,n,s,d,a),o-=d,s+=d,h-=d,a+=d,r.length-=d;break}r.mode=12;break;case 17:for(;l<14;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(r.nlen=257+(31&u),u>>>=5,l-=5,r.ndist=1+(31&u),u>>>=5,l-=5,r.ncode=4+(15&u),u>>>=4,l-=4,286<r.nlen||30<r.ndist){e.msg="too many length or distance symbols",r.mode=30;break}r.have=0,r.mode=18;case 18:for(;r.have<r.ncode;){for(;l<3;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.lens[A[r.have++]]=7&u,u>>>=3,l-=3;}for(;r.have<19;)r.lens[A[r.have++]]=0;if(r.lencode=r.lendyn,r.lenbits=7,S={bits:r.lenbits},x=T(0,r.lens,0,19,r.lencode,0,r.work,S),r.lenbits=S.bits,x){e.msg="invalid code lengths set",r.mode=30;break}r.have=0,r.mode=19;case 19:for(;r.have<r.nlen+r.ndist;){for(;g=(C=r.lencode[u&(1<<r.lenbits)-1])>>>16&255,b=65535&C,!((_=C>>>24)<=l);){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(b<16)u>>>=_,l-=_,r.lens[r.have++]=b;else {if(16===b){for(z=_+2;l<z;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(u>>>=_,l-=_,0===r.have){e.msg="invalid bit length repeat",r.mode=30;break}k=r.lens[r.have-1],d=3+(3&u),u>>>=2,l-=2;}else if(17===b){for(z=_+3;l<z;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}l-=_,k=0,d=3+(7&(u>>>=_)),u>>>=3,l-=3;}else {for(z=_+7;l<z;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}l-=_,k=0,d=11+(127&(u>>>=_)),u>>>=7,l-=7;}if(r.have+d>r.nlen+r.ndist){e.msg="invalid bit length repeat",r.mode=30;break}for(;d--;)r.lens[r.have++]=k;}}if(30===r.mode)break;if(0===r.lens[256]){e.msg="invalid code -- missing end-of-block",r.mode=30;break}if(r.lenbits=9,S={bits:r.lenbits},x=T(D,r.lens,0,r.nlen,r.lencode,0,r.work,S),r.lenbits=S.bits,x){e.msg="invalid literal/lengths set",r.mode=30;break}if(r.distbits=6,r.distcode=r.distdyn,S={bits:r.distbits},x=T(F,r.lens,r.nlen,r.ndist,r.distcode,0,r.work,S),r.distbits=S.bits,x){e.msg="invalid distances set",r.mode=30;break}if(r.mode=20,6===t)break e;case 20:r.mode=21;case 21:if(6<=o&&258<=h){e.next_out=a,e.avail_out=h,e.next_in=s,e.avail_in=o,r.hold=u,r.bits=l,R(e,c),a=e.next_out,i=e.output,h=e.avail_out,s=e.next_in,n=e.input,o=e.avail_in,u=r.hold,l=r.bits,12===r.mode&&(r.back=-1);break}for(r.back=0;g=(C=r.lencode[u&(1<<r.lenbits)-1])>>>16&255,b=65535&C,!((_=C>>>24)<=l);){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(g&&0==(240&g)){for(v=_,y=g,w=b;g=(C=r.lencode[w+((u&(1<<v+y)-1)>>v)])>>>16&255,b=65535&C,!(v+(_=C>>>24)<=l);){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}u>>>=v,l-=v,r.back+=v;}if(u>>>=_,l-=_,r.back+=_,r.length=b,0===g){r.mode=26;break}if(32&g){r.back=-1,r.mode=12;break}if(64&g){e.msg="invalid literal/length code",r.mode=30;break}r.extra=15&g,r.mode=22;case 22:if(r.extra){for(z=r.extra;l<z;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.length+=u&(1<<r.extra)-1,u>>>=r.extra,l-=r.extra,r.back+=r.extra;}r.was=r.length,r.mode=23;case 23:for(;g=(C=r.distcode[u&(1<<r.distbits)-1])>>>16&255,b=65535&C,!((_=C>>>24)<=l);){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(0==(240&g)){for(v=_,y=g,w=b;g=(C=r.distcode[w+((u&(1<<v+y)-1)>>v)])>>>16&255,b=65535&C,!(v+(_=C>>>24)<=l);){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}u>>>=v,l-=v,r.back+=v;}if(u>>>=_,l-=_,r.back+=_,64&g){e.msg="invalid distance code",r.mode=30;break}r.offset=b,r.extra=15&g,r.mode=24;case 24:if(r.extra){for(z=r.extra;l<z;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}r.offset+=u&(1<<r.extra)-1,u>>>=r.extra,l-=r.extra,r.back+=r.extra;}if(r.offset>r.dmax){e.msg="invalid distance too far back",r.mode=30;break}r.mode=25;case 25:if(0===h)break e;if(d=c-h,r.offset>d){if((d=r.offset-d)>r.whave&&r.sane){e.msg="invalid distance too far back",r.mode=30;break}p=d>r.wnext?(d-=r.wnext,r.wsize-d):r.wnext-d,d>r.length&&(d=r.length),m=r.window;}else m=i,p=a-r.offset,d=r.length;for(h<d&&(d=h),h-=d,r.length-=d;i[a++]=m[p++],--d;);0===r.length&&(r.mode=21);break;case 26:if(0===h)break e;i[a++]=r.length,h--,r.mode=21;break;case 27:if(r.wrap){for(;l<32;){if(0===o)break e;o--,u|=n[s++]<<l,l+=8;}if(c-=h,e.total_out+=c,r.total+=c,c&&(e.adler=r.check=r.flags?B(r.check,i,c,a-c):O(r.check,i,c,a-c)),c=h,(r.flags?u:L(u))!==r.check){e.msg="incorrect data check",r.mode=30;break}l=u=0;}r.mode=28;case 28:if(r.wrap&&r.flags){for(;l<32;){if(0===o)break e;o--,u+=n[s++]<<l,l+=8;}if(u!==(4294967295&r.total)){e.msg="incorrect length check",r.mode=30;break}l=u=0;}r.mode=29;case 29:x=1;break e;case 30:x=-3;break e;case 31:return  -4;case 32:default:return U}return e.next_out=a,e.avail_out=h,e.next_in=s,e.avail_in=o,r.hold=u,r.bits=l,(r.wsize||c!==e.avail_out&&r.mode<30&&(r.mode<27||4!==t))&&Z(e,e.output,e.next_out,c-e.avail_out)?(r.mode=31,-4):(f-=e.avail_in,c-=e.avail_out,e.total_in+=f,e.total_out+=c,r.total+=c,r.wrap&&c&&(e.adler=r.check=r.flags?B(r.check,i,c,e.next_out-c):O(r.check,i,c,e.next_out-c)),e.data_type=r.bits+(r.last?64:0)+(12===r.mode?128:0)+(20===r.mode||15===r.mode?256:0),(0==f&&0===c||4===t)&&x===N&&(x=-5),x)},r.inflateEnd=function(e){if(!e||!e.state)return U;var t=e.state;return t.window&&(t.window=null),e.state=null,N},r.inflateGetHeader=function(e,t){var r;return e&&e.state?0==(2&(r=e.state).wrap)?U:((r.head=t).done=false,N):U},r.inflateSetDictionary=function(e,t){var r,n=t.length;return e&&e.state?0!==(r=e.state).wrap&&11!==r.mode?U:11===r.mode&&O(1,t,n,0)!==r.check?-3:Z(e,t,n,n)?(r.mode=31,-4):(r.havedict=1,N):U},r.inflateInfo="pako inflate (from Nodeca project)";},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,t,r){var D=e("../utils/common"),F=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],N=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],U=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],P=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];t.exports=function(e,t,r,n,i,s,a,o){var h,u,l,f,c,d,p,m,_,g=o.bits,b=0,v=0,y=0,w=0,k=0,x=0,S=0,z=0,C=0,E=0,A=null,I=0,O=new D.Buf16(16),B=new D.Buf16(16),R=null,T=0;for(b=0;b<=15;b++)O[b]=0;for(v=0;v<n;v++)O[t[r+v]]++;for(k=g,w=15;1<=w&&0===O[w];w--);if(w<k&&(k=w),0===w)return i[s++]=20971520,i[s++]=20971520,o.bits=1,0;for(y=1;y<w&&0===O[y];y++);for(k<y&&(k=y),b=z=1;b<=15;b++)if(z<<=1,(z-=O[b])<0)return  -1;if(0<z&&(0===e||1!==w))return  -1;for(B[1]=0,b=1;b<15;b++)B[b+1]=B[b]+O[b];for(v=0;v<n;v++)0!==t[r+v]&&(a[B[t[r+v]]++]=v);if(d=0===e?(A=R=a,19):1===e?(A=F,I-=257,R=N,T-=257,256):(A=U,R=P,-1),b=y,c=s,S=v=E=0,l=-1,f=(C=1<<(x=k))-1,1===e&&852<C||2===e&&592<C)return 1;for(;;){for(p=b-S,_=a[v]<d?(m=0,a[v]):a[v]>d?(m=R[T+a[v]],A[I+a[v]]):(m=96,0),h=1<<b-S,y=u=1<<x;i[c+(E>>S)+(u-=h)]=p<<24|m<<16|_|0,0!==u;);for(h=1<<b-1;E&h;)h>>=1;if(0!==h?(E&=h-1,E+=h):E=0,v++,0==--O[b]){if(b===w)break;b=t[r+a[v]];}if(k<b&&(E&f)!==l){for(0===S&&(S=k),c+=y,z=1<<(x=b-S);x+S<w&&!((z-=O[x+S])<=0);)x++,z<<=1;if(C+=1<<x,1===e&&852<C||2===e&&592<C)return 1;i[l=E&f]=k<<24|x<<16|c-s|0;}}return 0!==E&&(i[c+E]=b-S<<24|64<<16|0),o.bits=k,0};},{"../utils/common":41}],51:[function(e,t,r){t.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"};},{}],52:[function(e,t,r){var i=e("../utils/common"),o=0,h=1;function n(e){for(var t=e.length;0<=--t;)e[t]=0;}var s=0,a=29,u=256,l=u+1+a,f=30,c=19,_=2*l+1,g=15,d=16,p=7,m=256,b=16,v=17,y=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],k=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],x=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],S=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],z=new Array(2*(l+2));n(z);var C=new Array(2*f);n(C);var E=new Array(512);n(E);var A=new Array(256);n(A);var I=new Array(a);n(I);var O,B,R,T=new Array(f);function D(e,t,r,n,i){this.static_tree=e,this.extra_bits=t,this.extra_base=r,this.elems=n,this.max_length=i,this.has_stree=e&&e.length;}function F(e,t){this.dyn_tree=e,this.max_code=0,this.stat_desc=t;}function N(e){return e<256?E[e]:E[256+(e>>>7)]}function U(e,t){e.pending_buf[e.pending++]=255&t,e.pending_buf[e.pending++]=t>>>8&255;}function P(e,t,r){e.bi_valid>d-r?(e.bi_buf|=t<<e.bi_valid&65535,U(e,e.bi_buf),e.bi_buf=t>>d-e.bi_valid,e.bi_valid+=r-d):(e.bi_buf|=t<<e.bi_valid&65535,e.bi_valid+=r);}function L(e,t,r){P(e,r[2*t],r[2*t+1]);}function j(e,t){for(var r=0;r|=1&e,e>>>=1,r<<=1,0<--t;);return r>>>1}function Z(e,t,r){var n,i,s=new Array(g+1),a=0;for(n=1;n<=g;n++)s[n]=a=a+r[n-1]<<1;for(i=0;i<=t;i++){var o=e[2*i+1];0!==o&&(e[2*i]=j(s[o]++,o));}}function W(e){var t;for(t=0;t<l;t++)e.dyn_ltree[2*t]=0;for(t=0;t<f;t++)e.dyn_dtree[2*t]=0;for(t=0;t<c;t++)e.bl_tree[2*t]=0;e.dyn_ltree[2*m]=1,e.opt_len=e.static_len=0,e.last_lit=e.matches=0;}function M(e){8<e.bi_valid?U(e,e.bi_buf):0<e.bi_valid&&(e.pending_buf[e.pending++]=e.bi_buf),e.bi_buf=0,e.bi_valid=0;}function H(e,t,r,n){var i=2*t,s=2*r;return e[i]<e[s]||e[i]===e[s]&&n[t]<=n[r]}function G(e,t,r){for(var n=e.heap[r],i=r<<1;i<=e.heap_len&&(i<e.heap_len&&H(t,e.heap[i+1],e.heap[i],e.depth)&&i++,!H(t,n,e.heap[i],e.depth));)e.heap[r]=e.heap[i],r=i,i<<=1;e.heap[r]=n;}function K(e,t,r){var n,i,s,a,o=0;if(0!==e.last_lit)for(;n=e.pending_buf[e.d_buf+2*o]<<8|e.pending_buf[e.d_buf+2*o+1],i=e.pending_buf[e.l_buf+o],o++,0===n?L(e,i,t):(L(e,(s=A[i])+u+1,t),0!==(a=w[s])&&P(e,i-=I[s],a),L(e,s=N(--n),r),0!==(a=k[s])&&P(e,n-=T[s],a)),o<e.last_lit;);L(e,m,t);}function Y(e,t){var r,n,i,s=t.dyn_tree,a=t.stat_desc.static_tree,o=t.stat_desc.has_stree,h=t.stat_desc.elems,u=-1;for(e.heap_len=0,e.heap_max=_,r=0;r<h;r++)0!==s[2*r]?(e.heap[++e.heap_len]=u=r,e.depth[r]=0):s[2*r+1]=0;for(;e.heap_len<2;)s[2*(i=e.heap[++e.heap_len]=u<2?++u:0)]=1,e.depth[i]=0,e.opt_len--,o&&(e.static_len-=a[2*i+1]);for(t.max_code=u,r=e.heap_len>>1;1<=r;r--)G(e,s,r);for(i=h;r=e.heap[1],e.heap[1]=e.heap[e.heap_len--],G(e,s,1),n=e.heap[1],e.heap[--e.heap_max]=r,e.heap[--e.heap_max]=n,s[2*i]=s[2*r]+s[2*n],e.depth[i]=(e.depth[r]>=e.depth[n]?e.depth[r]:e.depth[n])+1,s[2*r+1]=s[2*n+1]=i,e.heap[1]=i++,G(e,s,1),2<=e.heap_len;);e.heap[--e.heap_max]=e.heap[1],function(e,t){var r,n,i,s,a,o,h=t.dyn_tree,u=t.max_code,l=t.stat_desc.static_tree,f=t.stat_desc.has_stree,c=t.stat_desc.extra_bits,d=t.stat_desc.extra_base,p=t.stat_desc.max_length,m=0;for(s=0;s<=g;s++)e.bl_count[s]=0;for(h[2*e.heap[e.heap_max]+1]=0,r=e.heap_max+1;r<_;r++)p<(s=h[2*h[2*(n=e.heap[r])+1]+1]+1)&&(s=p,m++),h[2*n+1]=s,u<n||(e.bl_count[s]++,a=0,d<=n&&(a=c[n-d]),o=h[2*n],e.opt_len+=o*(s+a),f&&(e.static_len+=o*(l[2*n+1]+a)));if(0!==m){do{for(s=p-1;0===e.bl_count[s];)s--;e.bl_count[s]--,e.bl_count[s+1]+=2,e.bl_count[p]--,m-=2;}while(0<m);for(s=p;0!==s;s--)for(n=e.bl_count[s];0!==n;)u<(i=e.heap[--r])||(h[2*i+1]!==s&&(e.opt_len+=(s-h[2*i+1])*h[2*i],h[2*i+1]=s),n--);}}(e,t),Z(s,u,e.bl_count);}function X(e,t,r){var n,i,s=-1,a=t[1],o=0,h=7,u=4;for(0===a&&(h=138,u=3),t[2*(r+1)+1]=65535,n=0;n<=r;n++)i=a,a=t[2*(n+1)+1],++o<h&&i===a||(o<u?e.bl_tree[2*i]+=o:0!==i?(i!==s&&e.bl_tree[2*i]++,e.bl_tree[2*b]++):o<=10?e.bl_tree[2*v]++:e.bl_tree[2*y]++,s=i,u=(o=0)===a?(h=138,3):i===a?(h=6,3):(h=7,4));}function V(e,t,r){var n,i,s=-1,a=t[1],o=0,h=7,u=4;for(0===a&&(h=138,u=3),n=0;n<=r;n++)if(i=a,a=t[2*(n+1)+1],!(++o<h&&i===a)){if(o<u)for(;L(e,i,e.bl_tree),0!=--o;);else 0!==i?(i!==s&&(L(e,i,e.bl_tree),o--),L(e,b,e.bl_tree),P(e,o-3,2)):o<=10?(L(e,v,e.bl_tree),P(e,o-3,3)):(L(e,y,e.bl_tree),P(e,o-11,7));s=i,u=(o=0)===a?(h=138,3):i===a?(h=6,3):(h=7,4);}}n(T);var q=false;function J(e,t,r,n){P(e,(s<<1)+(n?1:0),3),function(e,t,r,n){M(e),(U(e,r),U(e,~r)),i.arraySet(e.pending_buf,e.window,t,r,e.pending),e.pending+=r;}(e,t,r);}r._tr_init=function(e){q||(function(){var e,t,r,n,i,s=new Array(g+1);for(n=r=0;n<a-1;n++)for(I[n]=r,e=0;e<1<<w[n];e++)A[r++]=n;for(A[r-1]=n,n=i=0;n<16;n++)for(T[n]=i,e=0;e<1<<k[n];e++)E[i++]=n;for(i>>=7;n<f;n++)for(T[n]=i<<7,e=0;e<1<<k[n]-7;e++)E[256+i++]=n;for(t=0;t<=g;t++)s[t]=0;for(e=0;e<=143;)z[2*e+1]=8,e++,s[8]++;for(;e<=255;)z[2*e+1]=9,e++,s[9]++;for(;e<=279;)z[2*e+1]=7,e++,s[7]++;for(;e<=287;)z[2*e+1]=8,e++,s[8]++;for(Z(z,l+1,s),e=0;e<f;e++)C[2*e+1]=5,C[2*e]=j(e,5);O=new D(z,w,u+1,l,g),B=new D(C,k,0,f,g),R=new D(new Array(0),x,0,c,p);}(),q=true),e.l_desc=new F(e.dyn_ltree,O),e.d_desc=new F(e.dyn_dtree,B),e.bl_desc=new F(e.bl_tree,R),e.bi_buf=0,e.bi_valid=0,W(e);},r._tr_stored_block=J,r._tr_flush_block=function(e,t,r,n){var i,s,a=0;0<e.level?(2===e.strm.data_type&&(e.strm.data_type=function(e){var t,r=4093624447;for(t=0;t<=31;t++,r>>>=1)if(1&r&&0!==e.dyn_ltree[2*t])return o;if(0!==e.dyn_ltree[18]||0!==e.dyn_ltree[20]||0!==e.dyn_ltree[26])return h;for(t=32;t<u;t++)if(0!==e.dyn_ltree[2*t])return h;return o}(e)),Y(e,e.l_desc),Y(e,e.d_desc),a=function(e){var t;for(X(e,e.dyn_ltree,e.l_desc.max_code),X(e,e.dyn_dtree,e.d_desc.max_code),Y(e,e.bl_desc),t=c-1;3<=t&&0===e.bl_tree[2*S[t]+1];t--);return e.opt_len+=3*(t+1)+5+5+4,t}(e),i=e.opt_len+3+7>>>3,(s=e.static_len+3+7>>>3)<=i&&(i=s)):i=s=r+5,r+4<=i&&-1!==t?J(e,t,r,n):4===e.strategy||s===i?(P(e,2+(n?1:0),3),K(e,z,C)):(P(e,4+(n?1:0),3),function(e,t,r,n){var i;for(P(e,t-257,5),P(e,r-1,5),P(e,n-4,4),i=0;i<n;i++)P(e,e.bl_tree[2*S[i]+1],3);V(e,e.dyn_ltree,t-1),V(e,e.dyn_dtree,r-1);}(e,e.l_desc.max_code+1,e.d_desc.max_code+1,a+1),K(e,e.dyn_ltree,e.dyn_dtree)),W(e),n&&M(e);},r._tr_tally=function(e,t,r){return e.pending_buf[e.d_buf+2*e.last_lit]=t>>>8&255,e.pending_buf[e.d_buf+2*e.last_lit+1]=255&t,e.pending_buf[e.l_buf+e.last_lit]=255&r,e.last_lit++,0===t?e.dyn_ltree[2*r]++:(e.matches++,t--,e.dyn_ltree[2*(A[r]+u+1)]++,e.dyn_dtree[2*N(t)]++),e.last_lit===e.lit_bufsize-1},r._tr_align=function(e){P(e,2,3),L(e,m,z),function(e){16===e.bi_valid?(U(e,e.bi_buf),e.bi_buf=0,e.bi_valid=0):8<=e.bi_valid&&(e.pending_buf[e.pending++]=255&e.bi_buf,e.bi_buf>>=8,e.bi_valid-=8);}(e);};},{"../utils/common":41}],53:[function(e,t,r){t.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0;};},{}],54:[function(e,t,r){(function(e){!function(r,n){if(!r.setImmediate){var i,s,t,a,o=1,h={},u=false,l=r.document,e=Object.getPrototypeOf&&Object.getPrototypeOf(r);e=e&&e.setTimeout?e:r,i="[object process]"==={}.toString.call(r.process)?function(e){process.nextTick(function(){c(e);});}:function(){if(r.postMessage&&!r.importScripts){var e=true,t=r.onmessage;return r.onmessage=function(){e=false;},r.postMessage("","*"),r.onmessage=t,e}}()?(a="setImmediate$"+Math.random()+"$",r.addEventListener?r.addEventListener("message",d,false):r.attachEvent("onmessage",d),function(e){r.postMessage(a+e,"*");}):r.MessageChannel?((t=new MessageChannel).port1.onmessage=function(e){c(e.data);},function(e){t.port2.postMessage(e);}):l&&"onreadystatechange"in l.createElement("script")?(s=l.documentElement,function(e){var t=l.createElement("script");t.onreadystatechange=function(){c(e),t.onreadystatechange=null,s.removeChild(t),t=null;},s.appendChild(t);}):function(e){setTimeout(c,0,e);},e.setImmediate=function(e){"function"!=typeof e&&(e=new Function(""+e));for(var t=new Array(arguments.length-1),r=0;r<t.length;r++)t[r]=arguments[r+1];var n={callback:e,args:t};return h[o]=n,i(o),o++},e.clearImmediate=f;}function f(e){delete h[e];}function c(e){if(u)setTimeout(c,0,e);else {var t=h[e];if(t){u=true;try{!function(e){var t=e.callback,r=e.args;switch(r.length){case 0:t();break;case 1:t(r[0]);break;case 2:t(r[0],r[1]);break;case 3:t(r[0],r[1],r[2]);break;default:t.apply(n,r);}}(t);}finally{f(e),u=false;}}}}function d(e){e.source===r&&"string"==typeof e.data&&0===e.data.indexOf(a)&&c(+e.data.slice(a.length));}}("undefined"==typeof self?void 0===e?this:e:self);}).call(this,"undefined"!=typeof commonjsGlobal?commonjsGlobal:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});},{}]},{},[10])(10)}); 
	} (jszip_min));
	return jszip_min.exports;
}

var jszip_minExports = requireJszip_min();
var JSZip = /*@__PURE__*/getDefaultExportFromCjs(jszip_minExports);

const indexCss = () => `@font-face{font-family:'Baloo Bhai 2';font-style:normal;font-weight:400 800;font-display:swap;src:url('../assets/offline-assets/fonts/Baloo-Bhai-2/Baloo-Bhai-2-Variable.woff2') format('woff2')}body{overflow:hidden;background-position:center;background-size:cover;background-repeat:no-repeat;height:100vh}*{user-select:none}.lido-disable-check-button{pointer-events:none;background-color:#9393935c !important;color:white}.lido-element-selected{border:2px solid;background-color:#ffdf7d !important}.diagonal-target,.diagonal-drop *{transform:scale(0.8) !important;opacity:1 !important}.cloned-element{display:flex !important;position:absolute !important;filter:grayscale(100%);pointer-events:none}.removeShadow{box-shadow:0px 0px 0px 0px #ff8900 !important}.highlight-element{border:2px solid white;box-shadow:rgb(243, 77, 8) 0px 0px 40px !important}.drop-element.empty{border:4px dashed #f34d08 !important}.drop-element.filled{border:'none' !important}.drag-element{box-shadow:0px 15px 11px rgba(43, 0, 0, 0.3) !important}.drag-element.dropped{box-shadow:none !important}.click-element{background-color:var(--btn-bg-color, rgba(255, 172, 76, 1)) !important;box-shadow:var(--btn-shadow-px) var(--btn-shadow-color, rgba(225, 121, 76, 1)) !important;cursor:pointer;transition:box-shadow 0.1s ease-out, transform 0.2s ease-out;}.click-element:active{box-shadow:0px 0px 0px var(--btn-shadow-color, rgba(225, 121, 76, 1)) !important;transform:translateY(var(--btn-active));}.click-element:focus{outline:2px solid dodgerblue;outline-offset:3px}.after-drop-popup-container{width:200%;height:200%;background-color:rgba(0, 0, 0, 0.8);position:absolute;display:flex;flex-direction:row-reverse;align-items:center;justify-content:center !important;gap:80px}.after-drop-popup-drag-element{scale:1.5;border-radius:8px;transform:none !important;position:unset !important}.after-drop-popup-drop-element{scale:1.5;border:unset;border-radius:8px;transform:none !important;position:unset !important}@keyframes zoomFadeIn{0%{transform:scale(0.6);opacity:0}100%{transform:scale(1);opacity:1}}.zoom-fade-in{animation:zoomFadeIn 0.8s ease-out forwards}@keyframes zoomFadeOut{0%{transform:scale(1);opacity:1}100%{transform:scale(0.6);opacity:0}}.zoom-fade-out{animation:zoomFadeOut 0.8s ease-in forwards}.slide-numbers{width:70px;height:70px;border:1px solid #f57139;background-color:white;font-weight:500;color:#f57139;font-size:44px;border-radius:40px;display:flex;align-items:center;justify-content:center;font-family:'Baloo Bhai 2', serif}.slide-numbers-bottom{position:absolute;display:flex;justify-content:space-around;align-items:center;bottom:-25px;width:100%;height:50px}.slide-numbers-left{position:absolute;display:flex;flex-direction:column;justify-content:space-around;height:100%;width:50px;left:-25px;bottom:0px}.lido-speak-icon{width:56px;height:56px;position:absolute;top:-25px;right:-25px;z-index:10;background-color:white;border:4px solid #F34D08;border-radius:16px;box-shadow:0px 4px 0px 0px #F34D08;background-size:contain;background-repeat:no-repeat;cursor:pointer}.lido-speak-icon:active{transform:translateY(8px);box-shadow:0px 0px 0px 0px !important}.lido-strong-shake{animation:strongShake 0.3s ease}.lido-scaled-shake{animation:scaledShake 0.6s ease-in-out}.lido-horizontal-shake{animation:horizontalShake 0.6s ease-in-out;border-radius:20px}.lido-vertical-shake{animation:verticalShake 0.6s ease-in-out;border-radius:20px}.lido-diagonal-shake{animation:diagonalShake 0.5s ease-in-out;border-radius:20px;will-change:transform}.lido-glow{animation:glowPulse 1s infinite alternate;transition:opacity 0.5s ease-in-out}.lido-box-highlight{animation:topToPlace 0.3s linear}.lido-display-hiddenvalue{position:absolute;top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:80px;font-weight:1000;color:brown;-webkit-text-stroke:2px white;font-family:'Baloo Bhai 2', sans-serif;pointer-events:none}.lido-image-colorize{position:relative;display:inline-block}.lido-image-colorize::after{content:'';position:absolute;inset:0;background:var(--tint-color);mix-blend-mode:multiply;opacity:0.8;pointer-events:none;mask-image:var(--mask-url);mask-size:cover;mask-repeat:no-repeat;mask-position:center}.lido-tts-highlight-overlay{position:fixed;left:0;top:0;pointer-events:none;z-index:9999;background:linear-gradient(      180deg,      rgba(255, 235, 59, 0.95),      rgba(255, 214, 0, 0.95)    );border-radius:6px;box-shadow:0 2px 6px rgba(0, 0, 0, 0.18),      inset 0 -1px 0 rgba(255, 255, 255, 0.25);transition:width 25ms ease-out,      height 25ms ease-out,      opacity 80ms ease-out;opacity:0.95;will-change:transform, width, height;contain:layout paint style}.category-dropped-onCorrect{box-shadow:rgba(129, 193, 39, 1) 0px 8px 8px 0px !important}.category-dropped-onInCorrect{box-shadow:rgba(255, 4, 16, 1) 0px 8px 8px 0px !important}`;

const animationCss = () => `@keyframes rightToPlace{from{transform:translateX(2000px)}to{transform:translateX(0)}}@keyframes topToPlace{from{transform:translateY(-1000px)}to{transform:translateY(0)}}@keyframes bottomToPlace{from{transform:translateY(1000px)}to{transform:translateY(0)}}@keyframes placeToLeft{from{}to{transform:translateX(-2000px)}}@keyframes placeToRight{from{}to{transform:translateX(2000px)}}@keyframes leftToPlace{from{transform:translateX(-2000px)}to{transform:translateX(0)}}@keyframes shake{0%{transform:translateX(0)}10%{transform:translateX(-5px)}20%{transform:translateX(5px)}30%{transform:translateX(-5px)}40%{transform:translateX(5px)}50%{transform:translateX(-5px)}60%{transform:translateX(5px)}70%{transform:translateX(-5px)}80%{transform:translateX(5px)}90%{transform:translateX(-5px)}100%{transform:translateX(0)}}@keyframes fallAndBounce{0%{transform:translateY(-1000px)}25%{transform:translateY(0px)}50%{transform:translateY(-200px)}75%{transform:translateY(0)}90%{transform:translateY(-100px)}100%{transform:translateY(0)}}@keyframes placeToDown{0%{transform:translateY(0)}100%{transform:translateY(1000px)}}@keyframes strongShake{0%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(8px)}60%{transform:translateX(-6px)}80%{transform:translateX(6px)}100%{transform:translateX(0)}}@keyframes scaledShake{0%{transform:scale(1) translateX(0);box-shadow:0 0 0 transparent}20%{transform:scale(1.10) translateX(-12px);box-shadow:0 0 10px red}40%{transform:scale(1.10) translateX(12px);box-shadow:0 0 12px red}60%{transform:scale(1.10) translateX(-8px);box-shadow:0 0 10px red}80%{transform:scale(1.10) translateX(8px);box-shadow:0 0 12px red}100%{transform:scale(1) translateX(0);box-shadow:none}}@keyframes horizontalShake{0%{transform:scale(1) translateX(0);background-color:transparent}20%{transform:translateX(-20px);background-color:rgba(255, 0, 0, 0.2)}40%{transform:translateX(20px);background-color:rgba(255, 0, 0, 0.4)}60%{transform:translateX(-10px);background-color:rgba(255, 0, 0, 0.3)}80%{transform:translateX(10px);background-color:rgba(255, 0, 0, 0.2)}100%{transform:translateX(0);background-color:transparent}}@keyframes verticalShake{0%{transform:translateY(0);background-color:transparent}20%{transform:translateY(-20px);background-color:rgba(255, 0, 0, 0.2)}40%{transform:translateY(0);background-color:rgba(255, 0, 0, 0.4)}60%{transform:translateY(20px);background-color:rgba(255, 0, 0, 0.2)}80%{transform:translateY(0);background-color:rgba(255, 0, 0, 0.1)}100%{transform:translateY(0);background-color:transparent}}@keyframes diagonalShake{0%{transform:translate(0, 0);background-color:transparent}25%{transform:translate(20px, -20px);background-color:rgba(255, 0, 0, 0.2)}50%{transform:translate(-20px, 20px);background-color:rgba(255, 0, 0, 0.3)}75%{transform:translate(10px, -10px);background-color:rgba(255, 0, 0, 0.2)}100%{transform:translate(0, 0);background-color:transparent}}@keyframes glowPulse{0%{filter:drop-shadow(0 0 5px yellow)              drop-shadow(0 0 10px yellow)              drop-shadow(0 0 20px yellow)              drop-shadow(0 0 30px orange)}50%{filter:drop-shadow(0 0 10px yellow)              drop-shadow(0 0 20px yellow)              drop-shadow(0 0 40px yellow)              drop-shadow(0 0 50px orange)}100%{filter:drop-shadow(0 0 5px yellow)              drop-shadow(0 0 10px yellow)              drop-shadow(0 0 20px yellow)              drop-shadow(0 0 30px orange)}}@keyframes trace-animation{0%{}100%{width:var(--trace-width, 100px);height:var(--trace-height, 100px)}}`;

const lidoHomeCss = () => `.lido-snackbar{visibility:visible;min-width:250px;background-color:#333;color:#fff;text-align:center;border-radius:2px;padding:16px;position:fixed;z-index:1;bottom:30px;left:50%;transform:translateX(-50%);font-size:17px}.lido-dot-container{display:flex;justify-content:space-between;align-items:center;visibility:hidden;position:absolute;left:50%;padding:0 5px;z-index:1;width:100vw;max-width:100vw;box-sizing:border-box;height:0px}.lido-dot{height:18px;width:18px;margin:0 4px;background-color:#bbb;border-radius:50%;display:inline-block;transition:background-color 0.3s;cursor:pointer;z-index:1}.lido-btn-dot-container{flex-shrink:1;flex-grow:1;display:flex;justify-content:center;align-items:center;text-align:center;z-index:1;min-width:0;height:0px}.lido-dot.completed{background-color:grey}.lido-dot.current{background-color:green}.lido-dot:not(.completed):not(.current){background-color:#bbb}#lido-arrow-left,#lido-arrow-right{width:88px;height:88px;display:flex;align-items:center;justify-content:center;border-radius:12px;z-index:1000;box-shadow:0px 8px 0px 0px #8b310f;background-color:#f34d08;cursor:pointer;visibility:hidden;flex-shrink:0}#lido-arrow-left:active,#lido-arrow-right:active{transform:translateY(8px);box-shadow:0px 0px 0px 0px}.navbar{display:flex;justify-content:center}.lido-exit-button,#main-audio{width:80px;height:80px;z-index:1000;cursor:pointer;background-color:white;display:flex;align-items:center;justify-content:center;border:4px solid #f34d08;border-radius:16px;box-shadow:0px 8px #f34d08;flex-shrink:0;}#main-audio:active,.popup-button:active,.lido-exit-button:active{margin-bottom:-8px;box-shadow:0px 0px 0px 0px !important}.lido-alert-popup{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(0, 0, 0, 0.5);display:flex;align-items:center;justify-content:center;z-index:1000}@media (max-width: 768px){#lido-arrow-left,#lido-arrow-right{width:70px;height:70px;margin:0 8px}.lido-exit-button,#main-audio{width:65px;height:65px;margin:0 8px}.lido-dot{height:16px;width:16px;margin:0 2.5px}}@media (max-width: 480px){#lido-arrow-left,#lido-arrow-right{width:74px;height:74px;margin:0px 5px}.lido-exit-button,#main-audio{width:65px;height:65px;margin:0px 5px}.lido-dot{height:15px;width:15px;margin:0 1.5px}.lido-dot-container{padding:0 3px}}@media (max-width: 375px){#lido-arrow-left,#lido-arrow-right{width:70px;height:70px;margin:0px 3px}.lido-exit-button,#main-audio{width:70px;height:70px;margin:0px 3px}.lido-dot{height:14px;width:14px;margin:0 1px}.lido-dot-container{padding:0 2px}}@media (max-width: 320px){#lido-arrow-left,#lido-arrow-right,.lido-exit-button,#main-audio{width:70px;height:70px;margin:0px 2px}.lido-dot{height:12px;width:12px;margin:0 0.5px}.lido-dot-container{padding:0 2px}}@media (max-width: 900px) and (orientation: landscape){#lido-arrow-left,#lido-arrow-right{width:70px;height:70px;margin:0px 5px}.lido-exit-button,#main-audio{width:70px;height:70px;margin:0px 5px}.lido-dot{height:14px;width:14px;margin:0 1px}.lido-dot-container{padding:0 5px}}.popup-exit-text{white-space:nowrap;font-size:22px;font-weight:600;margin-top:-8%}.lido-alert-parent{z-index:10000 !important;position:absolute;top:0;left:0}.popup-button{width:80px;height:80px;z-index:1000;cursor:pointer;display:flex;align-items:center;justify-content:center;border:4px solid #F34D08;border-radius:16px;box-shadow:0 8px 0 #F34D08}.nav-for-lanai{position:absolute;top:0%;left:0%;max-width:none;width:100%;height:auto;visibility:visible}`;

const gameScore = new GameScore();
const LidoHome = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        this.commonAudioPath = '';
        /** Boolean to show or hide navigation buttons */
        this.showNav = true;
        /** Array of active container indexes to be rendered */
        this.activeContainerIndexes = [];
        /** Language to apply to all texts */
        this.Lang = 'en';
        /**
         * XML data passed to the component, which is parsed and used to render various containers.
         */
        this.xmlData = '';
        /**
         * Initial index of the container being displayed.
         */
        this.initialIndex = 0;
        /**
         * Boolean that controls the playability of the game.
         */
        this.canplay = true;
        /**
         * Base URL for the containers.
         */
        this.baseUrl = '';
        /**
         * The height of the container (CSS value).
         */
        this.height = '';
        /** Unique identifier for the component instance.
         * If not provided, a UUID is generated to ensure uniqueness.
         */
        this.uuid = generateUUIDFallback();
        /**
         * ZIP URL pointing to a package containing XML and asset files.
         */
        this.zipUrl = '';
        /**
         * Current index of the container being displayed.
         */
        this.currentContainerIndex = this.initialIndex;
        /**
         * Tracks window resizes to force a complete unmount and remount of the container tree.
         */
        this.resizeTrigger = 0;
        /**
         * Boolean that controls the visibility of the exit confirmation popup.
         * This is set to true when the user attempts to exit the game.
         */
        this.exitFlag = false;
        /**
         * Stores the list of container-rendering functions parsed from XML.
         */
        this.containers = [];
        /** Holds the parsed data loaded from data.json.Each object in the array represents the dynamic data
          for one XML container (matched by index).
        */
        this.templateData = [];
        /** Regex used to detect placeholders in XML like {question_text}.It captures the key inside curly braces so it can be replaced
           with corresponding values from templateData during rendering.
        */
        this.placeholderRegex = /\{([a-zA-Z0-9_]+)\}/g;
        this.extractedAssets = {};
        this.handleNextContainerEvent = () => {
            this.NextContainerKey();
        };
        this.handlePrevContainerEvent = () => {
            this.PrevContainerKey();
        };
        this.handleChangeContainerEvent = (e) => {
            this.NextContainerKey(e.detail.index);
        };
        this.handleBeforeUnload = () => {
            AudioPlayer.getI().stop();
            localStorage.removeItem(ActivityScoreKey);
            // clearmemoryStorage();
        };
        this.handleWindowResize = () => {
            this.scaleNavbarContainer(); // re-scale navbar on resize
            this.resizeTrigger++; // Force Stencil to view the container as a new element
            this.containers = [...this.containers]; // trigger a full re-render
        };
        /**
         * Event handler for transitioning to the next container in the sequence.
         * If the last container is reached, it shows a completion message.
         */
        this.NextContainerKey = (index) => {
            var _a;
            if (this.uuid !== ((_a = document.querySelector('lido-home')) === null || _a === void 0 ? void 0 : _a.getAttribute('uuid')))
                return;
            if (index != undefined && index == this.currentContainerIndex)
                return;
            // Clear selected values from localStorage on container transition
            // clearmemoryStorage();
            if (index != undefined && index < this.containers.length) {
                // Move to the next container
                this.currentContainerIndex = index;
                // window.dispatchEvent(new CustomEvent('activityChange', { detail: { index: this.currentContainerIndex } }));
                dispatchActivityChangeEvent(this.currentContainerIndex);
            }
            else if (this.currentContainerIndex < this.containers.length - 1) {
                // Move to the next container
                this.currentContainerIndex++;
                // window.dispatchEvent(new CustomEvent('activityChange', { detail: { index: this.currentContainerIndex } }));
                dispatchActivityChangeEvent(this.currentContainerIndex);
            }
            else if (this.currentContainerIndex >= this.containers.length - 1) {
                // const event = new CustomEvent('gameCompleted');
                // window.dispatchEvent(event);
                localStorage.removeItem(ActivityScoreKey);
                // dispatchGameCompletedEvent();
                this.currentContainerIndex = null;
            }
            // Reset the containers array to trigger a re-render
            this.containers = [...this.containers];
            this.updateArrowVisibility();
        };
        this.PrevContainerKey = (index) => {
            if (this.currentContainerIndex <= 0)
                return;
            // Clear selected values from localStorage on container transition
            // clearmemoryStorage();
            // Move to the previous container
            this.currentContainerIndex--;
            // Dispatch event to update the UI or state
            dispatchActivityChangeEvent(this.currentContainerIndex);
            // Refresh container array and update button visibility
            this.containers = [...this.containers];
            this.updateArrowVisibility();
        };
        this.showDotsandbtn = false;
        // update arrow visibility
        this.updateArrowVisibility = () => {
            if (!this.showNav)
                return;
            setTimeout(() => {
                const containerElement = this.el.querySelector('lido-container');
                if (!containerElement)
                    return;
                const prevbtn = containerElement.getAttribute('show-prev-button');
                const nextbtn = containerElement.getAttribute('show-next-button');
                const rightbtn = this.el.querySelector('#lido-arrow-right');
                const leftbtn = this.el.querySelector('#lido-arrow-left');
                if (prevbtn !== 'true') {
                    leftbtn.style.visibility = 'hidden';
                }
                else {
                    leftbtn.style.visibility = 'visible';
                }
                if (nextbtn !== 'true') {
                    rightbtn.style.visibility = 'hidden';
                }
                else {
                    rightbtn.style.visibility = 'visible';
                }
            }, 100);
        };
        this.btnpopupRunId = 0;
        this.activeBtnpopupRunId = null;
        this.shouldStopActiveBtnpopupAudio = true;
        this.handleWindowTouch = (event) => {
            if (this.activeBtnpopupRunId === null)
                return;
            void this.cancelBtnpopupRun(this.hasAudioOnInteractionTarget(event.target));
        };
        this.handleWindowPointer = (event) => {
            if (event.pointerType !== 'touch')
                return;
            if (this.activeBtnpopupRunId === null)
                return;
            void this.cancelBtnpopupRun(this.hasAudioOnInteractionTarget(event.target));
        };
        this.popUpClick = (comment) => {
            const alertElement = this.el.querySelector('.lido-alert-popup');
            this.exitFlag = false;
            if (alertElement) {
                if (comment === 'exit') {
                    AudioPlayer.getI().stop();
                    Timer.getI().stop();
                    gameScore.rightMoves = 0;
                    gameScore.wrongMoves = 0;
                    gameScore.totalRightMovesCount = 0;
                    gameScore.totalWrongMovesCount = 0;
                    localStorage.removeItem(ActivityScoreKey);
                    // clearmemoryStorage();
                    alertElement.remove();
                    this.currentContainerIndex = 0;
                    dispatchGameExitEvent();
                }
                else {
                    alertElement.remove();
                }
            }
        };
    }
    translateHomeText(key) {
        var _a;
        const lang = (_a = this.Lang) === null || _a === void 0 ? void 0 : _a.trim();
        return lang ? instance.getFixedT(lang)(key) : instance.t(key);
    }
    onCommonAudioPathChange(path) {
        this.publishCommonAudioPath(path);
    }
    /**
     * Lifecycle method that runs before the component is loaded. It sets up event listeners for transitioning
     * between containers and parses the XML data into containers.
     */
    async componentWillLoad() {
        // Publish the current player's common-audio path before parsing XML so
        // child lido-text components cannot resolve auto-audio against the
        // previous player's global path.
        this.publishCommonAudioPath(this.commonAudioPath);
        this.navBarIcons = {
            exit: this.exitButtonUrl || exitUrl,
            prev: this.prevButtonUrl || prevUrl,
            next: this.nextButtonUrl || nextUrl,
            speak: this.speakerButtonUrl || speakUrl,
        };
        if (this.currentContainerIndex === 0) {
            localStorage.removeItem(ActivityScoreKey);
            // clearmemoryStorage();
        }
        // Listen for 'NextContainerKey' event to transition between containers
        window.addEventListener(NextContainerKey, this.handleNextContainerEvent);
        window.addEventListener(PrevContainerKey, this.handlePrevContainerEvent);
        window.addEventListener('changeContainer', this.handleChangeContainerEvent);
        if (this.zipUrl) {
            this.xmlData = '';
            await this.extractZipAndSetBase();
            await this.loadXmlFromZip();
        }
        await this.loadTemplateData();
        const trimmed = (this.xmlData || '').trim();
        if (trimmed.includes('lido-container')) {
            this.parseXMLData(this.xmlData);
        }
        else {
            const finalXml = await this.decompressBrotliBase64(this.xmlData);
            this.parseXMLData(finalXml);
        }
        // Parse the provided XML data
        // Remove stored values in localStorage when the page is about to be unloaded
        window.addEventListener('beforeunload', this.handleBeforeUnload);
    }
    async loadTemplateData() {
        if (!this.baseUrl && !this.zipUrl) {
            return;
        }
        const candidatePaths = [this.resolveAsset('data.json')].filter(Boolean);
        for (const path of candidatePaths) {
            try {
                const resolvedPath = path.startsWith('http') || path.startsWith('blob') ? path : getAssetPath(path);
                const response = await fetch(resolvedPath);
                if (!response.ok) {
                    continue;
                }
                const payload = await response.json();
                if (Array.isArray(payload)) {
                    this.templateData = payload.filter(item => item && typeof item === 'object');
                    if (this.templateData.length) {
                        return;
                    }
                }
            }
            catch (error) {
                console.warn(`[LidoHome] Failed to load template data from ${path}`, error);
            }
        }
    }
    async decompressBrotliBase64(base64) {
        var _a;
        // Normalize payload (raw base64 / quoted / data URL / escaped newlines)
        base64 = (base64 || '')
            .trim()
            .replace(/^data:.*;base64,/, '')
            .replace(/^['"]|['"]$/g, '')
            .replace(/\\n/g, '')
            .replace(/\s+/g, '')
            .replace(/-/g, '+')
            .replace(/_/g, '/');
        while (base64.length % 4) {
            base64 += '=';
        }
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        // Native Brotli first
        if ('DecompressionStream' in window) {
            try {
                const stream = new window.DecompressionStream('br');
                const blob = new Blob([bytes]);
                const decompressedStream = blob.stream().pipeThrough(stream);
                const buffer = await new Response(decompressedStream).arrayBuffer();
                const decoded = new TextDecoder().decode(buffer);
                return decoded;
            }
            catch (nativeErr) {
                console.warn('[LidoRoot] Native Brotli unavailable, trying WASM fallback.', nativeErr);
            }
        }
        // Pure-JS fallback (no wasm asset required)
        try {
            const brotliDecodeModule = await import('./decode-MrgnYVIE.js').then(function (n) { return n.d; });
            const brotliDecompressBuffer = brotliDecodeModule.BrotliDecompressBuffer || ((_a = brotliDecodeModule.default) === null || _a === void 0 ? void 0 : _a.BrotliDecompressBuffer);
            if (typeof brotliDecompressBuffer !== 'function') {
                throw new Error('BrotliDecompressBuffer function not found in brotli/dec/decode');
            }
            const decompressedBytes = brotliDecompressBuffer(bytes);
            const decoded = new TextDecoder().decode(decompressedBytes);
            return decoded;
        }
        catch (fallbackErr) {
            throw new Error(`Brotli decompression failed (native + fallback): ${fallbackErr instanceof Error ? fallbackErr.message : String(fallbackErr)}`);
        }
    }
    async extractZipAndSetBase() {
        this.revokeExtractedAssets();
        const normalizedZipPath = this.zipUrl.replace(/\\/g, '/');
        const zipUrl = normalizedZipPath.startsWith('http') || normalizedZipPath.startsWith('blob') || normalizedZipPath.startsWith('data')
            ? normalizedZipPath
            : getAssetPath(normalizedZipPath);
        const response = await fetch(zipUrl);
        if (!response.ok) {
            throw new Error('Unable to fetch ZIP');
        }
        const blob = await response.blob();
        const zip = await JSZip.loadAsync(blob);
        for (const fileName of Object.keys(zip.files)) {
            const file = zip.files[fileName];
            if (!file.dir) {
                const fileBlob = await file.async('blob');
                this.extractedAssets[fileName] = URL.createObjectURL(fileBlob);
            }
        }
        setActiveZipAssets(this.extractedAssets);
    }
    revokeExtractedAssets() {
        for (const objectUrl of Object.values(this.extractedAssets)) {
            URL.revokeObjectURL(objectUrl);
        }
        this.extractedAssets = {};
        clearActiveZipAssets();
    }
    async loadXmlFromZip() {
        const xmlPath = 'index.xml';
        const xmlBlobUrl = this.resolveAsset(xmlPath);
        if (!xmlBlobUrl) {
            console.warn('[LidoHome] ZIP extraction keys:', Object.keys(this.extractedAssets));
            throw new Error(`Unable to find XML file '${xmlPath}' inside ZIP`);
        }
        const response = await fetch(xmlBlobUrl);
        if (!response.ok) {
            throw new Error(`Unable to fetch XML from ZIP: ${response.statusText}`);
        }
        this.xmlData = await response.text();
    }
    resolveAsset(path) {
        // ZIP mode
        if (this.zipUrl) {
            const normalizedPath = path.replace(/^\/+/, '');
            const exactMatch = this.extractedAssets[path] || this.extractedAssets[normalizedPath];
            if (exactMatch) {
                return exactMatch;
            }
            const basename = normalizedPath.replace(/^.*\//, '');
            const matchingKey = Object.keys(this.extractedAssets).find(assetKey => assetKey === normalizedPath ||
                assetKey === basename ||
                assetKey.endsWith(`/${normalizedPath}`) ||
                assetKey.endsWith(`/${basename}`));
            return matchingKey ? this.extractedAssets[matchingKey] : undefined;
        }
        // Normal mode
        return `${this.baseUrl.replace(/\/+$/, '')}/${path}`;
    }
    componentDidLoad() {
        setTimeout(() => {
            this.showDotsandbtn = true;
        }, 10);
        this.updateArrowVisibility();
        // if (this.height == '' || this.height === '0' || this.height === '0px' || this.height === '0%') {
        this.scaleNavbarContainer();
        // } else {
        //   this.updateBackgroundImage();
        // }
        // this.currentContainerIndex = 0;
        this.handleIcons();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('touchstart', this.handleWindowTouch, { passive: true });
        window.addEventListener('pointerdown', this.handleWindowPointer, { passive: true });
    }
    publishCommonAudioPath(path) {
        if (!path)
            return;
        const cleanPath = path.replace(/\/+$/, '');
        window[LIDO_COMMON_AUDIO_PATH] = cleanPath;
        // Dispatch a global event so LidoText knows the path is ready
        window.dispatchEvent(new Event('lidoCommonAudioPathReady'));
    }
    async handleIcons() {
        var _a;
        const checkUrl = async (url, containerUrl, fallback) => {
            // if (!url && !containerUrl) return fallback ?? false;
            if (url)
                return convertUrlToRelative(url);
            if (containerUrl)
                return convertUrlToRelative(containerUrl);
            return fallback !== null && fallback !== void 0 ? fallback : false;
            // try {
            //   let res = await fetch(url);
            //   if (res.ok && url) {
            //     return url;
            //   } else {
            //     if (!containerUrl) return fallback ?? false;
            //     res = await fetch(containerUrl);
            //     return res.ok ? containerUrl : fallback ?? false;
            //   }
            // } catch {
            //   return fallback ?? false;
            // }
        };
        const container = document.getElementById(LidoContainer$1);
        const containerExit = container.getAttribute('exit-button-url');
        const containerPrev = container.getAttribute('prev-button-url');
        const containerNext = container.getAttribute('next-button-url');
        const containerSpeak = (_a = container.getAttribute('speak-button-url')) !== null && _a !== void 0 ? _a : container.getAttribute('speaker-button-url');
        this.navBarIcons = {
            exit: `${await checkUrl(this.exitButtonUrl, containerExit, exitUrl)}`,
            prev: `${await checkUrl(this.prevButtonUrl, containerPrev, prevUrl)}`,
            next: `${await checkUrl(this.nextButtonUrl, containerNext, nextUrl)}`,
            speak: `${await checkUrl(this.speakerButtonUrl, containerSpeak, speakUrl)}`,
        };
    }
    updateBackgroundImage() {
        const container = document.querySelector(LidoContainer$1);
        const bgImageSrc = container.getAttribute('bg-image');
        document.body.style.background = 'none';
        container.style.backgroundImage = bgImageSrc ? `url(${bgImageSrc})` : 'none';
        container.style.backgroundPosition = bgImageSrc ? `bottom` : 'none';
        setTimeout(() => {
            const navBar = document.querySelector('.lido-dot-container');
            navBar.classList.add('nav-for-lanai');
            container.append(navBar);
        }, 50);
    }
    /**
     * Lifecycle method that cleans up event listeners when the component is removed from the DOM.
     */
    disconnectedCallback() {
        AudioPlayer.destroyI();
        this.revokeExtractedAssets();
        window.removeEventListener(NextContainerKey, this.handleNextContainerEvent);
        window.removeEventListener('changeContainer', this.handleChangeContainerEvent);
        window.removeEventListener(PrevContainerKey, this.handlePrevContainerEvent);
        window.removeEventListener('beforeunload', this.handleBeforeUnload);
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('touchstart', this.handleWindowTouch);
        window.removeEventListener('pointerdown', this.handleWindowPointer);
    }
    /**
     * Parses the provided XML string into an XML DOM object and extracts the containers from it.
     *
     * @param xmlData - The XML data as a string.
     */
    parseXMLData(xmlData) {
        if (xmlData) {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlData, 'text/xml');
            const rootElement = xmlDoc.documentElement;
            // Parse containers from the root XML element
            this.parseContainers(rootElement);
        }
    }
    resolveContainerData(index) {
        var _a;
        if (!((_a = this.templateData) === null || _a === void 0 ? void 0 : _a.length))
            return null;
        if (this.templateData[index])
            return this.templateData[index];
        if (this.templateData.length === 1)
            return this.templateData[0];
        return null;
    }
    replacePlaceholders(value, data) {
        if (!data || !value)
            return value;
        return value.replace(this.placeholderRegex, (_match, key) => {
            const replacement = data[key];
            return replacement === undefined || replacement === null ? `{${key}}` : String(replacement);
        });
    }
    applyDataToElement(sourceElement, data) {
        if (!data)
            return sourceElement;
        const allElements = [sourceElement, ...Array.from(sourceElement.querySelectorAll('*'))];
        allElements.forEach(node => {
            Array.from(node.attributes).forEach(attr => {
                const replacedValue = attr.value.replace(this.placeholderRegex, (_match, key) => {
                    const replacement = data[key];
                    return replacement === undefined || replacement === null ? `{${key}}` : String(replacement);
                });
                if (replacedValue !== attr.value) {
                    node.setAttribute(attr.name, replacedValue);
                }
            });
        });
        return sourceElement;
    }
    onXmlDataChange(newValue) {
        this.parseXMLData(newValue);
    }
    /**
     * Recursively parses an XML element and its children, converting them into corresponding Stencil components.
     *
     * @param element - The XML element to parse.
     * @returns The corresponding Stencil component with parsed props and children.
     */
    parseElement(element) {
        const tagName = element.nodeName.toLowerCase();
        const props = {};
        // Extract attributes from the element and map them to props
        Array.from(element.attributes).forEach(attr => {
            props[attr.name] = attr.value;
        });
        // Recursively parse child elements
        const children = Array.from(element.childNodes)
            .map(child => {
            if (child.nodeType === 1) {
                return this.parseElement(child);
            }
            else if (child.nodeType === 3 && child.textContent.trim() !== '') {
                return child.textContent;
            }
            return null;
        })
            .filter(Boolean);
        if (tagName === 'lido-text' && props.string) {
            props.string = instance.t(props.string);
        }
        if (tagName === 'lido-text' && props.string) {
            props.string = instance.t(props.string);
        }
        // Map XML tags to Stencil components
        const componentMapping = {
            'lido-container': (h("lido-container", Object.assign({ key: this.resizeTrigger }, props, { canplay: this.canplay }, (!this.zipUrl ? { baseUrl: this.baseUrl } : {}), { height: this.height }), children)),
            'lido-flash-card': h("lido-flash-card", Object.assign({}, props), children),
            'lido-col': h("lido-col", Object.assign({}, props), children),
            'lido-trace': h("lido-trace", Object.assign({}, props), children),
            'lido-image': h("lido-image", Object.assign({}, props), children),
            'lido-row': h("lido-row", Object.assign({}, props), children),
            'lido-text': h("lido-text", Object.assign({}, props), children),
            'lido-pos': h("lido-pos", Object.assign({}, props), children),
            'lido-shape': h("lido-shape", Object.assign({}, props), children),
            'lido-wrap': h("lido-wrap", Object.assign({}, props), children),
            'lido-random': h("lido-random", Object.assign({}, props), children),
            'lido-avatar': h("lido-avatar", Object.assign({}, props), children),
            'lido-cell': h("lido-cell", Object.assign({}, props), children),
            'lido-slide-fill': h("lido-slide-fill", Object.assign({}, props), children),
            'lido-float': h("lido-float", Object.assign({}, props), children),
            'lido-keyboard': h("lido-keyboard", Object.assign({}, props), children),
            'lido-math-matrix': h("lido-math-matrix", Object.assign({}, props), children),
            'lido-balance': h("lido-balance", Object.assign({}, props), children),
            'lido-calculator': h("lido-calculator", Object.assign({}, props), children),
            'lido-canvas': h("lido-canvas", Object.assign({}, props), children),
        };
        // If the tag is known, return the corresponding Stencil component, otherwise log a warning
        if (componentMapping[tagName]) {
            return componentMapping[tagName];
        }
        else {
            console.warn(`Unknown tag: ${tagName}`);
            return null;
        }
    }
    /**
     * Parses the `lido-container` elements from the XML root element and stores them in the `containers` state.
     *
     * @param rootElement - The root element of the parsed XML document.
     */
    parseContainers(rootElement) {
        const containerElements = rootElement.querySelectorAll('lido-container');
        const containers = Array.from(containerElements)
            .map((container, index) => {
            if (this.activeContainerIndexes.length && !this.activeContainerIndexes.includes(index))
                return;
            const dataForContainer = this.resolveContainerData(index);
            const hydratedContainer = this.applyDataToElement(container, dataForContainer);
            // Return a factory function that generates a fresh JSX node each time
            return () => this.parseElement(hydratedContainer);
        })
            .filter(Boolean); // Remove any undefined entries
        this.containers = containers;
    }
    areAllDropsFilled() {
        const drops = Array.from(document.querySelectorAll('[type="drop"]'));
        const drags = Array.from(document.querySelectorAll('[type="drag"]')).filter(drag => drag.getAttribute('drop-to'));
        return drops.every(drop => {
            const dropId = drop.id;
            return drags.some(drag => drag.getAttribute('drop-to') === dropId);
        });
    }
    async btnpopup(runId) {
        var _a, _b;
        const isStale = () => runId !== this.btnpopupRunId;
        const container = document.getElementById(LidoContainer$1);
        if (isStale())
            return;
        if (!container || container.getAttribute('game-completed') === 'true')
            return;
        setCancelBtnPopup(false);
        await AudioPlayer.getI().stop();
        if (isStale())
            return;
        const allele = container.querySelectorAll('*');
        const templateId = container.getAttribute(TemplateID);
        if (templateId) {
            const instructEl = this.el.querySelector(`#${templateId}`);
            if (instructEl) {
                await executeActions("this.speak='true';", instructEl);
                if (isStale())
                    return;
            }
        }
        for (const el of Array.from(allele)) {
            if (getCancelBtnPopup() || isStale())
                break;
            const tabIndex = el.getAttribute('tab-index');
            const htmlel = el;
            if (tabIndex && Number(tabIndex) > 0) {
                const isVisible = (el) => {
                    const rect = el.getBoundingClientRect();
                    return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
                };
                const type = htmlel === null || htmlel === void 0 ? void 0 : htmlel.getAttribute('type');
                if (htmlel && htmlel.getAttribute('disable-speak') !== 'true' &&
                    // If it has type → must be visible
                    (((type === null || type === void 0 ? void 0 : type.trim()) && isVisible(htmlel)) ||
                        // If no type → speak anyway
                        !type || !type.trim())) {
                    await AudioPlayer.getI().play(htmlel);
                }
                if (getCancelBtnPopup() || isStale()) {
                    if (this.shouldStopActiveBtnpopupAudio) {
                        await AudioPlayer.getI().stop();
                    }
                    break;
                }
                await new Promise(resolve => setTimeout(resolve, 300));
                if (isStale())
                    break;
            }
        }
        if (isStale())
            return;
        if (this.areAllDropsFilled()) {
            const objectiveString = container['objective'];
            const objectiveArray = (_b = JSON.parse((_a = container.getAttribute(SelectedValuesKey)) !== null && _a !== void 0 ? _a : '[]')) !== null && _b !== void 0 ? _b : [];
            const res = matchStringPattern(objectiveString, objectiveArray);
            if (res) {
                triggerNextContainer();
            }
        }
        else if (container.getAttribute('game-completed') === 'true') {
            triggerNextContainer();
        }
        else ;
    }
    hasAudioOnInteractionTarget(target) {
        const element = target;
        if (!element)
            return false;
        const hasValidAudio = (candidate) => {
            if (!(candidate instanceof HTMLElement))
                return false;
            const audioAttr = candidate.getAttribute('audio');
            return !!audioAttr && audioAttr.trim().length > 0;
        };
        if (hasValidAudio(element))
            return true;
        if (hasValidAudio(element.closest('[audio]')))
            return true;
        if (hasValidAudio(element.querySelector('[audio]')))
            return true;
        return false;
    }
    async cancelBtnpopupRun(shouldStopAudio = true) {
        this.btnpopupRunId++;
        this.shouldStopActiveBtnpopupAudio = shouldStopAudio;
        setCancelBtnPopup(true);
        if (shouldStopAudio) {
            await AudioPlayer.getI().stop();
        }
    }
    async handleBtnpopupClick() {
        // Invalidate any in-flight run and stop audio immediately.
        await this.cancelBtnpopupRun();
        // Start fresh run.
        const nextRunId = this.btnpopupRunId;
        setCancelBtnPopup(false);
        this.activeBtnpopupRunId = nextRunId;
        this.shouldStopActiveBtnpopupAudio = true;
        try {
            await this.btnpopup(nextRunId);
        }
        finally {
            if (this.activeBtnpopupRunId === nextRunId) {
                this.activeBtnpopupRunId = null;
            }
            this.shouldStopActiveBtnpopupAudio = true;
        }
    }
    scaleNavbarContainer() {
        setTimeout(() => {
            const navBar = document.querySelector('.lido-dot-container');
            if (!navBar)
                return;
            if ((window.innerWidth === 1600 && window.innerHeight === 900) || (window.innerWidth === 900 && window.innerHeight === 1600)) {
                const exit_and_audio_margin = document.querySelectorAll('.lido-exit-button, #main-audio');
                exit_and_audio_margin.forEach(el => {
                    el.style.marginLeft = '10px';
                    el.style.marginRight = '10px';
                });
            }
            if (window.innerWidth > window.innerHeight) {
                navBar.style.top = '6%';
            }
            else {
                navBar.style.top = '3.5%';
            }
            // Apply the scale to the navbar
            navBar.style.transform = `translate(-50%, -50%)`;
            navBar.style.visibility = 'visible';
            Array.from(navBar.children).forEach(el => {
                const item = el;
                item.style.transform = `scale(${calculateScale()})`;
            });
            navBar.style.width = window.outerWidth + 'px';
        }, 500);
    }
    /**
     * Renders navigation dots for each container, indicating the progress of the user.
     * Clicking on a dot allows the user to jump to a specific container.
     */
    renderDots() {
        const style = { pointerEvents: this.canplay ? 'none' : '' };
        return (h("div", { id: "lido-dot-indicator", class: "lido-dot-container", style: { visibility: 'hidden' } }, h("div", { class: "lido-exit-button popup-button", onClick: () => {
                this.exitFlag = true;
                AudioPlayer.getI().stop();
            } }, h("lido-image", { src: this.navBarIcons.exit, width: "stretch" })), h("div", { class: "lido-btn-dot-container" }, h("div", { id: "lido-arrow-left", onClick: () => {
                triggerPrevcontainer();
            } }, h("lido-image", { src: this.navBarIcons.prev, width: "stretch" })), this.containers.map((_, index) => (h("div", { class: "parent_dots" }, h("span", { class: `lido-dot ${index < this.currentContainerIndex ? 'completed' : index === this.currentContainerIndex ? 'current' : ''}`, onClick: () => this.jumpToContainer(index), style: style })))), h("div", { id: "lido-arrow-right", onClick: event => {
                executeActions("this.nextBtn='true'", event.currentTarget);
            } }, h("lido-image", { src: this.navBarIcons.next, width: "stretch" }))), h("div", { id: "main-audio", class: "popup-button", onClick: () => this.handleBtnpopupClick() }, h("lido-image", { visible: "true", src: this.navBarIcons.speak, width: "stretch" }))));
    }
    /**
     * Jumps to a specific container based on the index of the dot clicked.
     *
     * @param index - The index of the container to jump to.
     */
    jumpToContainer(index) {
        this.NextContainerKey(index);
        // this.currentContainerIndex = index;
        // this.containers = [...this.containers]; // Trigger re-render
    }
    render() {
        var _a, _b;
        if (!this.xmlData) {
            // If no XML data is provided, prompt the user to provide it
            return h("div", null, "Please provide XML data.");
        }
        const style = {
            userSelect: 'none', // Prevent any field selection
        };
        return (h(Host, { class: "lido-home", uuid: this.uuid, "template-id": "", index: this.currentContainerIndex, totalIndex: this.containers.length, style: style }, h("div", { key: this.currentContainerIndex }, (_b = (_a = this.containers)[this.currentContainerIndex]) === null || _b === void 0 ? void 0 : _b.call(_a)), this.renderDots(), this.exitFlag && (h("div", { class: "lido-alert-parent" }, h("div", { class: "lido-alert-popup" }, h("lido-cell", { class: "lido-alert-content", visible: "true", layout: "col", width: "340px", height: "210px", "bg-color": "#fff", "border-radius": "16px", onEntry: "this.box-shadow= '0 4px 8px 0 rgba(0, 0, 0, 0.25)';" }, h("lido-text", { visible: "true", string: this.translateHomeText('Do you want to exit? button'), width: "294px", height: "38px", class: "popup-exit-text", "font-size": "22px", onEntry: "this.margin-bottom =' -36px';" }), h("lido-cell", { visible: "true", layout: "row", width: "294px", class: "btn-cell" }, h("lido-text", { visible: "true", string: this.translateHomeText('Exit button'), width: "92px", height: "53px", "font-size": "16px", margin: "0px 50px 0px 0px", class: "popup-button", onClick: () => this.popUpClick('exit'), borderRadius: "16px", onEntry: 'this.color="#F34D08"; this.font-weight="700"; this.box-shadow="0 2px 0 #F34D08";', fontFamily: "Baloo Bhai 2", "font-weight": "700", bgColor: "white", "border-radius": "16px" }), h("lido-text", { visible: "true", string: this.translateHomeText('Continue playing button'), width: "155px", height: "53px", "font-size": "16px", class: "popup-button", onClick: () => this.popUpClick('cancel'), borderRadius: "16px", onEntry: 'this.color=white; this.font-weight="700"; this.box-shadow="0 2px 0 #F34D08";', "font-family": "Baloo Bhai 2", "font-weight": "700", bgColor: "#F34D08", "border-radius": "16px" }))))))));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "commonAudioPath": [{
                "onCommonAudioPathChange": 0
            }],
        "xmlData": [{
                "onXmlDataChange": 0
            }]
    }; }
};
LidoHome.style = indexCss() + (animationCss() + lidoHomeCss());

var lib = {exports: {}};

var colorToFilter = {};

var errorHandling = {};

var errors = {};

var hasRequiredErrors;

function requireErrors () {
	if (hasRequiredErrors) return errors;
	hasRequiredErrors = 1;
	(function (exports) {
		// if there are too many new issues being created, change the below variables to the following:
		// export const UNEXPECTED_ERROR_MESSAGE_PREFIX =
		//   'Unexpected error has occurred, please report this by creating a new issue in the following link: ';
		Object.defineProperty(exports, "__esModule", { value: true });
		exports.MUST_INSTALL_PUPPETEER = exports.DEFAULT_CONVERSION_ERROR_MESSAGE = exports.UNEXPECTED_ERROR_MESSAGE_INTRODUCTION = exports.UNEXPECTED_ERROR_MESSAGE_LINK = exports.UNEXPECTED_ERROR_MESSAGE_PREFIX = void 0;
		// export const UNEXPECTED_ERROR_MESSAGE_LINK = 'https://github.com/OvidijusParsiunas/css-filter-converter/issues';
		exports.UNEXPECTED_ERROR_MESSAGE_PREFIX = 'Unexpected error has occurred, please report this by using the following link: ';
		exports.UNEXPECTED_ERROR_MESSAGE_LINK = 'https://github.com/OvidijusParsiunas/css-filter-converter/issues/new';
		exports.UNEXPECTED_ERROR_MESSAGE_INTRODUCTION = exports.UNEXPECTED_ERROR_MESSAGE_PREFIX + exports.UNEXPECTED_ERROR_MESSAGE_LINK;
		exports.DEFAULT_CONVERSION_ERROR_MESSAGE = 'Input value is invalid';
		exports.MUST_INSTALL_PUPPETEER = "To convert filter values to color in Node - you will first need to install 'puppeteer' by running:" +
		    ' \n npm install puppeteer'; 
	} (errors));
	return errors;
}

var hasRequiredErrorHandling;

function requireErrorHandling () {
	if (hasRequiredErrorHandling) return errorHandling;
	hasRequiredErrorHandling = 1;
	Object.defineProperty(errorHandling, "__esModule", { value: true });
	errorHandling.ErrorHandling = void 0;
	const errors_1 = requireErrors();
	class ErrorHandling {
	    static generateErrorResult(message) {
	        return { color: null, error: { message } };
	    }
	    static generateInputErrorMessage(colorType, colorString, format) {
	        const errorPrefix = `Input ${colorType} color string could not be parsed.`;
	        const actualStringReceived = `String received: ${colorString}.`;
	        const messageStrings = [errorPrefix, actualStringReceived];
	        if (format) {
	            const expectedFormat = `Expected format: ${format}.`;
	            messageStrings.splice(1, 0, expectedFormat);
	        }
	        return messageStrings.join(' ');
	    }
	    static generateUnexpectedError(error) {
	        const errorMessage = `${errors_1.UNEXPECTED_ERROR_MESSAGE_INTRODUCTION}: \n${error.message}`;
	        return ErrorHandling.generateErrorResult(errorMessage);
	    }
	    static hasError(param) {
	        return !!param.errorMessage;
	    }
	}
	errorHandling.ErrorHandling = ErrorHandling;
	return errorHandling;
}

var sheenUtil = {};

var hasRequiredSheenUtil;

function requireSheenUtil () {
	if (hasRequiredSheenUtil) return sheenUtil;
	hasRequiredSheenUtil = 1;
	Object.defineProperty(sheenUtil, "__esModule", { value: true });
	sheenUtil.SheenUtil = void 0;
	class SheenUtil {
	    static parseSheenFromOptions(options) {
	        if (options) {
	            if (typeof options.sheen === 'boolean')
	                return options.sheen;
	        }
	        return true;
	    }
	}
	sheenUtil.SheenUtil = SheenUtil;
	SheenUtil.SHEEN_FILTER_PREFIX = 'brightness(0) saturate(100%)';
	return sheenUtil;
}

var colorTypes = {};

var hasRequiredColorTypes;

function requireColorTypes () {
	if (hasRequiredColorTypes) return colorTypes;
	hasRequiredColorTypes = 1;
	(function (exports) {
		Object.defineProperty(exports, "__esModule", { value: true });
		exports.ColorTypes = void 0;
		(function (ColorTypes) {
		    ColorTypes["HEX"] = "hex";
		    ColorTypes["RGB"] = "rgb";
		    ColorTypes["HSL"] = "hsl";
		    ColorTypes["KEYWORD"] = "keyword";
		    ColorTypes["FILTER"] = "filter";
		})(exports.ColorTypes || (exports.ColorTypes = {})); 
	} (colorTypes));
	return colorTypes;
}

var rgbToFilter = {};

var rgbToFilterWorker = {};

var rgbColor = {};

var hasRequiredRgbColor;

function requireRgbColor () {
	if (hasRequiredRgbColor) return rgbColor;
	hasRequiredRgbColor = 1;
	Object.defineProperty(rgbColor, "__esModule", { value: true });
	rgbColor.RgbColor = void 0;
	class RgbColor {
	    constructor(rgb = [0, 0, 0], roundChannels = false) {
	        this.roundChannels = roundChannels;
	        this.r = this.clamp(rgb[0]);
	        this.g = this.clamp(rgb[1]);
	        this.b = this.clamp(rgb[2]);
	    }
	    clamp(value) {
	        if (value > 255) {
	            value = 255;
	        }
	        else if (value < 0) {
	            value = 0;
	        }
	        return this.roundChannels ? Math.round(value) : value;
	    }
	    setRgb(r, g, b) {
	        this.r = this.clamp(r);
	        this.g = this.clamp(g);
	        this.b = this.clamp(b);
	    }
	    multiply(matrix) {
	        const newR = this.clamp(this.r * matrix[0] + this.g * matrix[1] + this.b * matrix[2]);
	        const newG = this.clamp(this.r * matrix[3] + this.g * matrix[4] + this.b * matrix[5]);
	        const newB = this.clamp(this.r * matrix[6] + this.g * matrix[7] + this.b * matrix[8]);
	        this.r = newR;
	        this.g = newG;
	        this.b = newB;
	    }
	    hueRotate(angle = 0) {
	        angle = (angle / 180) * Math.PI;
	        const sin = Math.sin(angle);
	        const cos = Math.cos(angle);
	        this.multiply([
	            0.213 + cos * 0.787 - sin * 0.213,
	            0.715 - cos * 0.715 - sin * 0.715,
	            0.072 - cos * 0.072 + sin * 0.928,
	            0.213 - cos * 0.213 + sin * 0.143,
	            0.715 + cos * 0.285 + sin * 0.14,
	            0.072 - cos * 0.072 - sin * 0.283,
	            0.213 - cos * 0.213 - sin * 0.787,
	            0.715 - cos * 0.715 + sin * 0.715,
	            0.072 + cos * 0.928 + sin * 0.072,
	        ]);
	    }
	    sepia(value = 1) {
	        this.multiply([
	            0.393 + 0.607 * (1 - value),
	            0.769 - 0.769 * (1 - value),
	            0.189 - 0.189 * (1 - value),
	            0.349 - 0.349 * (1 - value),
	            0.686 + 0.314 * (1 - value),
	            0.168 - 0.168 * (1 - value),
	            0.272 - 0.272 * (1 - value),
	            0.534 - 0.534 * (1 - value),
	            0.131 + 0.869 * (1 - value),
	        ]);
	    }
	    saturate(value = 1) {
	        this.multiply([
	            0.213 + 0.787 * value,
	            0.715 - 0.715 * value,
	            0.072 - 0.072 * value,
	            0.213 - 0.213 * value,
	            0.715 + 0.285 * value,
	            0.072 - 0.072 * value,
	            0.213 - 0.213 * value,
	            0.715 - 0.715 * value,
	            0.072 + 0.928 * value,
	        ]);
	    }
	    linear(slope = 1, intercept = 0) {
	        this.r = this.clamp(this.r * slope + intercept * 255);
	        this.g = this.clamp(this.g * slope + intercept * 255);
	        this.b = this.clamp(this.b * slope + intercept * 255);
	    }
	    brightness(value = 1) {
	        this.linear(value);
	    }
	    contrast(value = 1) {
	        this.linear(value, -(0.5 * value) + 0.5);
	    }
	    invert(value = 1) {
	        this.r = this.clamp((value + (this.r / 255) * (1 - 2 * value)) * 255);
	        this.g = this.clamp((value + (this.g / 255) * (1 - 2 * value)) * 255);
	        this.b = this.clamp((value + (this.b / 255) * (1 - 2 * value)) * 255);
	    }
	}
	rgbColor.RgbColor = RgbColor;
	return rgbColor;
}

var hasRequiredRgbToFilterWorker;

function requireRgbToFilterWorker () {
	if (hasRequiredRgbToFilterWorker) return rgbToFilterWorker;
	hasRequiredRgbToFilterWorker = 1;
	// the code used within this class has been taken and modified from the following codepen owned by Barrett Sonntag:
	// https://codepen.io/sosuke/pen/Pjoqqp
	Object.defineProperty(rgbToFilterWorker, "__esModule", { value: true });
	rgbToFilterWorker.RgbToFilterWorker = void 0;
	const sheenUtil_1 = requireSheenUtil();
	const rgbColor_1 = requireRgbColor();
	class RgbToFilterWorker {
	    constructor(targetRgbColor, addSheen) {
	        this.targetRgbColor = targetRgbColor;
	        this.reusedRgbColor = new rgbColor_1.RgbColor();
	        this.reusedRoundedRgbColor = new rgbColor_1.RgbColor([0, 0, 0], true);
	        this.addSheen = addSheen;
	    }
	    static fmt(filters, idx, multiplier = 1) {
	        return Math.round(filters[idx] * multiplier);
	    }
	    generateCss(filters) {
	        const prefix = this.addSheen ? `${sheenUtil_1.SheenUtil.SHEEN_FILTER_PREFIX} ` : '';
	        // prettier-ignore
	        // eslint-disable-next-line max-len
	        return `${prefix}invert(${RgbToFilterWorker.fmt(filters, 0)}%) sepia(${RgbToFilterWorker.fmt(filters, 1)}%) saturate(${RgbToFilterWorker.fmt(filters, 2)}%) hue-rotate(${RgbToFilterWorker.fmt(filters, 3, 3.6)}deg) brightness(${RgbToFilterWorker.fmt(filters, 4)}%) contrast(${RgbToFilterWorker.fmt(filters, 5)}%)`;
	    }
	    applyFilters(color, filters, hueRotateDegrees) {
	        color.setRgb(0, 0, 0);
	        color.invert(filters[0] / 100);
	        color.sepia(filters[1] / 100);
	        color.saturate(filters[2] / 100);
	        color.hueRotate(hueRotateDegrees);
	        color.brightness(filters[4] / 100);
	        color.contrast(filters[5] / 100);
	        return (Math.abs(color.r - this.targetRgbColor.r) +
	            Math.abs(color.g - this.targetRgbColor.g) +
	            Math.abs(color.b - this.targetRgbColor.b));
	    }
	    loss(filters) {
	        return this.applyFilters(this.reusedRgbColor, filters, filters[3] * 3.6);
	    }
	    // candidates are accepted on the loss of the filter as it will be serialized to CSS (rounded parameters),
	    // evaluated under both fractional and per-stage 8-bit channel precision - browsers differ in intermediate
	    // precision, so a candidate is only as good as its worst rendering model
	    serializedLoss(filters) {
	        const serialized = filters.map((_, idx) => RgbToFilterWorker.fmt(filters, idx));
	        const hueRotateDegrees = RgbToFilterWorker.fmt(filters, 3, 3.6);
	        const fractionalLoss = this.applyFilters(this.reusedRgbColor, serialized, hueRotateDegrees);
	        const roundedLoss = this.applyFilters(this.reusedRoundedRgbColor, serialized, hueRotateDegrees);
	        return Math.max(fractionalLoss, roundedLoss);
	    }
	    static fixSpsa(value, idx) {
	        let max = 100;
	        if (idx === 2 /* saturate */) {
	            max = 7500;
	        }
	        else if (idx === 4 /* brightness */ || idx === 5 /* contrast */) {
	            max = 200;
	        }
	        if (idx === 3 /* hue-rotate */) {
	            if (value > max) {
	                value %= max;
	            }
	            else if (value < 0) {
	                value = max + (value % max);
	            }
	        }
	        else if (value < 0) {
	            value = 0;
	        }
	        else if (value > max) {
	            value = max;
	        }
	        return value;
	    }
	    spsa(A, a, c, values, iters) {
	        const alpha = 1;
	        const gamma = 0.16666666666666666;
	        let best = [];
	        let bestLoss = Infinity;
	        const deltas = new Array(6);
	        const highArgs = new Array(6);
	        const lowArgs = new Array(6);
	        for (let k = 0; k < iters; k += 1) {
	            const ck = c / Math.pow(k + 1, gamma);
	            for (let i = 0; i < 6; i += 1) {
	                deltas[i] = Math.random() > 0.5 ? 1 : -1;
	                highArgs[i] = values[i] + ck * deltas[i];
	                lowArgs[i] = values[i] - ck * deltas[i];
	            }
	            const lossDiff = this.loss(highArgs) - this.loss(lowArgs);
	            for (let i = 0; i < 6; i += 1) {
	                const g = (lossDiff / (2 * ck)) * deltas[i];
	                const ak = a[i] / Math.pow(A + k + 1, alpha);
	                values[i] = RgbToFilterWorker.fixSpsa(values[i] - ak * g, i);
	            }
	            // gradient estimation above stays on the smooth fractional loss - acceptance uses the serialized score
	            const loss = this.serializedLoss(values);
	            if (loss < bestLoss) {
	                best = values.slice(0);
	                bestLoss = loss;
	            }
	        }
	        return { values: best, loss: bestLoss };
	    }
	    solveNarrow(wide) {
	        const A = wide.loss;
	        const c = 2;
	        const A1 = A + 1;
	        const a = [0.25 * A1, 0.25 * A1, A1, 0.25 * A1, 0.2 * A1, 0.2 * A1];
	        return this.spsa(A, a, c, wide.values, 500);
	    }
	    solveWide() {
	        const A = 5;
	        const c = 15;
	        const a = [60, 180, 18000, 600, 1.2, 1.2];
	        let best = { values: [], loss: Infinity };
	        for (let i = 0; best.loss > 25 && i < 3; i += 1) {
	            const initial = [50, 20, 3750, 50, 100, 100];
	            const result = this.spsa(A, a, c, initial, 1000);
	            if (result.loss < best.loss) {
	                best = result;
	            }
	        }
	        return best;
	    }
	    convert() {
	        const result = this.solveNarrow(this.solveWide());
	        return {
	            loss: result.loss,
	            color: this.generateCss(result.values),
	        };
	    }
	}
	rgbToFilterWorker.RgbToFilterWorker = RgbToFilterWorker;
	return rgbToFilterWorker;
}

var hasRequiredRgbToFilter;

function requireRgbToFilter () {
	if (hasRequiredRgbToFilter) return rgbToFilter;
	hasRequiredRgbToFilter = 1;
	Object.defineProperty(rgbToFilter, "__esModule", { value: true });
	rgbToFilter.RgbToFilter = void 0;
	const errorHandling_1 = requireErrorHandling();
	const errors_1 = requireErrors();
	const rgbToFilterWorker_1 = requireRgbToFilterWorker();
	const rgbColor_1 = requireRgbColor();
	class RgbToFilter {
	    static generateConversionError(conversionErrorMessage) {
	        const errorMessage = conversionErrorMessage || errors_1.DEFAULT_CONVERSION_ERROR_MESSAGE;
	        return errorHandling_1.ErrorHandling.generateErrorResult(errorMessage);
	    }
	    static generateValidateAndParseError(errorMessage) {
	        return errorHandling_1.ErrorHandling.generateErrorResult(errorMessage);
	    }
	    static execute(rgb, addSheen) {
	        const rgbColor = new rgbColor_1.RgbColor(rgb);
	        const rgbToFilter = new rgbToFilterWorker_1.RgbToFilterWorker(rgbColor, addSheen);
	        return rgbToFilter.convert();
	    }
	    static convertToRGB(parseResultColor, convertToRgb) {
	        if (parseResultColor && convertToRgb) {
	            return convertToRgb(parseResultColor);
	        }
	        return null;
	    }
	    static convert(conversionProps) {
	        try {
	            const { colorString, validateAndParse, convertToRgb, conversionErrorMessage, addSheen } = conversionProps;
	            const trimmedString = colorString.trim().toLocaleLowerCase();
	            const parseResult = (validateAndParse === null || validateAndParse === void 0 ? void 0 : validateAndParse(trimmedString)) || { color: trimmedString };
	            if (errorHandling_1.ErrorHandling.hasError(parseResult))
	                return RgbToFilter.generateValidateAndParseError(parseResult.errorMessage);
	            const rgbColor = RgbToFilter.convertToRGB(parseResult.color, convertToRgb) || parseResult.color;
	            if (!rgbColor)
	                return RgbToFilter.generateConversionError(conversionErrorMessage);
	            return RgbToFilter.execute(rgbColor, addSheen);
	        }
	        catch (error) {
	            return errorHandling_1.ErrorHandling.generateUnexpectedError(error);
	        }
	    }
	}
	rgbToFilter.RgbToFilter = RgbToFilter;
	return rgbToFilter;
}

var colorParser = {};

var regex = {};

var hasRequiredRegex;

function requireRegex () {
	if (hasRequiredRegex) return regex;
	hasRequiredRegex = 1;
	Object.defineProperty(regex, "__esModule", { value: true });
	regex.MATCH_HEXADECIMAL = regex.MATCH_INTEGER_AND_FLOAT_NUMBERS = void 0;
	regex.MATCH_INTEGER_AND_FLOAT_NUMBERS = /(-?\d+(?:\.\d+)?)/g;
	regex.MATCH_HEXADECIMAL = /^#[0-9a-f]{3}([0-9a-f]{3})?$/i;
	return regex;
}

var inputLimits = {};

var hasRequiredInputLimits;

function requireInputLimits () {
	if (hasRequiredInputLimits) return inputLimits;
	hasRequiredInputLimits = 1;
	Object.defineProperty(inputLimits, "__esModule", { value: true });
	inputLimits.MAX_COLOR_INPUT_STRING_LENGTH = void 0;
	// this is used to prevent regex matcher from evaluating a long string that can be assumed to be incorrect
	// currently not applied to filter
	inputLimits.MAX_COLOR_INPUT_STRING_LENGTH = 25;
	return inputLimits;
}

var colorFormats = {};

var hasRequiredColorFormats;

function requireColorFormats () {
	if (hasRequiredColorFormats) return colorFormats;
	hasRequiredColorFormats = 1;
	(function (exports) {
		Object.defineProperty(exports, "__esModule", { value: true });
		exports.ColorFormats = void 0;
		(function (ColorFormats) {
		    ColorFormats["HEX"] = "#ffffff or #fff";
		    ColorFormats["RGB"] = "rgb([0-255], [0-255], [0-255]) or rgb([0-255], [0-255], [0-255], [0-1]) or rgb([0-100%], [0-100%], [0-100%]) or rgb([0-100%], [0-100%], [0-100%], [0-100%]) or [0-255], [0-255], [0-255] or [0-255] [0-255] [0-255]";
		    ColorFormats["HSL"] = "hsl([0-360], [0-100], [0-100]) or hsl([0-360], [0-100%], [0-100%]) or [0-360], [0-100], [0-100] or [0-360] [0-100] [0-100]";
		    ColorFormats["FILTER"] = "blur(), brightness(), contrast(), drop-shadow(), grayscale(), hue-rotate(), invert(), saturate(), sepia() with each parameter populated with %, px or deg where approriate e.g. contrast(101%)";
		    ColorFormats["KEYWORD"] = "Generic color string. See the following link for all available colors: https://github.com/colorjs/color-name/blob/master/index.js";
		})(exports.ColorFormats || (exports.ColorFormats = {})); 
	} (colorFormats));
	return colorFormats;
}

var colorName;
var hasRequiredColorName;

function requireColorName () {
	if (hasRequiredColorName) return colorName;
	hasRequiredColorName = 1;

	colorName = {
		"aliceblue": [240, 248, 255],
		"antiquewhite": [250, 235, 215],
		"aqua": [0, 255, 255],
		"aquamarine": [127, 255, 212],
		"azure": [240, 255, 255],
		"beige": [245, 245, 220],
		"bisque": [255, 228, 196],
		"black": [0, 0, 0],
		"blanchedalmond": [255, 235, 205],
		"blue": [0, 0, 255],
		"blueviolet": [138, 43, 226],
		"brown": [165, 42, 42],
		"burlywood": [222, 184, 135],
		"cadetblue": [95, 158, 160],
		"chartreuse": [127, 255, 0],
		"chocolate": [210, 105, 30],
		"coral": [255, 127, 80],
		"cornflowerblue": [100, 149, 237],
		"cornsilk": [255, 248, 220],
		"crimson": [220, 20, 60],
		"cyan": [0, 255, 255],
		"darkblue": [0, 0, 139],
		"darkcyan": [0, 139, 139],
		"darkgoldenrod": [184, 134, 11],
		"darkgray": [169, 169, 169],
		"darkgreen": [0, 100, 0],
		"darkgrey": [169, 169, 169],
		"darkkhaki": [189, 183, 107],
		"darkmagenta": [139, 0, 139],
		"darkolivegreen": [85, 107, 47],
		"darkorange": [255, 140, 0],
		"darkorchid": [153, 50, 204],
		"darkred": [139, 0, 0],
		"darksalmon": [233, 150, 122],
		"darkseagreen": [143, 188, 143],
		"darkslateblue": [72, 61, 139],
		"darkslategray": [47, 79, 79],
		"darkslategrey": [47, 79, 79],
		"darkturquoise": [0, 206, 209],
		"darkviolet": [148, 0, 211],
		"deeppink": [255, 20, 147],
		"deepskyblue": [0, 191, 255],
		"dimgray": [105, 105, 105],
		"dimgrey": [105, 105, 105],
		"dodgerblue": [30, 144, 255],
		"firebrick": [178, 34, 34],
		"floralwhite": [255, 250, 240],
		"forestgreen": [34, 139, 34],
		"fuchsia": [255, 0, 255],
		"gainsboro": [220, 220, 220],
		"ghostwhite": [248, 248, 255],
		"gold": [255, 215, 0],
		"goldenrod": [218, 165, 32],
		"gray": [128, 128, 128],
		"green": [0, 128, 0],
		"greenyellow": [173, 255, 47],
		"grey": [128, 128, 128],
		"honeydew": [240, 255, 240],
		"hotpink": [255, 105, 180],
		"indianred": [205, 92, 92],
		"indigo": [75, 0, 130],
		"ivory": [255, 255, 240],
		"khaki": [240, 230, 140],
		"lavender": [230, 230, 250],
		"lavenderblush": [255, 240, 245],
		"lawngreen": [124, 252, 0],
		"lemonchiffon": [255, 250, 205],
		"lightblue": [173, 216, 230],
		"lightcoral": [240, 128, 128],
		"lightcyan": [224, 255, 255],
		"lightgoldenrodyellow": [250, 250, 210],
		"lightgray": [211, 211, 211],
		"lightgreen": [144, 238, 144],
		"lightgrey": [211, 211, 211],
		"lightpink": [255, 182, 193],
		"lightsalmon": [255, 160, 122],
		"lightseagreen": [32, 178, 170],
		"lightskyblue": [135, 206, 250],
		"lightslategray": [119, 136, 153],
		"lightslategrey": [119, 136, 153],
		"lightsteelblue": [176, 196, 222],
		"lightyellow": [255, 255, 224],
		"lime": [0, 255, 0],
		"limegreen": [50, 205, 50],
		"linen": [250, 240, 230],
		"magenta": [255, 0, 255],
		"maroon": [128, 0, 0],
		"mediumaquamarine": [102, 205, 170],
		"mediumblue": [0, 0, 205],
		"mediumorchid": [186, 85, 211],
		"mediumpurple": [147, 112, 219],
		"mediumseagreen": [60, 179, 113],
		"mediumslateblue": [123, 104, 238],
		"mediumspringgreen": [0, 250, 154],
		"mediumturquoise": [72, 209, 204],
		"mediumvioletred": [199, 21, 133],
		"midnightblue": [25, 25, 112],
		"mintcream": [245, 255, 250],
		"mistyrose": [255, 228, 225],
		"moccasin": [255, 228, 181],
		"navajowhite": [255, 222, 173],
		"navy": [0, 0, 128],
		"oldlace": [253, 245, 230],
		"olive": [128, 128, 0],
		"olivedrab": [107, 142, 35],
		"orange": [255, 165, 0],
		"orangered": [255, 69, 0],
		"orchid": [218, 112, 214],
		"palegoldenrod": [238, 232, 170],
		"palegreen": [152, 251, 152],
		"paleturquoise": [175, 238, 238],
		"palevioletred": [219, 112, 147],
		"papayawhip": [255, 239, 213],
		"peachpuff": [255, 218, 185],
		"peru": [205, 133, 63],
		"pink": [255, 192, 203],
		"plum": [221, 160, 221],
		"powderblue": [176, 224, 230],
		"purple": [128, 0, 128],
		"rebeccapurple": [102, 51, 153],
		"red": [255, 0, 0],
		"rosybrown": [188, 143, 143],
		"royalblue": [65, 105, 225],
		"saddlebrown": [139, 69, 19],
		"salmon": [250, 128, 114],
		"sandybrown": [244, 164, 96],
		"seagreen": [46, 139, 87],
		"seashell": [255, 245, 238],
		"sienna": [160, 82, 45],
		"silver": [192, 192, 192],
		"skyblue": [135, 206, 235],
		"slateblue": [106, 90, 205],
		"slategray": [112, 128, 144],
		"slategrey": [112, 128, 144],
		"snow": [255, 250, 250],
		"springgreen": [0, 255, 127],
		"steelblue": [70, 130, 180],
		"tan": [210, 180, 140],
		"teal": [0, 128, 128],
		"thistle": [216, 191, 216],
		"tomato": [255, 99, 71],
		"turquoise": [64, 224, 208],
		"violet": [238, 130, 238],
		"wheat": [245, 222, 179],
		"white": [255, 255, 255],
		"whitesmoke": [245, 245, 245],
		"yellow": [255, 255, 0],
		"yellowgreen": [154, 205, 50]
	};
	return colorName;
}

var hasRequiredColorParser;

function requireColorParser () {
	if (hasRequiredColorParser) return colorParser;
	hasRequiredColorParser = 1;
	var __importDefault = (colorParser && colorParser.__importDefault) || function (mod) {
	    return (mod && mod.__esModule) ? mod : { "default": mod };
	};
	Object.defineProperty(colorParser, "__esModule", { value: true });
	colorParser.ColorParser = void 0;
	const regex_1 = requireRegex();
	const errorHandling_1 = requireErrorHandling();
	const inputLimits_1 = requireInputLimits();
	const colorFormats_1 = requireColorFormats();
	const colorTypes_1 = requireColorTypes();
	// eslint-disable-next-line import/no-extraneous-dependencies
	const color_name_1 = __importDefault(requireColorName());
	class ColorParser {
	    static validateAndParseHex(hexString) {
	        if (hexString.length < inputLimits_1.MAX_COLOR_INPUT_STRING_LENGTH) {
	            const isValid = hexString.match(regex_1.MATCH_HEXADECIMAL);
	            if (isValid)
	                return { color: hexString };
	        }
	        return { errorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.HEX, hexString, colorFormats_1.ColorFormats.HEX) };
	    }
	    // the reason why this is simply parsing the first three digits instead of the tailored format is because the number
	    // of variations of different inputs is very high. E.g. these are valid RGB values:
	    // rgb(1,2,3)
	    // rgb(1%,2%,3%)
	    // rgb(1,2,3,0.5)
	    // rgb(1 2 3 / 0.5)
	    // rgb(1 2 3 / 50%)
	    // Hence because the first three values are always consistent integers and the fourth is irrelevant, it is simpler to
	    // parse the first three integers and use them accordingly
	    static parseFirstThreeIntegersFromString(color) {
	        if (color.length < inputLimits_1.MAX_COLOR_INPUT_STRING_LENGTH) {
	            const regexResult = color.match(regex_1.MATCH_INTEGER_AND_FLOAT_NUMBERS);
	            regex_1.MATCH_INTEGER_AND_FLOAT_NUMBERS.lastIndex = 0;
	            if (regexResult && regexResult.length >= 3) {
	                return regexResult.slice(0, 3).map((numberString) => Number.parseInt(numberString));
	            }
	        }
	        return null;
	    }
	    static validateAndParseRgb(rgbString) {
	        const rgb = ColorParser.parseFirstThreeIntegersFromString(rgbString);
	        if (rgb && rgb[0] >= 0 && rgb[0] <= 255 && rgb[1] >= 0 && rgb[1] <= 255 && rgb[2] >= 0 && rgb[2] <= 255) {
	            return { color: rgb };
	        }
	        return { errorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.RGB, rgbString, colorFormats_1.ColorFormats.RGB) };
	    }
	    static validateAndParseHsl(hslString) {
	        const hsl = ColorParser.parseFirstThreeIntegersFromString(hslString);
	        if (hsl && hsl[0] >= 0 && hsl[0] <= 360 && hsl[1] >= 0 && hsl[1] <= 100 && hsl[2] >= 0 && hsl[2] <= 100) {
	            return { color: hsl };
	        }
	        return { errorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.HSL, hslString, colorFormats_1.ColorFormats.HSL) };
	    }
	    static validateAndParseKeyword(keyword) {
	        if (keyword.length < inputLimits_1.MAX_COLOR_INPUT_STRING_LENGTH) {
	            const isValid = color_name_1.default[keyword];
	            if (isValid)
	                return { color: keyword };
	        }
	        return { errorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.KEYWORD, keyword, colorFormats_1.ColorFormats.KEYWORD) };
	    }
	}
	colorParser.ColorParser = ColorParser;
	// There is a unique opportunity to validate the color input when this library operates in the browser
	// by creating a new element on the dom and adding the color to it to see if it is valid.
	// However it was decided not to use this approach as formats like hsl(1,2,3) are invalid in html elements.
	// Additionally, it can also be time consuming to create/find an element, adding color to it and validating
	// that color.
	return colorParser;
}

/* MIT license */

var conversions;
var hasRequiredConversions;

function requireConversions () {
	if (hasRequiredConversions) return conversions;
	hasRequiredConversions = 1;
	/* eslint-disable no-mixed-operators */
	const cssKeywords = requireColorName();

	// NOTE: conversions should only return primitive values (i.e. arrays, or
	//       values that give correct `typeof` results).
	//       do not use box values types (i.e. Number(), String(), etc.)

	const reverseKeywords = {};
	for (const key of Object.keys(cssKeywords)) {
		reverseKeywords[cssKeywords[key]] = key;
	}

	const convert = {
		rgb: {channels: 3, labels: 'rgb'},
		hsl: {channels: 3, labels: 'hsl'},
		hsv: {channels: 3, labels: 'hsv'},
		hwb: {channels: 3, labels: 'hwb'},
		cmyk: {channels: 4, labels: 'cmyk'},
		xyz: {channels: 3, labels: 'xyz'},
		lab: {channels: 3, labels: 'lab'},
		lch: {channels: 3, labels: 'lch'},
		hex: {channels: 1, labels: ['hex']},
		keyword: {channels: 1, labels: ['keyword']},
		ansi16: {channels: 1, labels: ['ansi16']},
		ansi256: {channels: 1, labels: ['ansi256']},
		hcg: {channels: 3, labels: ['h', 'c', 'g']},
		apple: {channels: 3, labels: ['r16', 'g16', 'b16']},
		gray: {channels: 1, labels: ['gray']}
	};

	conversions = convert;

	// Hide .channels and .labels properties
	for (const model of Object.keys(convert)) {
		if (!('channels' in convert[model])) {
			throw new Error('missing channels property: ' + model);
		}

		if (!('labels' in convert[model])) {
			throw new Error('missing channel labels property: ' + model);
		}

		if (convert[model].labels.length !== convert[model].channels) {
			throw new Error('channel and label counts mismatch: ' + model);
		}

		const {channels, labels} = convert[model];
		delete convert[model].channels;
		delete convert[model].labels;
		Object.defineProperty(convert[model], 'channels', {value: channels});
		Object.defineProperty(convert[model], 'labels', {value: labels});
	}

	convert.rgb.hsl = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const min = Math.min(r, g, b);
		const max = Math.max(r, g, b);
		const delta = max - min;
		let h;
		let s;

		if (max === min) {
			h = 0;
		} else if (r === max) {
			h = (g - b) / delta;
		} else if (g === max) {
			h = 2 + (b - r) / delta;
		} else if (b === max) {
			h = 4 + (r - g) / delta;
		}

		h = Math.min(h * 60, 360);

		if (h < 0) {
			h += 360;
		}

		const l = (min + max) / 2;

		if (max === min) {
			s = 0;
		} else if (l <= 0.5) {
			s = delta / (max + min);
		} else {
			s = delta / (2 - max - min);
		}

		return [h, s * 100, l * 100];
	};

	convert.rgb.hsv = function (rgb) {
		let rdif;
		let gdif;
		let bdif;
		let h;
		let s;

		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const v = Math.max(r, g, b);
		const diff = v - Math.min(r, g, b);
		const diffc = function (c) {
			return (v - c) / 6 / diff + 1 / 2;
		};

		if (diff === 0) {
			h = 0;
			s = 0;
		} else {
			s = diff / v;
			rdif = diffc(r);
			gdif = diffc(g);
			bdif = diffc(b);

			if (r === v) {
				h = bdif - gdif;
			} else if (g === v) {
				h = (1 / 3) + rdif - bdif;
			} else if (b === v) {
				h = (2 / 3) + gdif - rdif;
			}

			if (h < 0) {
				h += 1;
			} else if (h > 1) {
				h -= 1;
			}
		}

		return [
			h * 360,
			s * 100,
			v * 100
		];
	};

	convert.rgb.hwb = function (rgb) {
		const r = rgb[0];
		const g = rgb[1];
		let b = rgb[2];
		const h = convert.rgb.hsl(rgb)[0];
		const w = 1 / 255 * Math.min(r, Math.min(g, b));

		b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));

		return [h, w * 100, b * 100];
	};

	convert.rgb.cmyk = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;

		const k = Math.min(1 - r, 1 - g, 1 - b);
		const c = (1 - r - k) / (1 - k) || 0;
		const m = (1 - g - k) / (1 - k) || 0;
		const y = (1 - b - k) / (1 - k) || 0;

		return [c * 100, m * 100, y * 100, k * 100];
	};

	function comparativeDistance(x, y) {
		/*
			See https://en.m.wikipedia.org/wiki/Euclidean_distance#Squared_Euclidean_distance
		*/
		return (
			((x[0] - y[0]) ** 2) +
			((x[1] - y[1]) ** 2) +
			((x[2] - y[2]) ** 2)
		);
	}

	convert.rgb.keyword = function (rgb) {
		const reversed = reverseKeywords[rgb];
		if (reversed) {
			return reversed;
		}

		let currentClosestDistance = Infinity;
		let currentClosestKeyword;

		for (const keyword of Object.keys(cssKeywords)) {
			const value = cssKeywords[keyword];

			// Compute comparative distance
			const distance = comparativeDistance(rgb, value);

			// Check if its less, if so set as closest
			if (distance < currentClosestDistance) {
				currentClosestDistance = distance;
				currentClosestKeyword = keyword;
			}
		}

		return currentClosestKeyword;
	};

	convert.keyword.rgb = function (keyword) {
		return cssKeywords[keyword];
	};

	convert.rgb.xyz = function (rgb) {
		let r = rgb[0] / 255;
		let g = rgb[1] / 255;
		let b = rgb[2] / 255;

		// Assume sRGB
		r = r > 0.04045 ? (((r + 0.055) / 1.055) ** 2.4) : (r / 12.92);
		g = g > 0.04045 ? (((g + 0.055) / 1.055) ** 2.4) : (g / 12.92);
		b = b > 0.04045 ? (((b + 0.055) / 1.055) ** 2.4) : (b / 12.92);

		const x = (r * 0.4124) + (g * 0.3576) + (b * 0.1805);
		const y = (r * 0.2126) + (g * 0.7152) + (b * 0.0722);
		const z = (r * 0.0193) + (g * 0.1192) + (b * 0.9505);

		return [x * 100, y * 100, z * 100];
	};

	convert.rgb.lab = function (rgb) {
		const xyz = convert.rgb.xyz(rgb);
		let x = xyz[0];
		let y = xyz[1];
		let z = xyz[2];

		x /= 95.047;
		y /= 100;
		z /= 108.883;

		x = x > 0.008856 ? (x ** (1 / 3)) : (7.787 * x) + (16 / 116);
		y = y > 0.008856 ? (y ** (1 / 3)) : (7.787 * y) + (16 / 116);
		z = z > 0.008856 ? (z ** (1 / 3)) : (7.787 * z) + (16 / 116);

		const l = (116 * y) - 16;
		const a = 500 * (x - y);
		const b = 200 * (y - z);

		return [l, a, b];
	};

	convert.hsl.rgb = function (hsl) {
		const h = hsl[0] / 360;
		const s = hsl[1] / 100;
		const l = hsl[2] / 100;
		let t2;
		let t3;
		let val;

		if (s === 0) {
			val = l * 255;
			return [val, val, val];
		}

		if (l < 0.5) {
			t2 = l * (1 + s);
		} else {
			t2 = l + s - l * s;
		}

		const t1 = 2 * l - t2;

		const rgb = [0, 0, 0];
		for (let i = 0; i < 3; i++) {
			t3 = h + 1 / 3 * -(i - 1);
			if (t3 < 0) {
				t3++;
			}

			if (t3 > 1) {
				t3--;
			}

			if (6 * t3 < 1) {
				val = t1 + (t2 - t1) * 6 * t3;
			} else if (2 * t3 < 1) {
				val = t2;
			} else if (3 * t3 < 2) {
				val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
			} else {
				val = t1;
			}

			rgb[i] = val * 255;
		}

		return rgb;
	};

	convert.hsl.hsv = function (hsl) {
		const h = hsl[0];
		let s = hsl[1] / 100;
		let l = hsl[2] / 100;
		let smin = s;
		const lmin = Math.max(l, 0.01);

		l *= 2;
		s *= (l <= 1) ? l : 2 - l;
		smin *= lmin <= 1 ? lmin : 2 - lmin;
		const v = (l + s) / 2;
		const sv = l === 0 ? (2 * smin) / (lmin + smin) : (2 * s) / (l + s);

		return [h, sv * 100, v * 100];
	};

	convert.hsv.rgb = function (hsv) {
		const h = hsv[0] / 60;
		const s = hsv[1] / 100;
		let v = hsv[2] / 100;
		const hi = Math.floor(h) % 6;

		const f = h - Math.floor(h);
		const p = 255 * v * (1 - s);
		const q = 255 * v * (1 - (s * f));
		const t = 255 * v * (1 - (s * (1 - f)));
		v *= 255;

		switch (hi) {
			case 0:
				return [v, t, p];
			case 1:
				return [q, v, p];
			case 2:
				return [p, v, t];
			case 3:
				return [p, q, v];
			case 4:
				return [t, p, v];
			case 5:
				return [v, p, q];
		}
	};

	convert.hsv.hsl = function (hsv) {
		const h = hsv[0];
		const s = hsv[1] / 100;
		const v = hsv[2] / 100;
		const vmin = Math.max(v, 0.01);
		let sl;
		let l;

		l = (2 - s) * v;
		const lmin = (2 - s) * vmin;
		sl = s * vmin;
		sl /= (lmin <= 1) ? lmin : 2 - lmin;
		sl = sl || 0;
		l /= 2;

		return [h, sl * 100, l * 100];
	};

	// http://dev.w3.org/csswg/css-color/#hwb-to-rgb
	convert.hwb.rgb = function (hwb) {
		const h = hwb[0] / 360;
		let wh = hwb[1] / 100;
		let bl = hwb[2] / 100;
		const ratio = wh + bl;
		let f;

		// Wh + bl cant be > 1
		if (ratio > 1) {
			wh /= ratio;
			bl /= ratio;
		}

		const i = Math.floor(6 * h);
		const v = 1 - bl;
		f = 6 * h - i;

		if ((i & 0x01) !== 0) {
			f = 1 - f;
		}

		const n = wh + f * (v - wh); // Linear interpolation

		let r;
		let g;
		let b;
		/* eslint-disable max-statements-per-line,no-multi-spaces */
		switch (i) {
			default:
			case 6:
			case 0: r = v;  g = n;  b = wh; break;
			case 1: r = n;  g = v;  b = wh; break;
			case 2: r = wh; g = v;  b = n; break;
			case 3: r = wh; g = n;  b = v; break;
			case 4: r = n;  g = wh; b = v; break;
			case 5: r = v;  g = wh; b = n; break;
		}
		/* eslint-enable max-statements-per-line,no-multi-spaces */

		return [r * 255, g * 255, b * 255];
	};

	convert.cmyk.rgb = function (cmyk) {
		const c = cmyk[0] / 100;
		const m = cmyk[1] / 100;
		const y = cmyk[2] / 100;
		const k = cmyk[3] / 100;

		const r = 1 - Math.min(1, c * (1 - k) + k);
		const g = 1 - Math.min(1, m * (1 - k) + k);
		const b = 1 - Math.min(1, y * (1 - k) + k);

		return [r * 255, g * 255, b * 255];
	};

	convert.xyz.rgb = function (xyz) {
		const x = xyz[0] / 100;
		const y = xyz[1] / 100;
		const z = xyz[2] / 100;
		let r;
		let g;
		let b;

		r = (x * 3.2406) + (y * -1.5372) + (z * -0.4986);
		g = (x * -0.9689) + (y * 1.8758) + (z * 0.0415);
		b = (x * 0.0557) + (y * -0.204) + (z * 1.0570);

		// Assume sRGB
		r = r > 0.0031308
			? ((1.055 * (r ** (1.0 / 2.4))) - 0.055)
			: r * 12.92;

		g = g > 0.0031308
			? ((1.055 * (g ** (1.0 / 2.4))) - 0.055)
			: g * 12.92;

		b = b > 0.0031308
			? ((1.055 * (b ** (1.0 / 2.4))) - 0.055)
			: b * 12.92;

		r = Math.min(Math.max(0, r), 1);
		g = Math.min(Math.max(0, g), 1);
		b = Math.min(Math.max(0, b), 1);

		return [r * 255, g * 255, b * 255];
	};

	convert.xyz.lab = function (xyz) {
		let x = xyz[0];
		let y = xyz[1];
		let z = xyz[2];

		x /= 95.047;
		y /= 100;
		z /= 108.883;

		x = x > 0.008856 ? (x ** (1 / 3)) : (7.787 * x) + (16 / 116);
		y = y > 0.008856 ? (y ** (1 / 3)) : (7.787 * y) + (16 / 116);
		z = z > 0.008856 ? (z ** (1 / 3)) : (7.787 * z) + (16 / 116);

		const l = (116 * y) - 16;
		const a = 500 * (x - y);
		const b = 200 * (y - z);

		return [l, a, b];
	};

	convert.lab.xyz = function (lab) {
		const l = lab[0];
		const a = lab[1];
		const b = lab[2];
		let x;
		let y;
		let z;

		y = (l + 16) / 116;
		x = a / 500 + y;
		z = y - b / 200;

		const y2 = y ** 3;
		const x2 = x ** 3;
		const z2 = z ** 3;
		y = y2 > 0.008856 ? y2 : (y - 16 / 116) / 7.787;
		x = x2 > 0.008856 ? x2 : (x - 16 / 116) / 7.787;
		z = z2 > 0.008856 ? z2 : (z - 16 / 116) / 7.787;

		x *= 95.047;
		y *= 100;
		z *= 108.883;

		return [x, y, z];
	};

	convert.lab.lch = function (lab) {
		const l = lab[0];
		const a = lab[1];
		const b = lab[2];
		let h;

		const hr = Math.atan2(b, a);
		h = hr * 360 / 2 / Math.PI;

		if (h < 0) {
			h += 360;
		}

		const c = Math.sqrt(a * a + b * b);

		return [l, c, h];
	};

	convert.lch.lab = function (lch) {
		const l = lch[0];
		const c = lch[1];
		const h = lch[2];

		const hr = h / 360 * 2 * Math.PI;
		const a = c * Math.cos(hr);
		const b = c * Math.sin(hr);

		return [l, a, b];
	};

	convert.rgb.ansi16 = function (args, saturation = null) {
		const [r, g, b] = args;
		let value = saturation === null ? convert.rgb.hsv(args)[2] : saturation; // Hsv -> ansi16 optimization

		value = Math.round(value / 50);

		if (value === 0) {
			return 30;
		}

		let ansi = 30
			+ ((Math.round(b / 255) << 2)
			| (Math.round(g / 255) << 1)
			| Math.round(r / 255));

		if (value === 2) {
			ansi += 60;
		}

		return ansi;
	};

	convert.hsv.ansi16 = function (args) {
		// Optimization here; we already know the value and don't need to get
		// it converted for us.
		return convert.rgb.ansi16(convert.hsv.rgb(args), args[2]);
	};

	convert.rgb.ansi256 = function (args) {
		const r = args[0];
		const g = args[1];
		const b = args[2];

		// We use the extended greyscale palette here, with the exception of
		// black and white. normal palette only has 4 greyscale shades.
		if (r === g && g === b) {
			if (r < 8) {
				return 16;
			}

			if (r > 248) {
				return 231;
			}

			return Math.round(((r - 8) / 247) * 24) + 232;
		}

		const ansi = 16
			+ (36 * Math.round(r / 255 * 5))
			+ (6 * Math.round(g / 255 * 5))
			+ Math.round(b / 255 * 5);

		return ansi;
	};

	convert.ansi16.rgb = function (args) {
		let color = args % 10;

		// Handle greyscale
		if (color === 0 || color === 7) {
			if (args > 50) {
				color += 3.5;
			}

			color = color / 10.5 * 255;

			return [color, color, color];
		}

		const mult = (~~(args > 50) + 1) * 0.5;
		const r = ((color & 1) * mult) * 255;
		const g = (((color >> 1) & 1) * mult) * 255;
		const b = (((color >> 2) & 1) * mult) * 255;

		return [r, g, b];
	};

	convert.ansi256.rgb = function (args) {
		// Handle greyscale
		if (args >= 232) {
			const c = (args - 232) * 10 + 8;
			return [c, c, c];
		}

		args -= 16;

		let rem;
		const r = Math.floor(args / 36) / 5 * 255;
		const g = Math.floor((rem = args % 36) / 6) / 5 * 255;
		const b = (rem % 6) / 5 * 255;

		return [r, g, b];
	};

	convert.rgb.hex = function (args) {
		const integer = ((Math.round(args[0]) & 0xFF) << 16)
			+ ((Math.round(args[1]) & 0xFF) << 8)
			+ (Math.round(args[2]) & 0xFF);

		const string = integer.toString(16).toUpperCase();
		return '000000'.substring(string.length) + string;
	};

	convert.hex.rgb = function (args) {
		const match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
		if (!match) {
			return [0, 0, 0];
		}

		let colorString = match[0];

		if (match[0].length === 3) {
			colorString = colorString.split('').map(char => {
				return char + char;
			}).join('');
		}

		const integer = parseInt(colorString, 16);
		const r = (integer >> 16) & 0xFF;
		const g = (integer >> 8) & 0xFF;
		const b = integer & 0xFF;

		return [r, g, b];
	};

	convert.rgb.hcg = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const max = Math.max(Math.max(r, g), b);
		const min = Math.min(Math.min(r, g), b);
		const chroma = (max - min);
		let grayscale;
		let hue;

		if (chroma < 1) {
			grayscale = min / (1 - chroma);
		} else {
			grayscale = 0;
		}

		if (chroma <= 0) {
			hue = 0;
		} else
		if (max === r) {
			hue = ((g - b) / chroma) % 6;
		} else
		if (max === g) {
			hue = 2 + (b - r) / chroma;
		} else {
			hue = 4 + (r - g) / chroma;
		}

		hue /= 6;
		hue %= 1;

		return [hue * 360, chroma * 100, grayscale * 100];
	};

	convert.hsl.hcg = function (hsl) {
		const s = hsl[1] / 100;
		const l = hsl[2] / 100;

		const c = l < 0.5 ? (2.0 * s * l) : (2.0 * s * (1.0 - l));

		let f = 0;
		if (c < 1.0) {
			f = (l - 0.5 * c) / (1.0 - c);
		}

		return [hsl[0], c * 100, f * 100];
	};

	convert.hsv.hcg = function (hsv) {
		const s = hsv[1] / 100;
		const v = hsv[2] / 100;

		const c = s * v;
		let f = 0;

		if (c < 1.0) {
			f = (v - c) / (1 - c);
		}

		return [hsv[0], c * 100, f * 100];
	};

	convert.hcg.rgb = function (hcg) {
		const h = hcg[0] / 360;
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		if (c === 0.0) {
			return [g * 255, g * 255, g * 255];
		}

		const pure = [0, 0, 0];
		const hi = (h % 1) * 6;
		const v = hi % 1;
		const w = 1 - v;
		let mg = 0;

		/* eslint-disable max-statements-per-line */
		switch (Math.floor(hi)) {
			case 0:
				pure[0] = 1; pure[1] = v; pure[2] = 0; break;
			case 1:
				pure[0] = w; pure[1] = 1; pure[2] = 0; break;
			case 2:
				pure[0] = 0; pure[1] = 1; pure[2] = v; break;
			case 3:
				pure[0] = 0; pure[1] = w; pure[2] = 1; break;
			case 4:
				pure[0] = v; pure[1] = 0; pure[2] = 1; break;
			default:
				pure[0] = 1; pure[1] = 0; pure[2] = w;
		}
		/* eslint-enable max-statements-per-line */

		mg = (1.0 - c) * g;

		return [
			(c * pure[0] + mg) * 255,
			(c * pure[1] + mg) * 255,
			(c * pure[2] + mg) * 255
		];
	};

	convert.hcg.hsv = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		const v = c + g * (1.0 - c);
		let f = 0;

		if (v > 0.0) {
			f = c / v;
		}

		return [hcg[0], f * 100, v * 100];
	};

	convert.hcg.hsl = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		const l = g * (1.0 - c) + 0.5 * c;
		let s = 0;

		if (l > 0.0 && l < 0.5) {
			s = c / (2 * l);
		} else
		if (l >= 0.5 && l < 1.0) {
			s = c / (2 * (1 - l));
		}

		return [hcg[0], s * 100, l * 100];
	};

	convert.hcg.hwb = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;
		const v = c + g * (1.0 - c);
		return [hcg[0], (v - c) * 100, (1 - v) * 100];
	};

	convert.hwb.hcg = function (hwb) {
		const w = hwb[1] / 100;
		const b = hwb[2] / 100;
		const v = 1 - b;
		const c = v - w;
		let g = 0;

		if (c < 1) {
			g = (v - c) / (1 - c);
		}

		return [hwb[0], c * 100, g * 100];
	};

	convert.apple.rgb = function (apple) {
		return [(apple[0] / 65535) * 255, (apple[1] / 65535) * 255, (apple[2] / 65535) * 255];
	};

	convert.rgb.apple = function (rgb) {
		return [(rgb[0] / 255) * 65535, (rgb[1] / 255) * 65535, (rgb[2] / 255) * 65535];
	};

	convert.gray.rgb = function (args) {
		return [args[0] / 100 * 255, args[0] / 100 * 255, args[0] / 100 * 255];
	};

	convert.gray.hsl = function (args) {
		return [0, 0, args[0]];
	};

	convert.gray.hsv = convert.gray.hsl;

	convert.gray.hwb = function (gray) {
		return [0, 100, gray[0]];
	};

	convert.gray.cmyk = function (gray) {
		return [0, 0, 0, gray[0]];
	};

	convert.gray.lab = function (gray) {
		return [gray[0], 0, 0];
	};

	convert.gray.hex = function (gray) {
		const val = Math.round(gray[0] / 100 * 255) & 0xFF;
		const integer = (val << 16) + (val << 8) + val;

		const string = integer.toString(16).toUpperCase();
		return '000000'.substring(string.length) + string;
	};

	convert.rgb.gray = function (rgb) {
		const val = (rgb[0] + rgb[1] + rgb[2]) / 3;
		return [val / 255 * 100];
	};
	return conversions;
}

var route;
var hasRequiredRoute;

function requireRoute () {
	if (hasRequiredRoute) return route;
	hasRequiredRoute = 1;
	const conversions = requireConversions();

	/*
		This function routes a model to all other models.

		all functions that are routed have a property `.conversion` attached
		to the returned synthetic function. This property is an array
		of strings, each with the steps in between the 'from' and 'to'
		color models (inclusive).

		conversions that are not possible simply are not included.
	*/

	function buildGraph() {
		const graph = {};
		// https://jsperf.com/object-keys-vs-for-in-with-closure/3
		const models = Object.keys(conversions);

		for (let len = models.length, i = 0; i < len; i++) {
			graph[models[i]] = {
				// http://jsperf.com/1-vs-infinity
				// micro-opt, but this is simple.
				distance: -1,
				parent: null
			};
		}

		return graph;
	}

	// https://en.wikipedia.org/wiki/Breadth-first_search
	function deriveBFS(fromModel) {
		const graph = buildGraph();
		const queue = [fromModel]; // Unshift -> queue -> pop

		graph[fromModel].distance = 0;

		while (queue.length) {
			const current = queue.pop();
			const adjacents = Object.keys(conversions[current]);

			for (let len = adjacents.length, i = 0; i < len; i++) {
				const adjacent = adjacents[i];
				const node = graph[adjacent];

				if (node.distance === -1) {
					node.distance = graph[current].distance + 1;
					node.parent = current;
					queue.unshift(adjacent);
				}
			}
		}

		return graph;
	}

	function link(from, to) {
		return function (args) {
			return to(from(args));
		};
	}

	function wrapConversion(toModel, graph) {
		const path = [graph[toModel].parent, toModel];
		let fn = conversions[graph[toModel].parent][toModel];

		let cur = graph[toModel].parent;
		while (graph[cur].parent) {
			path.unshift(graph[cur].parent);
			fn = link(conversions[graph[cur].parent][cur], fn);
			cur = graph[cur].parent;
		}

		fn.conversion = path;
		return fn;
	}

	route = function (fromModel) {
		const graph = deriveBFS(fromModel);
		const conversion = {};

		const models = Object.keys(graph);
		for (let len = models.length, i = 0; i < len; i++) {
			const toModel = models[i];
			const node = graph[toModel];

			if (node.parent === null) {
				// No possible conversion, or this node is the source model.
				continue;
			}

			conversion[toModel] = wrapConversion(toModel, graph);
		}

		return conversion;
	};
	return route;
}

var colorConvert;
var hasRequiredColorConvert;

function requireColorConvert () {
	if (hasRequiredColorConvert) return colorConvert;
	hasRequiredColorConvert = 1;
	const conversions = requireConversions();
	const route = requireRoute();

	const convert = {};

	const models = Object.keys(conversions);

	function wrapRaw(fn) {
		const wrappedFn = function (...args) {
			const arg0 = args[0];
			if (arg0 === undefined || arg0 === null) {
				return arg0;
			}

			if (arg0.length > 1) {
				args = arg0;
			}

			return fn(args);
		};

		// Preserve .conversion property if there is one
		if ('conversion' in fn) {
			wrappedFn.conversion = fn.conversion;
		}

		return wrappedFn;
	}

	function wrapRounded(fn) {
		const wrappedFn = function (...args) {
			const arg0 = args[0];

			if (arg0 === undefined || arg0 === null) {
				return arg0;
			}

			if (arg0.length > 1) {
				args = arg0;
			}

			const result = fn(args);

			// We're assuming the result is an array here.
			// see notice in conversions.js; don't use box types
			// in conversion functions.
			if (typeof result === 'object') {
				for (let len = result.length, i = 0; i < len; i++) {
					result[i] = Math.round(result[i]);
				}
			}

			return result;
		};

		// Preserve .conversion property if there is one
		if ('conversion' in fn) {
			wrappedFn.conversion = fn.conversion;
		}

		return wrappedFn;
	}

	models.forEach(fromModel => {
		convert[fromModel] = {};

		Object.defineProperty(convert[fromModel], 'channels', {value: conversions[fromModel].channels});
		Object.defineProperty(convert[fromModel], 'labels', {value: conversions[fromModel].labels});

		const routes = route(fromModel);
		const routeModels = Object.keys(routes);

		routeModels.forEach(toModel => {
			const fn = routes[toModel];

			convert[fromModel][toModel] = wrapRounded(fn);
			convert[fromModel][toModel].raw = wrapRaw(fn);
		});
	});

	colorConvert = convert;
	return colorConvert;
}

var hasRequiredColorToFilter;

function requireColorToFilter () {
	if (hasRequiredColorToFilter) return colorToFilter;
	hasRequiredColorToFilter = 1;
	var __importDefault = (colorToFilter && colorToFilter.__importDefault) || function (mod) {
	    return (mod && mod.__esModule) ? mod : { "default": mod };
	};
	Object.defineProperty(colorToFilter, "__esModule", { value: true });
	colorToFilter.ColorToFilter = void 0;
	const errorHandling_1 = requireErrorHandling();
	const sheenUtil_1 = requireSheenUtil();
	const colorTypes_1 = requireColorTypes();
	const rgbToFilter_1 = requireRgbToFilter();
	const colorParser_1 = requireColorParser();
	const color_convert_1 = __importDefault(requireColorConvert());
	class ColorToFilter {
	    static rgbToFilter(rgbString, options) {
	        return rgbToFilter_1.RgbToFilter.convert({
	            colorString: rgbString,
	            validateAndParse: colorParser_1.ColorParser.validateAndParseRgb,
	            addSheen: sheenUtil_1.SheenUtil.parseSheenFromOptions(options),
	        });
	    }
	    static hexToFilter(hexString, options) {
	        return rgbToFilter_1.RgbToFilter.convert({
	            colorString: hexString,
	            validateAndParse: colorParser_1.ColorParser.validateAndParseHex,
	            convertToRgb: color_convert_1.default.hex.rgb,
	            addSheen: sheenUtil_1.SheenUtil.parseSheenFromOptions(options),
	        });
	    }
	    static hslToFilter(hslString, options) {
	        return rgbToFilter_1.RgbToFilter.convert({
	            colorString: hslString,
	            validateAndParse: colorParser_1.ColorParser.validateAndParseHsl,
	            convertToRgb: color_convert_1.default.hsl.rgb,
	            addSheen: sheenUtil_1.SheenUtil.parseSheenFromOptions(options),
	        });
	    }
	    static keywordToFilter(keyword, options) {
	        return rgbToFilter_1.RgbToFilter.convert({
	            colorString: keyword,
	            validateAndParse: colorParser_1.ColorParser.validateAndParseKeyword,
	            convertToRgb: color_convert_1.default.keyword.rgb,
	            conversionErrorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.KEYWORD, keyword),
	            addSheen: sheenUtil_1.SheenUtil.parseSheenFromOptions(options),
	        });
	    }
	}
	colorToFilter.ColorToFilter = ColorToFilter;
	return colorToFilter;
}

var filterToColor = {};

var filterToHex = {};

var browser = {};

var shared = {};

var hasRequiredShared;

function requireShared () {
	if (hasRequiredShared) return shared;
	hasRequiredShared = 1;
	Object.defineProperty(shared, "__esModule", { value: true });
	shared.FilterToHexShared = void 0;
	const errorHandling_1 = requireErrorHandling();
	const colorFormats_1 = requireColorFormats();
	const colorTypes_1 = requireColorTypes();
	class FilterToHexShared {
	    static generateInputErrorMessage(filterString) {
	        return errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.FILTER, filterString, colorFormats_1.ColorFormats.FILTER);
	    }
	    // functions are encapsulated within a single method in order to allow them to be executed within the same context
	    // of the puppeteer evaluate method
	    static addSVGElementsToDOMAndValidateFilter(filterString, svgSideLength = 1) {
	        function createSVGElement() {
	            const xmlns = 'http://www.w3.org/2000/svg';
	            const svgElement = document.createElementNS(xmlns, 'svg');
	            svgElement.style.height = 'inherit';
	            svgElement.style.width = 'inherit';
	            svgElement.style.float = 'left';
	            svgElement.style.filter = filterString;
	            const rect = document.createElementNS(xmlns, 'rect');
	            rect.setAttributeNS(null, 'width', svgSideLength.toString());
	            rect.setAttributeNS(null, 'height', svgSideLength.toString());
	            svgElement.appendChild(rect);
	            return svgElement;
	        }
	        function createSVGContainerElement() {
	            const svgContainerElement = document.createElement('div');
	            svgContainerElement.style.height = `${svgSideLength}px`;
	            svgContainerElement.style.width = `${svgSideLength}px`;
	            svgContainerElement.style.position = 'absolute';
	            svgContainerElement.style.top = '0px';
	            svgContainerElement.style.left = '0px';
	            return svgContainerElement;
	        }
	        const svgContainerElement = createSVGContainerElement();
	        const svgElement = createSVGElement();
	        if (svgElement.style.filter === '')
	            return { errorMessage: 'error indicator', svgContainerElement };
	        svgContainerElement.appendChild(svgElement);
	        document.body.appendChild(svgContainerElement);
	        return { svgContainerElement };
	    }
	    // functions are encapsulated within a single method in order to allow them to be executed within the same context
	    // of the puppeteer evaluate method
	    static async getColorViaImageDataURL(base64EncodedDataURL) {
	        function rgbToHex(r, g, b) {
	            if (r > 255 || g > 255 || b > 255)
	                throw new Error('Invalid color component');
	            return ((r << 16) | (g << 8) | b).toString(16);
	        }
	        function getData(canvasElement) {
	            const canvasStartCoordinate = 0;
	            const canvasFinalCoordinate = canvasElement.width;
	            return canvasElement.getContext('2d').getImageData(canvasStartCoordinate, canvasStartCoordinate, canvasFinalCoordinate, canvasFinalCoordinate).data;
	        }
	        function getCanvasHexColor(canvasElement) {
	            const data = getData(canvasElement);
	            const hex = rgbToHex(data[0], data[1], data[2]);
	            return `#${`000000${hex}`.slice(-6)}`;
	        }
	        function createCanvasElement(imageElement) {
	            const canvasElement = document.createElement('canvas');
	            canvasElement.width = imageElement.width;
	            canvasElement.height = imageElement.height;
	            canvasElement.getContext('2d').drawImage(imageElement, 0, 0, imageElement.width, imageElement.height);
	            return canvasElement;
	        }
	        async function createImage() {
	            // the load event must be awaited as some browsers (Firefox) report 0 width/height until the data URL
	            // is decoded, which would create a 0-sized canvas and cause getImageData to throw an IndexSizeError
	            const imageElement = new Image();
	            return new Promise((resolve, reject) => {
	                imageElement.onload = () => resolve(imageElement);
	                imageElement.onerror = () => reject(new Error('Failed to load the SVG image data URL'));
	                imageElement.src = base64EncodedDataURL;
	            });
	        }
	        const imageElement = await createImage();
	        const canvasElement = createCanvasElement(imageElement);
	        return getCanvasHexColor(canvasElement);
	    }
	}
	shared.FilterToHexShared = FilterToHexShared;
	return shared;
}

var domToImage = {exports: {}};

var hasRequiredDomToImage;

function requireDomToImage () {
	if (hasRequiredDomToImage) return domToImage.exports;
	hasRequiredDomToImage = 1;
	(function (module) {
		(function (global) {

		    var util = newUtil();
		    var inliner = newInliner();
		    var fontFaces = newFontFaces();
		    var images = newImages();

		    // Default impl options
		    var defaultOptions = {
		        // Default is to fail on error, no placeholder
		        imagePlaceholder: undefined,
		        // Default cache bust is false, it will use the cache
		        cacheBust: false
		    };

		    var domtoimage = {
		        toSvg: toSvg,
		        toPng: toPng,
		        toJpeg: toJpeg,
		        toBlob: toBlob,
		        toPixelData: toPixelData,
		        impl: {
		            fontFaces: fontFaces,
		            images: images,
		            util: util,
		            inliner: inliner,
		            options: {}
		        }
		    };

		    module.exports = domtoimage;


		    /**
		     * @param {Node} node - The DOM Node object to render
		     * @param {Object} options - Rendering options
		     * @param {Function} options.filter - Should return true if passed node should be included in the output
		     *          (excluding node means excluding it's children as well). Not called on the root node.
		     * @param {String} options.bgcolor - color for the background, any valid CSS color value.
		     * @param {Number} options.width - width to be applied to node before rendering.
		     * @param {Number} options.height - height to be applied to node before rendering.
		     * @param {Object} options.style - an object whose properties to be copied to node's style before rendering.
		     * @param {Number} options.quality - a Number between 0 and 1 indicating image quality (applicable to JPEG only),
		                defaults to 1.0.
		     * @param {String} options.imagePlaceholder - dataURL to use as a placeholder for failed images, default behaviour is to fail fast on images we can't fetch
		     * @param {Boolean} options.cacheBust - set to true to cache bust by appending the time to the request url
		     * @return {Promise} - A promise that is fulfilled with a SVG image data URL
		     * */
		    function toSvg(node, options) {
		        options = options || {};
		        copyOptions(options);
		        return Promise.resolve(node)
		            .then(function (node) {
		                return cloneNode(node, options.filter, true);
		            })
		            .then(embedFonts)
		            .then(inlineImages)
		            .then(applyOptions)
		            .then(function (clone) {
		                return makeSvgDataUri(clone,
		                    options.width || util.width(node),
		                    options.height || util.height(node)
		                );
		            });

		        function applyOptions(clone) {
		            if (options.bgcolor) clone.style.backgroundColor = options.bgcolor;

		            if (options.width) clone.style.width = options.width + 'px';
		            if (options.height) clone.style.height = options.height + 'px';

		            if (options.style)
		                Object.keys(options.style).forEach(function (property) {
		                    clone.style[property] = options.style[property];
		                });

		            return clone;
		        }
		    }

		    /**
		     * @param {Node} node - The DOM Node object to render
		     * @param {Object} options - Rendering options, @see {@link toSvg}
		     * @return {Promise} - A promise that is fulfilled with a Uint8Array containing RGBA pixel data.
		     * */
		    function toPixelData(node, options) {
		        return draw(node, options || {})
		            .then(function (canvas) {
		                return canvas.getContext('2d').getImageData(
		                    0,
		                    0,
		                    util.width(node),
		                    util.height(node)
		                ).data;
		            });
		    }

		    /**
		     * @param {Node} node - The DOM Node object to render
		     * @param {Object} options - Rendering options, @see {@link toSvg}
		     * @return {Promise} - A promise that is fulfilled with a PNG image data URL
		     * */
		    function toPng(node, options) {
		        return draw(node, options || {})
		            .then(function (canvas) {
		                return canvas.toDataURL();
		            });
		    }

		    /**
		     * @param {Node} node - The DOM Node object to render
		     * @param {Object} options - Rendering options, @see {@link toSvg}
		     * @return {Promise} - A promise that is fulfilled with a JPEG image data URL
		     * */
		    function toJpeg(node, options) {
		        options = options || {};
		        return draw(node, options)
		            .then(function (canvas) {
		                return canvas.toDataURL('image/jpeg', options.quality || 1.0);
		            });
		    }

		    /**
		     * @param {Node} node - The DOM Node object to render
		     * @param {Object} options - Rendering options, @see {@link toSvg}
		     * @return {Promise} - A promise that is fulfilled with a PNG image blob
		     * */
		    function toBlob(node, options) {
		        return draw(node, options || {})
		            .then(util.canvasToBlob);
		    }

		    function copyOptions(options) {
		        // Copy options to impl options for use in impl
		        if(typeof(options.imagePlaceholder) === 'undefined') {
		            domtoimage.impl.options.imagePlaceholder = defaultOptions.imagePlaceholder;
		        } else {
		            domtoimage.impl.options.imagePlaceholder = options.imagePlaceholder;
		        }

		        if(typeof(options.cacheBust) === 'undefined') {
		            domtoimage.impl.options.cacheBust = defaultOptions.cacheBust;
		        } else {
		            domtoimage.impl.options.cacheBust = options.cacheBust;
		        }
		    }

		    function draw(domNode, options) {
		        return toSvg(domNode, options)
		            .then(util.makeImage)
		            .then(util.delay(100))
		            .then(function (image) {
		                var canvas = newCanvas(domNode);
		                canvas.getContext('2d').drawImage(image, 0, 0);
		                return canvas;
		            });

		        function newCanvas(domNode) {
		            var canvas = document.createElement('canvas');
		            canvas.width = options.width || util.width(domNode);
		            canvas.height = options.height || util.height(domNode);

		            if (options.bgcolor) {
		                var ctx = canvas.getContext('2d');
		                ctx.fillStyle = options.bgcolor;
		                ctx.fillRect(0, 0, canvas.width, canvas.height);
		            }

		            return canvas;
		        }
		    }

		    function cloneNode(node, filter, root) {
		        if (!root && filter && !filter(node)) return Promise.resolve();

		        return Promise.resolve(node)
		            .then(makeNodeCopy)
		            .then(function (clone) {
		                return cloneChildren(node, clone, filter);
		            })
		            .then(function (clone) {
		                return processClone(node, clone);
		            });

		        function makeNodeCopy(node) {
		            if (node instanceof HTMLCanvasElement) return util.makeImage(node.toDataURL());
		            return node.cloneNode(false);
		        }

		        function cloneChildren(original, clone, filter) {
		            var children = original.childNodes;
		            if (children.length === 0) return Promise.resolve(clone);

		            return cloneChildrenInOrder(clone, util.asArray(children), filter)
		                .then(function () {
		                    return clone;
		                });

		            function cloneChildrenInOrder(parent, children, filter) {
		                var done = Promise.resolve();
		                children.forEach(function (child) {
		                    done = done
		                        .then(function () {
		                            return cloneNode(child, filter);
		                        })
		                        .then(function (childClone) {
		                            if (childClone) parent.appendChild(childClone);
		                        });
		                });
		                return done;
		            }
		        }

		        function processClone(original, clone) {
		            if (!(clone instanceof Element)) return clone;

		            return Promise.resolve()
		                .then(cloneStyle)
		                .then(clonePseudoElements)
		                .then(copyUserInput)
		                .then(fixSvg)
		                .then(function () {
		                    return clone;
		                });

		            function cloneStyle() {
		                copyStyle(window.getComputedStyle(original), clone.style);

		                function copyStyle(source, target) {
		                    if (source.cssText) target.cssText = source.cssText;
		                    else copyProperties(source, target);

		                    function copyProperties(source, target) {
		                        util.asArray(source).forEach(function (name) {
		                            target.setProperty(
		                                name,
		                                source.getPropertyValue(name),
		                                source.getPropertyPriority(name)
		                            );
		                        });
		                    }
		                }
		            }

		            function clonePseudoElements() {
		                [':before', ':after'].forEach(function (element) {
		                    clonePseudoElement(element);
		                });

		                function clonePseudoElement(element) {
		                    var style = window.getComputedStyle(original, element);
		                    var content = style.getPropertyValue('content');

		                    if (content === '' || content === 'none') return;

		                    var className = util.uid();
		                    clone.className = clone.className + ' ' + className;
		                    var styleElement = document.createElement('style');
		                    styleElement.appendChild(formatPseudoElementStyle(className, element, style));
		                    clone.appendChild(styleElement);

		                    function formatPseudoElementStyle(className, element, style) {
		                        var selector = '.' + className + ':' + element;
		                        var cssText = style.cssText ? formatCssText(style) : formatCssProperties(style);
		                        return document.createTextNode(selector + '{' + cssText + '}');

		                        function formatCssText(style) {
		                            var content = style.getPropertyValue('content');
		                            return style.cssText + ' content: ' + content + ';';
		                        }

		                        function formatCssProperties(style) {

		                            return util.asArray(style)
		                                .map(formatProperty)
		                                .join('; ') + ';';

		                            function formatProperty(name) {
		                                return name + ': ' +
		                                    style.getPropertyValue(name) +
		                                    (style.getPropertyPriority(name) ? ' !important' : '');
		                            }
		                        }
		                    }
		                }
		            }

		            function copyUserInput() {
		                if (original instanceof HTMLTextAreaElement) clone.innerHTML = original.value;
		                if (original instanceof HTMLInputElement) clone.setAttribute("value", original.value);
		            }

		            function fixSvg() {
		                if (!(clone instanceof SVGElement)) return;
		                clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

		                if (!(clone instanceof SVGRectElement)) return;
		                ['width', 'height'].forEach(function (attribute) {
		                    var value = clone.getAttribute(attribute);
		                    if (!value) return;

		                    clone.style.setProperty(attribute, value);
		                });
		            }
		        }
		    }

		    function embedFonts(node) {
		        return fontFaces.resolveAll()
		            .then(function (cssText) {
		                var styleNode = document.createElement('style');
		                node.appendChild(styleNode);
		                styleNode.appendChild(document.createTextNode(cssText));
		                return node;
		            });
		    }

		    function inlineImages(node) {
		        return images.inlineAll(node)
		            .then(function () {
		                return node;
		            });
		    }

		    function makeSvgDataUri(node, width, height) {
		        return Promise.resolve(node)
		            .then(function (node) {
		                node.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
		                return new XMLSerializer().serializeToString(node);
		            })
		            .then(util.escapeXhtml)
		            .then(function (xhtml) {
		                return '<foreignObject x="0" y="0" width="100%" height="100%">' + xhtml + '</foreignObject>';
		            })
		            .then(function (foreignObject) {
		                return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' +
		                    foreignObject + '</svg>';
		            })
		            .then(function (svg) {
		                return 'data:image/svg+xml;charset=utf-8,' + svg;
		            });
		    }

		    function newUtil() {
		        return {
		            escape: escape,
		            parseExtension: parseExtension,
		            mimeType: mimeType,
		            dataAsUrl: dataAsUrl,
		            isDataUrl: isDataUrl,
		            canvasToBlob: canvasToBlob,
		            resolveUrl: resolveUrl,
		            getAndEncode: getAndEncode,
		            uid: uid(),
		            delay: delay,
		            asArray: asArray,
		            escapeXhtml: escapeXhtml,
		            makeImage: makeImage,
		            width: width,
		            height: height
		        };

		        function mimes() {
		            /*
		             * Only WOFF and EOT mime types for fonts are 'real'
		             * see http://www.iana.org/assignments/media-types/media-types.xhtml
		             */
		            var WOFF = 'application/font-woff';
		            var JPEG = 'image/jpeg';

		            return {
		                'woff': WOFF,
		                'woff2': WOFF,
		                'ttf': 'application/font-truetype',
		                'eot': 'application/vnd.ms-fontobject',
		                'png': 'image/png',
		                'jpg': JPEG,
		                'jpeg': JPEG,
		                'gif': 'image/gif',
		                'tiff': 'image/tiff',
		                'svg': 'image/svg+xml'
		            };
		        }

		        function parseExtension(url) {
		            var match = /\.([^\.\/]*?)$/g.exec(url);
		            if (match) return match[1];
		            else return '';
		        }

		        function mimeType(url) {
		            var extension = parseExtension(url).toLowerCase();
		            return mimes()[extension] || '';
		        }

		        function isDataUrl(url) {
		            return url.search(/^(data:)/) !== -1;
		        }

		        function toBlob(canvas) {
		            return new Promise(function (resolve) {
		                var binaryString = window.atob(canvas.toDataURL().split(',')[1]);
		                var length = binaryString.length;
		                var binaryArray = new Uint8Array(length);

		                for (var i = 0; i < length; i++)
		                    binaryArray[i] = binaryString.charCodeAt(i);

		                resolve(new Blob([binaryArray], {
		                    type: 'image/png'
		                }));
		            });
		        }

		        function canvasToBlob(canvas) {
		            if (canvas.toBlob)
		                return new Promise(function (resolve) {
		                    canvas.toBlob(resolve);
		                });

		            return toBlob(canvas);
		        }

		        function resolveUrl(url, baseUrl) {
		            var doc = document.implementation.createHTMLDocument();
		            var base = doc.createElement('base');
		            doc.head.appendChild(base);
		            var a = doc.createElement('a');
		            doc.body.appendChild(a);
		            base.href = baseUrl;
		            a.href = url;
		            return a.href;
		        }

		        function uid() {
		            var index = 0;

		            return function () {
		                return 'u' + fourRandomChars() + index++;

		                function fourRandomChars() {
		                    /* see http://stackoverflow.com/a/6248722/2519373 */
		                    return ('0000' + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
		                }
		            };
		        }

		        function makeImage(uri) {
		            return new Promise(function (resolve, reject) {
		                var image = new Image();
		                image.onload = function () {
		                    resolve(image);
		                };
		                image.onerror = reject;
		                image.src = uri;
		            });
		        }

		        function getAndEncode(url) {
		            var TIMEOUT = 30000;
		            if(domtoimage.impl.options.cacheBust) {
		                // Cache bypass so we dont have CORS issues with cached images
		                // Source: https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
		                url += ((/\?/).test(url) ? "&" : "?") + (new Date()).getTime();
		            }

		            return new Promise(function (resolve) {
		                var request = new XMLHttpRequest();

		                request.onreadystatechange = done;
		                request.ontimeout = timeout;
		                request.responseType = 'blob';
		                request.timeout = TIMEOUT;
		                request.open('GET', url, true);
		                request.send();

		                var placeholder;
		                if(domtoimage.impl.options.imagePlaceholder) {
		                    var split = domtoimage.impl.options.imagePlaceholder.split(/,/);
		                    if(split && split[1]) {
		                        placeholder = split[1];
		                    }
		                }

		                function done() {
		                    if (request.readyState !== 4) return;

		                    if (request.status !== 200) {
		                        if(placeholder) {
		                            resolve(placeholder);
		                        } else {
		                            fail('cannot fetch resource: ' + url + ', status: ' + request.status);
		                        }

		                        return;
		                    }

		                    var encoder = new FileReader();
		                    encoder.onloadend = function () {
		                        var content = encoder.result.split(/,/)[1];
		                        resolve(content);
		                    };
		                    encoder.readAsDataURL(request.response);
		                }

		                function timeout() {
		                    if(placeholder) {
		                        resolve(placeholder);
		                    } else {
		                        fail('timeout of ' + TIMEOUT + 'ms occured while fetching resource: ' + url);
		                    }
		                }

		                function fail(message) {
		                    console.error(message);
		                    resolve('');
		                }
		            });
		        }

		        function dataAsUrl(content, type) {
		            return 'data:' + type + ';base64,' + content;
		        }

		        function escape(string) {
		            return string.replace(/([.*+?^${}()|\[\]\/\\])/g, '\\$1');
		        }

		        function delay(ms) {
		            return function (arg) {
		                return new Promise(function (resolve) {
		                    setTimeout(function () {
		                        resolve(arg);
		                    }, ms);
		                });
		            };
		        }

		        function asArray(arrayLike) {
		            var array = [];
		            var length = arrayLike.length;
		            for (var i = 0; i < length; i++) array.push(arrayLike[i]);
		            return array;
		        }

		        function escapeXhtml(string) {
		            return string.replace(/#/g, '%23').replace(/\n/g, '%0A');
		        }

		        function width(node) {
		            var leftBorder = px(node, 'border-left-width');
		            var rightBorder = px(node, 'border-right-width');
		            return node.scrollWidth + leftBorder + rightBorder;
		        }

		        function height(node) {
		            var topBorder = px(node, 'border-top-width');
		            var bottomBorder = px(node, 'border-bottom-width');
		            return node.scrollHeight + topBorder + bottomBorder;
		        }

		        function px(node, styleProperty) {
		            var value = window.getComputedStyle(node).getPropertyValue(styleProperty);
		            return parseFloat(value.replace('px', ''));
		        }
		    }

		    function newInliner() {
		        var URL_REGEX = /url\(['"]?([^'"]+?)['"]?\)/g;

		        return {
		            inlineAll: inlineAll,
		            shouldProcess: shouldProcess,
		            impl: {
		                readUrls: readUrls,
		                inline: inline
		            }
		        };

		        function shouldProcess(string) {
		            return string.search(URL_REGEX) !== -1;
		        }

		        function readUrls(string) {
		            var result = [];
		            var match;
		            while ((match = URL_REGEX.exec(string)) !== null) {
		                result.push(match[1]);
		            }
		            return result.filter(function (url) {
		                return !util.isDataUrl(url);
		            });
		        }

		        function inline(string, url, baseUrl, get) {
		            return Promise.resolve(url)
		                .then(function (url) {
		                    return baseUrl ? util.resolveUrl(url, baseUrl) : url;
		                })
		                .then(get || util.getAndEncode)
		                .then(function (data) {
		                    return util.dataAsUrl(data, util.mimeType(url));
		                })
		                .then(function (dataUrl) {
		                    return string.replace(urlAsRegex(url), '$1' + dataUrl + '$3');
		                });

		            function urlAsRegex(url) {
		                return new RegExp('(url\\([\'"]?)(' + util.escape(url) + ')([\'"]?\\))', 'g');
		            }
		        }

		        function inlineAll(string, baseUrl, get) {
		            if (nothingToInline()) return Promise.resolve(string);

		            return Promise.resolve(string)
		                .then(readUrls)
		                .then(function (urls) {
		                    var done = Promise.resolve(string);
		                    urls.forEach(function (url) {
		                        done = done.then(function (string) {
		                            return inline(string, url, baseUrl, get);
		                        });
		                    });
		                    return done;
		                });

		            function nothingToInline() {
		                return !shouldProcess(string);
		            }
		        }
		    }

		    function newFontFaces() {
		        return {
		            resolveAll: resolveAll,
		            impl: {
		                readAll: readAll
		            }
		        };

		        function resolveAll() {
		            return readAll()
		                .then(function (webFonts) {
		                    return Promise.all(
		                        webFonts.map(function (webFont) {
		                            return webFont.resolve();
		                        })
		                    );
		                })
		                .then(function (cssStrings) {
		                    return cssStrings.join('\n');
		                });
		        }

		        function readAll() {
		            return Promise.resolve(util.asArray(document.styleSheets))
		                .then(getCssRules)
		                .then(selectWebFontRules)
		                .then(function (rules) {
		                    return rules.map(newWebFont);
		                });

		            function selectWebFontRules(cssRules) {
		                return cssRules
		                    .filter(function (rule) {
		                        return rule.type === CSSRule.FONT_FACE_RULE;
		                    })
		                    .filter(function (rule) {
		                        return inliner.shouldProcess(rule.style.getPropertyValue('src'));
		                    });
		            }

		            function getCssRules(styleSheets) {
		                var cssRules = [];
		                styleSheets.forEach(function (sheet) {
		                    try {
		                        util.asArray(sheet.cssRules || []).forEach(cssRules.push.bind(cssRules));
		                    } catch (e) {
		                        console.log('Error while reading CSS rules from ' + sheet.href, e.toString());
		                    }
		                });
		                return cssRules;
		            }

		            function newWebFont(webFontRule) {
		                return {
		                    resolve: function resolve() {
		                        var baseUrl = (webFontRule.parentStyleSheet || {}).href;
		                        return inliner.inlineAll(webFontRule.cssText, baseUrl);
		                    },
		                    src: function () {
		                        return webFontRule.style.getPropertyValue('src');
		                    }
		                };
		            }
		        }
		    }

		    function newImages() {
		        return {
		            inlineAll: inlineAll,
		            impl: {
		                newImage: newImage
		            }
		        };

		        function newImage(element) {
		            return {
		                inline: inline
		            };

		            function inline(get) {
		                if (util.isDataUrl(element.src)) return Promise.resolve();

		                return Promise.resolve(element.src)
		                    .then(get || util.getAndEncode)
		                    .then(function (data) {
		                        return util.dataAsUrl(data, util.mimeType(element.src));
		                    })
		                    .then(function (dataUrl) {
		                        return new Promise(function (resolve, reject) {
		                            element.onload = resolve;
		                            element.onerror = reject;
		                            element.src = dataUrl;
		                        });
		                    });
		            }
		        }

		        function inlineAll(node) {
		            if (!(node instanceof Element)) return Promise.resolve(node);

		            return inlineBackground(node)
		                .then(function () {
		                    if (node instanceof HTMLImageElement)
		                        return newImage(node).inline();
		                    else
		                        return Promise.all(
		                            util.asArray(node.childNodes).map(function (child) {
		                                return inlineAll(child);
		                            })
		                        );
		                });

		            function inlineBackground(node) {
		                var background = node.style.getPropertyValue('background');

		                if (!background) return Promise.resolve(node);

		                return inliner.inlineAll(background)
		                    .then(function (inlined) {
		                        node.style.setProperty(
		                            'background',
		                            inlined,
		                            node.style.getPropertyPriority('background')
		                        );
		                    })
		                    .then(function () {
		                        return node;
		                    });
		            }
		        }
		    }
		})(); 
	} (domToImage));
	return domToImage.exports;
}

var hasRequiredBrowser;

function requireBrowser () {
	if (hasRequiredBrowser) return browser;
	hasRequiredBrowser = 1;
	var __createBinding = (browser && browser.__createBinding) || (Object.create ? (function(o, m, k, k2) {
	    if (k2 === undefined) k2 = k;
	    var desc = Object.getOwnPropertyDescriptor(m, k);
	    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
	      desc = { enumerable: true, get: function() { return m[k]; } };
	    }
	    Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
	    if (k2 === undefined) k2 = k;
	    o[k2] = m[k];
	}));
	var __setModuleDefault = (browser && browser.__setModuleDefault) || (Object.create ? (function(o, v) {
	    Object.defineProperty(o, "default", { enumerable: true, value: v });
	}) : function(o, v) {
	    o["default"] = v;
	});
	var __importStar = (browser && browser.__importStar) || function (mod) {
	    if (mod && mod.__esModule) return mod;
	    var result = {};
	    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
	    __setModuleDefault(result, mod);
	    return result;
	};
	Object.defineProperty(browser, "__esModule", { value: true });
	browser.FilterToHexBrowser = void 0;
	const errorHandling_1 = requireErrorHandling();
	const shared_1 = requireShared();
	class FilterToHexBrowser extends shared_1.FilterToHexShared {
	    static cleanup(svgContainerElement) {
	        svgContainerElement.remove();
	    }
	    static returnInputError(filterString, svgContainerElement) {
	        const errorMessage = shared_1.FilterToHexShared.generateInputErrorMessage(filterString);
	        const errorResult = errorHandling_1.ErrorHandling.generateErrorResult(errorMessage);
	        FilterToHexBrowser.cleanup(svgContainerElement);
	        return errorResult;
	    }
	    static async getImageBase64ViaSVG(svgContainerElement) {
	        const domToImage = (await Promise.resolve().then(() => __importStar(requireDomToImage())));
	        return domToImage.toPng(svgContainerElement);
	    }
	    static async convert(filterString) {
	        const { errorMessage, svgContainerElement } = shared_1.FilterToHexShared.addSVGElementsToDOMAndValidateFilter(filterString);
	        if (errorMessage)
	            return FilterToHexBrowser.returnInputError(filterString, svgContainerElement);
	        const base64EncodedDataURL = await FilterToHexBrowser.getImageBase64ViaSVG(svgContainerElement);
	        const hexColor = await shared_1.FilterToHexShared.getColorViaImageDataURL(base64EncodedDataURL);
	        FilterToHexBrowser.cleanup(svgContainerElement);
	        return { color: hexColor };
	    }
	}
	browser.FilterToHexBrowser = FilterToHexBrowser;
	return browser;
}

var node = {};

var hasRequiredNode;

function requireNode () {
	if (hasRequiredNode) return node;
	hasRequiredNode = 1;
	Object.defineProperty(node, "__esModule", { value: true });
	node.FilterToHexNode = void 0;
	const errorHandling_1 = requireErrorHandling();
	const errors_1 = requireErrors();
	const colorFormats_1 = requireColorFormats();
	const colorTypes_1 = requireColorTypes();
	const shared_1 = requireShared();
	class FilterToHexNode extends shared_1.FilterToHexShared {
	    static cleanup(browser) {
	        if (FilterToHexNode.IS_HEADLESS)
	            browser === null || browser === void 0 ? void 0 : browser.close();
	    }
	    static returnError(errorMsg, browser) {
	        const errorResult = errorHandling_1.ErrorHandling.generateErrorResult(errorMsg);
	        FilterToHexNode.cleanup(browser);
	        return errorResult;
	    }
	    static async getImageBase64ViaSVG(page) {
	        const endodedScreenshotData = await page.screenshot({ encoding: FilterToHexNode.BASE_64_ENCODING });
	        return `${FilterToHexNode.ENCODED_DATA_URL_PREFIX}${endodedScreenshotData}`;
	    }
	    static async openBrowserPage(browser) {
	        const page = await browser.newPage();
	        await page.setViewport({
	            width: FilterToHexNode.SVG_SIDE_LENGTH_PX,
	            height: FilterToHexNode.SVG_SIDE_LENGTH_PX,
	        });
	        return page;
	    }
	    static async addSVGAndValidateFilter(page, filterString) {
	        const svgAddResult = await page.evaluate(shared_1.FilterToHexShared.addSVGElementsToDOMAndValidateFilter, filterString, FilterToHexNode.SVG_SIDE_LENGTH_PX);
	        if (svgAddResult.errorMessage) {
	            return {
	                errorMessage: errorHandling_1.ErrorHandling.generateInputErrorMessage(colorTypes_1.ColorTypes.FILTER, filterString, colorFormats_1.ColorFormats.FILTER),
	            };
	        }
	        return svgAddResult;
	    }
	    static async getPuppeteerDependency() {
	        try {
	            // this is used to prevent tsc from evaluating the puppeteer module by adding dynamicity to the require path
	            const pathPadding = '';
	            // eslint-disable-next-line prefer-template
	            return commonjsRequire('puppeteer' + pathPadding);
	        }
	        catch (e) {
	            return { errorMessage: errors_1.MUST_INSTALL_PUPPETEER };
	        }
	    }
	    static async preparePuppeteerBrowser() {
	        const puppeteer = await FilterToHexNode.getPuppeteerDependency();
	        if (errorHandling_1.ErrorHandling.hasError(puppeteer))
	            return puppeteer;
	        return puppeteer.launch({ headless: FilterToHexNode.IS_HEADLESS });
	    }
	    // puppeteer versions higher than 6.0.0 have a bug where the view blinks when taking a screnshot of a specific
	    // element, hence in order to not have to force the user to install a specific version of puppeteer (especially if
	    // they are already using it for another use-case), the logic here is configured to reduce the viewport to the svg
	    // size and then proceed to take a screenshot of the viewport via the page.screenshot api
	    static async convert(filterString) {
	        const browser = await FilterToHexNode.preparePuppeteerBrowser();
	        if (errorHandling_1.ErrorHandling.hasError(browser))
	            return FilterToHexNode.returnError(browser.errorMessage);
	        const page = await FilterToHexNode.openBrowserPage(browser);
	        const addSvgResult = await FilterToHexNode.addSVGAndValidateFilter(page, filterString);
	        if (errorHandling_1.ErrorHandling.hasError(addSvgResult))
	            return FilterToHexNode.returnError(addSvgResult.errorMessage, browser);
	        const base64EncodedDataURL = await FilterToHexNode.getImageBase64ViaSVG(page);
	        const hexColor = await page.evaluate(shared_1.FilterToHexShared.getColorViaImageDataURL, base64EncodedDataURL);
	        FilterToHexNode.cleanup(browser);
	        return { color: hexColor };
	    }
	}
	node.FilterToHexNode = FilterToHexNode;
	FilterToHexNode.BASE_64_ENCODING = 'base64';
	FilterToHexNode.ENCODED_DATA_URL_PREFIX = `data:image/png;${FilterToHexNode.BASE_64_ENCODING},`;
	FilterToHexNode.IS_HEADLESS = true;
	// 1px SVG/viewport length is not enough to take a screenshot when headless mode is off, hence it is set to 2px
	FilterToHexNode.SVG_SIDE_LENGTH_PX = 2;
	return node;
}

var hasRequiredFilterToHex;

function requireFilterToHex () {
	if (hasRequiredFilterToHex) return filterToHex;
	hasRequiredFilterToHex = 1;
	var __createBinding = (filterToHex && filterToHex.__createBinding) || (Object.create ? (function(o, m, k, k2) {
	    if (k2 === undefined) k2 = k;
	    var desc = Object.getOwnPropertyDescriptor(m, k);
	    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
	      desc = { enumerable: true, get: function() { return m[k]; } };
	    }
	    Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
	    if (k2 === undefined) k2 = k;
	    o[k2] = m[k];
	}));
	var __setModuleDefault = (filterToHex && filterToHex.__setModuleDefault) || (Object.create ? (function(o, v) {
	    Object.defineProperty(o, "default", { enumerable: true, value: v });
	}) : function(o, v) {
	    o["default"] = v;
	});
	var __importStar = (filterToHex && filterToHex.__importStar) || function (mod) {
	    if (mod && mod.__esModule) return mod;
	    var result = {};
	    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
	    __setModuleDefault(result, mod);
	    return result;
	};
	Object.defineProperty(filterToHex, "__esModule", { value: true });
	filterToHex.FilterToHex = void 0;
	const errorHandling_1 = requireErrorHandling();
	const browser_1 = requireBrowser();
	class FilterToHex {
	    static async convert(filterString, convertFromHex, options) {
	        try {
	            let result;
	            if (typeof window === 'undefined') {
	                const { FilterToHexNode } = await Promise.resolve().then(() => __importStar(requireNode()));
	                result = await FilterToHexNode.convert(filterString);
	            }
	            else {
	                result = await browser_1.FilterToHexBrowser.convert(filterString);
	            }
	            if (result.color && convertFromHex && typeof result.color === 'string') {
	                result.color = convertFromHex(result.color, options);
	            }
	            return result;
	        }
	        catch (error) {
	            return errorHandling_1.ErrorHandling.generateUnexpectedError(error);
	        }
	    }
	}
	filterToHex.FilterToHex = FilterToHex;
	return filterToHex;
}

var hexToColor = {};

var colorFormatter = {};

var hasRequiredColorFormatter;

function requireColorFormatter () {
	if (hasRequiredColorFormatter) return colorFormatter;
	hasRequiredColorFormatter = 1;
	Object.defineProperty(colorFormatter, "__esModule", { value: true });
	colorFormatter.ColorFormatter = void 0;
	class ColorFormatter {
	    static arrayToRgbString(rgbArray) {
	        return `rgb(${rgbArray[0]}, ${rgbArray[1]}, ${rgbArray[2]})`;
	    }
	    static arrayToHslString(hslArray) {
	        return `hsl(${hslArray[0]}deg, ${hslArray[1]}%, ${hslArray[2]}%)`;
	    }
	}
	colorFormatter.ColorFormatter = ColorFormatter;
	return colorFormatter;
}

var hasRequiredHexToColor;

function requireHexToColor () {
	if (hasRequiredHexToColor) return hexToColor;
	hasRequiredHexToColor = 1;
	var __importDefault = (hexToColor && hexToColor.__importDefault) || function (mod) {
	    return (mod && mod.__esModule) ? mod : { "default": mod };
	};
	Object.defineProperty(hexToColor, "__esModule", { value: true });
	hexToColor.HexToColor = void 0;
	const colorFormatter_1 = requireColorFormatter();
	const color_convert_1 = __importDefault(requireColorConvert());
	class HexToColor {
	    static convertToRgb(color, options) {
	        const result = color_convert_1.default.hex.rgb(color);
	        return (options === null || options === void 0 ? void 0 : options.resultType) === 'string' ? colorFormatter_1.ColorFormatter.arrayToRgbString(result) : result;
	    }
	    static convertToHsl(color, options) {
	        const result = color_convert_1.default.hex.hsl(color);
	        return (options === null || options === void 0 ? void 0 : options.resultType) === 'string' ? colorFormatter_1.ColorFormatter.arrayToHslString(result) : result;
	    }
	}
	hexToColor.HexToColor = HexToColor;
	return hexToColor;
}

var hasRequiredFilterToColor;

function requireFilterToColor () {
	if (hasRequiredFilterToColor) return filterToColor;
	hasRequiredFilterToColor = 1;
	Object.defineProperty(filterToColor, "__esModule", { value: true });
	filterToColor.FilterToColor = void 0;
	const filterToHex_1 = requireFilterToHex();
	const hexToColor_1 = requireHexToColor();
	class FilterToColor {
	    static async filterToHex(filterString) {
	        const result = await filterToHex_1.FilterToHex.convert(filterString);
	        if (result.color)
	            result.color = result.color.toUpperCase();
	        return result;
	    }
	    static async filterToRgb(filterString, options) {
	        return filterToHex_1.FilterToHex.convert(filterString, hexToColor_1.HexToColor.convertToRgb, options);
	    }
	    static async filterToHsl(filterString, options) {
	        return filterToHex_1.FilterToHex.convert(filterString, hexToColor_1.HexToColor.convertToHsl, options);
	    }
	}
	filterToColor.FilterToColor = FilterToColor;
	return filterToColor;
}

var hasRequiredLib;

function requireLib () {
	if (hasRequiredLib) return lib.exports;
	hasRequiredLib = 1;
	(function (module, exports) {
		Object.defineProperty(exports, "__esModule", { value: true });
		const colorToFilter_1 = requireColorToFilter();
		const filterToColor_1 = requireFilterToColor();
		class CssFilterConverter {
		    static rgbToFilter(rgbString, options) {
		        return colorToFilter_1.ColorToFilter.rgbToFilter(rgbString, options);
		    }
		    static hexToFilter(hexString, options) {
		        return colorToFilter_1.ColorToFilter.hexToFilter(hexString, options);
		    }
		    static hslToFilter(hslString, options) {
		        return colorToFilter_1.ColorToFilter.hslToFilter(hslString, options);
		    }
		    static keywordToFilter(keyword, options) {
		        return colorToFilter_1.ColorToFilter.keywordToFilter(keyword, options);
		    }
		    static async filterToHex(filterString) {
		        return filterToColor_1.FilterToColor.filterToHex(filterString);
		    }
		    static async filterToRgb(filterString, options) {
		        return filterToColor_1.FilterToColor.filterToRgb(filterString, options);
		    }
		    static async filterToHsl(filterString, options) {
		        return filterToColor_1.FilterToColor.filterToHsl(filterString, options);
		    }
		}
		exports.default = CssFilterConverter;
		module.exports = CssFilterConverter; 
	} (lib, lib.exports));
	return lib.exports;
}

var libExports = requireLib();
var CssFilter = /*@__PURE__*/getDefaultExportFromCjs(libExports);

const lidoImageCss = () => `.lido-image{user-select:none;-webkit-user-drag:none;object-fit:contain;width:100% !important;height:100% !important;aspect-ratio:1 / 1;transform:rotate(0) !important;margin:0 !important}.slice{background-repeat:no-repeat;background-position:center;background-size:100% 100%}`;

const LidoImage = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Specifies the width for border-image slice (e.g., "30px", "2em").
         * Only used when `isSlice` is enabled.
         */
        this.sliceWidth = '30px';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS filter to apply visual effects (e.g., blur, brightness) to the image.
         * Example: 'blur(5px)', 'brightness(0.8)', 'grayscale(100%)'
         */
        this.filter = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * CSS transform property to apply transformations like rotate, scale, translate, etc.
         * Example: 'rotate(45deg)' or 'scale(1.2)'.
         */
        this.transform = '';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
    }
    /**
     * Lifecycle method that runs after the component has been loaded into the DOM.
     * It initializes custom events based on the `type` of the image component.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        if (this.filter !== '') {
            const img = this.el.getElementsByTagName('img')[0];
            if (img) {
                img.style.filter = `${CssFilter.hexToFilter(tinycolor(this.filter).toHexString()).color}`;
            }
        }
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) ? 'flex' : 'none',
            alignItems: 'center',
            justifyContent: 'center',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            transform: parseProp(this.transform, orientation),
            borderRadius: this.borderRadius,
            // Slice Style
            borderImageSource: this.isSlice === 'true' ? `url(${convertUrlToRelative(this.src)})` : 'none',
            borderImageSlice: this.isSlice === 'true' ? `${parseInt(this.sliceWidth)} fill` : 'unset',
            borderImageRepeat: this.isSlice === 'true' ? 'round' : 'unset',
            borderImageWidth: this.isSlice === 'true' ? `${this.sliceWidth}` : 'unset',
            backgroundImage: this.isSlice === 'true' ? `url(${convertUrlToRelative(this.src)})` : 'none',
        };
    }
    render() {
        if (this.isSlice === 'true') {
            return (h(Host, { class: "slice", id: this.id, type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, value: this.value, minDrops: this.minDrops, maxDrops: this.maxDrops, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }));
        }
        else {
            return (h(Host, { id: this.id, type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, value: this.value, minDrops: this.minDrops, maxDrops: this.maxDrops, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "disable-speak": this.disableSpeak }, h("img", { class: "lido-image", src: convertUrlToRelative(this.src), alt: "", style: this.style })));
        }
    }
    get el() { return getElement(this); }
};
LidoImage.style = lidoImageCss();

const lidoKeyboardCss = () => `.lido-keyboard{display:flex;flex-direction:column;align-items:center;gap:30px}.input-area{display:flex;gap:15px}input[type="text"]{font-size:30px;font-weight:600;padding-left:20px;width:300px;height:70px;border:2px solid;background:whitesmoke;border-radius:20px;text-align:center}.keyboard-wrapper{justify-content:center;width:700px}.disabled{opacity:0.5;pointer-events:none}.key-button{background:aquamarine;font-weight:600}`;

const LidoKeyboard = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Comma-separated list of keys, optionally with status (e.g., "A,B-disable,C") */
        this.keys = '';
        /** Gap between key buttons (default: "10px") */
        this.gap = '10px';
        /** Background color for each key button */
        this.bgColor = '';
        /** Border radius for key buttons (e.g., "8px") */
        this.borderRadius = '';
        /**
         * Indicates whether the keyboard input is enabled.
         * When set to `true`, the component will respond to keyboard events.
         */
        this.keyboardInput = false;
        /** Number of columns in the keyboard layout (default: "10") */
        this.columns = '10';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        /** Tracks the number of keys clicked by the user */
        this.numberOfClick = 0;
        /** Current input string entered via the keyboard */
        this.inputString = '';
        /** Dynamic style object that stores resolved styles based on props */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    async inputValidation(e) {
        if (this.type !== 'click')
            return;
        const container = document.getElementById(LidoContainer$1);
        const clickedValue = e.target.getAttribute('value');
        if (!clickedValue)
            return;
        let selectedValue = JSON.parse(localStorage.getItem(SelectedValuesKey)) || '';
        localStorage.setItem(SelectedValuesKey, JSON.stringify(selectedValue));
        const bodyRect = document.body.getBoundingClientRect();
        // Get all word bubbles (make sure bubbles have class "bubble-element")
        const bubbles = Array.from(container.querySelectorAll('.bubble-element'));
        const overlapingBubbles = bubbles.filter(bubble => {
            const elemRect = bubble.getBoundingClientRect();
            return elemRect.left < bodyRect.right && elemRect.right > bodyRect.left && elemRect.top < bodyRect.bottom && elemRect.bottom > bodyRect.top;
        });
        // Find a bubble whose word starts with current progress + clicked letter
        const matchedBubble = overlapingBubbles.find(bubble => {
            const word = bubble.getAttribute('value'); // full word like "one"
            const hasElement = word === null || word === void 0 ? void 0 : word.startsWith(this.inputString.toLowerCase());
            return hasElement ? bubble : null;
        });
        if (matchedBubble) {
            // If full word completed
            if (this.inputString.toLowerCase() === matchedBubble.getAttribute('value').toLowerCase()) {
                storingEachActivityScore(true);
                AudioPlayer.getI().play(matchedBubble);
                stopHighlightForSpeakingElement(matchedBubble);
                setTimeout(() => { this.inputString = ''; }, 1000);
                const elementOnCorrect = matchedBubble.getAttribute('onCorrect');
                await executeActions(elementOnCorrect, matchedBubble);
                matchedBubble.style.animation = 'none';
                matchedBubble.style.pointerEvents = 'none';
                this.numberOfClick++;
                localStorage.removeItem(SelectedValuesKey);
                if (this.numberOfClick === this.letterLength) {
                    const onCorrrect = container.getAttribute('onCorrect');
                    container.style.pointerEvents = 'none';
                    await executeActions(onCorrrect, this.el);
                    calculateScore();
                    triggerNextContainer();
                }
                else {
                    handleFloatElementPosition(matchedBubble);
                }
            }
        }
        else {
            // ❌ Incorrect click
            storingEachActivityScore(false);
            setTimeout(() => { this.inputString = ''; }, 1000);
            localStorage.removeItem(SelectedValuesKey);
            const onInCorrrect = container.getAttribute('onInCorrect');
            await executeActions(onInCorrrect, this.el);
        }
    }
    componentDidLoad() {
        const container = document.getElementById(LidoContainer$1);
        if (container.getAttribute('drop-action') === DropAction.InfiniteDrop) {
            const buttons = this.el.querySelectorAll('.key-button');
            const firstButton = buttons[0];
            buttons.forEach((button) => {
                button.style.width = firstButton.offsetWidth + 'px';
                button.style.height = firstButton.offsetHeight + 'px';
            });
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            fontSize: parseProp(this.fontSize, orientation),
            fontFamily: this.fontFamily,
            color: parseProp(this.fontColor, orientation),
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'flex' : 'none',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: parseProp(this.borderRadius, orientation),
            columns: parseProp(`${this.columns}`, orientation),
            gap: parseProp(this.gap, orientation),
        };
    }
    render() {
        const keysArray = this.keys.split(',').map(k => k.trim());
        const container = document.getElementById(LidoContainer$1);
        const showCheck = container.getAttribute('show-check') === 'true';
        return (h(Host, { key: '4de3b75fa2905744ad610d147d9b4fe9912dd732', class: "lido-keyboard", style: { width: this.style.width, height: this.style.height, position: 'relative', margin: this.style.margin, zIndex: this.z } }, this.keyboardInput && (h("div", { key: '7b5d293c52747700cde9c1069cfbbdae065e64f9', class: "input-area" }, h("input", { key: '03a91cd87e6bb4f09bf698087258426dd9232f67', type: "text", value: this.inputString, class: "input-area", readonly: true }), h("lido-text", { key: 'd30e033a055df52b30b2f2775c2b3410ee37df63', visible: showCheck ? 'true' : 'false', string: "<<", "bg-color": "black", "font-color": "white", "border-radius": "20px", "font-size": "30px", width: "100px", height: "70px", type: "click", onClick: () => {
                this.inputString = this.inputString.slice(0, -1);
                this.inputValidation(event);
            } }), h("lido-text", { key: '70d78aed7dedbe7d03a05c13c4c320029280bb03', visible: showCheck ? 'true' : 'false', id: "lido-checkButton", string: "Enter", "bg-color": "green", "font-color": "white", "border-radius": "20px", "font-size": "30px", width: "150px", height: "70px", type: "click" }))), this.letterLength && (h("lido-text", { key: '19306cd12bd98dc8dc7b54b20bad3f2f0318116f', visible: "true", string: `${this.numberOfClick}/${this.letterLength}`, "font-size": "60px", "font-color": "white", onEntry: "this.position='absolute'; this.right='0'; this.fontWeight='800';", x: "unset" })), h("div", { key: '826900d6ba26175eb45d2e7e4c02fccce2004db3', class: "keyboard-wrapper", style: {
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignContent: 'stretch',
                gap: this.gap,
                width: '100%',
                height: '100%',
            } }, keysArray.map((key, index) => {
            const [label, status] = key.split('-');
            const isDisabled = status === 'disable';
            let string = label === 'Space' ? ' ' : label;
            return (h("lido-text", { id: 'key-button-' + index, style: {
                    flex: `0 0 calc(${100 / parseInt(this.style.columns)}% - ${this.style.gap})`,
                }, visible: "true", "font-size": this.style.fontSize, "font-color": this.fontColor, "font-family": this.fontFamily, "bg-color": this.bgColor, string: label, onEntry: this.onEntry, "border-radius": this.style.borderRadius, value: label.toLowerCase(), type: this.type, class: `key-button${isDisabled ? ' disabled' : ''}`, onClick: () => {
                    this.inputString += string;
                    this.inputValidation(event);
                }, "disable-speak": this.disableSpeak }));
        }))));
    }
    get el() { return getElement(this); }
};
LidoKeyboard.style = lidoKeyboardCss();

const lidoMathMatrixCss = () => `.math-matrix{width:100%;height:100%;display:flex;justify-content:center}.slot{width:100%;height:100%;text-align:center;align-content:center;font-size:42px;font-weight:800;font-family:'Baloo Bhai 2';box-sizing:content-box}.slot:hover{opacity:0.7}.slot-parent{width:100%;height:100%;display:flex;justify-content:center;align-items:center;flex-direction:column}.slot-active{background-color:var(--active-bg-color);background-image:var(--bg-image);background-size:contain;background-position:center;background-repeat:no-repeat}.slot-inactive{background-color:var(--deactive-bg-color);background-size:cover;background-position:center;background-repeat:no-repeat}.topIndex,.leftIndex,.bottomIndex{height:100%;width:100%;text-align:center;align-content:center;font-size:30px;font-weight:600;font-family:'Baloo Bhai 2'}`;

const LidoMathMatrix = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Number of rows in the matrix */
        this.rows = "10";
        /** Number of columns in the matrix */
        this.cols = "10";
        /** Number of slots to pre-fill as active by default */
        this.defualtFill = 0;
        /** Show row index numbers on the left side */
        this.leftIndex = false;
        /** Show column index numbers on the top side */
        this.topIndex = false;
        /** Show row index numbers on the bottom side */
        this.bottomIndex = false;
        /** Enable/disable click interactions on the slots */
        this.clickable = true;
        /** If true, only active slots are visible; inactive ones are hidden */
        this.activeOnlyVisible = false;
        /** Background color for active slots */
        this.activeBgColor = 'transparent';
        this.deactiveBgColor = 'transparent';
        /** Border style applied to each slot */
        this.border = '2px solid green';
        /** Height of the slot container */
        this.height = '100%';
        /** Width of the slot container */
        this.width = '100%';
        /** Border radius for each slot */
        this.borderRadius = '5px';
        /** Controls the visibility of the matrix (accepts "true" or "false" as string) */
        this.visible = 'false';
        /** Tracks the previously filled slot index to clear it when a new slot is clicked */
        this.previousFilledSlot = -1;
        /** Reference to the previously filled slot element for clearing its text */
        this.previousFilledSlotElement = null;
        /** Holds dynamically generated inline styles for the container */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    updateValue(index) {
        this.el.setAttribute('value', index);
    }
    componentDidLoad() {
        const slotElements = this.el.querySelectorAll('.slot');
        initEventsForElement(this.el, this.type);
        slotElements.forEach((el, i) => {
            const slot = el;
            slot.style.setProperty('--active-bg-color', this.activeBgColor);
            slot.style.setProperty('--deactive-bg-color', this.deactiveBgColor);
            this.clickable ? (slot.style.pointerEvents = '') : (slot.style.pointerEvents = 'none');
            slot.style.border = this.border;
            slot.style.color = this.fontColor;
            if (slot.className.includes('slot-active')) {
                slot.style.visibility = '';
                if (this.matrixImage) {
                    slot.style.setProperty('--bg-image', `url(${convertUrlToRelative(this.matrixImage)})`);
                }
            }
            else if (this.activeOnlyVisible) {
                slot.style.visibility = 'hidden';
            }
        });
        this.updateSlots();
        this.updateStyles();
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        this.updateSlots();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateSlots() {
        const slotElement = this.el.querySelectorAll('.slot');
        const fristElement = this.el.querySelector('.slot');
        if (!slotElement.length || !fristElement)
            return;
        const container = document.getElementById(LidoContainer$1);
        let numOfRows = this.rows;
        let numOfCols = this.cols;
        if (container && container.getAttribute("template-id") === "multiplyBeeds") {
            numOfCols = "9";
            numOfRows = "1";
        }
        const elementSize = Number(numOfRows) < Number(numOfCols) ? this.el.offsetHeight : this.el.offsetWidth;
        const numberOfSlots = Number(numOfRows) > Number(numOfCols) ? Number(numOfRows) : Number(numOfCols);
        const slotParent = this.el.querySelectorAll('.slot-parent');
        const slotMaxValues = elementSize / numberOfSlots;
        slotParent.forEach(parent => {
            parent.style.width = `${slotMaxValues}px`;
            Array.from(parent.children).forEach(el => {
                const item = el;
                item.style.width = `${slotMaxValues}px`;
                item.style.height = `${slotMaxValues}px`;
                if (this.type === 'drop' || this.type === 'drag' || this.type === 'checkerBlock') {
                    this.el.style.width = 'auto';
                    this.el.style.height = 'auto';
                }
                if ((!this.topIndex && item.classList.contains('topIndex')) ||
                    (!this.leftIndex && item.classList.contains('leftIndex')) ||
                    (!this.bottomIndex && item.classList.contains('bottomIndex'))) {
                    if (item.classList.contains('leftIndex'))
                        item.parentElement.remove();
                    item.remove();
                }
            });
        });
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) === 'true' ? 'flex' : 'none',
            borderRadius: parseProp(this.borderRadius, orientation),
            left: parseProp(this.x, orientation),
            top: parseProp(this.y, orientation),
            cols: parseProp(`${this.cols}`, orientation),
            rows: parseProp(`${this.rows}`, orientation),
        };
    }
    handleClickSlot(element) {
        const index = parseInt(element.className.split(' ')[1].split('-')[1]);
        const slotElements = this.el.querySelectorAll('.slot');
        slotElements.forEach((el, i) => {
            const slotEl = el;
            if (i < index) {
                slotEl.classList.add('slot-active');
                slotEl.classList.remove('slot-inactive');
                if (this.matrixImage) {
                    slotEl.style.setProperty('--bg-image', `url(${convertUrlToRelative(this.matrixImage)})`);
                }
            }
            else {
                slotEl.classList.remove('slot-active');
                slotEl.classList.add('slot-inactive');
            }
        });
        if (this.previousFilledSlot !== -1) {
            // Clear the text from the previously filled slot
            if (this.previousFilledSlotElement !== null) {
                this.previousFilledSlotElement.textContent = '';
            }
        }
        // Display the slot value/text on the clicked slot itself
        element.textContent = index.toString();
        // Track this slot as the previously filled slot for next click
        this.previousFilledSlot = index;
        this.previousFilledSlotElement = element;
        // If the slot is the bottom-most slot for this matrix, dispatch a generic event
        // so templates or global handlers can handle bottom-slot behaviour (e.g., MultiplyBeadsAnimation).
        if (index === slotElements.length) {
            try {
                const event = new CustomEvent('math-matrix-bottom-click', {
                    detail: {
                        matrix: this.el,
                        cols: this.style.cols,
                        rows: this.style.rows,
                    },
                    bubbles: true,
                    composed: true,
                });
                // dispatch from the host so listeners on container or document receive it
                this.el.dispatchEvent(event);
            }
            catch (err) {
                console.warn('Error dispatching math-matrix-bottom-click from handleClickSlot', err);
            }
        }
        this.updateValue(index.toString());
        const container = document.getElementById(LidoContainer$1);
        const isWriteSetGrid = this.clickable &&
            this.type === 'checkerBlock' &&
            this.el.id === 'mat1' &&
            !!(container === null || container === void 0 ? void 0 : container.getAttribute('equationCheck'));
        if (isWriteSetGrid && container) {
            const result = !!equationCheck(container.getAttribute('equationCheck'));
            console.log('Write Set checkerBlock click:', { result });
            storingEachActivityScore(result);
        }
        // trigger the next container if right slot was clicked
        validateObjectiveStatus();
    }
    getSlotData() {
        const data = {};
        if (!this.text)
            return data;
        this.text.split(',').forEach((item, index) => {
            const [rawText, rawColor] = item.split('-');
            const num = parseInt(rawText.trim());
            if (!isNaN(num)) {
                data[index] = { text: rawText.trim(), color: rawColor === null || rawColor === void 0 ? void 0 : rawColor.trim() };
            }
        });
        return data;
    }
    render() {
        let slotNumber = 1;
        const slotData = this.getSlotData();
        return (h(Host, { key: '8a17727416da00fda95c401c3a005cdea1e732d0', class: "math-matrix", style: {
                height: this.style.height,
                width: this.style.width,
                z: this.style.z,
                display: this.style.display,
                top: this.style.top,
                left: this.style.left,
            }, type: this.type, value: this.value, "tab-index": this.tabIndex, rows: this.style.rows, cols: this.style.cols, text: this.text, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, Array.from({ length: parseInt(this.style.rows) + 1 }, (_, rowIndex) => (h("div", { class: "slot-parent", key: `row-${rowIndex}` }, h("div", { style: rowIndex === 0 && { visibility: 'hidden' }, class: "topIndex" }, rowIndex), Array.from({ length: parseInt(this.style.cols) }, (_, colIndex) => {
            var _a, _b;
            return rowIndex === 0 ? (h("div", { class: "leftIndex" }, ++colIndex)) : (h("div", { class: `slot slot-${slotNumber} ${this.defualtFill >= slotNumber ? 'slot-active' : 'slot-inactive'}`, onClick: (ev) => this.handleClickSlot(ev.currentTarget), key: `slot-${rowIndex}-${colIndex}`, style: {
                    borderRadius: this.style.borderRadius,
                    backgroundColor: ((_a = slotData[slotNumber - 1]) === null || _a === void 0 ? void 0 : _a.color) || '',
                } }, (_b = slotData[slotNumber - 1]) === null || _b === void 0 ? void 0 :
                _b.text, slotNumber++ && null));
        }), h("div", { style: rowIndex === 0 && { visibility: 'hidden' }, class: "bottomIndex" }, parseInt(this.style.cols) * rowIndex))))));
    }
    get el() { return getElement(this); }
};
LidoMathMatrix.style = lidoMathMatrixCss();

const lidoPosCss = () => `.lido-pos{top:var(--y, 0);left:var(--x, 0);height:var(--height, 100%);width:var(--width, 100%);background-color:var(--bgColor, #eeeeee);display:flex;justify-content:space-around;flex-direction:column;position:fixed}.lido-pos>*{position:absolute}`;

const LidoPos = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the positional element.
         */
        this.id = '';
        /**
         * Value assigned to the component, often used for internal logic or data tracking.
         */
        this.value = '';
        /**
         * The height of the component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the component (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the component (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the element relative to others.
         */
        this.z = '0';
        /**
         * Background color of the component (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The type of the component, used for conditional logic or specific styles.
         */
        this.type = '';
        /**
         * Tab index to support keyboard navigation within the component.
         */
        this.tabIndex = 0;
        /**
         * Visibility flag to control whether the element is displayed (`true`) or hidden (`false`).
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the component is entered, often used to trigger animations or custom logic.
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * Lifecycle hook that is called after the component has been rendered in the DOM.
     * It initializes custom events based on the `type` of the component.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: JSON.parse(parseProp(`${this.visible}`, orientation)) ? 'block' : 'none', // Toggle visibility
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: 'cfd38900b31991e89c21a099fc4f91f77663ae94', id: this.id, class: "lido-pos", type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, minDrops: this.minDrops, maxDrops: this.maxDrops, value: this.value, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: '73f7bfe2d8214693d6f40a4dab6d735906ad4eaa' })));
    }
    get el() { return getElement(this); }
};
LidoPos.style = lidoPosCss();

const lidoRandomCss = () => `.lido-random{position:relative;width:100%;height:100%}.lido-random>*{position:absolute}`;

const LidoRandom = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Unique identifier for the random container.
         */
        this.id = '';
        /**
         * Value associated with the component, often used for internal logic.
         */
        this.value = '';
        /**
         * The height of the container (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * The width of the container (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the container (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the container (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the container relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the container (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The type of the component, used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the container. If `true`, the container is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It randomly positions all child elements within the container using CSS `top` and `left` percentages.
     */
    componentDidLoad() {
        setTimeout(() => {
            // Select all direct child elements of the component
            const parentcontainer = this.el.parentElement;
            if (!parentcontainer)
                return;
            // Get parent size
            const parentWidth = parentcontainer.offsetWidth;
            const parentHeight = parentcontainer.offsetHeight;
            // Place child elements randomly inside parent
            const children = Array.from(this.el.children);
            children.forEach(child => {
                const childWidth = child.offsetWidth;
                const childHeight = child.offsetHeight;
                const maxLeft = parentWidth - childWidth;
                const maxTop = parentHeight - childHeight;
                const randLeft = Math.random() * maxLeft;
                const randTop = Math.random() * maxTop;
                child.style.position = 'absolute';
                child.style.left = `${randLeft}px`;
                child.style.top = `${randTop}px`;
            });
        }, 50);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    render() {
        // Inline styles for the container, including dimensions, positioning, and visibility
        const style = {
            height: this.height,
            width: this.width,
            top: this.y,
            left: this.x,
            display: this.visible ? 'block' : 'none', // Toggle visibility
            zIndex: this.z,
            backgroundColor: this.bgColor,
            margin: this.margin,
        };
        return (h(Host, { key: 'a4cec45d407b57833a4296a20230717534adf39b', class: "lido-random", type: this.type, "tab-index": this.tabIndex, value: this.value, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, minDrops: this.minDrops, maxDrops: this.maxDrops, onInCorrect: this.onInCorrect, onEntry: this.onEntry }, h("slot", { key: 'b80726b68b7f1c009f35352b9d05cd573159f87b' })));
    }
    get el() { return getElement(this); }
};
LidoRandom.style = lidoRandomCss();

const LidoRoot = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /** Language to apply to all texts */
        this.Lang = '';
        /**
         * Prop to hold the XML file path or URL. This can be a relative path or an external URL.
         */
        this.xmlPath = '';
        /**
         * Initial index of the container being displayed.
         */
        this.initialIndex = 0;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Boolean that controls the playability of the game.
         */
        this.canplay = true;
        /**
         * Base URL for the containers.
         */
        this.baseUrl = '';
        /**
         * ZIP URL pointing to a package containing XML and asset files.
         */
        this.zipUrl = '';
    }
    /**
     * Lifecycle method that runs before the component is loaded.
     * It fetches the XML data from the specified path or URL and sets it to the component's state.
     */
    connectedCallback() {
        this.setLanguage(this.Lang);
    }
    onLangChange(newLang) {
        this.setLanguage(newLang);
    }
    setLanguage(lang) {
        const effectiveLang = lang || instance.language;
        instance.changeLanguage(effectiveLang);
    }
    async componentWillLoad() {
        var _a, _b;
        // If a ZIP URL is provided, we will load XML from the ZIP rather than fetching an external xmlPath.
        if (this.zipUrl) {
            this.xmlData = '';
            return;
        }
        const xmlPath = (_a = this.xmlPath) !== null && _a !== void 0 ? _a : this.baseUrl + (((_b = this.baseUrl) === null || _b === void 0 ? void 0 : _b.endsWith('/')) ? 'index.xml' : '/index.xml');
        // Fetch the XML data
        try {
            const resolvedPath = xmlPath.startsWith('http')
                ? xmlPath // Use the provided URL if it's an HTTP/HTTPS link
                : getAssetPath(xmlPath); // Otherwise, resolve it as an asset path
            const response = await fetch(resolvedPath);
            if (!response.ok) {
                throw new Error(`Failed to fetch XML data: ${response.statusText}`);
            }
            const data = await response.text();
            // Store the XML data in the component's state
            this.xmlData = data;
        }
        catch (error) {
            console.error('Error fetching XML data:', error);
            this.xmlData = null;
        }
    }
    render() {
        // Show a loading message until the XML data is fetched
        if (this.xmlData === undefined) {
            return h("div", null, "Loading...");
        }
        // Show an error message if the XML data could not be fetched
        if (this.xmlData === null) {
            return h("div", null, "Error loading XML data. Please check the path or URL.");
        }
        // Once the XML data is loaded, pass it to the `lido-home` component
        return (h("lido-home", Object.assign({ showNav: true, activeContainerIndexes: [], initialIndex: this.initialIndex, canplay: this.canplay, xmlData: this.xmlData, baseUrl: this.baseUrl }, (this.zipUrl ? { zipUrl: this.zipUrl } : {}), { exitButtonUrl: this.exitButtonUrl, prevButtonUrl: this.prevButtonUrl, nextButtonUrl: this.nextButtonUrl, speakerButtonUrl: this.speakerButtonUrl })));
    }
    static get assetsDirs() { return ["assets"]; }
    static get watchers() { return {
        "Lang": [{
                "onLangChange": 0
            }]
    }; }
};

const lidoRowCss = () => `.lido-row{display:flex;justify-content:space-around;align-items:center;}.lido-row>*{}`;

const LidoRow = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
    }
    /**
     * Lifecycle hook that runs after the component is loaded into the DOM.
     * It initializes custom events based on the `type` of the row component.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: this.visible ? (this.display ? parseProp(this.display, orientation) : 'flex') : 'none', // Toggle visibility
            flexDirection: !this.direction ? 'row' : parseProp(this.direction, orientation),
            gridTemplateColumns: this.display && parseProp(this.display, orientation) === 'grid' ? 'repeat(auto-fill, minmax(186px, auto))' : undefined,
            gap: this.display && parseProp(this.display, orientation) === 'grid' ? '20px' : undefined,
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: 'c69aea0b1b11d9aec167d1a4376f68073f91ca81', class: "lido-row", type: this.type, "tab-index": this.tabIndex, value: this.value, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, minDrops: this.minDrops, maxDrops: this.maxDrops, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "disable-speak": this.disableSpeak }, h("slot", { key: '8756ee0447057cddb949e23decbde5fe4d1d25c8' })));
    }
    get el() { return getElement(this); }
};
LidoRow.style = lidoRowCss();

const lidoShapeCss = () => `.lido-shape{position:absolute;top:var(--y);left:var(--x);display:var(--display);z-index:var(--z);justify-content:center;align-items:center}.lido-rectangle{border-radius:0}.lido-circle{width:var(--width);height:var(--width);border-radius:50%;background-color:var(--bgColor)}.lido-ellipse{width:var(--width);height:var(--height);border-radius:50%;background-color:var(--bgColor)}.lido-triangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--bgColor);clip-path:polygon(50% 0%, 100% 100%, 0% 100%)}.lido-rightTriangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--bgColor);clip-path:polygon(100% 0%, 100% 100%, 0% 100%)}.lido-leftTriangle{width:var(--triangleWidth);height:var(--triangleHeight);background-color:var(--triangleBgColor);clip-path:polygon(0% 0%, 100% 100%, 0% 100%)}.lido-parallelogram{width:var(--paralleWidth);height:var(--paralleHeight);transform:skew(20deg)}.lido-trapezium{width:var(--trapeziumWidth);height:var(--trapeziumHeight);background-color:var(--bgColor);clip-path:polygon(      20% 0%,         80% 0%,         100% 100%,      0% 100%      )}.lido-hexagon{width:var(--hexagonWidth);height:var(--hexagonHeight);background-color:var(--bgColor);clip-path:polygon(      25% 0%,         75% 0%,         100% 50%,       75% 100%,       25% 100%,       0% 50%       )}.lido-cone{width:var(--coneWidth);height:var(--coneHeight);background-color:var(--bgColor);clip-path:polygon(            15% 10%,      25% 4%,      35% 1%,      50% 0%,      65% 1%,      75% 4%,      85% 10%,              50% 100%    )}.lido-star{width:var(--starWidth);height:var(--starHeight);background-color:var(--starBgColor);clip-path:polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)}.lido-pentagon{width:var(--pentagonWidth);height:var(--pentagonHeight);background-color:var(--pentagonBgColor);clip-path:polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)}.lido-heptagon{width:var(--heptagonWidth);height:var(--heptagonHeight);background-color:var(--heptagonBgColor);clip-path:polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)}.lido-octagon{width:var(--octagonWidth);height:var(--octagonHeight);background-color:var(--octagonBgColor);clip-path:polygon(25% 0%, 75% 0%, 100% 25%, 100% 75%, 75% 100%, 25% 100%, 0% 75%, 0% 25%)}.lido-rhombus{width:var(--rhombusWidth);height:var(--rhombusHeight);background-color:var(--rhombusBgColor);clip-path:polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)}.lido-heart{height:var(--heartHeight);width:var(--heartWidth);border-image:radial-gradient(var(--heartBgColor) 69%, #0000 70%) 84.5%/50%;clip-path:polygon(-41% 0, 50% 91%, 141% 0)}.cube{width:100%;height:100%;position:relative;transform-style:preserve-3d;transform:rotateX(-20deg) rotateY(45deg)}.face{position:absolute;width:var(--face-width,150px);height:var(--face-width,150px);background:var(--face-bg-color,150px);box-shadow:inset -20px -20px 40px rgba(0,0,0,0.3)}.front{transform:rotateY(  0deg) translateZ(var(--face-translate, 75px))}.back{transform:rotateY(180deg) translateZ(var(--face-translate, 75px))}.right{transform:rotateY( 90deg) translateZ(var(--face-translate, 75px))}.left{transform:rotateY(-90deg) translateZ(var(--face-translate, 75px))}.top{transform:rotateX( 90deg) translateZ(var(--face-translate, 75px))}.bottom{transform:rotateX(-90deg) translateZ(var(--face-translate, 75px))}.lido-cylinder{width:var(--width);height:var(--height);border-radius:100% / 80px;background:radial-gradient(50% 40px at 50% 40px, #0003 99.99%, #0000 0),      radial-gradient(50% 40px at 50% calc(100% - 40px), #fff3 99.99%, #0000 0),      red}.lido-sphere{position:relative;width:var(--width);height:var(--width);border-radius:50%;background:radial-gradient(circle at 30% 18%, #22d4ff 0%, #18c2f4 9%, rgba(24, 194, 244, 0.2) 18%, transparent 30%),      radial-gradient(circle at 36% 26%, #0f8fff 0%, #0b67e6 30%, #083fbe 62%, #120084 100%);box-shadow:inset -22px -26px 40px rgba(5, 0, 70, 0.38),      inset 14px 14px 24px rgba(255, 255, 255, 0.05),      0 4px 2px rgba(0, 0, 0, 0.78);overflow:visible}.lido-sphere::after{content:'';position:absolute;top:50%;left:50%;width:100%;height:16%;border-radius:50%;border-top:2px dashed rgba(0, 0, 0, 0.65);border-bottom:3px solid rgba(0, 0, 0, 0.85);box-sizing:border-box;transform:translate(-50%, -50%);pointer-events:none}`;

const LidoShape = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the shape element.
         */
        this.id = '';
        /**
         * Value associated with the shape, typically used for internal logic or tracking.
         */
        this.value = '';
        /**
         * The height of the shape (CSS value, e.g., '100px', '50%').
         * This is ignored for polygons.
         */
        this.height = 'auto';
        /**
         * The width of the shape (CSS value, e.g., '100px', '50%').
         * This is ignored for polygons.
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * X-axis (horizontal) position of the shape (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the shape (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the shape relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the shape (CSS color value, e.g., '#FFFFFF', 'blue').
         * This is ignored for polygons.
         */
        this.bgColor = '';
        /**
         * Defines the type of the shape, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Type of shape to render (e.g., 'circle', 'rectangle', 'polygon').
         */
        this.shapeType = 'circle';
        /**
         * Controls the visibility of the shape. If `true`, the shape is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the shape.
         */
        this.audio = '';
        /**
         * Event handler triggered when the shape is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * Event handler triggered when the shape is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        /** Holds dynamically generated inline styles for the container */
        this.style = {};
    }
    /**
     * Lifecycle hook that runs after the component is loaded into the DOM.
     * It initializes custom events based on the `type` of the shape component.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.updateStyles();
        this.lido3DShapes();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            x: parseProp(`${this.x}`, orientation),
            y: parseProp(`${this.y}`, orientation),
            height: parseProp(`${this.height}`, orientation),
            width: parseProp(`${this.width}`, orientation),
        };
    }
    lido3DShapes() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        if (this.shapeType === "lido-cube") {
            const faces = this.el.querySelectorAll(".face");
            faces.forEach(item => {
                const face = item;
                face.style.setProperty("--face-width", parseProp(`${this.width}`, orientation));
                const translateValue = parseInt(parseProp(`${this.width}`, orientation)) / 2;
                face.style.setProperty("--face-translate", `${translateValue}px`);
                face.style.setProperty("--face-bg-color", this.bgColor);
            });
        }
    }
    render() {
        // Inline styles to position and size the shape component
        const style = {
            height: this.shapeType !== 'polygon' ? this.style.height : undefined, // Set height unless it's a polygon
            width: this.shapeType !== 'polygon' ? this.style.width : undefined, // Set width unless it's a polygon
            top: this.style.y,
            left: this.style.x,
            display: this.visible ? 'block' : 'none', // Toggle visibility
            zIndex: this.z,
            backgroundColor: this.shapeType !== 'polygon' ? this.bgColor : 'transparent', // Apply background only if not a polygon
            margin: this.margin,
        };
        return (h(Host, { key: '90b323eacac8b702168f612f79000da757109ec1', class: `lido-shape ${this.shapeType}`, value: this.value, type: this.type, "tab-index": this.tabIndex, style: style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, minDrops: this.minDrops, maxDrops: this.maxDrops, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, "disable-speak": this.disableSpeak }, this.shapeType === "lido-cube" &&
            h("div", { key: '16b4a96f302cd6b1c80023a29253e85fe0937622', class: "cube" }, h("div", { key: '9ce4dfa0021b463aa5dba4c0651d144f844c2db0', class: "face top" }), h("div", { key: 'f10410ef05cbde0a024ccbdbfb4fb7099c1bd9d3', class: "face bottom" }), h("div", { key: '2a08b1857613efd1db596d72a9324ac5b3379628', class: "face left" }), h("div", { key: '4922b4b63dc9538e68d143109bfa12782382ee48', class: "face right" }), h("div", { key: '983bc6815a3b5e6023d76394e0bdeb12c493b771', class: "face front" }), h("div", { key: 'eab0224f427b8a345d3c3285d8d2828b39871eaa', class: "face back" }))));
    }
    get el() { return getElement(this); }
};
LidoShape.style = lidoShapeCss();

const lidoSlideFillCss = () => `.lido-svg-element,.lido-slide-svg{width:100%;height:100%}`;

const LidoSlideFill = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Unique identifier for the component instance
         */
        this.id = 'lido-slide-fill';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * Type of number to be displayed on the ruler.
         * Can be 'integer', 'decimal', or 'fraction'.
         */
        this.numberType = 'integer';
        /**
         * Minimum value shown on the ruler (used for number generation)
         */
        this.min = 0;
        /**
         * Number of divisions or segments to split the ruler path into
         */
        this.division = 5;
        /**
         * Maximum value shown on the ruler (used for number generation)
         */
        this.max = 10;
        /**
         * Defines the type of the component, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * Internal state to hold the SVG content after fetching and processing
         */
        this.svgContent = '';
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.originalHeight = null;
        this.originalY = null;
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    async componentWillLoad() {
        await this.renderSVG();
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    async onSrcChange() {
        await this.renderSVG();
        this.onPropChange();
    }
    async renderSVG() {
        const response = await fetch(convertUrlToRelative(this.src));
        if (response.ok) {
            let svgText = await response.text();
            let pathIndex = 0;
            svgText = svgText.replace(/<path([^>]*)>/g, (match, attrs) => {
                pathIndex++;
                const id = pathIndex === 1 ? 'glassPath' : pathIndex === 2 ? 'rulerPath' : `path${pathIndex}`;
                return `<path id="${id}"${attrs}>`;
            });
            const clipPathDef = `
        <clipPath id="clipGlass">
          <use xlink:href="#glassPath" />
        </clipPath>
      `;
            svgText = svgText.replace(/<svg([^>]*)>/, `<svg class="lido-slide-svg"$1>
          ${clipPathDef}
        `);
            svgText = svgText.replace(/<rect([^>]*)\/?>/, `<rect id="fillArea" $1 clip-path="url(#clipGlass)" />`);
            this.svgContent = svgText;
        }
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        this.updateFill();
        this.addRulerNumbers();
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: parseProp(`${this.visible}`, orientation) ? 'flex' : 'none',
            alignItems: 'center',
            justifyContent: 'center',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: this.borderRadius,
        };
    }
    onPropChange() {
        this.updateFill();
        this.addRulerNumbers();
    }
    updateFill() {
        var _a;
        const svgEl = (_a = this.el.querySelector('.lido-svg-element')) === null || _a === void 0 ? void 0 : _a.querySelector('svg');
        if (!svgEl)
            return;
        const rect = svgEl.querySelector('#fillArea');
        if (!rect)
            return;
        const fillDirection = this.fillDirection;
        let originalSize;
        let originalOffset;
        if (this.fillDirection === 'vertical') {
            if (this.originalHeight === null || this.originalY === null) {
                this.originalHeight = +rect.getAttribute('height') || 100;
                this.originalY = +rect.getAttribute('y') || 0;
            }
            originalSize = this.originalHeight;
            originalOffset = this.originalY;
        }
        else {
            if (this.originalHeight === null || this.originalY === null) {
                this.originalHeight = +rect.getAttribute('width') || 100;
                this.originalY = +rect.getAttribute('x') || 0;
            }
            originalSize = this.originalHeight;
            originalOffset = this.originalY;
        }
        const fullSize = originalSize;
        const start = originalOffset;
        // Parse fill ("30%" or "30")
        let fillPercent = 0;
        if (typeof this.fill === 'string') {
            const percentMatch = this.fill.match(/^(\d+(?:\.\d+)?)%$/);
            if (percentMatch) {
                fillPercent = Math.min(Math.max(parseFloat(percentMatch[1]) / 100, 0), 1);
            }
            else {
                const numericMatch = this.fill.match(/^(\d+(?:\.\d+)?)$/);
                if (numericMatch) {
                    fillPercent = Math.min(Math.max(parseFloat(numericMatch[1]) / 100, 0), 1);
                }
            }
        }
        const newSize = fullSize * fillPercent;
        const newOffset = fillDirection === 'vertical' ? start + (fullSize - newSize) : start;
        if (fillDirection === 'vertical') {
            rect.setAttribute('height', newSize.toString());
            rect.setAttribute('y', newOffset.toString());
        }
        else {
            rect.setAttribute('width', newSize.toString());
            rect.setAttribute('x', '0');
        }
    }
    addRulerNumbers() {
        var _a;
        const svgEl = (_a = this.el.querySelector('.lido-svg-element')) === null || _a === void 0 ? void 0 : _a.querySelector('svg');
        if (!svgEl)
            return;
        const rulerPath = svgEl.querySelector('#rulerPath');
        if (!rulerPath)
            return;
        // Clear old numbers
        const oldNumbers = svgEl.querySelectorAll('.ruler-number');
        oldNumbers.forEach(node => node.remove());
        const divisions = this.division;
        const pointsCount = divisions + 1;
        const pathLength = rulerPath.getTotalLength();
        const stepValue = (this.max - this.min) / divisions;
        for (let i = 0; i < pointsCount; i++) {
            let value = 0;
            if (this.fillDirection === 'vertical') {
                value = this.max - i * stepValue;
            }
            else if (this.fillDirection === 'horizontal') {
                value = this.min + i * stepValue;
            }
            const pointAtLength = rulerPath.getPointAtLength((pathLength / divisions) * i);
            const textElem = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            const fraction$1 = fraction(value / this.max);
            value = this.numberType === 'integer' ? Math.round(value) : this.numberType === 'decimal' ? parseFloat(value.toFixed(1)) : fraction$1.toFraction(true);
            textElem.classList.add('ruler-number');
            textElem.setAttribute('x', pointAtLength.x.toString());
            textElem.setAttribute('y', (pointAtLength.y + 15).toString());
            textElem.setAttribute('text-anchor', 'end');
            textElem.setAttribute('font-size', '40');
            textElem.setAttribute('fill', '#333');
            textElem.textContent = value.toString();
            svgEl.appendChild(textElem);
        }
    }
    render() {
        return (h(Host, { key: 'df8a5474f641fec4d842013a04ef9e3d422a8ab2', id: this.id, class: "lido-slide-fill", src: this.src, fill: this.fill, fillDirection: this.fillDirection, slider: this.slider, style: this.style, min: this.min, max: this.max, division: this.division, numberType: this.numberType, onEntry: this.onEntry, type: this.type, "disable-speak": this.disableSpeak }, h("div", { key: 'e7b6bcc17f8caea30b074f24596b6b044833d170', innerHTML: this.svgContent, class: "lido-svg-element" })));
    }
    get el() { return getElement(this); }
    static get watchers() { return {
        "src": [{
                "onSrcChange": 0
            }],
        "fill": [{
                "onPropChange": 0
            }],
        "division": [{
                "onPropChange": 0
            }],
        "fillDirection": [{
                "onPropChange": 0
            }],
        "numberType": [{
                "onPropChange": 0
            }],
        "min": [{
                "onPropChange": 0
            }],
        "max": [{
                "onPropChange": 0
            }]
    }; }
};
LidoSlideFill.style = lidoSlideFillCss();

const lidoTextCss = () => `.lido-text{transition:background-color 0.3s ease;user-select:none;align-items:center;justify-content:center;text-align:center;border-radius:24px;color:#333;cursor:pointer;font-family:'Baloo Bhai 2', serif}.text-letters{transition:color 0.3s, text-shadow 0.3s;display:inline-block;padding:0 2px}.text-letters.letter-highlight{color:#8e24aa;background:none;border-radius:0;text-shadow:0 2px 8px #8e24aa88;animation:text-letter-bounce 0.4s}.text-words{transition:color 0.3s, text-shadow 0.3s;display:inline-block;padding:0 2px}.text-words.word-highlight{color:#8e24aa;background:none;border-radius:0;text-shadow:0 2px 8px #8e24aa88;animation:text-word-bounce 0.4s}@keyframes text-letter-bounce{0%{transform:scale(1)}60%{transform:scale(1.4)}100%{transform:scale(1)}}@keyframes text-word-bounce{0%{transform:scale(1)}60%{transform:scale(1.3)}100%{transform:scale(1)}}`;

const LidoText = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element if it is true.
         */
        this.showSpeakIcon = false;
        /**
         * Unique identifier for the text element.
         */
        this.id = '';
        /**
         * Value associated with the text element, typically used for internal logic or tracking.
        */
        this.value = '';
        /**
         * Number of drag elements required for count-based drop interactions.
         * Used by the Blender template to determine the correct and incorrect border state.
         */
        this.requiredDrops = '';
        /**
         * The string of text to be displayed in the component.
         */
        this.string = '';
        /**
         * Font family for the text (CSS value, e.g., 'Arial', 'Times New Roman').
         */
        this.fontFamily = '';
        /**
         * Font size for the text (CSS value, e.g., '16px', '1.5em').
         */
        this.fontSize = '20px';
        /**
         * Font color for the text (CSS color value, e.g., '#000000', 'red').
         */
        this.fontColor = '';
        /**
         * When set to `true`, the text will highlight while being spoken, typically used for accessibility.
         */
        this.highlightWhileSpeaking = false;
        /**
         * Height of the text component (CSS value, e.g., '100px', '50%').
         */
        this.height = 'auto';
        /**
         * Width of the text component (CSS value, e.g., '100px', '50%').
         */
        this.width = 'auto';
        /**
         * The ARIA label of the container. Used for accessibility to indicate the purpose of the element.
         */
        this.ariaLabel = '';
        /**
         * The ARIA hidden attribute of the container. Used for accessibility to hide the element.
         */
        this.ariaHidden = '';
        /**
         * Allows the text element to be freely moved by pointer/touch and persists the final x/y attributes.
         */
        this.move = 'false';
        /**
         * X-axis (horizontal) position of the text component (CSS value, e.g., '10px', '5vw').
         */
        this.x = '0px';
        /**
         * Y-axis (vertical) position of the text component (CSS value, e.g., '10px', '5vh').
         */
        this.y = '0px';
        /**
         * Z-index for stacking order of the text component relative to other elements.
         */
        this.z = '0';
        /**
         * Background color of the text component (CSS color value, e.g., '#FFFFFF', 'blue').
         */
        this.bgColor = '';
        /**
         * The border image of the column (CSS border-image value, e.g., 'url(border.png)', 'linear-gradient(red, blue)').
         */
        this.borderImage = '';
        /**
         * Defines the type of the component, which can be used for conditional logic or specific styling.
         */
        this.type = '';
        /**
         * Tab index for keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Controls the visibility of the text component. If `true`, the text is visible; otherwise, it is hidden.
         */
        this.visible = false;
        /**
         * URL or identifier for an audio file associated with the text component.
         */
        this.audio = '';
        /**
         * Event handler triggered when the text component is touched or clicked.
         */
        this.onTouch = '';
        /**
         * Event handler for an Incorrect matching action, which can be used to trigger custom logic when the action is incorrect.
         */
        this.onInCorrect = '';
        /**
         * Event handler for a Correct matching action, which can be used to hide the column or trigger other custom logic.
         */
        this.onCorrect = '';
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * Event handler triggered when the text component is entered (useful for animations or logic on entry).
         */
        this.onEntry = '';
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
         * CSS padding value applied to each child element inside the container.
         * Accepts standard CSS padding formats (e.g., '10px', '5px 10px', etc.).
         */
        this.padding = '';
        /**
         * CSS filter to apply border radius to the image.
         * Example: '10px' for  images.
         */
        this.borderRadius = '0px';
        /**
         * Indicates whether to wrap each letter or each word of the text in a span element.
         * This can be useful for animations or styling individual letters.
         */
        this.spanType = '';
        /**
         * Stores the dynamic style properties for the component, allowing runtime updates to styling.
         */
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It initializes custom events based on the `type` of the text component.
     */
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
        initEventsForElement(this.el, this.type);
        // only create span element if requested
        if (this.spanType === 'words' || this.spanType === 'letters') {
            this.addSpanToText();
        }
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
        if (!this.audio || this.audio.trim() === "") {
            const applyAutoAudio = () => {
                const autoAudio = this.resolveAutoAudio();
                if (autoAudio) {
                    this.audio = autoAudio;
                }
            };
            // If path is already available, apply immediately
            if (window.__LIDO_COMMON_AUDIO_PATH__) {
                applyAutoAudio();
            }
            else {
                // Otherwise, wait for it
                window.addEventListener(LIDO_COMMON_AUDIO_READY_EVENT, applyAutoAudio, { once: true });
            }
        }
    }
    resolveAutoAudio() {
        const base = window[LIDO_COMMON_AUDIO_PATH];
        if (!base || !this.string)
            return null;
        const fileName = this.string;
        return `${base}/${fileName}.mp3`;
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const borderImg = this.borderImage ? convertUrlToRelative(this.borderImage) : '';
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            fontSize: parseProp(this.fontSize, orientation),
            fontFamily: this.fontFamily,
            color: parseProp(this.fontColor, orientation),
            display: parseProp(`${this.visible}`, orientation) === "true" ? 'flex' : 'none', // Toggle visibility
            borderImage: `url(${borderImg})`,
            borderImageSlice: borderImg ? '0 fill' : '',
            margin: parseProp(this.margin, orientation),
            padding: parseProp(this.padding, orientation),
            borderRadius: parseProp(this.borderRadius, orientation),
        };
    }
    async addSpanToText() {
        const content = this.el.querySelector('.lido-text-content');
        if (!content)
            return;
        const text = content.textContent || '';
        content.innerHTML = '';
        // Wrap each letters in a span inside .lido-text-content
        if (this.spanType === 'letters') {
            text.split('').forEach((letter, idx) => {
                // Skip spaces
                if (letter.trim() === '')
                    return;
                // Create a span for each letter
                const letterSpan = document.createElement('span');
                letterSpan.textContent = letter;
                letterSpan.className = 'text-letters';
                content.appendChild(letterSpan);
            });
        }
        // Wrap each words in a span inside .lido-text-content
        if (this.spanType === 'words') {
            text.split(' ').forEach((word, idx) => {
                const wordSpan = document.createElement('span');
                wordSpan.textContent = word;
                wordSpan.className = 'text-words';
                content.appendChild(wordSpan);
            });
        }
    }
    render() {
        const displayText = instance.t(this.string).replace(/_phonics?/gi, '');
        return (h(Host, { key: 'e26a94ac52d05601588db0f756ba17b95848777a', class: "lido-text", value: this.value, "required-drops": this.requiredDrops, type: this.type, "tab-index": this.tabIndex, audio: this.audio, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, minDrops: this.minDrops, maxDrops: this.maxDrops, id: this.id, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, move: this.move, "span-type": this.spanType, "disable-speak": `${this.disableSpeak}` }, this.spanType !== '' ? h("div", { class: "lido-text-content" }, " ", displayText) : displayText));
    }
    get el() { return getElement(this); }
};
LidoText.style = lidoTextCss();

const lidoTraceCss = () => `:host{display:block;position:relative}#lido-svgContainer{display:flex;justify-content:center;align-items:center;overflow:hidden}.lido-trace-svg{width:100%;height:100%;touch-action:none}#lido-draggableCircle{cursor:pointer;fill:#CF1565;transition:fill 0.2s, r 0.2s}.lido-blindTracing{stroke:none !important}.lido-blindFreeTrace{stroke:none !important}.lido-hovered{cursor:grab;fill:darkred}#lido-controls{position:fixed;bottom:0;left:0;right:0;display:flex;justify-content:space-between;padding:10px;background-color:#f0f0f0;border-top:1px solid #ccc}button{padding:10px;font-size:16px}@media (max-width: 600px){button{padding:8px;font-size:14px}}.lido-trace-path-green{}.lido-flow-indicator{stroke:blue;stroke-width:2;stroke-dasharray:6, 6;fill:none}.lido-trace{height:700px;width:700px;z-index:1;justify-items:center;align-content:center}.trace-animate{animation:trace-bounce 0.5s}@keyframes trace-bounce{0%{transform:scale(1)}30%{transform:scale(1.05)}60%{transform:scale(0.95)}100%{transform:scale(1)}}`;

const LidoTrace = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * Various configuration properties for `lido-trace`
         */
        /**
         * Unique identifier for this `lido-trace` component instance.
         */
        this.id = '';
        /**
         * Source URL or path for the SVG file used in this component.
         */
        this.svgSource = '';
        /**
         * Array of SVG URLs to be used for tracing, separated by semicolons.
         * This allows multiple SVGs to be loaded and traced in sequence.
         */
        this.svgUrls = [];
        /**
         * Array of audio URLs to be played when tracing is completed, separated by semicolons.
         * This allows multiple audio files to be loaded and played in sequence.
         */
        this.audioUrls = [];
        /**
         * Index of the currently active SVG in the `svgUrls` array.
         * This is used to track which SVG is currently being traced.
         */
        this.currentSvgIndex = 0;
        /**
         * Specifies whether the component is currently in a moving state.
         * This can be used to control animations or transitions.
         * Defaults to `false`.
         */
        this.moving = false;
        /**
         * A custom string value associated with the component for additional data or identification.
         */
        this.value = '';
        /**
         * Specifies the height of the component container, accepts any valid CSS height value (e.g., `"100px"`, `"50%"`).
         */
        this.height = 'auto';
        /**
         * Specifies the width of the component container, accepts any valid CSS width value (e.g., `"100px"`, `"50%"`).
         */
        this.width = 'auto';
        /**
         * URL or identifier for an audio file associated with the text component.
         */
        this.audio = '';
        /**
         * Defines the x-coordinate position (left offset) of the component container, using any valid CSS `left` value (e.g., `"10px"`, `"5%"`).
         */
        this.x = '0px';
        /**
         * Defines the y-coordinate position (top offset) of the component container, using any valid CSS `top` value (e.g., `"10px"`, `"5%"`).
         */
        this.y = '0px';
        /**
         * Sets the z-index of the component, controlling its stacking order on the page.
         */
        this.z = '0';
        /**
         * Accessible label for screen readers, providing a textual description of the component's purpose.
         */
        this.ariaLabel = '';
        /**
         * Controls visibility for assistive technologies. If `"true"`, the component is hidden from screen readers.
         */
        this.ariaHidden = '';
        /**
         * Sets the tab order of the component within the page, enabling keyboard navigation.
         */
        this.tabIndex = 0;
        /**
         * Mode for the tracing interaction, defining how users interact with the SVG paths.
         * Options may include `"noFlow"`, `"showFlow"`, `"freeTrace"`, `"blindTracing"`, and `"blindFreeTrace"`
         */
        this.mode = TraceMode.ShowFlow;
        /**
         * URL for the finger hint image
         */
        this.fingerHintUrl = getAssetPath('assets/Tracing-hand.svg');
        /**
         * Indicates whether to highlight the text associated with the SVG when the trace is completed.
         */
        this.highlightTextId = '';
        /**
         * Indicates whether to play an animation trace when the SVG is completed.
         */
        this.animationTrace = false;
        /**
         * Delay in milliseconds to make the cell visible after mount.
         */
        this.delayVisible = '';
        /**
         * When set to true, disables the speak functionality of long press for this component and its children.
         */
        this.disableSpeak = false;
        this.style = {};
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
        this.fileIndex = -1;
        this.isDragging = false;
        this.activePointerId = null;
        this.activeTraceState = null;
        // Counter for throttling free trace updates
        // This is only an internal counter. Keeping it out of @State prevents a
        // Stencil component re-render while the user is dragging.
        this.freeTraceUpdateCounter = 0;
        /** ───────────────────────────────────────────────────────────
         *  NEW: idle‑timer + finger‑hint state
         *  ─────────────────────────────────────────────────────────── */
        this.idleTimer = null;
        this.fingerImg = null;
    }
    // MODES = ['noFlow', 'showFlow', 'freeTrace', 'blindTracing', 'blindFreeTrace'];
    // Handle the pointermove event with optimizations
    // Update the path trace as the red circle moves
    async initializeSVG() {
        this.cleanupTraceState(this.activeTraceState);
        let state = {
            fileIndex: -1,
            currentPathIndex: 0,
            lastLength: 0,
            totalPathLength: 0,
            isDragging: false,
            circle: null,
            paths: [],
            svg: null,
            proximityThreshold: 60, // Increased general proximity threshold (was 100)
            freeTraceProximityThreshold: 350, // Increased proximity for free trace (was 50)
            rafId: null,
            pointerMoveEvent: null,
            activePointerId: null,
            mode: this.mode,
            flowMarkers: [],
            freeTraceLines: [],
            currentFreePath: [],
            lastPointerPos: null,
            dragOffset: null,
            isCompletingPath: false,
            touchProximityThreshold: null,
            pointerTransform: null,
            pointerRect: null,
        };
        this.activeTraceState = state;
        const url = this.svgUrls[this.currentSvgIndex];
        if (!url || url.trim() === '') {
            console.error('No SVG URL provided or index out of bounds.');
            return;
        }
        await this.fetchSVG(convertUrlToRelative(url));
        await this.loadAnotherSVG(state, true); // Load the first SVG
    }
    componentDidLoad() {
        setVisibilityWithDelay(this.el, this.delayVisible);
    }
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize);
        window.addEventListener('load', this.handleWindowLoad);
        this.svgUrls = this.svgSource.split(';').map(s => s.trim());
        this.currentSvgIndex = 0;
        if (this.showSpeakIcon) {
            speakIcon(this.el);
            this.el.append(speakIcon(this.el));
        }
        this.initializeSVG();
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
        this.cleanupTraceState(this.activeTraceState);
        this.activeTraceState = null;
    }
    /** Release listeners, pending frames, timers, and cached SVG geometry. */
    cleanupTraceState(state) {
        var _a;
        if (!state)
            return;
        (_a = state.cleanup) === null || _a === void 0 ? void 0 : _a.call(state);
        if (state.rafId)
            cancelAnimationFrame(state.rafId);
        state.rafId = null;
        state.pointerMoveEvent = null;
        state.pathSamples = [];
        state.paths = [];
        state.svg = null;
        if (this.idleTimer !== null) {
            clearTimeout(this.idleTimer);
            this.idleTimer = null;
        }
        this.hideFingerHint();
    }
    /** ───────────────────────────────────────────────────────────
     *  Idle‑timer helpers
     *  ─────────────────────────────────────────────────────────── */
    resetIdleTimer(state) {
        if (this.idleTimer !== null) {
            clearTimeout(this.idleTimer);
            this.idleTimer = null;
        }
        this.idleTimer = window.setTimeout(() => {
            this.showFingerHint(state);
        }, 3000);
    }
    showFingerHint(state) {
        var _a;
        if (this.fingerImg)
            return; // already showing
        const currentPath = state.paths[state.currentPathIndex];
        if (!currentPath)
            return;
        /**  FIX: centre the image on the path (was offset down‑right)  **/
        const IMG_SIZE = 40; // width & height of finger.png
        const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
        const testImage = new Image();
        testImage.onload = () => {
            img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', convertUrlToRelative(this.fingerHintUrl));
        };
        testImage.onerror = () => {
            img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', convertUrlToRelative(fingerUrl));
        };
        testImage.src = convertUrlToRelative(this.fingerHintUrl || fingerUrl);
        img.setAttribute('width', `${IMG_SIZE}`);
        img.setAttribute('height', `${IMG_SIZE}`);
        img.setAttribute('id', 'lido-finger-hint');
        img.style.pointerEvents = 'none';
        img.style.opacity = '0.8';
        // place the image so its centre aligns with the path’s start point
        // const start = currentPath.getPointAtLength(0);
        img.setAttribute('x', '0');
        img.setAttribute('y', '0');
        // animateMotion
        const motion = document.createElementNS('http://www.w3.org/2000/svg', 'animateMotion');
        motion.setAttribute('dur', '2s');
        motion.setAttribute('repeatCount', 'indefinite');
        const mpath = document.createElementNS('http://www.w3.org/2000/svg', 'mpath');
        mpath.setAttributeNS('http://www.w3.org/1999/xlink', 'href', `#${currentPath.id}`);
        motion.appendChild(mpath);
        img.appendChild(motion);
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(img);
        this.fingerImg = img;
    }
    hideFingerHint() {
        if (this.fingerImg && this.fingerImg.parentNode) {
            this.fingerImg.parentNode.removeChild(this.fingerImg);
        }
        this.fingerImg = null;
    }
    // Fetch the SVG file asynchronously
    async fetchSVG(url) {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch SVG (${url}): ${response.statusText}`);
        }
        return await response.text();
    }
    // to calculate the bounding box of all paths
    calculateBoundingBox(paths, padding = 22) {
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        paths.forEach(path => {
            const length = path.getTotalLength();
            const numPoints = 100; // Number of points to sample along the path
            for (let i = 0; i <= numPoints; i++) {
                const point = path.getPointAtLength((i / numPoints) * length);
                if (point.x < minX)
                    minX = point.x;
                if (point.y < minY)
                    minY = point.y;
                if (point.x > maxX)
                    maxX = point.x;
                if (point.y > maxY)
                    maxY = point.y;
            }
        });
        // Apply padding
        minX -= padding;
        minY -= padding;
        maxX += padding;
        maxY += padding;
        return { minX, minY, maxX, maxY };
    }
    // Insert the fetched SVG into the container and adjust viewBox
    insertSVG(svgText) {
        const svgContainer = document.getElementById('lido-svgContainer');
        if (!svgContainer)
            return;
        svgContainer.innerHTML = svgText;
        // After inserting, get the SVG element
        const svgElement = svgContainer.querySelector('svg');
        svgElement.classList.add('lido-trace-svg');
        // Remove the width and height attributes from the SVG element
        svgElement.removeAttribute('width');
        svgElement.removeAttribute('height');
        // Get all paths
        const paths = svgElement.querySelectorAll('path, line');
        // Calculate bounding box
        const bbox = this.calculateBoundingBox(Array.from(paths));
        // Set the viewBox to the bounding box
        const viewBoxWidth = bbox.maxX - bbox.minX;
        const viewBoxHeight = bbox.maxY - bbox.minY;
        svgElement.setAttribute('viewBox', `${bbox.minX} ${bbox.minY} ${viewBoxWidth} ${viewBoxHeight}`);
    }
    // Retrieve the SVG element from the container
    getSVGElement() {
        const svgContainer = document.getElementById('lido-svgContainer');
        return svgContainer.querySelector('svg');
    }
    // Get all path and line elements from the SVG
    getPaths(svg) {
        return Array.from(svg.querySelectorAll('path, line'));
    }
    // Create a single dotted line with an arrow at the end for the entire path
    createFlowMarkersForPath(path) {
        var _a;
        if (!path)
            return;
        const svg = path.ownerSVGElement;
        if (!svg)
            return;
        // --- 1. Create the dotted line that follows the same path ---
        // Create a new <path> element that will visually represent the flow (dotted line)
        const dottedLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        // Copy the "d" (path drawing instructions) from the original path
        dottedLine.setAttribute('d', path.getAttribute('d') || '');
        dottedLine.setAttribute('stroke', 'blue');
        dottedLine.setAttribute('stroke-width', '2');
        // Define a repeating pattern of dashes: "6 units on, 6 units off"
        dottedLine.setAttribute('stroke-dasharray', '6,6');
        dottedLine.setAttribute('fill', 'none');
        // Add a class name for styling or later querying
        dottedLine.setAttribute('class', 'lido-flow-indicator');
        (_a = path.parentNode) === null || _a === void 0 ? void 0 : _a.appendChild(dottedLine);
        // --- 2. Ensure we only add <defs> + marker once per SVG ---
        // Look for an existing <defs> section with our custom ID inside the SVG
        let defs = svg.querySelector('defs#lido-flow-defs');
        // If it doesn’t exist, create one and insert it at the top of the SVG
        if (!defs) {
            defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
            defs.setAttribute('id', 'lido-flow-defs');
            svg.insertBefore(defs, svg.firstChild); // defs should usually be at the beginning
        }
        // --- 3. Create a unique marker for this path ---
        const uniqueId = `arrow-${Math.random().toString(36)}`;
        // Create the <marker> element that defines the arrowhead
        const marker = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        marker.setAttribute('id', uniqueId);
        // Set the width/height of the marker viewport (10x10 units)
        marker.setAttribute('markerWidth', '10');
        marker.setAttribute('markerHeight', '10');
        // Reference point inside the marker (where the path will attach to arrow)
        marker.setAttribute('refX', '5');
        marker.setAttribute('refY', '5');
        // Automatically rotate arrowhead to match the path direction
        marker.setAttribute('orient', 'auto');
        // Scale the marker relative to the stroke width of the path
        marker.setAttribute('markerUnits', 'strokeWidth');
        // --- Create the arrow shape itself ---
        const arrowPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        // Define the arrowhead shape using SVG path commands
        arrowPath.setAttribute('d', 'M0,0 L10,5 L0,10 L2,5 Z');
        arrowPath.setAttribute('fill', 'blue');
        marker.appendChild(arrowPath);
        defs.appendChild(marker);
        // --- 4. Attach the arrow marker to the end of the dotted line  ---
        dottedLine.setAttribute('marker-end', `url(#${uniqueId})`);
        return dottedLine;
    }
    // Show or hide flow indicators based on mode
    updateFlowIndicators(state) {
        const indicators = state.svg.querySelectorAll('.lido-flow-indicator');
        indicators.forEach(indicator => {
            if (state.mode === TraceMode.NoFlow) {
                indicator.style.display = 'none';
            }
            else if (state.mode === TraceMode.ShowFlow) {
                indicator.style.display = 'block';
            }
        });
    }
    // Create a new path element for the drawing effect
    setupDrawingPath(state) {
        state.paths.forEach((path, index) => {
            const pathLength = path.getTotalLength();
            // Geometry calls are expensive on slower SVG implementations. Cache
            // the length once and reuse it during pointer movement.
            path._lidoTraceLength = pathLength;
            path._lidoTraceStart = path.getPointAtLength(0);
            path._lidoTraceEnd = path.getPointAtLength(pathLength);
            path._lidoTraceIsClosed = this.getDistanceSquared(path._lidoTraceStart, path._lidoTraceEnd) < 200;
            // Index the path once. Repeated getPointAtLength calls are expensive on
            // low-end SVG implementations and used to dominate every pointer frame.
            const sampleCount = 192;
            const sampleStep = pathLength / sampleCount || 1;
            const samples = [];
            for (let sampleIndex = 0; sampleIndex <= sampleCount; sampleIndex++) {
                const length = Math.min(pathLength, sampleIndex * sampleStep);
                const point = path.getPointAtLength(length);
                samples.push({ x: point.x, y: point.y, length });
            }
            path._lidoTraceSamples = samples;
            path._lidoTraceSampleStep = sampleStep;
            // /** give every path an id so <mpath> can follow it */
            path.setAttribute('id', 'lido-path-' + index); //  ← NEW
            // Create green path for tracing effect
            const greenPath = path.cloneNode();
            greenPath.style.opacity = '100';
            greenPath.style['stroke-opacity'] = '100';
            // greenPath.setAttribute('stroke', 'green');
            const strokeWidth = path.style['stroke-width'] || path.getAttribute('stroke-width');
            greenPath.setAttribute('stroke-width', strokeWidth);
            greenPath.setAttribute('stroke-dasharray', pathLength.toString());
            greenPath.setAttribute('stroke-dashoffset', pathLength.toString()); // Hidden initially
            path.parentNode.appendChild(greenPath, path);
            path.setAttribute('class', 'lido-trace-path'); // Add class for easier reference
            greenPath.setAttribute('class', 'lido-trace-path-green'); // Add class for easier reference
            path.greenPath = greenPath;
            path.classList.add(state.mode);
            // Conditionally hide or show the black path based on blind tracing mode
            if (state.mode === TraceMode.BlindTracing || state.mode === TraceMode.BlindFreeTrace) {
                // In blind tracing or blind free trace mode, hide the black path
                path.setAttribute('stroke', 'none');
            }
            else {
                // In other modes, show the black path
                path.setAttribute('stroke', '#000');
                path.setAttribute('stroke-width', strokeWidth);
                path.setAttribute('fill', 'none');
                path.setAttribute('stroke-dasharray', pathLength.toString());
                path.setAttribute('stroke-dashoffset', '0'); // Fully visible initially
            }
            // Only create flow markers for the current path in normal modes
            if (index === state.currentPathIndex && state.mode === TraceMode.ShowFlow) {
                state.flowMarkers = this.createFlowMarkersForPath(path);
            }
        });
        state.totalPathLength = state.paths[state.currentPathIndex]._lidoTraceLength;
    }
    // Set up the draggable circle at the start of the first path
    setupDraggableCircle(state) {
        var _a;
        const firstPathStart = state.paths[0].getPointAtLength(0);
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        state.paths[state.currentPathIndex].style['stroke-width'] || state.paths[state.currentPathIndex].getAttribute('stroke-width');
        circle.setAttribute('id', 'lido-draggableCircle');
        circle.setAttribute('cx', firstPathStart.x.toString());
        circle.setAttribute('cy', firstPathStart.y.toString());
        circle.setAttribute('r', `20`); // Radius of the draggable circle
        circle.setAttribute('fill', '#CF1565'); // fill the color for the circle
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(circle);
        state.circle = circle;
        this.resetIdleTimer(state); // ← start idle timer once the SVG is ready
    }
    // Add necessary event listeners using Pointer Events
    addEventListeners(state) {
        var _a, _b, _c, _d;
        // Ensure the circle exists before adding events
        if (!state.circle || !state.paths || state.paths.length === 0)
            return;
        state.svg.style.touchAction = 'none';
        state.circle.style.touchAction = 'none';
        // Keep named handlers so the detached SVG can be fully released when the
        // next trace starts. Anonymous handlers here previously retained every
        // completed trace for the lifetime of the page.
        const onPointerDown = (evt) => {
            evt.preventDefault(); // Prevent default actions like text selection
            state.pointerRect = state.svg.getBoundingClientRect();
            state.pointerTransform = this.getSvgViewBoxTransform(state.svg, state.pointerRect);
            const pointerPos = this.getPointerPosition(evt, state.svg, state.pointerTransform, state.pointerRect);
            const circlePos = {
                x: parseFloat(state.circle.getAttribute('cx')),
                y: parseFloat(state.circle.getAttribute('cy')),
            };
            const distance = this.getDistanceSquared(pointerPos, circlePos);
            const startThreshold = this.getProximityThresholdForEvent(state, evt);
            const isWithinStartThreshold = distance <= startThreshold * startThreshold;
            if (isWithinStartThreshold || evt.pointerType === 'touch') {
                state.isDragging = true;
                state.activePointerId = evt.pointerId;
                state.dragOffset = {
                    x: pointerPos.x - circlePos.x,
                    y: pointerPos.y - circlePos.y,
                };
                try {
                    state.circle.setPointerCapture(evt.pointerId);
                }
                catch (_a) {
                    // iOS/Safari can be fussy with pointer capture on SVG nodes.
                }
                state.lastPointerPos = circlePos;
            }
            this.hideFingerHint(); // ← NEW
            this.resetIdleTimer(state); // ← NEW
        };
        // Handle pointermove on the SVG to update the circle position
        const onPointerMove = (evt) => {
            if (!state.isDragging || evt.pointerId !== state.activePointerId)
                return;
            evt.preventDefault();
            state.pointerMoveEvent = evt;
            if (!state.rafId) {
                state.rafId = requestAnimationFrame(() => {
                    this.handlePointerMove(state);
                    state.rafId = null;
                });
            }
        };
        // Handle pointerup and pointercancel on the SVG to stop dragging
        const endDrag = (evt) => {
            if (evt.pointerId === state.activePointerId) {
                state.isDragging = false;
                state.activePointerId = null;
                state.lastPointerPos = null;
                state.dragOffset = null;
                this.hideFingerHint(); // ← NEW
                this.resetIdleTimer(state); // ← NEW
            }
        };
        (_a = state.svg) === null || _a === void 0 ? void 0 : _a.addEventListener('pointerup', endDrag);
        (_b = state.svg) === null || _b === void 0 ? void 0 : _b.addEventListener('pointercancel', endDrag);
        // Optional: Prevent context menu on long press
        const onContextMenu = (evt) => {
            evt.preventDefault();
        };
        state.circle.addEventListener('pointerdown', onPointerDown, { passive: false });
        (_c = state.svg) === null || _c === void 0 ? void 0 : _c.addEventListener('pointermove', onPointerMove);
        (_d = state.svg) === null || _d === void 0 ? void 0 : _d.addEventListener('contextmenu', onContextMenu);
        state.cleanup = () => {
            var _a, _b, _c, _d, _e;
            (_a = state.circle) === null || _a === void 0 ? void 0 : _a.removeEventListener('pointerdown', onPointerDown);
            (_b = state.svg) === null || _b === void 0 ? void 0 : _b.removeEventListener('pointermove', onPointerMove);
            (_c = state.svg) === null || _c === void 0 ? void 0 : _c.removeEventListener('pointerup', endDrag);
            (_d = state.svg) === null || _d === void 0 ? void 0 : _d.removeEventListener('pointercancel', endDrag);
            (_e = state.svg) === null || _e === void 0 ? void 0 : _e.removeEventListener('contextmenu', onContextMenu);
            state.isDragging = false;
            state.activePointerId = null;
        };
    }
    // Modified handlePointerMove function
    async handlePointerMove(state) {
        var _a, _b, _c, _d, _e;
        if (!state.isDragging)
            return;
        if (!state.circle || !state.paths || state.paths.length === 0)
            return;
        if (state.isCompletingPath)
            return;
        this.hideFingerHint(); // user is active, remove hint
        const evt = state.pointerMoveEvent;
        const rawPointerPos = this.getPointerPosition(evt, state.svg, state.pointerTransform, state.pointerRect);
        const pointerPos = state.dragOffset
            ? {
                x: rawPointerPos.x - state.dragOffset.x,
                y: rawPointerPos.y - state.dragOffset.y,
            }
            : rawPointerPos;
        const circlePos = {
            x: parseFloat(state.circle.getAttribute('cx')),
            y: parseFloat(state.circle.getAttribute('cy')),
        };
        // Only update if pointer moved a minimum distance (to reduce unnecessary updates)
        const MOVE_THRESHOLD = 1; // px
        let pointerMoveDistanceSquared = Infinity;
        if (state.lastPointerPos) {
            const dx = pointerPos.x - state.lastPointerPos.x;
            const dy = pointerPos.y - state.lastPointerPos.y;
            pointerMoveDistanceSquared = dx * dx + dy * dy;
            if (pointerMoveDistanceSquared < MOVE_THRESHOLD * MOVE_THRESHOLD) {
                return;
            }
        }
        const currentPath = state.paths[state.currentPathIndex];
        if (!currentPath) {
            console.error('No valid path found at the current index');
            return;
        }
        // Use a reduced proximity threshold for free trace mode
        const proximityThreshold = this.getProximityThresholdForEvent(state, evt);
        const proximitySquared = proximityThreshold * proximityThreshold;
        // Calculate the distance between the pointer and the draggable circle
        const distanceSquared = this.getDistanceSquared(pointerPos, circlePos);
        // If the pointer is outside the proximity threshold, do not proceed with drawing or moving
        if (distanceSquared > proximitySquared) {
            return; // Skip any further actions
        }
        const isFreeTraceMode = state.mode === TraceMode.FreeTrace || state.mode === TraceMode.BlindFreeTrace;
        const closestPoint = this.getClosestPointOnPath(currentPath, pointerPos, isFreeTraceMode ? undefined : state.lastLength);
        // Ensure drawing happens only within proximity threshold
        const distanceToPathSquared = this.getDistanceSquared(pointerPos, closestPoint);
        if (distanceToPathSquared > proximitySquared) {
            return; // Skip drawing if too far from the path
        }
        // For free trace mode and blind free trace mode, allow free drawing only if within the reduced proximity threshold
        if (isFreeTraceMode) {
            // Throttle: Only update every 2nd event (for reducing excessive dom updates)
            this.freeTraceUpdateCounter = (this.freeTraceUpdateCounter || 0) + 1;
            if (this.freeTraceUpdateCounter % 2 !== 0) {
                return;
            }
            // Initialize the currentFreePath array if it's not created
            if (!state.currentFreePath) {
                state.currentFreePath = [];
            }
            // Create a new polyline element if it's the first trace for the current path index
            if (!state.currentFreePath[state.currentPathIndex]) {
                const newPolyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
                const strokeWidth = state.paths[state.currentPathIndex].style['stroke-width'] || state.paths[state.currentPathIndex].getAttribute('stroke-width');
                newPolyline.setAttribute('stroke-width', strokeWidth);
                newPolyline.setAttribute('fill', 'none');
                newPolyline.setAttribute('stroke-linecap', 'round');
                newPolyline.setAttribute('stroke', 'lightgreen');
                newPolyline.setAttribute('points', `${pointerPos.x},${pointerPos.y}`);
                (_a = state.svg) === null || _a === void 0 ? void 0 : _a.appendChild(newPolyline);
                state.currentFreePath[state.currentPathIndex] = newPolyline;
                // Store points array for this polyline
                state.currentFreePolylinePoints = state.currentFreePolylinePoints || [];
                state.currentFreePolylinePoints[state.currentPathIndex] = [{ x: pointerPos.x, y: pointerPos.y }];
                // Reset lastPointerPos for the new path
                state.lastPointerPos = pointerPos;
                // Add a points counter to limit path growth
                state.freeTracePointsCount = 1;
            }
            // Limit the number of points in the free trace path for performance
            const MAX_FREE_TRACE_POINTS = 5;
            state.freeTracePointsCount = (state.freeTracePointsCount || 1) + 1;
            if (state.freeTracePointsCount > MAX_FREE_TRACE_POINTS) {
                // If limit reached, skip adding more points
                return;
            }
            // Add the new point to the polyline's points array
            state.currentFreePolylinePoints = state.currentFreePolylinePoints || [];
            let pointsArr = state.currentFreePolylinePoints[state.currentPathIndex] || [];
            pointsArr.push({ x: pointerPos.x, y: pointerPos.y });
            state.currentFreePolylinePoints[state.currentPathIndex] = pointsArr;
            // Update the polyline's points attribute
            const pointsStr = pointsArr.map(pt => `${pt.x},${pt.y}`).join(' ');
            state.currentFreePath[state.currentPathIndex].setAttribute('points', pointsStr);
            // Move the draggable circle with the freehand trace
            state.circle.setAttribute('cx', pointerPos.x.toString());
            state.circle.setAttribute('cy', pointerPos.y.toString());
            // Keep the original safety check without scanning every SVG child.
            if (state.circle.parentNode !== state.svg) {
                (_b = state.svg) === null || _b === void 0 ? void 0 : _b.appendChild(state.circle);
            }
            // Update the last pointer position
            state.lastPointerPos = pointerPos;
            // For polyline, estimate the end by number of points (not path length)
            if (pointsArr.length >= MAX_FREE_TRACE_POINTS) {
                this.moveToNextPath(state);
                state.currentFreePath[state.currentPathIndex] = null; // Reset free path for next path
                state.currentFreePolylinePoints[state.currentPathIndex] = [];
                state.freeTracePointsCount = 0;
            }
            // this.resetIdleTimer(state); // ← keep timer alive
            return; // Exit early since we're in free trace or blind free trace mode
        }
        // In normal modes, allow movement and drawing only within the general proximity threshold
        const BACKWARD_TOLERANCE = 20; // allow slight backward movement
        const MAX_FORWARD_JUMP = 80; // prevent jumping to wrong segment
        const RECOVERY_FORWARD_JUMP = Math.min(320, Math.max(160, state.totalPathLength * 0.45)); // recover on long strokes without skipping short paths
        const RECOVERY_END_BUFFER = Math.min(60, Math.max(24, state.totalPathLength * 0.12)); // don't let recovery auto-finish the last part
        const RECOVERY_POINTER_MOVE_THRESHOLD = 8; // only recover after a meaningful drag, not during slow tracing
        let guidedClosestPoint = closestPoint;
        let isValidProgress = guidedClosestPoint.length >= state.lastLength - BACKWARD_TOLERANCE &&
            guidedClosestPoint.length - state.lastLength <= MAX_FORWARD_JUMP;
        if (!isValidProgress) {
            const recoveryPoint = this.getClosestPointOnPath(currentPath, pointerPos);
            const recoveryDistanceSquared = this.getDistanceSquared(pointerPos, recoveryPoint);
            const canRecover = pointerMoveDistanceSquared >= RECOVERY_POINTER_MOVE_THRESHOLD * RECOVERY_POINTER_MOVE_THRESHOLD &&
                recoveryDistanceSquared <= proximitySquared &&
                recoveryPoint.length >= state.lastLength - BACKWARD_TOLERANCE &&
                recoveryPoint.length - state.lastLength <= RECOVERY_FORWARD_JUMP &&
                recoveryPoint.length < state.totalPathLength - RECOVERY_END_BUFFER;
            if (canRecover) {
                guidedClosestPoint = recoveryPoint;
                isValidProgress = true;
            }
        }
        if (state.isDragging && isValidProgress) {
            state.lastLength = Math.max(state.lastLength, guidedClosestPoint.length);
            state.lastPointerPos = pointerPos;
            // Only update the circle if it moved enough
            if (Math.abs(guidedClosestPoint.x - circlePos.x) > MOVE_THRESHOLD || Math.abs(guidedClosestPoint.y - circlePos.y) > MOVE_THRESHOLD) {
                state.circle.setAttribute('cx', guidedClosestPoint.x.toString());
                state.circle.setAttribute('cy', guidedClosestPoint.y.toString());
            }
            // Keep the original safety check without scanning every SVG child.
            if (state.circle.parentNode !== state.svg) {
                (_c = state.svg) === null || _c === void 0 ? void 0 : _c.appendChild(state.circle);
            }
            (_d = currentPath.greenPath) === null || _d === void 0 ? void 0 : _d.setAttribute('stroke-dashoffset', (state.totalPathLength - state.lastLength).toString());
            // Completion logic for closed paths: only allow completion if almost all points are traced
            const COMPLETION_THRESHOLD = 0.95; // 95% of the path must be traced
            let percentComplete = state.lastLength / state.totalPathLength;
            const pathIsClosed = (_e = currentPath._lidoTraceIsClosed) !== null && _e !== void 0 ? _e : false;
            if (pathIsClosed && state.totalPathLength > 50) {
                if (percentComplete >= COMPLETION_THRESHOLD) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    // Animate the draggable circle & green trace to the very end, then proceed
                    await this.animatePathToEnd(state, currentPath);
                    if (state.currentPathIndex < state.paths.length - 1) {
                        this.moveToNextPath(state);
                    }
                    else if (state.currentPathIndex === state.paths.length - 1) {
                        this.moveToNextContainer();
                    }
                }
            }
            else {
                // For open paths, allow completion if near the end
                if (state.totalPathLength - 1 - state.lastLength < 5 && state.currentPathIndex < state.paths.length - 1) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    this.moveToNextPath(state);
                }
                else if (state.totalPathLength - 1 - state.lastLength < 5 && state.currentPathIndex === state.paths.length - 1) {
                    if (state.isCompletingPath)
                        return;
                    state.isCompletingPath = true;
                    this.moveToNextContainer();
                }
            }
        }
        // this.resetIdleTimer(state); // ← keep timer alive
    }
    // Smoothly animate the draggable circle + green stroke from current lastLength to totalPathLength
    animatePathToEnd(state, path, duration = 300) {
        if (!path || !state.svg)
            return Promise.resolve();
        if (state._animatingToEnd)
            return Promise.resolve();
        state._animatingToEnd = true;
        const start = state.lastLength || 0;
        const end = path.getTotalLength();
        const startTime = performance.now();
        // get greenPath safely: prefer the attached property, otherwise query by class near the original path
        const greenPath = path.greenPath ||
            (path.parentNode && path.parentNode.querySelector('.lido-trace-path-green'));
        return new Promise(resolve => {
            const step = (now) => {
                const t = Math.min(1, (now - startTime) / duration);
                const eased = t; // linear easing
                const currentLen = start + (end - start) * eased;
                state.lastLength = currentLen;
                // update circle position and green path dashoffset
                const pt = path.getPointAtLength(currentLen);
                if (state.circle) {
                    state.circle.setAttribute('cx', pt.x.toString());
                    state.circle.setAttribute('cy', pt.y.toString());
                }
                if (greenPath) {
                    greenPath.setAttribute('stroke-dashoffset', (state.totalPathLength - currentLen).toString());
                }
                if (t < 1) {
                    requestAnimationFrame(step);
                }
                else {
                    // ensure fully complete
                    state.lastLength = end;
                    if (state.circle) {
                        const finalPt = path.getPointAtLength(end);
                        state.circle.setAttribute('cx', finalPt.x.toString());
                        state.circle.setAttribute('cy', finalPt.y.toString());
                    }
                    if (greenPath) {
                        greenPath.setAttribute('stroke-dashoffset', '0');
                    }
                    state._animatingToEnd = false;
                    resolve();
                }
            };
            requestAnimationFrame(step);
        });
    }
    // Move to the next container after completing the current SVG
    async moveToNextContainer() {
        this.isDragging = false;
        if (this.moving)
            return; // Prevent multiple calls
        this.moving = true; // Set moving to true to prevent re-entrance
        if (this.highlightTextId) {
            this.highlightLetter(this.currentSvgIndex);
        }
        if (this.animationTrace) {
            await this.playTraceAnimation();
        }
        storingEachActivityScore(true);
        const delay = 1000; // milliseconds
        if (this.currentSvgIndex < this.svgUrls.length - 1) {
            await new Promise(resolve => setTimeout(resolve, delay));
            this.currentSvgIndex++;
            await this.initializeSVG();
            const svgContainer = document.getElementById('lido-svgContainer');
            svgContainer.style.visibility = 'visible';
            this.moving = false;
            if (this.el && this.onCorrect) {
                await executeActions(this.onCorrect, this.el);
            }
            return;
        }
        const container = document.querySelector(LidoContainer$1);
        const containerOnCorrect = container.getAttribute("onCorrect");
        if (container && containerOnCorrect) {
            await new Promise(resolve => setTimeout(resolve, delay));
            await executeActions(containerOnCorrect, this.el);
        }
        calculateScore();
        triggerNextContainer();
    }
    // Get the pointer position relative to the SVG
    getPointerPosition(evt, svg, cachedTransform, cachedRect) {
        var _a;
        const viewBoxPoint = this.getPointerPositionFromViewBox(evt, svg, cachedTransform, cachedRect);
        if (viewBoxPoint)
            return viewBoxPoint;
        const svgPoint = svg.createSVGPoint();
        svgPoint.x = evt.clientX;
        svgPoint.y = evt.clientY;
        const ctm = (_a = svg.getScreenCTM()) === null || _a === void 0 ? void 0 : _a.inverse();
        return ctm ? svgPoint.matrixTransform(ctm) : { x: evt.clientX, y: evt.clientY };
    }
    getPointerPositionFromViewBox(evt, svg, cachedTransform, cachedRect) {
        const rect = cachedRect || svg.getBoundingClientRect();
        const viewBox = svg.viewBox.baseVal;
        if (!rect.width || !rect.height || !viewBox.width || !viewBox.height) {
            return null;
        }
        const { offsetX, offsetY, scaleX, scaleY } = cachedTransform || this.getSvgViewBoxTransform(svg, rect);
        return {
            x: viewBox.x + (evt.clientX - rect.left - offsetX) / scaleX,
            y: viewBox.y + (evt.clientY - rect.top - offsetY) / scaleY,
        };
    }
    getSvgViewBoxTransform(svg, rect = svg.getBoundingClientRect()) {
        const viewBox = svg.viewBox.baseVal;
        const preserveAspectRatio = svg.preserveAspectRatio.baseVal;
        const scaleX = rect.width / viewBox.width;
        const scaleY = rect.height / viewBox.height;
        const SVG_PRESERVEASPECTRATIO_NONE = 1;
        const SVG_MEETORSLICE_SLICE = 2;
        if (preserveAspectRatio.align === SVG_PRESERVEASPECTRATIO_NONE) {
            return { offsetX: 0, offsetY: 0, scaleX, scaleY };
        }
        const scale = preserveAspectRatio.meetOrSlice === SVG_MEETORSLICE_SLICE ? Math.max(scaleX, scaleY) : Math.min(scaleX, scaleY);
        const renderedWidth = viewBox.width * scale;
        const renderedHeight = viewBox.height * scale;
        let offsetX = 0;
        let offsetY = 0;
        const align = preserveAspectRatio.align;
        if (align === 3 || align === 6 || align === 9) {
            offsetX = (rect.width - renderedWidth) / 2;
        }
        else if (align === 4 || align === 7 || align === 10) {
            offsetX = rect.width - renderedWidth;
        }
        if (align === 5 || align === 6 || align === 7) {
            offsetY = (rect.height - renderedHeight) / 2;
        }
        else if (align === 8 || align === 9 || align === 10) {
            offsetY = rect.height - renderedHeight;
        }
        return { offsetX, offsetY, scaleX: scale, scaleY: scale };
    }
    getProximityThresholdForEvent(state, evt) {
        const baseThreshold = state.mode === TraceMode.FreeTrace || state.mode === TraceMode.BlindFreeTrace ? state.freeTraceProximityThreshold : state.proximityThreshold;
        if ((evt === null || evt === void 0 ? void 0 : evt.pointerType) !== 'touch' || !state.svg) {
            return baseThreshold;
        }
        const rect = state.svg.getBoundingClientRect();
        const viewBox = state.svg.viewBox.baseVal;
        if (!rect.width || !rect.height || !viewBox.width || !viewBox.height) {
            return baseThreshold;
        }
        const { scaleX, scaleY } = this.getSvgViewBoxTransform(state.svg, rect);
        const touchTargetInSvgUnits = 44 * Math.max(1 / scaleX, 1 / scaleY);
        return Math.max(baseThreshold, touchTargetInSvgUnits);
    }
    // Calculate the squared Euclidean distance between two points
    getDistanceSquared(p1, p2) {
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        return dx * dx + dy * dy;
    }
    // Find the closest point on the given path to the specified point using two-pass sampling (optimized)
    getClosestPointOnPath(pathNode, point, lastLength) {
        var _a;
        const pathLength = (_a = pathNode._lidoTraceLength) !== null && _a !== void 0 ? _a : pathNode.getTotalLength();
        const samples = pathNode._lidoTraceSamples;
        const sampleStep = pathNode._lidoTraceSampleStep;
        if ((samples === null || samples === void 0 ? void 0 : samples.length) && sampleStep) {
            const searchWindow = lastLength === undefined ? pathLength : 150;
            const searchStart = lastLength === undefined ? 0 : Math.max(0, lastLength - searchWindow);
            const searchEnd = lastLength === undefined ? pathLength : Math.min(pathLength, lastLength + searchWindow);
            let nearest = samples[Math.max(0, Math.min(samples.length - 1, Math.round((lastLength || 0) / sampleStep)))];
            let nearestDistance = Infinity;
            for (const sample of samples) {
                if (sample.length < searchStart || sample.length > searchEnd)
                    continue;
                const distance = this.getDistanceSquared(point, sample);
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearest = sample;
                }
            }
            // Refine only around the cached winner. This keeps the path accurate
            // while reducing hot-path geometry calls from roughly 50 to a handful.
            const refinementStep = 6;
            const refineStart = Math.max(searchStart, nearest.length - sampleStep);
            const refineEnd = Math.min(searchEnd, nearest.length + sampleStep);
            let closestPoint = Object.assign({}, nearest);
            let minDistanceSquared = nearestDistance;
            for (let length = refineStart; length <= refineEnd; length += refinementStep) {
                const candidate = pathNode.getPointAtLength(length);
                const distance = this.getDistanceSquared(point, candidate);
                if (distance < minDistanceSquared) {
                    minDistanceSquared = distance;
                    closestPoint = { x: candidate.x, y: candidate.y, length };
                }
            }
            return closestPoint;
        }
        let closestPoint = { x: 0, y: 0, length: 0 };
        let minDistanceSquared = Infinity;
        const coarseStep = 40;
        const fineStep = 6;
        //  dynamic search window (prevents jump)
        const SEARCH_WINDOW = 150;
        let searchStart = 0;
        let searchEnd = pathLength;
        // If lastLength exists → restrict search (smooth tracing)
        if (lastLength !== undefined) {
            searchStart = Math.max(0, lastLength - SEARCH_WINDOW);
            searchEnd = Math.min(pathLength, lastLength + SEARCH_WINDOW);
        }
        let coarseClosest = { length: searchStart };
        for (let i = searchStart; i <= searchEnd; i += coarseStep) {
            const pt = pathNode.getPointAtLength(i);
            const dist = this.getDistanceSquared(point, pt);
            if (dist < minDistanceSquared) {
                minDistanceSquared = dist;
                coarseClosest = { x: pt.x, y: pt.y, length: i };
            }
        }
        const fineStart = Math.max(0, coarseClosest.length - coarseStep);
        const fineEnd = Math.min(pathLength, coarseClosest.length + coarseStep);
        minDistanceSquared = Infinity;
        for (let i = fineStart; i <= fineEnd; i += fineStep) {
            const pt = pathNode.getPointAtLength(i);
            const dist = this.getDistanceSquared(point, pt);
            if (dist < minDistanceSquared) {
                minDistanceSquared = dist;
                closestPoint = { x: pt.x, y: pt.y, length: i };
            }
        }
        return closestPoint;
    }
    // Load the next or previous SVG based on the isNext flag
    async loadAnotherSVG(state, isNext) {
        state.isDragging = false;
        try {
            if (state.svg) {
                this.cleanupPreviousSVG(state);
            }
            const svgText = await this.fetchSVG(convertUrlToRelative(this.svgSource.split(';').map(s => s.trim())[this.currentSvgIndex]));
            this.insertSVG(svgText);
            state.svg = this.getSVGElement();
            if (this.mode === TraceMode.BlindTracing || this.mode === TraceMode.BlindFreeTrace) {
                //make image in the svg style as display none
                state.svg.querySelectorAll('image').forEach(img => {
                    img.style.display = 'none';
                });
            }
            state.paths = this.getPaths(state.svg);
            this.setupDrawingPath(state);
            this.setupDraggableCircle(state);
            this.addEventListeners(state);
        }
        catch (error) {
            console.error(`Error loading SVG (${this.svgSource}):`, error);
        }
    }
    // Cleanup previous SVG's elements and state
    cleanupPreviousSVG(state) {
        var _a, _b;
        if (state.circle) {
            (_a = state.svg) === null || _a === void 0 ? void 0 : _a.removeChild(state.circle);
            state.circle = null;
        }
        const indicators = (_b = state.svg) === null || _b === void 0 ? void 0 : _b.querySelectorAll('.lido-flow-indicator');
        indicators.forEach(indicator => {
            indicator.remove(); // Remove all previous flow indicators
        });
        state.currentPathIndex = 0;
        state.lastLength = 0;
        state.totalPathLength = state.paths[0].getTotalLength();
        this.hideFingerHint();
        this.resetIdleTimer(state);
    }
    // Move to the next path in the SVG
    async moveToNextPath(state) {
        var _a, _b;
        state.isDragging = false;
        state.currentPathIndex++;
        state.lastLength = 0;
        state.isCompletingPath = false;
        this.hideFingerHint(); // remove hint when changing path
        if (state.currentPathIndex >= state.paths.length) {
            this.moveToNextContainer();
            return;
        }
        const nextPath = state.paths[state.currentPathIndex];
        if (!nextPath) {
            console.error('No valid path found at the next index');
            return;
        }
        state.totalPathLength = nextPath.getTotalLength();
        const startPoint = nextPath.getPointAtLength(0);
        (_a = state.circle) === null || _a === void 0 ? void 0 : _a.setAttribute('cx', startPoint.x.toString());
        (_b = state.circle) === null || _b === void 0 ? void 0 : _b.setAttribute('cy', startPoint.y.toString());
        if (state.mode === TraceMode.ShowFlow) {
            state.flowMarkers = this.createFlowMarkersForPath(nextPath);
        }
        this.resetIdleTimer(state);
    }
    async playTraceAnimation() {
        const el = document.getElementById(this.id);
        if (!el)
            return;
        el.classList.add('trace-animate');
        // Wait for the animation to finish (500ms)
        await new Promise(resolve => setTimeout(resolve, 500));
        el.classList.remove('trace-animate');
    }
    async highlightLetter(index) {
        const container = document.getElementById(LidoContainer$1);
        if (!container)
            return;
        const traceElement = this.el;
        if (!traceElement)
            return;
        // Ensure highlightTextId is set
        const textId = this.highlightTextId;
        if (!textId)
            return;
        // Find the lido-text element by id
        const textElem = document.getElementById(textId);
        if (!textElem)
            return;
        // Extract audio URLs from the trace element's audio attribute
        const audioList = this.audio;
        if (!audioList)
            return;
        this.audioUrls = audioList.split(';').map(s => s.trim());
        // Check if the textElem has a span-type attribute
        const spanType = textElem.getAttribute('span-type');
        if (!spanType)
            return;
        // Find the .lido-text-content container inside lido-text
        const content = textElem.querySelector('.lido-text-content');
        if (!content)
            return;
        if (spanType === 'letters') {
            const letters = content.querySelectorAll('.text-letters');
            if (index < 0 || index >= letters.length)
                return;
            // Highlight the current letter keeping the previous ones highlighted
            const letter = letters[index];
            if (letter) {
                const svgContainer = traceElement.querySelector('#lido-svgContainer');
                await executeActions("this.alignMatch='true';", textElem, svgContainer);
                svgContainer.style.animation = 'trace-animation 0.4s forwards';
                svgContainer.style.setProperty('--trace-width', `${letter.offsetWidth - 5}px`);
                svgContainer.style.setProperty('--trace-height', `${letter.offsetHeight - 5}px`);
                await executeActions("this.alignMatch='true';", letter, svgContainer);
                setTimeout(() => {
                    letter.classList.add('letter-highlight');
                    svgContainer.style.transform = '';
                    svgContainer.style.animation = '';
                    svgContainer.style.visibility = 'hidden';
                }, 500);
                if (this.audioUrls[this.currentSvgIndex]) {
                    const audio = new Audio(convertUrlToRelative(this.audioUrls[this.currentSvgIndex]));
                    await audio.play();
                }
            }
        }
        if (spanType === 'words') {
            const words = content.querySelectorAll('.text-words');
            if (index < 0 || index >= words.length)
                return;
            // Highlight the current word keeping the previous ones highlighted
            const word = words[index];
            if (word) {
                word.classList.add('word-highlight');
                if (this.audioUrls[this.currentSvgIndex]) {
                    const audio = new Audio(convertUrlToRelative(this.audioUrls[this.currentSvgIndex]));
                    await audio.play();
                }
            }
        }
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            // position: 'absolute',
        };
    }
    render() {
        return (h(Host, { key: '07506adee10b4f0348ba7b7c4d0f338d7e61cfd9', class: "lido-trace", id: this.id, audio: this.audio, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, tabindex: this.tabIndex, "disable-speak": this.disableSpeak }, h("div", { key: '9b3c311582a7246cded868234a47293ae78a3932', style: this.style, id: "lido-svgContainer" })));
    }
    static get assetsDirs() { return ["assets"]; }
    get el() { return getElement(this); }
    static get watchers() { return {
        "svgSource": [{
                "initializeSVG": 0
            }],
        "mode": [{
                "initializeSVG": 0
            }]
    }; }
};
LidoTrace.style = lidoTraceCss();

const lidoWrapCss = () => `.lido-wrap{display:grid;grid-gap:10px;grid-template-columns:repeat(auto-fill, minmax(186px, auto))}.lido-wrap>*{padding:10px;background-color:var(--child-bg-color, #f0f0f0);box-sizing:border-box}.lido-flex{display:flex;flex-wrap:wrap;align-content:flex-start;gap:10px}`;

const LidoWrap = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        /**
         * Controls whether the speak icon should appear directly on the top right corner of targeted element.
         */
        this.showSpeakIcon = false;
        /**
         * The minimum number of drag elements that must be dropped inside the Drop element.
         */
        this.minDrops = 1;
        /**
         * The Maximum number of drag elements that can be dropped inside the Drop element.
         */
        this.maxDrops = 1;
        /**
         * CSS margin value applied to each child element inside the container.
         * Accepts standard CSS margin formats (e.g., '10px', '5px 10px', etc.).
         */
        this.margin = '';
        /**
          * When set to true, disables the speak functionality of long press for this component and its children.
          */
        this.disableSpeak = false;
        this.handleWindowResize = () => this.updateStyles();
        this.handleWindowLoad = () => this.updateStyles();
    }
    /**
     * Lifecycle hook that runs after the component is rendered in the DOM.
     * It initializes custom events based on the `type` of the wrap container.
     */
    componentDidLoad() {
        initEventsForElement(this.el, this.type);
        handlingChildElements(this.el, this.minLength, this.maxLength, this.childElementsLength);
        if (this.flex === 'true') {
            this.el.classList.remove('lido-wrap');
            this.el.classList.add('lido-flex');
        }
        if (this.showSpeakIcon) {
            attachSpeakIcon(this.el);
        }
    }
    /**
     * Lifecycle method that runs before the component is rendered.
     * Initializes styles and sets up event listeners for resize and load events.
     */
    componentWillLoad() {
        this.updateStyles();
        window.addEventListener('resize', this.handleWindowResize); // Update on screen rotation
        window.addEventListener('load', this.handleWindowLoad); // Update on screen rotation
    }
    disconnectedCallback() {
        window.removeEventListener('resize', this.handleWindowResize);
        window.removeEventListener('load', this.handleWindowLoad);
    }
    updateStyles() {
        const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
        this.style = {
            height: parseProp(this.height, orientation),
            width: parseProp(this.width, orientation),
            backgroundColor: parseProp(this.bgColor, orientation),
            top: parseProp(this.y, orientation),
            left: parseProp(this.x, orientation),
            zIndex: this.z,
            display: JSON.parse(parseProp(`${this.visible}`, orientation)) ? (this.flex === 'true' ? 'flex' : 'grid') : 'none', // Toggle visibility
            margin: parseProp(this.margin, orientation),
        };
    }
    render() {
        return (h(Host, { key: '8d8ea2a16213d6a54c947d2fa20dd094024d30d1', class: "lido-wrap", value: this.value, type: this.type, "tab-index": this.tabIndex, style: this.style, "aria-label": this.ariaLabel, "aria-hidden": this.ariaHidden, audio: this.audio, minDrops: this.minDrops, maxDrops: this.maxDrops, onTouch: this.onTouch, onCorrect: this.onCorrect, onInCorrect: this.onInCorrect, onEntry: this.onEntry, disableSpeak: this.disableSpeak }, h("slot", { key: 'f42ddae95ef36fe6e7a42d2ccfcb58bf09243b08' })));
    }
    get el() { return getElement(this); }
};
LidoWrap.style = lidoWrapCss();

export { LidoAvatar as lido_avatar, LidoBalance as lido_balance, LidoCalculator as lido_calculator, LidoCanvas as lido_canvas, LidoCell as lido_cell, LidoCol as lido_col, LidoContainer as lido_container, LidoFlash as lido_flash_card, LidoFloat as lido_float, LidoHome as lido_home, LidoImage as lido_image, LidoKeyboard as lido_keyboard, LidoMathMatrix as lido_math_matrix, LidoPos as lido_pos, LidoRandom as lido_random, LidoRoot as lido_root, LidoRow as lido_row, LidoShape as lido_shape, LidoSlideFill as lido_slide_fill, LidoText as lido_text, LidoTrace as lido_trace, LidoWrap as lido_wrap };
